/* Microsoft SQL Server - Scripting			*/
/* Server: DORAEMON					*/
/* Database: isonet4					*/
/* Creation Date 3/24/97 11:45:11 AM 			*/

/****** Object:  Stored Procedure dbo.sp_add_Curriculum    Script Date: 3/24/97 11:45:14 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.sp_add_Curriculum') and sysstat & 0xf = 4)
	drop procedure dbo.sp_add_Curriculum
GO

/****** Object:  Stored Procedure dbo.sp_add_Currisb    Script Date: 3/24/97 11:45:14 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.sp_add_Currisb') and sysstat & 0xf = 4)
	drop procedure dbo.sp_add_Currisb
GO

/****** Object:  Stored Procedure dbo.sp_add_class    Script Date: 3/24/97 11:45:15 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.sp_add_class') and sysstat & 0xf = 4)
	drop procedure dbo.sp_add_class
GO

/****** Object:  Stored Procedure dbo.sp_add_room    Script Date: 3/24/97 11:45:15 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.sp_add_room') and sysstat & 0xf = 4)
	drop procedure dbo.sp_add_room
GO

/****** Object:  Stored Procedure dbo.sp_delete_Curriculum    Script Date: 3/24/97 11:45:15 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.sp_delete_Curriculum') and sysstat & 0xf = 4)
	drop procedure dbo.sp_delete_Curriculum
GO

/****** Object:  Stored Procedure dbo.sp_delete_Currisb    Script Date: 3/24/97 11:45:15 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.sp_delete_Currisb') and sysstat & 0xf = 4)
	drop procedure dbo.sp_delete_Currisb
GO

/****** Object:  Stored Procedure dbo.sp_delete_class    Script Date: 3/24/97 11:45:15 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.sp_delete_class') and sysstat & 0xf = 4)
	drop procedure dbo.sp_delete_class
GO

/****** Object:  Stored Procedure dbo.sp_delete_room    Script Date: 3/24/97 11:45:15 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.sp_delete_room') and sysstat & 0xf = 4)
	drop procedure dbo.sp_delete_room
GO

/****** Object:  Stored Procedure dbo.sp_get_Curriculum    Script Date: 3/24/97 11:45:15 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.sp_get_Curriculum') and sysstat & 0xf = 4)
	drop procedure dbo.sp_get_Curriculum
GO

/****** Object:  Stored Procedure dbo.sp_get_Currisb    Script Date: 3/24/97 11:45:15 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.sp_get_Currisb') and sysstat & 0xf = 4)
	drop procedure dbo.sp_get_Currisb
GO

/****** Object:  Stored Procedure dbo.sp_get_bld    Script Date: 3/24/97 11:45:15 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.sp_get_bld') and sysstat & 0xf = 4)
	drop procedure dbo.sp_get_bld
GO

/****** Object:  Stored Procedure dbo.sp_get_class    Script Date: 3/24/97 11:45:15 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.sp_get_class') and sysstat & 0xf = 4)
	drop procedure dbo.sp_get_class
GO

/****** Object:  Stored Procedure dbo.sp_get_room    Script Date: 3/24/97 11:45:15 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.sp_get_room') and sysstat & 0xf = 4)
	drop procedure dbo.sp_get_room
GO

/****** Object:  Stored Procedure dbo.sp_get_subj    Script Date: 3/24/97 11:45:15 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.sp_get_subj') and sysstat & 0xf = 4)
	drop procedure dbo.sp_get_subj
GO

/****** Object:  Stored Procedure dbo.sp_get_tccl    Script Date: 3/24/97 11:45:15 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.sp_get_tccl') and sysstat & 0xf = 4)
	drop procedure dbo.sp_get_tccl
GO

/****** Object:  Stored Procedure dbo.sp_get_tchr    Script Date: 3/24/97 11:45:15 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.sp_get_tchr') and sysstat & 0xf = 4)
	drop procedure dbo.sp_get_tchr
GO

/****** Object:  Stored Procedure dbo.sp_update_Curriculum    Script Date: 3/24/97 11:45:15 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.sp_update_Curriculum') and sysstat & 0xf = 4)
	drop procedure dbo.sp_update_Curriculum
GO

/****** Object:  Stored Procedure dbo.sp_update_Currisb    Script Date: 3/24/97 11:45:15 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.sp_update_Currisb') and sysstat & 0xf = 4)
	drop procedure dbo.sp_update_Currisb
GO

/****** Object:  Stored Procedure dbo.sp_update_bld    Script Date: 3/24/97 11:45:15 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.sp_update_bld') and sysstat & 0xf = 4)
	drop procedure dbo.sp_update_bld
GO

/****** Object:  Stored Procedure dbo.sp_update_class    Script Date: 3/24/97 11:45:15 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.sp_update_class') and sysstat & 0xf = 4)
	drop procedure dbo.sp_update_class
GO

/****** Object:  Stored Procedure dbo.sp_update_room    Script Date: 3/24/97 11:45:15 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.sp_update_room') and sysstat & 0xf = 4)
	drop procedure dbo.sp_update_room
GO

/****** Object:  Stored Procedure dbo.sp_add_Curriculum    Script Date: 3/24/97 11:45:15 AM ******/
CREATE PROCEDURE sp_add_Curriculum
	@Curriculum_Id char(8),
	@Curriculum_Name_Thai char(50),
	@Curriculum_Name_Eng char(50),
	@Curriculum_Name_Thai_Abbr char(20),
	@Curriculum_Name_Eng_Abbr char(20),
	@Curriculum_Total_Credit int,
	@Dept_Id char(3)

AS

BEGIN

delete 	curriculum

where	curriculum_id = @curriculum_id

insert into Curriculum(
	Curriculum_Id,
	Curriculum_Name_Thai,
	Curriculum_Name_Eng,
	Curriculum_Name_Thai_Abbr,
	Curriculum_Name_Eng_Abbr,
	Curriculum_Total_Credit,
	Dept_Id)
Values(
	@Curriculum_Id,
	@Curriculum_Name_Thai,
	@Curriculum_Name_Eng,
	@Curriculum_Name_Thai_Abbr,
	@Curriculum_Name_Eng_Abbr,
	@Curriculum_Total_Credit,
	@Dept_Id)


End
GO

/****** Object:  Stored Procedure dbo.sp_add_Currisb    Script Date: 3/24/97 11:45:15 AM ******/
CREATE PROCEDURE sp_add_Currisb
	@Curriculum_Id char(8),
	@SubGroup_Type_Id char(2),
	@Subj_Id char(6),
	@YearStudy char(1),
	@TermStudy char(1)
AS

BEGIN

insert into Curriculum_Subj(
	Curriculum_Id,
	SubGroup_Type_Id,	
	Subj_Id,
	YearStudy,
	TermStudy)
Values(
	@Curriculum_Id,
	@SubGroup_Type_Id,	
	@Subj_Id,
	@YearStudy,
	@TermStudy)

End
GO

/****** Object:  Stored Procedure dbo.sp_add_class    Script Date: 3/24/97 11:45:15 AM ******/
CREATE PROCEDURE sp_add_class
	@Subj_Id char(6),
	@Academic_Year char(4),
	@Academic_Term char(1),
	@Lec_Group_No char(2),
	@Lab_Group_No char(2),
	@Class_Day char(3),
	@Class_Time_Begin char(5),
	@Class_Time_End char(5),
	@Room_Code char(20),
	@Class_Max_Std int
AS

BEGIN

insert into Class(
	Subj_Id,
	Academic_Year,
	Academic_Term,
	Lec_Group_No,
	Lab_Group_No,
	Class_Day,
	Class_Time_Begin,
	Class_Time_End,
	Room_Code,
	Teacher_Id,
	Class_Max_Std)
Values(
	@Subj_Id,
	@Academic_Year,
	@Academic_Term,
	@Lec_Group_No,
	@Lab_Group_No,
	@Class_Day,
	@Class_Time_Begin,
	@Class_Time_End,
	@Room_Code,
	"",
	@Class_Max_Std)

End
GO

/****** Object:  Stored Procedure dbo.sp_add_room    Script Date: 3/24/97 11:45:15 AM ******/
CREATE PROCEDURE sp_add_room
	@Room_Code char(20),
	@Building_Code char(7),
	@Room_Floor_No int,
	@Room_Type char(3),
	@Room_Capacity int
AS

Begin

Insert into Room(
	Room_Code,
	Building_Code,
	Room_Floor_No,
	Room_Type,
	Room_Capacity)
Values(
	@Room_Code,
	@Building_Code,
	@Room_Floor_No,
	@Room_Type,
	@Room_Capacity)
End	
GO

/****** Object:  Stored Procedure dbo.sp_delete_Curriculum    Script Date: 3/24/97 11:45:15 AM ******/
CREATE PROCEDURE sp_delete_Curriculum
	@Curriculum_Id char(8)
AS

begin

delete
	Curriculum
where
	Curriculum_Id = @Curriculum_Id

End
GO

/****** Object:  Stored Procedure dbo.sp_delete_Currisb    Script Date: 3/24/97 11:45:15 AM ******/
CREATE PROCEDURE sp_delete_Currisb
	@Curriculum_Id char(8),
	@SubGroup_Type_Id char(2),	
	@Subj_Id char(6)
AS

BEGIN

delete	
	Curriculum_Subj
where
	Curriculum_Id = @Curriculum_Id
	and SubGroup_Type_Id = @SubGroup_Type_Id	
	and Subj_Id = @Subj_Id


End
GO

/****** Object:  Stored Procedure dbo.sp_delete_class    Script Date: 3/24/97 11:45:15 AM ******/
CREATE PROCEDURE sp_delete_class
	@Subj_Id char(6),
	@Academic_Year char(4),
	@Academic_Term char(1),
	@Lec_Group_No char(2),
	@Lab_Group_No char(2),
	@Class_Day char(3),
	@Class_Time_Begin char(5),
	@Class_Time_End char(5),
	@Room_Code char(20)
AS

begin

Delete
	Class
where
	Subj_Id = @Subj_Id
	and Academic_Year = @Academic_Year
	and Academic_Term = @Academic_Term
	and Lec_Group_No = @Lec_Group_No
	and Lab_Group_No = @Lab_Group_No
	and Class_day = @Class_Day
	and Class_Time_Begin = @Class_Time_Begin
	and Class_Time_End = @Class_Time_End
	and Room_Code = @Room_Code
End
GO

/****** Object:  Stored Procedure dbo.sp_delete_room    Script Date: 3/24/97 11:45:15 AM ******/
CREATE PROCEDURE sp_delete_room
	@Room_Code char(20)
AS

begin

delete
	Room
where
	Room_Code = @Room_Code

End
GO

/****** Object:  Stored Procedure dbo.sp_get_Curriculum    Script Date: 3/24/97 11:45:15 AM ******/
create procedure sp_get_Curriculum as

begin

select 
	Curriculum_Id,
	Curriculum_Name_Thai,
	Curriculum_Name_Eng,
	Curriculum_Name_Thai_Abbr,
	Curriculum_Name_Eng_Abbr,
	Curriculum_Total_Credit,
	Dept_Id

	
from
	Curriculum

End
GO

/****** Object:  Stored Procedure dbo.sp_get_Currisb    Script Date: 3/24/97 11:45:15 AM ******/
CREATE PROCEDURE sp_get_Currisb
	
AS

BEGIN

select	
	Curriculum_Id,
	SubGroup_Type_Id,	
	Subj_Id,
	YearStudy,
	TermStudy
from
	Curriculum_Subj

End
GO

/****** Object:  Stored Procedure dbo.sp_get_bld    Script Date: 3/24/97 11:45:15 AM ******/
CREATE PROCEDURE sp_get_bld
AS

BEGIN

SELECT 
	Building_Code,
	Building_Name,
	Building_Place
FROM
	Building

END
GO

/****** Object:  Stored Procedure dbo.sp_get_class    Script Date: 3/24/97 11:45:15 AM ******/
create procedure sp_get_class

as

begin

select 
	Subj_Id,
	Academic_Year,
	Academic_Term,
	Lec_Group_No,
	Lab_Group_No,
	Class_Day,
	Class_Time_Begin,
	Class_Time_End,
	Room_Code,
	Class_Max_Std
from
	Class

End
GO

/****** Object:  Stored Procedure dbo.sp_get_room    Script Date: 3/24/97 11:45:15 AM ******/


create procedure sp_get_room

as

begin

select 
	Room_Code,
	Building_Code,
	Room_Floor_No,
	Room_Type,
	Room_Capacity
from
	Room

End
GO

/****** Object:  Stored Procedure dbo.sp_get_subj    Script Date: 3/24/97 11:45:15 AM ******/
CREATE PROCEDURE sp_get_subj
AS

begin

select 	Subj_Id ,
	Subj_Name_Thai ,
	Subj_Name_Eng  ,
	Subj_Descrip_Thai  ,
	Subj_Descrip_Eng  ,
	Subj_Dept_Id  ,
	SubGroup_Type_Id  ,
	Subj_Lec_Credit,
	Subj_Lab_Credit ,
	Subj_Year_Begin,
	Subj_Term_Begin  ,
	Subj_Year_End  ,
	Subj_Term_End  ,
	Year_Study 
	
from subject
END
GO


/****** Object:  Stored Procedure dbo.sp_get_tccl    Script Date: 3/24/97 11:45:15 AM ******/

create procedure sp_get_tccl

as

begin

select 
	Subj_Id,
	Academic_Year,
	Academic_Term,
	Lec_Group_No,
	Lab_Group_No,
	Teacher_ID
from
	TeacherClass

End
GO

/****** Object:  Stored Procedure dbo.sp_get_tchr    Script Date: 3/24/97 11:45:15 AM ******/

CREATE PROCEDURE sp_get_tchr
AS

BEGIN

SELECT 
	Teacher_Id,
	Teacher_Title_Thai,
	Teacher_Name_Thai,
	Teacher_Sname_Thai,
	Teacher_Position_Thai,
	Dept_Id
FROM
	Teacher

END
GO

/****** Object:  Stored Procedure dbo.sp_update_Curriculum    Script Date: 3/24/97 11:45:15 AM ******/
CREATE PROCEDURE sp_update_Curriculum
	@Curriculum_Id char(8),
	@Curriculum_Name_Thai char(50),
	@Curriculum_Name_Eng char(50),
	@Curriculum_Name_Thai_Abbr char(20),
	@Curriculum_Name_Eng_Abbr char(20),
	@Curriculum_Total_Credit int,
	@Dept_Id char(3)
AS

Begin

update 
	Curriculum
set
	Curriculum_Id = @Curriculum_Id,
	Curriculum_Name_Thai = @Curriculum_Name_Thai,
	Curriculum_Name_Eng = @Curriculum_Name_Eng,
	Curriculum_Name_Thai_Abbr = @Curriculum_Name_Thai_Abbr,
	Curriculum_Name_Eng_Abbr = @Curriculum_Name_Eng_Abbr,
	Curriculum_Total_Credit = @Curriculum_Total_Credit,
	Dept_Id = @Dept_Id
	
where
	Curriculum_Id = @Curriculum_Id
End
GO

/****** Object:  Stored Procedure dbo.sp_update_Currisb    Script Date: 3/24/97 11:45:15 AM ******/
CREATE PROCEDURE sp_update_Currisb
	@Curriculum_Id char(8),
	@SubGroup_Type_Id char(2),	
	@Subj_Id char(6),
	@YearStudy char(1),
	@TermStudy char(1)
AS

BEGIN

update	
	Curriculum_Subj
set
	Curriculum_Id = @Curriculum_Id,
	SubGroup_Type_Id = @SubGroup_Type_Id,	
	Subj_Id = @Subj_Id,
	YearStudy = @YearStudy,
	TermStudy = @TermStudy
where
	Curriculum_Id = @Curriculum_Id
	and SubGroup_Type_Id = @SubGroup_Type_Id
	and Subj_Id = @Subj_Id
End
GO

/****** Object:  Stored Procedure dbo.sp_update_bld    Script Date: 3/24/97 11:45:15 AM ******/
CREATE PROCEDURE sp_update_bld
	@Building_Code Char(7),
	@Building_Name char(30),
	@Building_Place char(150)
AS

BEGIN

Update
	Building
Set
	Building_Name = @Building_Name,
	Building_Place = @Building_Place
Where
	Building_Code Like @Building_Code

END
GO

/****** Object:  Stored Procedure dbo.sp_update_class    Script Date: 3/24/97 11:45:15 AM ******/
CREATE PROCEDURE sp_update_class
	@Subj_id char(6),
	@Academic_Year char(4),
	@Academic_Term char(1),
	@Lec_Group_No char(2),
	@Lab_Group_No char(2),
	@Class_Day char(3),
	@Class_Time_Begin char(5),
	@Class_Time_End char(5),
	@Room_Code char(20),
	@Class_Max_Std int
AS

begin

update
	Class
set
	Teacher_Id = "",
	Class_Max_Std = @Class_Max_Std
where
	Subj_id = @Subj_id 
	and Academic_Year = @Academic_Year
	and Academic_Term = @Academic_Term
	and Lec_Group_No = @Lec_Group_No
	and Lab_Group_No = @Lab_Group_No
	and Class_Day = @Class_Day
	and Class_Time_Begin = @Class_Time_Begin
	and Class_Time_End = @Class_Time_End
	and Room_Code = @Room_Code

End
GO

/****** Object:  Stored Procedure dbo.sp_update_room    Script Date: 3/24/97 11:45:15 AM ******/
CREATE PROCEDURE sp_update_room
	@Room_Code char(20),
	@Building_Code char(7),
	@Room_Floor_No int,
	@Room_Type char(3),
	@Room_Capacity int
AS

Begin

update 
	Room	
set
	Building_Code = @Building_Code,
	Room_Floor_No = @Room_Floor_No,
	Room_Type = @Room_Type,
	Room_Capacity = @Room_Capacity
where
	Room_Code = @Room_Code
End
GO

