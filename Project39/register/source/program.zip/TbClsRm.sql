/* Microsoft SQL Server - Scripting			*/
/* Server: DORAEMON					*/
/* Database: isonet4					*/
/* Creation Date 3/24/97 11:47:36 AM 			*/

/****** Object:  Table dbo.Building    Script Date: 3/24/97 11:47:38 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.Building') and sysstat & 0xf = 3)
	drop table dbo.Building
GO

/****** Object:  Table dbo.Class    Script Date: 3/24/97 11:47:38 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.Class') and sysstat & 0xf = 3)
	drop table dbo.Class
GO

/****** Object:  Table dbo.Curriculum    Script Date: 3/24/97 11:47:39 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.Curriculum') and sysstat & 0xf = 3)
	drop table dbo.Curriculum
GO

/****** Object:  Table dbo.Curriculum_Subj    Script Date: 3/24/97 11:47:39 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.Curriculum_Subj') and sysstat & 0xf = 3)
	drop table dbo.Curriculum_Subj
GO

/****** Object:  Table dbo.Room    Script Date: 3/24/97 11:47:39 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.Room') and sysstat & 0xf = 3)
	drop table dbo.Room
GO

/****** Object:  Table dbo.Subject    Script Date: 3/24/97 11:47:39 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.Subject') and sysstat & 0xf = 3)
	drop table dbo.Subject
GO

/****** Object:  Table dbo.Teacher    Script Date: 3/24/97 11:47:39 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.Teacher') and sysstat & 0xf = 3)
	drop table dbo.Teacher
GO

/****** Object:  Table dbo.TeacherClass    Script Date: 3/24/97 11:47:39 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.TeacherClass') and sysstat & 0xf = 3)
	drop table dbo.TeacherClass
GO

/****** Object:  Table dbo.Building    Script Date: 3/24/97 11:47:39 AM ******/
CREATE TABLE dbo.Building (
	Building_Code char (7) NOT NULL ,
	Building_Name char (30) NULL ,
	Building_Place char (150) NULL 
)
GO

/****** Object:  Table dbo.Class    Script Date: 3/24/97 11:47:39 AM ******/
CREATE TABLE dbo.Class (
	Subj_Id char (6) NOT NULL ,
	Academic_Year char (4) NOT NULL ,
	Academic_Term char (1) NOT NULL ,
	Lec_Group_No char (2) NOT NULL ,
	Lab_Group_No char (2) NOT NULL ,
	Class_Day char (3) NOT NULL ,
	Class_Time_Begin char (5) NOT NULL ,
	Class_Time_End char (5) NOT NULL ,
	Room_Code char (20) NOT NULL ,
	Teacher_Id char (5) NOT NULL ,
	Class_Max_Std int NOT NULL ,
	Active_Flag char (1) NULL 
)
GO

/****** Object:  Table dbo.Curriculum    Script Date: 3/24/97 11:47:39 AM ******/
CREATE TABLE dbo.Curriculum (
	Curriculum_Id char (8) NOT NULL ,
	Curriculum_Name_Thai char (50) NULL ,
	Curriculum_Name_Eng char (50) NULL ,
	Curriculum_Name_Thai_Abbr char (20) NULL ,
	Curriculum_Name_Eng_Abbr char (20) NULL ,
	Curriculum_Total_Credit int NULL ,
	Dept_Id char (3) NULL 
)
GO

/****** Object:  Table dbo.Curriculum_Subj    Script Date: 3/24/97 11:47:39 AM ******/
CREATE TABLE dbo.Curriculum_Subj (
	Curriculum_Id char (8) NOT NULL ,
	SubGroup_Type_Id char (2) NOT NULL ,
	Subj_Id char (6) NOT NULL ,
	YearStudy char (1) NULL ,
	TermStudy char (1) NULL 
)
GO

/****** Object:  Table dbo.Room    Script Date: 3/24/97 11:47:39 AM ******/
CREATE TABLE dbo.Room (
	Room_Code char (20) NOT NULL ,
	Building_Code char (7) NULL ,
	Room_Floor_No int NULL ,
	Room_Type char (3) NULL ,
	Room_Capacity int NULL ,
	Active_Flag char (1) NULL 
)
GO

/****** Object:  Table dbo.Subject    Script Date: 3/24/97 11:47:39 AM ******/
CREATE TABLE dbo.Subject (
	Subj_Id char (6) NOT NULL ,
	Subj_Name_Thai char (50) NULL ,
	Subj_Name_Eng char (50) NULL ,
	Subj_Descrip_Thai char (255) NULL ,
	Subj_Descrip_Eng char (255) NULL ,
	Subj_Dept_Id char (3) NULL ,
	SubGroup_Type_Id char (2) NULL ,
	Subj_Lec_Credit smallint NULL ,
	Subj_Lab_Credit smallint NULL ,
	Subj_Year_Begin char (4) NULL ,
	Subj_Term_Begin char (1) NULL ,
	Subj_Year_End char (4) NULL ,
	Subj_Term_End char (1) NULL ,
	Year_Study char (1) NULL 
)
GO

/****** Object:  Table dbo.Teacher    Script Date: 3/24/97 11:47:39 AM ******/
CREATE TABLE dbo.Teacher (
	Teacher_Id char (5) NOT NULL ,
	Teacher_Title_Thai char (6) NULL ,
	Teacher_Name_Thai char (15) NULL ,
	Teacher_Sname_Thai char (25) NULL ,
	Teacher_Position_Thai char (18) NULL ,
	Dept_Id char (3) NULL 
)
GO

/****** Object:  Table dbo.TeacherClass    Script Date: 3/24/97 11:47:39 AM ******/
CREATE TABLE dbo.TeacherClass (
	Subj_id char (6) NOT NULL ,
	Academic_Year char (4) NOT NULL ,
	Academic_Term char (1) NOT NULL ,
	Lec_Group_No char (2) NOT NULL ,
	Lab_Group_No char (2) NOT NULL ,
	MaxStd int NOT NULL ,
	Teacher_ID char (5) NOT NULL 
)
GO

