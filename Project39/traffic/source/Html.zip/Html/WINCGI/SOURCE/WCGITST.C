/*****************************************************************************/
/* wcgitst (c) Copyright 1995-1995 Michael Kofler                            */
/*****************************************************************************/
/* Win CGI Sample Program                                                    */
/*****************************************************************************/
#ifndef lint
static char copyright[] =
"@(#) Copyright (c) 1995 - 1995 Michael Kofler, Computer Software Manufaktur GmbH. Vienna.\n";
#endif  /* not lint */


/********************** Includes ****************************************/
#include <windows.h>
#include "winsock.h"
#include <commdlg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <io.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dos.h>

/* This must be included when using WINCGI.DLL  */
#include "wincgi.h"

#define DO_WORK         WM_USER+1


/********************** Globals *****************************************/
char            szAppName[]="wcgitst";
HMENU           hWndMainMenu;
HANDLE          hInst;
HDC             hdc;
char            CGIFileName[WCGI_LONGSTR];
char            ContentFileName[WCGI_LONGSTR];
char            OutputFileName[WCGI_LONGSTR];
char            Parameters[WCGI_MONSTERSTR];

long PASCAL WndProc(HWND, WORD, WORD, LONG);


/************************************************************************/
/* WinMain                                                              */
/************************************************************************/
int      PASCAL WinMain(HANDLE hInstance, HANDLE hPrevInstance,
                        LPSTR lpszCmdLine, int cmdShow)
{
        MSG             msg;
        WNDCLASS        wndclass;
        HWND            hwndmain;

        if (!hPrevInstance)
        {
                /* Define the window class for this application.        */
                wndclass.style         = CS_HREDRAW;
                wndclass.lpfnWndProc   = WndProc;
                wndclass.cbClsExtra    = 0;
                wndclass.cbWndExtra    = 0;
                wndclass.hInstance     = hInstance;
                wndclass.hIcon         = LoadIcon(hInstance, szAppName);
                wndclass.hCursor       = LoadCursor(NULL, IDC_ARROW);
                wndclass.hbrBackground = GetStockObject(WHITE_BRUSH);
                wndclass.lpszMenuName  = NULL;
                wndclass.lpszClassName = szAppName;
                /* Register the class                                   */
                if (!RegisterClass(&wndclass))
                {
                        return(FALSE);
                } /* endif */
        }
        else
        {
                return(FALSE);
        } /* endif */


        CSM_ParseCmdLine(lpszCmdLine,CGIFileName);

        hInst = hInstance;

        if ( (hwndmain = CreateWindow(szAppName,"WCGITST",
                            WS_OVERLAPPEDWINDOW,
                            CW_USEDEFAULT, CW_USEDEFAULT,
                            CW_USEDEFAULT, CW_USEDEFAULT,
                            NULL, NULL, hInstance, NULL)) == NULL)
        {
                MessageBox(hwndmain,"Could not create Window",szAppName, MB_ICONEXCLAMATION | MB_OK);
                return(FALSE);
        } /* endif */



        ShowWindow(hwndmain,SW_SHOWMINNOACTIVE);
        UpdateWindow(hwndmain);

        while (GetMessage(&msg, NULL, 0, 0))
        {
                TranslateMessage(&msg);
                DispatchMessage(&msg);
        } /* endwhile */
        return(msg.wParam);
} /* end of WinMain */





/************************************************************************/
/* WndProc - handles messages for this application                      */
/*                                                                      */
/* paramaters:                                                          */
/*             hWnd          - The window handle for this message       */
/*             message       - The message number                       */
/*             wParam        - The WORD parameter for this message      */
/*             lParam        - The LONG parameter for this message      */
/*                                                                      */
/* returns:                                                             */
/*             depends on message.                                      */
/*                                                                      */
/************************************************************************/
long FAR PASCAL WndProc(HWND hWnd, WORD message, WORD wParam, LONG lParam)
{
        HMENU            hMenu;
        HICON            hIcon;
        struct WinCGIEnv CGIPART;
        struct ACCEPT    ACCEPT;
        struct ExtraHeaders ExtraHeaders_1;
        struct FormLiteral  FormLiteral;
        struct FormExternal FormExternal;
        struct FormHuge     FormHuge;
        char hlp[4096];
        int i;
        int fh;

        switch (message)
        {
            case WM_CREATE:
                hInst = ((LPCREATESTRUCT) lParam)->hInstance;


                /* Usefull to do it like that                   */
                /* So the create is finished                    */
                SendMessage (hWnd, DO_WORK, 0, 0);
                return 0;
                break;

            case DO_WORK:
                /* Read the CGI Section of the INI File, and the ACCEPT Headers */
                CSM_ReadIniEntries(CGIFileName,&CGIPART,&ACCEPT);
                /* Now retrieve the Extra Headers, if there are any          */
                /* Be sure to call CSM_FreeExtraHeaders, at the end          */
                /* As the DLL is doing some mallocs for you                  */
                CSM_GetExtraHeaders(CGIFileName,&ExtraHeaders_1);

                CSM_GetFormLiteral(CGIFileName,&FormLiteral);
                CSM_GetFormExternal(CGIFileName,&FormExternal);
                CSM_GetFormHuge(CGIFileName,&FormHuge);

                strcpy(OutputFileName,CGIPART.Output_File);


                fh = _open( OutputFileName, _O_RDWR | _O_CREAT | _O_BINARY |_O_APPEND, _S_IREAD | _S_IWRITE );
                wsprintf(hlp,"Content-type: text/html\r\n\r\n");
                write(fh,hlp,strlen(hlp));

                wsprintf(hlp,"<HEAD><TITLE>WINCGI - Test</TITLE></HEAD>\r\n");
                write(fh,hlp,strlen(hlp));

                wsprintf(hlp,"<H1>WINCGI Report</H1>\r\n");
                write(fh,hlp,strlen(hlp));

                wsprintf(hlp,"<STRONG>Used Command :</STRONG> %s<P>\r\n",CGIPART.Request_Method);
                write(fh,hlp,strlen(hlp));

                wsprintf(hlp,"<STRONG>Welcome to Alibaba - The WWW Server</STRONG>\r\n");
                write(fh,hlp,strlen(hlp));

                wsprintf(hlp,"<H2>CGI Section</H2>\r\n");
                write(fh,hlp,strlen(hlp));

                wsprintf(hlp,"<UL>\r\n");
                write(fh,hlp,strlen(hlp));

                wsprintf(hlp,"<LI><STRONG>Request Protocol :</STRONG> %s\r\n",CGIPART.Request_Protocol);
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<LI><STRONG>Executable Path :</STRONG> %s\r\n",CGIPART.Executable_Path);
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<LI><STRONG>Logical Path :</STRONG> %s\r\n",CGIPART.Logical_Path);
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<LI><STRONG>Physical Path :</STRONG> %s\r\n",CGIPART.Physical_Path);
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<LI><STRONG>Query String :</STRONG> %s\r\n",CGIPART.Query_String);
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<LI><STRONG>Referer :</STRONG> %s\r\n",CGIPART.Referer);
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<LI><STRONG>From :</STRONG> %s\r\n",CGIPART.From);
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<LI><STRONG>Content Type :</STRONG> %s\r\n",CGIPART.Content_Type);
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<LI><STRONG>Content Length :</STRONG> %d\r\n",CGIPART.Content_Length);
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<LI><STRONG>Content File :</STRONG> %s\r\n",CGIPART.Content_File);
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<LI><STRONG>Server Software :</STRONG> %s\r\n",CGIPART.Server_Software);
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<LI><STRONG>Server Name :</STRONG> %s\r\n",CGIPART.Server_Name);
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<LI><STRONG>Server Port :</STRONG> %d\r\n",CGIPART.Server_Port);
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<LI><STRONG>Server Admin :</STRONG> %s\r\n",CGIPART.Server_Admin);
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<LI><STRONG>CGI Version :</STRONG> %s\r\n",CGIPART.CGI_Version);
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<LI><STRONG>Remote Host :</STRONG> %s\r\n",CGIPART.Remote_Host);
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<LI><STRONG>Remote Address :</STRONG> %s\r\n",CGIPART.Remote_Address);
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<LI><STRONG>Authentication Method :</STRONG> %s\r\n",CGIPART.Authentication_Method);
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<LI><STRONG>Authentication Realm :</STRONG> %s\r\n",CGIPART.Authentication_Realm);
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<LI><STRONG>Authenticated User :</STRONG> %s\r\n",CGIPART.Authenticated_Username);
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"</UL>\r\n");
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<HR Size=4>\r\n");
                write(fh,hlp,strlen(hlp));

                wsprintf(hlp,"<H2>System Section</H2>\r\n");
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<UL>\r\n");
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<LI><STRONG>GMT Offset :</STRONG> %d\r\n",CGIPART.GMT_Offset);
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<LI><STRONG>Debug Mode :</STRONG> %s\r\n",CGIPART.Debug_Mode);
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<LI><STRONG>Output File :</STRONG> %s\r\n",CGIPART.Output_File);
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<LI><STRONG>Content File :</STRONG> %s\r\n",CGIPART.Content_File);
                write(fh,hlp,strlen(hlp));

                wsprintf(hlp,"</UL>\r\n");
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<HR Size=4>\r\n");
                write(fh,hlp,strlen(hlp));



                wsprintf(hlp,"<H2>Accept Section</H2>\r\n");
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<UL>\r\n");
                write(fh,hlp,strlen(hlp));
                for ( i = 0; i < ACCEPT.MaxAcceptUsed; i++)
                {
                        wsprintf(hlp,"<LI><STRONG>%s</STRONG>\r\n",ACCEPT.OneAccField[i].MimeType);
                        write(fh,hlp,strlen(hlp));
                } /* endfor */
                wsprintf(hlp,"</UL>\r\n");
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<HR Size=4>\r\n");
                write(fh,hlp,strlen(hlp));

                wsprintf(hlp,"<H2>Extra Headers Section</H2>\r\n");
                write(fh,hlp,strlen(hlp));
                if (ExtraHeaders_1.MaxUsed > 0)
                {
                        wsprintf(hlp,"<UL>\r\n");
                        write(fh,hlp,strlen(hlp));
                        for (i = 0; i < ExtraHeaders_1.MaxUsed; i++)
                        {
                                wsprintf(hlp,"<LI><STRONG>%s :</STRONG>%s\r\n",
                                         ExtraHeaders_1.OneExtraHeader[i].Var,
                                         ExtraHeaders_1.OneExtraHeader[i].Value);
                                write(fh,hlp,strlen(hlp));
                        } /* endfor */
                        wsprintf(hlp,"</UL>\r\n");
                        write(fh,hlp,strlen(hlp));
                }
                else
                {
                        wsprintf(hlp,"No Extra Headers existing\r\n<P>");
                        write(fh,hlp,strlen(hlp));
                } /* endif */

                wsprintf(hlp,"<HR Size=4>\r\n");
                write(fh,hlp,strlen(hlp));

                wsprintf(hlp,"<H2>Form Literal Section</H2>\r\n");
                write(fh,hlp,strlen(hlp));
                if (FormLiteral.MaxUsed > 0)
                {
                        wsprintf(hlp,"<UL>\r\n");
                        write(fh,hlp,strlen(hlp));
                        for (i = 0; i < FormLiteral.MaxUsed; i++)
                        {
                                wsprintf(hlp,"<LI><STRONG>%s :</STRONG>%s\r\n",
                                         FormLiteral.OneFormLiteral[i].Var,
                                         FormLiteral.OneFormLiteral[i].Value);
                                write(fh,hlp,strlen(hlp));
                        } /* endfor */
                        wsprintf(hlp,"</UL>\r\n");
                        write(fh,hlp,strlen(hlp));
                }
                else
                {
                        wsprintf(hlp,"Nothing defined in Form Literal Section\r\n<P>");
                        write(fh,hlp,strlen(hlp));
                } /* endif */


                wsprintf(hlp,"<HR Size=4>\r\n");
                write(fh,hlp,strlen(hlp));

                wsprintf(hlp,"<H2>Form External Section</H2>\r\n");
                write(fh,hlp,strlen(hlp));
                if (FormExternal.MaxUsed > 0)
                {
                        wsprintf(hlp,"<UL>\r\n");
                        write(fh,hlp,strlen(hlp));
                        for (i = 0; i < FormExternal.MaxUsed; i++)
                        {
                                wsprintf(hlp,"<LI><STRONG>%s :</STRONG>%s %d\r\n",
                                         FormExternal.OneFormExternal[i].Var,
                                         FormExternal.OneFormExternal[i].FileName,
                                         FormExternal.OneFormExternal[i].Size);
                                write(fh,hlp,strlen(hlp));
                        } /* endfor */
                        wsprintf(hlp,"</UL>\r\n");
                        write(fh,hlp,strlen(hlp));
                }
                else
                {
                        wsprintf(hlp,"Nothing defined in Form External Section\r\n<P>");
                        write(fh,hlp,strlen(hlp));
                } /* endif */

                wsprintf(hlp,"<HR Size=4>\r\n");
                write(fh,hlp,strlen(hlp));

                wsprintf(hlp,"<H2>Form Huge Section</H2>\r\n");
                write(fh,hlp,strlen(hlp));
                if (FormHuge.MaxUsed > 0)
                {
                        wsprintf(hlp,"<UL>\r\n");
                        write(fh,hlp,strlen(hlp));
                        for (i = 0; i < FormHuge.MaxUsed; i++)
                        {
                                wsprintf(hlp,"<LI><STRONG>%s :</STRONG>%d %d\r\n",
                                         FormHuge.OneFormHuge[i].Var,
                                         FormHuge.OneFormHuge[i].Offset,
                                         FormHuge.OneFormHuge[i].Size);
                                write(fh,hlp,strlen(hlp));
                        } /* endfor */
                        wsprintf(hlp,"</UL>\r\n");
                        write(fh,hlp,strlen(hlp));
                }
                else
                {
                        wsprintf(hlp,"Nothing defined in Form Huge Section\r\n<P>");
                        write(fh,hlp,strlen(hlp));
                } /* endif */

                wsprintf(hlp,"<HR Size=4>\r\n");
                write(fh,hlp,strlen(hlp));

                wsprintf(hlp,"Please check out our homepage for <STRONG>Alibaba</STRONG> updates and latest product infos :");
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<A HREF=\"http://www.csm.co.at/csm/\">http://www.csm.co.at/csm/</A><P>\r\n");
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<UL>\r\n");
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<LI><A HREF=\"mailto:sales@csm.co.at\">Yes, I want sales information</A>\r\n");
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<LI><A HREF=\"mailto:support@csm.co.at\">I need help !</A>\r\n");
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"</UL>\r\n");
                write(fh,hlp,strlen(hlp));
                wsprintf(hlp,"<HR Size=4>\r\n");
                write(fh,hlp,strlen(hlp));

                _close(fh);
                /* Free the allocated Extra Headers Memory */
                CSM_FreeExtraHeaders(&ExtraHeaders_1);
                CSM_FreeFormLiteral(&FormLiteral);
                CSM_FreeFormExternal(&FormExternal);
                CSM_FreeFormHuge(&FormHuge);

                SendMessage (hWnd, WM_CLOSE, 0, 0);
                return 0;
                break;

            case WM_DESTROY:
            case WM_QUIT:
                PostQuitMessage(0);
                DestroyMenu(hWndMainMenu);
                break;
            default:
                return(DefWindowProc(hWnd, message, wParam, lParam));
        } /* endswitch */
        return(0L);
} /* end of WndProc */
