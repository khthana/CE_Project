import java.awt.* ;

public class PomCanvas extends Canvas{
   Image pomImg ;

   public PomCanvas(Image  img){
       pomImg = img;
                               }

   public void paint(Graphics  g ){
      g.drawImage(pomImg,
      -1 *((PomScrollWindow)getParent()).imgX,
      -1 *((PomScrollWindow)getParent()).imgY,
          this);
                                  }
                                       } //--- end of class ImageCanvas
