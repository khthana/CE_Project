import  java.applet.* ;
import  java.awt.* ;


public class PomProJect extends Applet{
Image  img;
PomScrollWindow picturewind;

public void init(){
  img = getImage(getCodeBase(),"image/00.gif");
  picturewind = new PomScrollWindow(img) ;
  setLayout(new BorderLayout());
  add("Center",picturewind);
                  }

}; //---- end of class 
