import java.awt.* ;

public class PomScrollWindow extends Panel {
  PomCanvas    imgCnvs ;
  Scrollbar    vertBar ;
  Scrollbar    horzBar ;
  Image        image ;
  int          imgWidth ;
  int          imgHeight ;

  int          imgX ;
  int          imgY ;

  int           page ;

public PomScrollWindow(Image img){
  image = img;
  imgX = imgY = 0;

  while((imgHeight=image.getHeight(this))== -1); //---�ͨ����Ҩ���Ŵ�Ҿ����

  while((imgWidth=image.getWidth(this))== -1); //---�ͨ����Ҩ���Ŵ�Ҿ����

  imgCnvs = new PomCanvas(image);

  vertBar = new Scrollbar(Scrollbar.VERTICAL);
  horzBar = new Scrollbar(Scrollbar.HORIZONTAL);

  GridBagLayout gridbag = new GridBagLayout();
  setLayout(gridbag);

  GridBagConstraints  c = new GridBagConstraints();
  c.fill = GridBagConstraints.BOTH ;
  c.weightx = 1.0 ;
  c.weighty = 1.0 ;
  gridbag.setConstraints(imgCnvs,c);
  add(imgCnvs);

  c.fill = GridBagConstraints.VERTICAL ;
  c.gridwidth = GridBagConstraints.REMAINDER ;
  gridbag.setConstraints(vertBar,c);
  add(vertBar);

  c.fill = GridBagConstraints.HORIZONTAL ;
  c.gridwidth = 1 ;
  gridbag.setConstraints(horzBar,c);
  add(horzBar);
                                        } //--- end of PomPictureWindow
public synchronized void reshape(int x,
                                 int y,
                                 int width,
                                 int height){
  super.reshape(x,y,width,height);
  if(width > imgWidth + vertBar.bounds().width){
     horzBar.disable();
     } else{
          horzBar.enable();
          Rectangle bndRect = bounds();
          int barWidth = vertBar.preferredSize().width ;
          int max = imgWidth - (bndRect.width - barWidth);
          page= max / 10;
          int oldMax = horzBar.getMaximum();
          if(oldMax == 0) imgX = 0;
             else imgX = (int)(((float)imgX/(float)oldMax) * (float)max) ;
          horzBar.setValues(imgX,page,0,max);
          horzBar.setPageIncrement(page);
           }
  if(height > imgHeight+horzBar.bounds().height){
     vertBar.disable();
     } else{
          vertBar.enable();
          Rectangle bndRect = bounds();
          int barWidth = vertBar.preferredSize().width ;
          int max = imgWidth - (bndRect.width-barWidth) ;
          page = max/10;
          int oldMax = horzBar.getMaximum() ;
          if(oldMax == 0 ) imgX = 0;
            else imgX = (int)(((float)imgX/(float)oldMax)*(float)max);
          horzBar.setValues(imgX,page,0,max) ;
          horzBar.setPageIncrement(page) ;
           }
   if(height > imgHeight+horzBar.bounds().height) {
       vertBar.disable();
       } else {
          vertBar.enable();
          Rectangle bndRect = bounds();
          int barHeight = vertBar.preferredSize().height ;
          int max = imgHeight - (bndRect.height-barHeight) ;
          page = max/10;
          int oldMax = vertBar.getMaximum() ;
          if(oldMax == 0 ) imgY = 0;
            else imgY = (int)(((float)imgY/(float)oldMax)*(float)max);
          vertBar.setValues(imgX,page,0,max) ;
          vertBar.setPageIncrement(page) ;
              }
                        }//---end of reshape

public boolean handleEvent(Event e){
  if( e.target == horzBar ){
    switch(e.id){
       case Event.SCROLL_PAGE_UP:
       case Event.SCROLL_LINE_UP:

       case Event.SCROLL_ABSOLUTE:

       case Event.SCROLL_LINE_DOWN:
       case Event.SCROLL_PAGE_DOWN:

       imgX = horzBar.getValue() ;
       imgCnvs.repaint();

       return true;
                 }//--end of switch
                           } //---end of if
   else if(e.target == vertBar){
    switch(e.id){
       case Event.SCROLL_PAGE_UP:
       case Event.SCROLL_LINE_UP:

       case Event.SCROLL_ABSOLUTE:

       case Event.SCROLL_LINE_DOWN:
       case Event.SCROLL_PAGE_DOWN:

       imgY = vertBar.getValue() ;
       imgCnvs.repaint();

       return true;
                 }//--end of switch

                               } //--- end of else if

       return super.handleEvent(e);

          }//--- end of method handleEvent

                         }; //---end of class PomPictureWindow

