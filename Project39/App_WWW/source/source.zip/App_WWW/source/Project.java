import java.awt.*;
import java.applet.*;
import java.net.*;
import java.lang.*;
import java.io.DataOutputStream;
import java.lang.Integer;
import java.lang.String;
import java.*;

public class Project extends Applet {
       List ProductList;
	   String list1,list2,list3,list4,list5,list6,list7,list8;
	   String list9,list10,list11,list12,list13,list14,list15,list16,list17,list18;
	   String list19,list20,list21,list22,list23,list24,list25,list26;
	   String list27,list28,list29,list30;
	   Button PrevButton,NextButton;
	   String button1,button2,button3,button4,button5,button6,button7;
	   Label  ProductLabel,InformationLabel,MultimediaLabel;
	   Label  IDLabel,NameLabel,InfoLabel,TelLabel,FaxLabel;
	   Label  EmailLabel,AddressLabel,OtherLabel,SumLabel;
	   Button SendEMailButton,HomePageButton,BUYButton;
	   String label1,label2,label3;
	   String label4,label5,label6,label7,label8,label9,label10,label11,label12;
	   TextField IDField,NameField,TelField,FaxField;
	   TextField EmailField,AddressField,AmountField,SumField;
	   TextArea InfoArea,OtherArea;
	   Button PlayAudioButton,StopAudioButton;
	   Checkbox ShowPicCheck;
	   String chkbx1;
	   String key0,key1,key2,key3,key4;
	   Frame sending,window;
	   String cost1,cost2,cost3,cost4,cost5,cost6,cost7,cost8;
	   String cost9,cost10,cost11,cost12,cost13,cost14,cost15,cost16;
	   String cost17,cost18,cost19,cost20,cost21,cost22,cost23,cost24;
	   String cost25,cost26,cost27,cost28,cost29,cost30;
	   Image image1,image2;	
	   int[] TempArray;
	   AudioClip audio,audio1,audio2,audio3,audio4,audio5,audio6,audio7,audio8;
	   AudioClip audio9,audio10,audio11,audio12,audio13,audio14,audio15,audio16;
	   AudioClip audio17,audio18,audio19,audio20,audio21,audio22,audio23,audio24;
	   AudioClip audio25,audio26,audio27,audio28,audio29,audio30;	   
	   String id1,id2,id3,id4,id5,id6,id7,id8,id9,id10,id11,id12,id13,id14,id15;
	   String id16,id17,id18,id19,id20,id21,id22,id23,id24,id25,id26,id27,id28,id29,id30;
	   String name1,name2,name3,name4,name5,name6,name7,name8;
	   String name9,name10,name11,name12,name13,name14,name15,name16;
	   String name17,name18,name19,name20,name21,name22,name23,name24;
	   String name25,name26,name27,name28,name29,name30;
	   String info1,info2,info3,info4,info5,info6,info7,info8;
	   String info9,info10,info11,info12,info13,info14,info15,info16;
	   String info17,info18,info19,info20,info21,info22,info23,info24;
	   String info25,info26,info27,info28,info29,info30;	
	   int KEYENCRYPT;
	   String sound1,sound2,sound3,sound4,sound5,sound6,sound7,sound8;
	   String sound9,sound10,sound11,sound12,sound13,sound14,sound15,sound16;	
	   String sound17,sound18,sound19,sound20,sound21,sound22,sound23;
	   String sound24,sound25,sound26,sound27,sound28,sound29,sound30;
	   long SENDING1,SENDING2,SENDING3,SENDING5,SENDING6,SENDING7;
	   long SENDING8,SENDING9;  
	   int indexChoice; 
	
       public void init() {
	 	
		      TempArray = new int[100];
	
			  key0 = getParameter("key0");
			
			  key1 = getParameter("key1");
			  
			  key2 = getParameter("key2");
			  
			  key3 = getParameter("key3");
			
			  key4 = getParameter("key4");
	
	   		  list1 = getParameter("list1");
/*			          if (list1 == null) {
						  list1 = "Television";
					  }*/
			  
			  list2 = getParameter("list2");
/*			          if (list2 == null) {
						  list2 = "Video";
					  }*/
				
			  list3 = getParameter("list3");
/*			          if (list3 == null) {
						  list3 = "Stereo";
					  }*/
			  
			  list4 = getParameter("list4");
/*			          if (list4 == null) {
						  list4 = "Fax";
					  }*/
					
			  list5 = getParameter("list5");
/*			          if (list5 == null) {
						  list5 = "Computer";
					  }*/
			  
			  list6 = getParameter("list6");
/*			          if (list6 == null) {
						  list6 = "Telephone";
					  }*/
				
			  list7 = getParameter("list7");
/*			          if (list7 == null) {
						  list7 = "Modem";
					  }*/
			  
			  list8 = getParameter("list8");
/*			          if (list8 == null) {
						  list8 = "Radio";
					  } */
				
			  list9 = getParameter("list9");
/*			          if (list9 == null) {
						  list9 = "Printer";
					  }*/
			  
			  list10 = getParameter("list10");
/*			          if (list10 == null) {
						  list10 = "Watch";
					  }*/
				
			  list11 = getParameter("list11");
/*			          if (list11 == null) {
						  list11 = "Fan";
					  }*/
			  
			  list12 = getParameter("list12");
/*			          if (list12 == null) {
						  list12 = "Camera";
					  }*/
					
			  list13 = getParameter("list13");
/*			          if (list13 == null) {
						  list13 = "Pager";
					  }*/
			  
			  list14 = getParameter("list14");
/*			          if (list14 == null) {
						  list14 = "Walkman";
					  }*/
				
			  list15 = getParameter("list15");
/*			          if (list15 == null) {
						  list15 = "Mobile Phone";
					  }*/
			  
			  list16 = getParameter("list16");
/*			          if (list16 == null) {
						  list16 = "Tape Player";
					  }*/
					
			  list17 = getParameter("list17");
			  list18 = getParameter("list18");
			  list19 = getParameter("list19");
			  list20 = getParameter("list20");
			  list21 = getParameter("list21");
			  list22 = getParameter("list22");
			  list23 = getParameter("list23");
			  list24 = getParameter("list24");
			  list25 = getParameter("list25");
			  list26 = getParameter("list26");
			  list27 = getParameter("list27");
			  list28 = getParameter("list28");
			  list29 = getParameter("list29");
			  list30 = getParameter("list30");
			  
			  button1 = getParameter("button1");
					  if (button1 == null) {
						  button1 = "Previous";
					  }
			  
			  button2 = getParameter("button2");
					  if (button2 == null) {
						  button2 = "Next";
					  }
					
			  button3 = getParameter("button3");
					  if (button3 == null) {
						  button3 = "Home Page";
					  }
					
			  button4 = getParameter("button4");
					  if (button4 == null) {
						  button4 = "COST";
					  }
					
			  button5 = getParameter("button5");
					  if (button5 == null) {
						  button5 = "BUY";
					  }
			
			  button6 = getParameter("button6");
			          if (button6 == null) {
						  button6 = "Play Audio";
					  }
				
			  button7 = getParameter("button7");
			          if (button7 == null) {
						  button7 = "Stop Audio";
					  }

			  id1 = getParameter("id1");
			  name1 = getParameter("list1");
	 		  cost1 = getParameter("cost1");
			  sound1 = getParameter("sound1");
	
	          id2 = getParameter("id2");
			  name2 = getParameter("list2");
	 		  cost2 = getParameter("cost2");
			  sound2 = getParameter("sound2");
			
	 		  id3 = getParameter("id3");
			  name3 = getParameter("list3");
	 		  cost3 = getParameter("cost3");
			  sound3 = getParameter("sound3");
			
	          id4 = getParameter("id4");
			  name4 = getParameter("list4");
	 		  cost4 = getParameter("cost4");
			  sound4 = getParameter("sound4");
			
	          id5 = getParameter("id5");
			  name5 = getParameter("list5");
	 		  cost5 = getParameter("cost5");
			  sound5 = getParameter("sound5");
			
			  id6 = getParameter("id6");
			  name6 = getParameter("list6");
	 		  cost6 = getParameter("cost6");
			  sound6 = getParameter("sound6");
			
	  		  id7 = getParameter("id7");
			  name7 = getParameter("list7");
	 		  cost7 = getParameter("cost7");
			  sound7 = getParameter("sound7");
			
	          id8 = getParameter("id8");
			  name8 = getParameter("list8");
	 		  cost8 = getParameter("cost8");
			  sound8 = getParameter("sound8");
			
			  id9 = getParameter("id9");
			  name9 = getParameter("list9");
	 		  cost9 = getParameter("cost9");
			  sound9 = getParameter("sound9");
			
	          id10 = getParameter("id10");
			  name10 = getParameter("list10");
	 		  cost10 = getParameter("cost10");		
			  sound10 = getParameter("sound10");
						
			  id11 = getParameter("id11");
			  name11 = getParameter("list11");
	 		  cost11 = getParameter("cost11");
			  sound11 = getParameter("sound11");
			
			  id12 = getParameter("id12");
			  name12 = getParameter("list12");
	 		  cost12 = getParameter("cost12");
			  sound12 = getParameter("sound12");
			
			  id13 = getParameter("id13");
			  name13 = getParameter("list13");
	 		  cost13 = getParameter("cost13");
		      sound13 = getParameter("sound13");
			
			  id14 = getParameter("id14");
			  name14 = getParameter("list14");
	 		  cost14 = getParameter("cost14");
			  sound14 = getParameter("sound14");
			
			  id15 = getParameter("id15");
			  name15 = getParameter("list15");
	 		  cost15 = getParameter("cost15");
			  sound15 = getParameter("sound15");
			
			  id16 = getParameter("id16");
			  name16 = getParameter("list16");
	 		  cost16 = getParameter("cost16");
			  sound16 = getParameter("sound16");
			
			  id17 = getParameter("id17");
			  name17 = getParameter("list17");
	 		  cost17 = getParameter("cost17");
			  sound17 = getParameter("sound17");
	
	          id18 = getParameter("id18");
			  name18 = getParameter("list18");
	 		  cost18 = getParameter("cost18");
			  sound18 = getParameter("sound18");
			
	 		  id19 = getParameter("id19");
			  name19 = getParameter("list19");
	 		  cost19 = getParameter("cost19");
			  sound19 = getParameter("sound19");
			
	          id20 = getParameter("id20");
			  name20 = getParameter("list20");
	 		  cost20 = getParameter("cost20");
			  sound20 = getParameter("sound20");
			
	          id21 = getParameter("id21");
			  name21 = getParameter("list21");
	 		  cost21 = getParameter("cost21");
			  sound21 = getParameter("sound21");
			
			  id22 = getParameter("id22");
			  name22 = getParameter("list22");
	 		  cost22 = getParameter("cost22");
			  sound22 = getParameter("sound22");
			
	  		  id23 = getParameter("id23");
			  name23 = getParameter("list23");
	 		  cost23 = getParameter("cost23");
			  sound23 = getParameter("sound23");
			
	          id24 = getParameter("id24");
			  name24 = getParameter("list24");
	 		  cost24 = getParameter("cost24");
			  sound24 = getParameter("sound24");
			
			  id25 = getParameter("id25");
			  name25 = getParameter("list25");
	 		  cost25 = getParameter("cost25");
			  sound25 = getParameter("sound25");
			
	          id26 = getParameter("id26");
			  name26 = getParameter("list26");
	 		  cost26 = getParameter("cost26");		
			  sound26 = getParameter("sound26");
						
			  id27 = getParameter("id27");
			  name27 = getParameter("list27");
	 		  cost27 = getParameter("cost27");
			  sound27 = getParameter("sound27");
			
			  id28 = getParameter("id28");
			  name28 = getParameter("list28");
	 		  cost28 = getParameter("cost28");
			  sound28 = getParameter("sound28");
			
			  id29 = getParameter("id29");
			  name29 = getParameter("list29");
	 		  cost29 = getParameter("cost29");
		      sound29 = getParameter("sound29");
			
			  id30 = getParameter("id30");
			  name30 = getParameter("list30");
	 		  cost30 = getParameter("cost30");
			  sound30 = getParameter("sound31");
			
			  label1 = getParameter("label1");
	                 if (label1 == null) {
						 label1 = "PRODUCT";
				     }
			  
			  label2 = getParameter("label2");
			         if (label2 == null) {
						 label2 = "INFORMATION";
					 }
					
			  label3 = getParameter("label3");
			         if (label3 == null) {
						 label3 = "MULTIMEDIA";
					 }
					
			  label4 = getParameter("label4");
					 if (label4 == null) {
						 label4 = "Product ID";
				     }
					
			  label5 = getParameter("label5");
					 if (label5 == null) {
						 label5 = "NAME";
					 }
					
			  label6 = getParameter("label6");
	                 if 
					(label6 == null) {
						 label6 = "COST";
				     }
			  
			  label7 = getParameter("label7");
			         if (label7 == null) {
						 label7 = "TEL.";
					 }
					
			  label8 = getParameter("label8");
			         if (label8 == null) {
						 label8 = "FAX.";
					 }
					
			  label9 = getParameter("label9");
					 if (label9 == null) {
						 label9 = "CARD NO.";
				     }
					
			  label10 = getParameter("label10");
					  if (label10 == null) {
						 label10 = "PASSWORD";
					  }
				
			  label11 = getParameter("label11");
					  if (label11 == null) {
						  label11 = "AMOUNT";											
					  }
					
			  label12 = getParameter("label12");
					  if (label12 == null) {
						  label12 = "SUM";
					  }
					
			  chkbx1 = getParameter("chkbx1");
			         if (chkbx1 == null) {
						 chkbx1 = "Show Picture";
					 }
					
			  cost1 = getParameter("cost1");
			  cost2 = getParameter("cost2");
			  cost3 = getParameter("cost3");
			  cost4 = getParameter("cost4");
			  cost5 = getParameter("cost5");
			  cost6 = getParameter("cost6");
			  cost7 = getParameter("cost7");
			  cost8 = getParameter("cost8");
			  cost9 = getParameter("cost9");
			  cost10 = getParameter("cost10");
			  cost11 = getParameter("cost11");
			  cost12 = getParameter("cost12");
			  cost13 = getParameter("cost13");
			  cost14 = getParameter("cost14");
			  cost15 = getParameter("cost15");
			  cost16 = getParameter("cost16");
			
			  ProductLabel = new Label(label1, Label.CENTER);
			  
	   		  ProductList = new List(10, false);
	   		  ProductList.addItem(list1);
			  ProductList.addItem(list2);
	   		  ProductList.addItem(list3);
			  ProductList.addItem(list4);
			  ProductList.addItem(list5);
			  ProductList.addItem(list6);
	   		  ProductList.addItem(list7);
			  ProductList.addItem(list8);
			  ProductList.addItem(list9);
			  ProductList.addItem(list10);
			  ProductList.addItem(list11);
			  ProductList.addItem(list12);
	   		  ProductList.addItem(list13);
			  ProductList.addItem(list14);
			  ProductList.addItem(list15);
			  ProductList.addItem(list16);
			  ProductList.addItem(list17);
			  ProductList.addItem(list18);
			  ProductList.addItem(list19);
			  ProductList.addItem(list20);
			  ProductList.addItem(list21);
	   		  ProductList.addItem(list22);
			  ProductList.addItem(list23);
			  ProductList.addItem(list24);
			  ProductList.addItem(list25);
			  ProductList.addItem(list26);
			  ProductList.addItem(list27);
	   		  ProductList.addItem(list28);
			  ProductList.addItem(list29);
			  ProductList.addItem(list30);			
			
			  PrevButton = new Button(button1);  
			  NextButton = new Button(button2);
			
			  InformationLabel = new Label(label2);			  
						  			
			  IDLabel = new Label(label4, Label.CENTER);
			  IDField = new TextField();
			 
			  NameLabel = new Label(label5, Label.CENTER);
			  NameField = new TextField();
			
			  InfoLabel = new Label(label6, Label.CENTER);
			  InfoArea = new TextArea(5,40);
			
//			  TelLabel = new Label(label7, Label.CENTER);
//			  TelField = new TextField(40);
			
//			  FaxLabel = new Label(label8, Label.CENTER);
//			  FaxField = new TextField(40);
			
			  EmailLabel = new Label(label9, Label.CENTER);
			  EmailField = new TextField();
			
			  AddressLabel = new Label(label10, Label.CENTER);
			  AddressField = new TextField(40);
			  AddressField.setEchoCharacter('*');
			
			  OtherLabel = new Label(label11, Label.CENTER);
//			  OtherArea = new TextArea(5,40);
			  AmountField = new TextField(40);
			
			  SumLabel = new Label(label12, Label.CENTER);
			  SumField = new TextField(40);
						  
			  SendEMailButton = new Button(button3);
			  HomePageButton = new Button(button4);
			  BUYButton = new Button(button5);	

			  MultimediaLabel = new Label(label3,Label.CENTER);
			  ShowPicCheck = new Checkbox(chkbx1);
			  PlayAudioButton = new Button(button6);
              StopAudioButton = new Button(button7); 					  			
			  
			  add(ProductLabel);
	    	  add(ProductList);
			  add(PrevButton);
			  add(NextButton);
			
			  add(InformationLabel);
			
			  add(IDLabel);
			  add(IDField);
			  add(NameLabel);
			  add(NameField);
			  add(InfoLabel);
			  add(InfoArea);
//			  add(TelLabel);
//			  add(TelField); 
//			  add(FaxLabel);
//			  add(FaxField);
			  add(EmailLabel);
			  add(EmailField);
			  add(AddressLabel);
			  add(AddressField);
              add(OtherLabel);
//              add(OtherArea);			  
			  add(AmountField);
			  add(SumLabel);
			  add(SumField);
			
			  add(SendEMailButton);
			  add(HomePageButton);
			  add(BUYButton);
			  
			  add(MultimediaLabel);			  
			  add(ShowPicCheck);
			  add(PlayAudioButton);
			  add(StopAudioButton);

			  audio  = getAudioClip(getCodeBase(),sound1);
			  audio1 = getAudioClip(getCodeBase(),sound1);
			  audio2 = getAudioClip(getCodeBase(),"spacemusic.au");
			  audio3 = getAudioClip(getCodeBase(),"bong.au");
			  audio4 = getAudioClip(getCodeBase(),"gong.au");
/*		      audio5 = getAudioClip(getCodeBase(),sound5);
			  audio6 = getAudioClip(getCodeBase(),sound6);
			  audio7 = getAudioClip(getCodeBase(),sound7);
			  audio8 = getAudioClip(getCodeBase(),sound8);
		      audio9 = getAudioClip(getCodeBase(),sound9);
			  audio10 = getAudioClip(getCodeBase(),sound10);
			  audio11 = getAudioClip(getCodeBase(),sound11);
			  audio12 = getAudioClip(getCodeBase(),sound12);
		      audio13 = getAudioClip(getCodeBase(),sound13);
			  audio14 = getAudioClip(getCodeBase(),sound14);
			  audio15 = getAudioClip(getCodeBase(),sound15);
			  audio16 = getAudioClip(getCodeBase(),sound16);	*/
			  
			  indexChoice = ProductList.getSelectedIndex();
			
			  validate();	   
	   }
	
	   public void paint(Graphics g) {
       		  Dimension d = size();
       		  g.drawRect(0,0, d.width - 1, d.height - 1);
			  g.drawRect(15,50,165,280);
			  g.drawRect(195,50,260,140);
			  g.drawRect(195,202,260,128);
//	    	  g.drawRect(470,50,165,280);
			
			  ProductLabel.reshape(45,52,100,20);
			  ProductList.reshape(20,83,155,160);
			  PrevButton.reshape(20,295,77,30);
			  NextButton.reshape(98,295,77,30);
			
			  InformationLabel.reshape(277,52,101,20);  
			  IDLabel.reshape(200,83,82,20);
	          IDField.reshape(283,83,167,20);		
			  NameLabel.reshape(200,104,82,20);
			  NameField.reshape(283,104,167,20);
			  InfoLabel.reshape(200,125,82,20);
			  InfoArea.reshape(283,125,167,60);
//			  TelLabel.reshape(200,186,30,20);
//			  TelField.reshape(231,186,96,20);
//			  FaxLabel.reshape(323,186,30,20);
//			  FaxField.reshape(354,186,96,20);
			
			  
			  EmailLabel.reshape(200,207,82,20);
	          EmailField.reshape(283,207,167,20);		  
			  AddressLabel.reshape(200,228,82,20);
	          AddressField.reshape(283,228,167,20);
	          OtherLabel.reshape(200,249,100,20);
//	          OtherArea.reshape(283,249,167,45);		
			  AmountField.reshape(300,249,150,20);
			  SumLabel.reshape(200,270,100,20);
			  SumField.reshape(300,270,150,20);
			
			  SendEMailButton.reshape(200,295,82,30);
     		  HomePageButton.reshape(283,295,82,30);
              BUYButton.reshape(366,295,82,30);     
			  Font f = new Font("TimesRoman", Font.BOLD, 30);			  
			  g.setColor(Color.red);
			  g.setFont(f);
			  g.drawString("IKKE SHOP",150,40);
			  Font f1 = new Font("Helvetica",Font.BOLD,16);
			  g.setFont(f1);
			  g.drawString("Choose the good you would like to buy...",20,380);
			  
//			  MultimediaLabel.reshape(480,52,155,20); 
//			  g.drawImage(image1,480,62,this);
//              ShowPicCheck.reshape(480,233,150,30);
//              PlayAudioButton.reshape(475,264,155,30);
//              StopAudioButton.reshape(475,295,155,30);      		  
			  
/*			  g.drawImage(image2,485 ,83 ,150 ,117, this);*/
	   }
		 
	   public String GetMember(){
			  String key0get;
              
			  key0get = key0; 	          
			  return key0get;
	   }
	
	   public String Getkey1() {
			  String key1get;
			  
			  key1get = key1;
			  return key1get;
	   }
		
	   public String Getkey2() {
			  String key2get;
			  
			  key2get = key2;
			  return key2get;			
	   }
	
	   public String Getkey3() {
			  String key3get;
				
		      key3get = key3;
			  return key3get;
	   }
	
	   public String Getkey4() {
			  String key4get;
				
			  key4get = key4;
			  return key4get;
	   }		
	 
	   public String GetName() {
		      String name;
				
			  name = NameField.getText();
			  return name;
	   }
	
	   public String GetPsswd() {
	 		  String Psswd;
			
		      Psswd = AddressField.getText();			
	          return Psswd;
	   }
	  
	   public String GetCardNo() {
			  String CardNo;
			 
			  CardNo = EmailField.getText();
			  return CardNo;
	   }
	
	   public String GetAmount() {
			  String amount;
			
			  amount = AmountField.getText();
			  return amount;
	   }		      		
	
	   public String GetCost() {
			  String cost;
			  
			  cost = InfoArea.getText();
			  return cost;
	   }
	   	
	   public int RandomNumber(int Upper,int Lower) {
			  int randomm = (int)(Math.random() * (Upper - Lower) + Lower);			  
			  return randomm;
	   }
	   	
	   public int ComputeCost(String cost, String amount) {		
			  String test;
			
			  int costthis = Integer.parseInt(cost);
			  int amountthis = Integer.parseInt(amount);	           
			  int sum = costthis * amountthis;			  
			  return sum;
	   }

	   public long Encryption(String E, String N, String M) {
		      int[] arrayofE = new int[14];
			  double Encrypt;
	          int TempX,TempTest;	
				  				     		  
			  int TempTest1,TempTest2,TempTest3,TempTest4,TempTest5;
			  int TempTest6,TempTest7,TempTest8,TempTest9,TempTest10;
			  int TempTest11,TempTest12,TempTest13;
			  
			  long Nusr = Long.parseLong(N);
			  long Eusr = Long.parseLong(E);			 

//change E to binary
					  
	          for (int i = 0; i < 14; i++) {
				   if ((Eusr / (Math.pow(2, (14-(i+1))))) >= 1) {			
				       arrayofE[i] = 1;
				   }		      
				   else arrayofE[i] = 0;
				   if (Eusr >= (Math.pow(2, 14-(i+1)))) {				
				       Eusr = Eusr - (long)(Math.pow(2, 14-(i+1)));
				   }
	          }		  

			  int Message = Integer.parseInt(M);			  		
			  long TempM = 1;
			  for (int i = 0; i < 14 ; i++) {
			      TempM = TempM * TempM;
			      TempM = TempM % Nusr;				
				
			   	  if (arrayofE[i] == 1 ){
					 TempM = TempM * Message;										
				  }
				  TempM = TempM % Nusr;				
			  }
		
  			  return TempM;			      
   	   }					 
		
	   public String Sending(String Eusr,String Nusr,String Eserv,String Nserv, String M0, String M1, String M2, String M3, String M4) {
			  String sending;
			
			  String send0 = String.valueOf(Encryption(Eserv,Nserv,M0));
              String send1 = String.valueOf(Encryption(Eserv,Nserv,M1));
              String send2 = String.valueOf(Encryption(Eserv,Nserv,M2));
			  String send3 = String.valueOf(Encryption(Eserv,Nserv,M3));
			  String send4 = String.valueOf(PasswdEncrypt(M4));
			  String send5 = String.valueOf(Encryption(Eserv,Nserv,String.valueOf(KEYENCRYPT)));
			  String send6 = String.valueOf(Encryption(Eusr,Nusr,send1));			  
			  String send7 = String.valueOf(Encryption(Eusr,Nusr,send2));
			  String send8 = String.valueOf(Encryption(Eusr,Nusr,send3));
			  String send9 = String.valueOf(Encryption(Eusr,Nusr,send5));
			
			  sending = "0=" + send0 + "&1=" + send1 + "&2=" + send2 + "&3=" + send3 + "&4=" + send4 + "&5=" + send5 + "&6=" + send6 + "&7=" + send7 + "&8=" + send8 + "&9=" + send9;			
			
			  return sending;
 	   }
	
	   public boolean action(Event evt, Object arg) {			  
			  if (arg.equals("Home Page")) {			     
				  URL url;
				  String data;
				  String u = "http://161.246.6.105/mr_post/mrp1.html";
					 
//					 data = GetAddress();					 
					 data = u;
					 try {
						 url = new URL(data);
						 getAppletContext().showDocument(url);
						 }
					 catch (MalformedURLException e) {
					     System.out.println("Error " + e);
					 }
				 return true;
			  }
						
			  if(arg.equals("BUY")) {
				     URL url;
					 String data;
					 String u = "http://161.246.6.105/cgi-win/Laem-sample/vb/vb12/vb1.exe/";
			
			         data = Sending(key1,key2,key3,key4,key0,IDField.getText(),AmountField.getText(),EmailField.getText(),AddressField.getText());         		 
					 try {
						 url = new URL(u + data);
						 getAppletContext().showDocument(url);
						 }
					 catch (MalformedURLException e) {
					     System.out.println("Error " + e);
					 }
				 return true;
			  }	   
			  
			  if (arg.equals("COST")) {			     			   				 
			     
				 SumField.setText(String.valueOf(ComputeCost(GetCost(),GetAmount())));
				 return true;			  	 				 						     
			  }
			  
			  if (arg.equals("Next")) {
			
				 indexChoice = indexChoice + 1;
				 ProductList.select(indexChoice);
				 return true;
			  }
			  
			  if (arg.equals("Previous")) {
			
				 indexChoice = indexChoice - 1;
				 ProductList.select(indexChoice);
			     return true;
			  }
			  if (arg.equals("Play Audio")) {
				 audio.play();
				 return true;
			  }
			  
			  if (arg.equals("Stop Audio")) {
				 audio.stop();
				 return true;
			  }
			 
/*			  if (arg.equals(list1)) {
				 indexChoice = ProductList.getSelectedIndex();
				 IDField.setText(id1);
				 NameField.setText(name1);
				 InfoArea.setText(cost1);
				 audio = audio1;				 
			     return true;
              }	*/
			
			  if (indexChoice == 1) {
			     IDField.setText(id1);
				 NameField.setText(name1);
				 InfoArea.setText(cost1);
				 audio = audio1;
				 return true;
			  }

/*			  if (arg.equals(list2)) {
			     indexChoice = ProductList.getSelectedIndex();
				 IDField.setText(id2);
				 NameField.setText(name2);
				 InfoArea.setText(cost2);
				 audio = audio2;
			     return true;
              }	*/
			
			  if (indexChoice == 2) {
//			     indexChoice = ProductList.getSelectedIndex();
				 IDField.setText(id2);
				 NameField.setText(name2);
				 InfoArea.setText(cost2);
				 audio = audio2;
			     return true;
              }	


			  if (arg.equals(list3)) {
			     indexChoice = ProductList.getSelectedIndex();
				 IDField.setText(id3);
				 NameField.setText(name3);
				 InfoArea.setText(cost3);
				 audio = audio3;
			     return true;
              }	

			  if (arg.equals(list4)) {
			     indexChoice = ProductList.getSelectedIndex();
				 IDField.setText(id4);
				 NameField.setText(name4);
				 InfoArea.setText(cost4);
				 audio = audio4;
			     return true;
              }	
	
		      if (arg.equals(list5)) {
			     indexChoice = ProductList.getSelectedIndex();
				 IDField.setText(id5);
				 NameField.setText(name5);
				 InfoArea.setText(cost5);
				 audio = audio5;
			     return true;
              }	

			  if (arg.equals(list6)) {
				 indexChoice = ProductList.getSelectedIndex();
				 IDField.setText(id6);
				 NameField.setText(name6);
				 InfoArea.setText(cost6);
				 audio = audio6;
			     return true;
              }	

			  if (arg.equals(list7)) {
			     indexChoice = ProductList.getSelectedIndex();
				 IDField.setText(id7);
				 NameField.setText(name7);
				 InfoArea.setText(cost7);
				 audio = audio7;
			     return true;
              }	

			  if (arg.equals(list8)) {
			     indexChoice = ProductList.getSelectedIndex();
				 IDField.setText(id8);
				 NameField.setText(name8);
				 InfoArea.setText(cost8);
				 audio = audio8;
			     return true;
              }	

			  if (arg.equals(list9)) {
				 indexChoice = ProductList.getSelectedIndex();
				 IDField.setText(id9);
				 NameField.setText(name9);
				 InfoArea.setText(cost9);
				 audio = audio9;
			     return true;
              }	

			  if (arg.equals(list10)) {
				 indexChoice = ProductList.getSelectedIndex();
				 IDField.setText(id10);
				 NameField.setText(name10);
				 InfoArea.setText(cost10);
				 audio = audio10;
			     return true;
              }	

			  if (arg.equals(list11)) {
				 indexChoice = ProductList.getSelectedIndex();
				 IDField.setText(id11);
				 NameField.setText(name11);
				 InfoArea.setText(cost11);
				 audio = audio11;
			     return true;
              }	

			  if (arg.equals(list12)) {
				 indexChoice = ProductList.getSelectedIndex();
				 IDField.setText(id12);
				 NameField.setText(name12);
				 InfoArea.setText(cost12);
				 audio = audio12;
			     return true;
              }	

			  if (arg.equals(list13)) {
				 indexChoice = ProductList.getSelectedIndex();
				 IDField.setText(id13);
				 NameField.setText(name13);
				 InfoArea.setText(cost13);
				 audio = audio13;
			     return true;
              }	

			  if (arg.equals(list14)) {
				 indexChoice = ProductList.getSelectedIndex();
				 IDField.setText(id14);
				 NameField.setText(name14);
				 InfoArea.setText(cost14);
				 audio = audio14;
			     return true;
              }	

			  if (arg.equals(list15)) {
				 indexChoice = ProductList.getSelectedIndex();
				 IDField.setText(id15);
				 NameField.setText(name15);
				 InfoArea.setText(cost15);
				 audio = audio15;
			     return true;
              }	

			  if (arg.equals(list16)) {
				 indexChoice = ProductList.getSelectedIndex();
				 IDField.setText(id16);
				 NameField.setText(name16);
				 InfoArea.setText(cost16);
				 audio = audio16;
			     return true;
              }	
			
			  if (arg.equals(list17)) {
				 indexChoice = ProductList.getSelectedIndex();
				 IDField.setText(id17);
				 NameField.setText(name17);
				 InfoArea.setText(cost17);
				 audio = audio17;				 
			     return true;
              }	

			  if (arg.equals(list18)) {
				 indexChoice = ProductList.getSelectedIndex();
				 IDField.setText(id18);
				 NameField.setText(name18);
				 InfoArea.setText(cost18);
				 audio = audio18;
			     return true;
              }	

			  if (arg.equals(list19)) {
				 indexChoice = ProductList.getSelectedIndex();
				 IDField.setText(id19);
				 NameField.setText(name19);
				 InfoArea.setText(cost19);
				 audio = audio19;
			     return true;
              }	

			  if (arg.equals(list20)) {
				 indexChoice = ProductList.getSelectedIndex();
				 IDField.setText(id20);
				 NameField.setText(name20);
				 InfoArea.setText(cost20);
				 audio = audio20;
			     return true;
              }	
	
		      if (arg.equals(list21)) {
				 indexChoice = ProductList.getSelectedIndex();
				 IDField.setText(id21);
				 NameField.setText(name21);
				 InfoArea.setText(cost21);
				 audio = audio20;
			     return true;
              }	

			  if (arg.equals(list22)) {
				 indexChoice = ProductList.getSelectedIndex();
				 IDField.setText(id22);
				 NameField.setText(name22);
				 InfoArea.setText(cost22);
				 audio = audio22;
			     return true;
              }	

			  if (arg.equals(list23)) {
				 indexChoice = ProductList.getSelectedIndex();
				 IDField.setText(id23);
				 NameField.setText(name23);
				 InfoArea.setText(cost23);
				 audio = audio23;
			     return true;
              }	

			  if (arg.equals(list24)) {
				 indexChoice = ProductList.getSelectedIndex();
				 IDField.setText(id24);
				 NameField.setText(name24);
				 InfoArea.setText(cost24);
				 audio = audio24;
			     return true;
              }	

			  if (arg.equals(list25)) {
				 indexChoice = ProductList.getSelectedIndex();
				 IDField.setText(id25);
				 NameField.setText(name25);
				 InfoArea.setText(cost25);
				 audio = audio25;
			     return true;
              }	

			  if (arg.equals(list26)) {
				 indexChoice = ProductList.getSelectedIndex();
				 IDField.setText(id26);
				 NameField.setText(name26);
				 InfoArea.setText(cost26);
				 audio = audio26;
			     return true;
              }	

			  if (arg.equals(list27)) {
				 indexChoice = ProductList.getSelectedIndex();
				 IDField.setText(id27);
				 NameField.setText(name27);
				 InfoArea.setText(cost27);
				 audio = audio27;
			     return true;
              }	

			  if (arg.equals(list28)) {
				 indexChoice = ProductList.getSelectedIndex();
				 IDField.setText(id28);
				 NameField.setText(name28);
				 InfoArea.setText(cost28);
				 audio = audio28;
			     return true;
              }	

			  if (arg.equals(list29)) {
				 indexChoice = ProductList.getSelectedIndex();
				 IDField.setText(id29);
				 NameField.setText(name29);
				 InfoArea.setText(cost29);
				 audio = audio29;
			     return true;
              }	
	
			  if (arg.equals(list30)) {
				 indexChoice = ProductList.getSelectedIndex();			
				 IDField.setText(id30);
				 NameField.setText(name30);
				 InfoArea.setText(cost30);
				 audio = audio30;
			     return true;
              }				  					  
			  return false;
	   }
		
	   public int CreateKey(){
			  int key;			  
			  
			  key = RandomNumber(10,1);
			  return key;
			
	   }
	
	   public String PasswdEncrypt(String psswd) {	
			  String temp,test,test2;			  
			  int key,n;			  
			  String result;		   
			
			  n = psswd.length();
//			  keychange = Integer.parseInt(keying);
			  key = CreateKey();		
			  KEYENCRYPT = key;
			  String[] password = new String[n];
			  for (int i = 0; i< n; i++) {
				  password[i] = psswd.substring(i,i+1);
				  int change = ChartoDec(password[i]);
				  change = change + key;
				  if (change > 126) {
					  change = change % 126;
				  }
				  password[i] = DectoChar(change);				  				  				  
			  }
			  result = "";	
 			  for (int i = 0; i< n; i++) {
				  result = result + password[i];
			  }	 			  
			  String cipher = result;		  			  
		      return cipher;			  			  			  
	   }		
	
	   public int ChartoDec (String data) {
			  int Dec;
			  
			  Dec = 1;		
			   			  
			  if (data.compareTo("!") == 0) {
			  	 Dec = 33; 				 			 			
			  }
			  else if (data.compareTo("#") == 0) {
			     Dec = 35;							
			  }
			  else if (data.compareTo("$") == 0) {
				 Dec = 36;				 
			  }			  
			  else if (data.compareTo("%") == 0) {
				 Dec = 37;
			  }
			  else if (data.compareTo("&") == 0) {
			     Dec = 38;							
			  }
			  else if (data.compareTo("'") == 0) {
				 Dec = 39;				 
			  }			  
			  else if (data.compareTo("(") == 0) {
				 Dec = 40;
			  }
			  else if (data.compareTo(")") == 0) {
			     Dec = 41;
			  }
		      else if (data.compareTo("*") == 0) {
			     Dec = 42;							
			  }
			  else if (data.compareTo("+") == 0) {
				 Dec = 43;				 
			  }			  
			  else if (data.compareTo(",") == 0) {
				 Dec = 44;
			  }
			  else if (data.compareTo("-") == 0) {
			     Dec = 45;							
			  }
			  else if (data.compareTo(".") == 0) {
				 Dec = 46;				 
			  }			  
			  else if (data.compareTo("/") == 0) {
				 Dec = 47;
			  }
			  else if (data.compareTo("0") == 0) {
			     Dec = 48;	
			  }
			  else if (data.compareTo("1") == 0) {
			     Dec = 49;							
			  }
			  else if (data.compareTo("2") == 0) {
				 Dec = 50;				 
			  }			  
			  else if (data.compareTo("3") == 0) {
				 Dec = 51;
			  }
			  else if (data.compareTo("4") == 0) {
			     Dec = 52;							
			  }
			  else if (data.compareTo("5") == 0) {
				 Dec = 53;				 
			  }			  
			  else if (data.compareTo("6") == 0) {
				 Dec = 54;
			  }
			  else if (data.compareTo("7") == 0) {
			     Dec = 55;
			  }
		      else if (data.compareTo("8") == 0) {
			     Dec = 56;							
			  }
			  else if (data.compareTo("9") == 0) {
				 Dec = 57;				 
			  }			  
			  else if (data.compareTo(":") == 0) {
				 Dec = 58;
			  }
			  else if (data.compareTo(";") == 0) {
			     Dec = 59;							
			  }
			  else if (data.compareTo("<") == 0) {
				 Dec = 60;				 
			  }			  
			  else if (data.compareTo("=") == 0) {
				 Dec = 61;
			  }
			  else if (data.compareTo(">") == 0) {
			     Dec = 62;	
			  }		
			  else if (data.compareTo("?") == 0) {
			     Dec = 63;							
			  }
			  else if (data.compareTo("@") == 0) {
				 Dec = 64;				 
			  }			  
			  else if (data.compareTo("A") == 0) {
				 Dec = 65;
			  }
			  else if (data.compareTo("B") == 0) {
			     Dec = 66;							
			  }
			  else if (data.compareTo("C") == 0) {
				 Dec = 67;				 
			  }			  
			  else if (data.compareTo("D") == 0) {
				 Dec = 68;
			  }
			  else if (data.compareTo("E") == 0) {
			     Dec = 69;
			  }
		      else if (data.compareTo("F") == 0) {
			     Dec = 70;							
			  }
			  else if (data.compareTo("G") == 0) {
				 Dec = 71;				 
			  }			  
			  else if (data.compareTo("H") == 0) {
				 Dec = 72;
			  }
			  else if (data.compareTo("I") == 0) {
			     Dec = 73;							
			  }
			  else if (data.compareTo("J") == 0) {
				 Dec = 74;				 
			  }			  
			  else if (data.compareTo("K") == 0) {
				 Dec = 75;
			  }
			  else if (data.compareTo("L") == 0) {
			     Dec = 76;	
			  }
			  else if (data.compareTo("M") == 0) {
			     Dec = 77;							
			  }
			  else if (data.compareTo("N") == 0) {
				 Dec = 78;				 
			  }			  
			  else if (data.compareTo("O") == 0) {
				 Dec = 79;
			  }
			  else if (data.compareTo("P") == 0) {
			     Dec = 80;							
			  }
			  else if (data.compareTo("Q") == 0) {
				 Dec = 81;				 
			  }			  
			  else if (data.compareTo("R") == 0) {
				 Dec = 82;
			  }
			  else if (data.compareTo("S") == 0) {
			     Dec = 83;
			  }
		      else if (data.compareTo("T") == 0) {
			     Dec = 84;							
			  }
			  else if (data.compareTo("U") == 0) {
				 Dec = 85;				 
			  }			  
			  else if (data.compareTo("V") == 0) {
				 Dec = 86;
			  }
			  else if (data.compareTo("W") == 0) {
			     Dec = 87;							
			  }
			  else if (data.compareTo("X") == 0) {
				 Dec = 88;				 
			  }			  
			  else if (data.compareTo("Y") == 0) {
				 Dec = 89;
			  }
			  else if (data.compareTo("Z") == 0) {
			     Dec = 90;	
			  }		
			  else if (data.compareTo("[") == 0) {
			     Dec = 91;							
			  }
/*			  else if (data.compareTo("\") == 0) {
				 Dec = 92;				 
			  }			  */
			  else if (data.compareTo("]") == 0) {
				 Dec = 93;
			  }
			  else if (data.compareTo("^") == 0) {
			     Dec = 94;							
			  }
			  else if (data.compareTo("_") == 0) {
				 Dec = 95;				 
			  }			  
			  else if (data.compareTo("a") == 0) {
				 Dec = 97;
			  }
			  else if (data.compareTo("b") == 0) {
			     Dec = 98;
			  }
		      else if (data.compareTo("c") == 0) {
			     Dec = 99;							
			  }
			  else if (data.compareTo("d") == 0) {
				 Dec = 100;				 
			  }			  
			  else if (data.compareTo("e") == 0) {
				 Dec = 101;
			  }
			  else if (data.compareTo("f") == 0) {
			     Dec = 102;							
			  }
			  else if (data.compareTo("g") == 0) {
				 Dec = 103;				 
			  }			  
			  else if (data.compareTo("h") == 0) {
				 Dec = 104;
			  }
			  else if (data.compareTo("i") == 0) {
			     Dec = 105;	
			  }
			  else if (data.compareTo("j") == 0) {
			     Dec = 106;							
			  }
			  else if (data.compareTo("k") == 0) {
				 Dec = 107;				 
			  }			  
			  else if (data.compareTo("l") == 0) {
				 Dec = 108;
			  }
			  else if (data.compareTo("m") == 0) {
			     Dec = 109;							
			  }
			  else if (data.compareTo("n") == 0) {
				 Dec = 110;				 
			  }			  
			  else if (data.compareTo("o") == 0) {
				 Dec = 111;
			  }
			  else if (data.compareTo("p") == 0) {
			     Dec = 112;
			  }
		      else if (data.compareTo("q") == 0) {
			     Dec = 113;							
			  }
			  else if (data.compareTo("r") == 0) {
				 Dec = 114;				 
			  }			  
			  else if (data.compareTo("s") == 0) {
				 Dec = 115;
			  }
			  else if (data.compareTo("t") == 0) {
			     Dec = 116;							
			  }
			  else if (data.compareTo("u") == 0) {
				 Dec = 117;				 
			  }			  
			  else if (data.compareTo("v") == 0) {
				 Dec = 118;
			  }
			  else if (data.compareTo("w") == 0) {
			     Dec = 119;	
			  }		
			  else if (data.compareTo("x") == 0) {
			     Dec = 120;							
			  }
			  else if (data.compareTo("y") == 0) {
				 Dec = 121;				 
			  }			  
			  else if (data.compareTo("z") == 0) {
				 Dec = 122;
			  }
			  else if (data.compareTo("{") == 0) {
			     Dec = 123;							
			  }
			  else if (data.compareTo("|") == 0) {
				 Dec = 124;				 
			  }			  
			  else if (data.compareTo("}") == 0) {
				 Dec = 125;
			  }
			  else if (data.compareTo("~") == 0) {
			     Dec = 126;
			  }		      
			  
			  return Dec;				  
	   }	 				  			  	   
	
	   public String DectoChar(int data) {
	          String CHAR;
			  
			  CHAR = "";
			  if (data == 33) {
			  	 CHAR = "!"; 				 			 			
			  }
			  else if (data == 35) {
			     CHAR = "#";							
			  }
			  else if (data == 36) {
				 CHAR = "$";				 
			  }			  
			  else if (data == 37) {
				 CHAR = "%";
			  }
			  else if (data == 38) {
			     CHAR = "&";							
			  }
			  else if (data == 39) {
				 CHAR = "'";				 
			  }			  
			  else if (data == 40) {
				 CHAR = "(";
			  }
			  else if (data == 41) {
			     CHAR = ")";
			  }
		      else if (data == 42) {
			     CHAR = "*";							
			  }
			  else if (data == 43) {
				 CHAR = "+";				 
			  }			  
			  else if (data == 44) {
				 CHAR = ",";
			  }
			  else if (data == 45) {
			     CHAR = "-";							
			  }
			  else if (data == 46) {
				 CHAR = ".";				 
			  }			  
			  else if (data == 47) {
				 CHAR = "/";
			  }
			  else if (data == 48) {
			     CHAR = "0";	
			  }
			  else if (data == 49) {
			     CHAR = "1";							
			  }
			  else if (data == 50) {
				 CHAR = "2";				 
			  }			  
			  else if (data == 51) {
				 CHAR = "3";
			  }
			  else if (data == 52) {
			     CHAR = "4";							
			  }
			  else if (data == 53) {
				 CHAR = "5";				 
			  }			  
			  else if (data == 54) {
				 CHAR = "6";
			  }
			  else if (data == 55) {
			     CHAR = "7";
			  }
		      else if (data == 56) {
			     CHAR = "8";							
			  }
			  else if (data == 57) {
				 CHAR = "9";				 
			  }			  
			  else if (data == 58) {
				 CHAR = ":";
			  }
			  else if (data == 59) {
			     CHAR = ";";							
			  }
			  else if (data == 60) {
				 CHAR = "<";				 
			  }			  
			  else if (data == 61) {
				 CHAR = "=";
			  }
			  else if (data == 62) {
			     CHAR = ">";	
			  }		
			  else if (data == 63) {
			     CHAR = "?";							
			  }
			  else if (data == 64) {
				 CHAR = "@";				 
			  }			  
			  else if (data == 65) {
				 CHAR = "A";
			  }
			  else if (data == 66) {
			     CHAR = "B";							
			  }
			  else if (data == 67) {
				 CHAR = "C";				 
			  }			  
			  else if (data == 68) {
				 CHAR = "D";
			  }
			  else if (data == 69) {
			     CHAR = "E";
			  }
		      else if (data == 70) {
			     CHAR = "F";							
			  }
			  else if (data == 71) {
				 CHAR = "G";				 
			  }			  
			  else if (data == 72) {
				 CHAR = "H";
			  }
			  else if (data == 73) {
			     CHAR = "I";							
			  }
			  else if (data == 74) {
				 CHAR = "J";				 
			  }			  
			  else if (data == 75) {
				 CHAR = "K";
			  }
			  else if (data == 76) {
			     CHAR = "L";	
			  }
			  else if (data == 77) {
			     CHAR = "M";							
			  }
			  else if (data == 78) {
				 CHAR = "N";				 
			  }			  
			  else if (data == 79) {
				 CHAR = "O";
			  }
			  else if (data == 80) {
			     CHAR = "P";							
			  }
			  else if (data== 81) {
				 CHAR = "Q";				 
			  }			  
			  else if (data == 82) {
				 CHAR = "R";
			  }
			  else if (data == 83) {
			     CHAR = "S";
			  }
		      else if (data == 84) {
			     CHAR = "T";							
			  }
			  else if (data == 85) {
				 CHAR = "U";				 
			  }			  
			  else if (data == 86) {
				 CHAR = "V";
			  }
			  else if (data == 87) {
			     CHAR = "W";							
			  }
			  else if (data == 88) {
				 CHAR = "X";				 
			  }			  
			  else if (data == 89) {
				 CHAR = "Y";
			  }
			  else if (data == 90) {
			     CHAR = "Z";	
			  }		
			  else if (data == 91) {
			     CHAR = "[";							
			  }
/*			  else if (data == 92) {
				 CHAR = "\";				 
			  }			  */
			  else if (data == 93) {
				 CHAR = "]";
			  }
			  else if (data == 94) {
			     CHAR = "^";							
			  }
			  else if (data == 95) {
				 CHAR = "_";				 
			  }			  
			  else if (data == 97) {
				 CHAR = "a";
			  }
			  else if (data == 98) {
			     CHAR = "b";
			  }
		      else if (data == 99) {
			     CHAR = "c";							
			  }
			  else if (data == 100) {
				 CHAR = "d";				 
			  }			  
			  else if (data == 101) {
				 CHAR = "e";
			  }
			  else if (data == 102) {
			     CHAR = "f";							
			  }
			  else if (data == 103) {
				 CHAR = "g";				 
			  }			  
			  else if (data == 104) {
				 CHAR = "h";
			  }
			  else if (data == 105) {
			     CHAR = "i";	
			  }
			  else if (data == 106) {
			     CHAR = "j";							
			  }
			  else if (data == 107) {
				 CHAR = "k";				 
			  }			  
			  else if (data == 108) {
				 CHAR = "l";
			  }
			  else if (data == 109) {
			     CHAR = "m";							
			  }
			  else if (data == 110) {
				 CHAR = "n";				 
			  }			  
			  else if (data == 111) {
				 CHAR = "o";
			  }
			  else if (data == 112) {
			     CHAR = "p";
			  }
		      else if (data == 113) {
			     CHAR = "q";							
			  }
			  else if (data == 114) {                      
				 CHAR = "r";				 
			  }			  
			  else if (data == 115) {
				 CHAR = "s";
			  }
			  else if (data == 116) {
			     CHAR = "t";							
			  }
			  else if (data == 117) {
				 CHAR = "u";				 
			  }			  
			  else if (data == 118) {
				 CHAR = "v";
			  }
			  else if (data == 119) {
			     CHAR = "w";	
			  }		
			  else if (data == 120) {
			     CHAR = "x";							
			  }
			  else if (data == 121) {
				 CHAR = "y";				 
			  }			  
			  else if (data == 122) {
				 CHAR = "z";
			  }
			  else if (data == 123) {
			     CHAR = "{";							
			  }
			  else if (data == 124) {
				 CHAR = "|";				 
			  }			  
			  else if (data == 125) {
				 CHAR = "}";
			  }
			  else if (data == 126) {
			     CHAR = "~";
			  }		      	
					
			  return CHAR;
	   }		
}
