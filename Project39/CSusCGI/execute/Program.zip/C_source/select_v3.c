
/* Result Sets Interface */
#ifndef SQL_CRSR
#  define SQL_CRSR
  struct sql_cursor
  {
    unsigned int curocn;
    void *ptr1;
    void *ptr2;
    unsigned long magic;
  };
  typedef struct sql_cursor sql_cursor;
  typedef struct sql_cursor SQL_CURSOR;
#endif /* SQL_CRSR */

/* Thread Safety */
typedef void * sql_context;
typedef void * SQL_CONTEXT;

/* File name & Package Name */
struct sqlcxp
{
  unsigned short fillen;
           char  filnam[13];
};
static struct sqlcxp sqlfpn =
{
    12,
    "select_v3.pc"
};


static unsigned long sqlctx = 316403;


static struct sqlexd {
   unsigned int   sqlvsn;
   unsigned int   arrsiz;
   unsigned int   iters;
   unsigned int   offset;
   unsigned short selerr;
   unsigned short sqlety;
   unsigned int   unused;
            short *cud;
   unsigned char  *sqlest;
            char  *stmt;
   unsigned char  **sqphsv;
   unsigned int   *sqphsl;
            short **sqpind;
   unsigned int   *sqparm;
   unsigned int   **sqparc;
   unsigned char  *sqhstv[3];
   unsigned int   sqhstl[3];
            short *sqindv[3];
   unsigned int   sqharm[3];
   unsigned int   *sqharc[3];
} sqlstm = {8,3};

/* Prototypes */
extern sqlcxt (/*_ void **, unsigned long *,
                   struct sqlexd *, struct sqlcxp * _*/);
extern sqlcx2t(/*_ void **, unsigned long *,
                   struct sqlexd *, struct sqlcxp * _*/);
extern sqlbuft(/*_ void **, char * _*/);
extern sqlgs2t(/*_ void **, char * _*/);
extern sqlorat(/*_ void **, unsigned long *, void * _*/);

/* Forms Interface */
static int IAPSUCC = 0;
static int IAPFAIL = 1403;
static int IAPFTL  = 535;
extern sqliem(/*_ char *, int * _*/);

typedef struct { unsigned short len; unsigned char arr[1]; } VARCHAR;
typedef struct { unsigned short len; unsigned char arr[1]; } varchar;

/* cud (compilation unit data) array */
static short sqlcud0[] =
{8,4130,
2,0,0,1,0,0,27,363,0,3,3,0,1,0,1,97,0,0,1,97,0,0,1,97,0,0,
28,0,0,2,105,0,4,374,0,3,2,0,1,0,2,9,0,0,1,9,0,0,1,9,0,0,
54,0,0,3,102,0,4,379,0,3,2,0,1,0,2,9,0,0,1,9,0,0,1,9,0,0,
80,0,0,4,103,0,4,384,0,3,2,0,1,0,2,9,0,0,1,9,0,0,1,9,0,0,
106,0,0,5,105,0,4,389,0,3,2,0,1,0,2,9,0,0,1,9,0,0,1,9,0,0,
132,0,0,6,0,0,30,393,0,0,0,0,1,0,
146,0,0,7,105,0,4,403,0,3,2,0,1,0,2,9,0,0,1,9,0,0,1,9,0,0,
172,0,0,8,102,0,4,408,0,3,2,0,1,0,2,9,0,0,1,9,0,0,1,9,0,0,
198,0,0,9,103,0,4,413,0,3,2,0,1,0,2,9,0,0,1,9,0,0,1,9,0,0,
224,0,0,10,105,0,4,418,0,3,2,0,1,0,2,9,0,0,1,9,0,0,1,9,0,0,
250,0,0,11,0,0,30,422,0,0,0,0,1,0,
264,0,0,12,105,0,4,432,0,3,2,0,1,0,2,9,0,0,1,9,0,0,1,9,0,0,
290,0,0,13,102,0,4,437,0,3,2,0,1,0,2,9,0,0,1,9,0,0,1,9,0,0,
316,0,0,14,103,0,4,442,0,3,2,0,1,0,2,9,0,0,1,9,0,0,1,9,0,0,
342,0,0,15,105,0,4,447,0,3,2,0,1,0,2,9,0,0,1,9,0,0,1,9,0,0,
368,0,0,16,0,0,30,451,0,0,0,0,1,0,
382,0,0,17,105,0,4,461,0,3,2,0,1,0,2,9,0,0,1,9,0,0,1,9,0,0,
408,0,0,18,102,0,4,466,0,3,2,0,1,0,2,9,0,0,1,9,0,0,1,9,0,0,
434,0,0,19,103,0,4,471,0,3,2,0,1,0,2,9,0,0,1,9,0,0,1,9,0,0,
460,0,0,20,105,0,4,476,0,3,2,0,1,0,2,9,0,0,1,9,0,0,1,9,0,0,
486,0,0,21,0,0,30,480,0,0,0,0,1,0,
500,0,0,22,105,0,4,490,0,3,2,0,1,0,2,9,0,0,1,9,0,0,1,9,0,0,
526,0,0,23,102,0,4,495,0,3,2,0,1,0,2,9,0,0,1,9,0,0,1,9,0,0,
552,0,0,24,103,0,4,500,0,3,2,0,1,0,2,9,0,0,1,9,0,0,1,9,0,0,
578,0,0,25,105,0,4,505,0,3,2,0,1,0,2,9,0,0,1,9,0,0,1,9,0,0,
604,0,0,26,0,0,30,509,0,0,0,0,1,0,
618,0,0,27,105,0,4,519,0,3,2,0,1,0,2,9,0,0,1,9,0,0,1,9,0,0,
644,0,0,28,102,0,4,524,0,3,2,0,1,0,2,9,0,0,1,9,0,0,1,9,0,0,
670,0,0,29,103,0,4,529,0,3,2,0,1,0,2,9,0,0,1,9,0,0,1,9,0,0,
696,0,0,30,105,0,4,534,0,3,2,0,1,0,2,9,0,0,1,9,0,0,1,9,0,0,
722,0,0,31,0,0,30,538,0,0,0,0,1,0,
736,0,0,32,105,0,4,548,0,3,2,0,1,0,2,9,0,0,1,9,0,0,1,9,0,0,
762,0,0,33,102,0,4,553,0,3,2,0,1,0,2,9,0,0,1,9,0,0,1,9,0,0,
788,0,0,34,103,0,4,558,0,3,2,0,1,0,2,9,0,0,1,9,0,0,1,9,0,0,
814,0,0,35,105,0,4,563,0,3,2,0,1,0,2,9,0,0,1,9,0,0,1,9,0,0,
840,0,0,36,0,0,30,567,0,0,0,0,1,0,
};


/*  INSERT VERSION 3.0 */

/*  The STUDENT TABLE 
**  FIRST_NAME  VARCHAR2(128) IS NOT NULL
**  LAST_NAME   VARCHAR2(128) IS NOT NULL
**  PHONE_NUM   VARCHAR2(128) IS NOT NULL
**  E_MAIL      VARCHAR2(128) IS NOT NULL
**  ADDRESS     VARCHAR2(128) IS NOT NULL
**  U_COMMENT   VARCHAR2(128) IS NOT NULL
**  (FIRST_NAME,LAST_NAME) IS PRIMARY KEY
*/

#include <stdio.h>
#include <stdlib.h>

/* This is the structure we use 
   for the query-string elements */

#define MAXQELEMENTS (7)



/* The DECLARE Section */
/* EXEC SQL BEGIN DECLARE SECTION; */ 


/*
** Host variables for accessing the STUDENT table.
*/

/* VARCHAR vcFName[30]; */ 
struct { unsigned short len; unsigned char arr[30]; } vcFName;

/* VARCHAR vcLName[30]; */ 
struct { unsigned short len; unsigned char arr[30]; } vcLName;

/* VARCHAR vcPhoneNum[20]; */ 
struct { unsigned short len; unsigned char arr[20]; } vcPhoneNum;

/* VARCHAR vcEmail[50]; */ 
struct { unsigned short len; unsigned char arr[50]; } vcEmail;

/* VARCHAR vcAddress[128]; */ 
struct { unsigned short len; unsigned char arr[128]; } vcAddress;

/* VARCHAR vcComment[128]; */ 
struct { unsigned short len; unsigned char arr[128]; } vcComment;


/*
** Indicator variables for the host variables defined above.
*/

short indFName;
short indLName;
short indPhoneNum;
short indEmail;
short indAddress;
short indComment;

/* EXEC SQL END DECLARE SECTION; */ 

/* End DECLARE Section */


/* The DECLARE Section */
/* EXEC SQL BEGIN DECLARE SECTION; */ 


/* Host variables for logging into the Oracle database */

char scUserName[21]; 
char scPassword[21];
char scDatabaseName[21];

/* EXEC SQL END DECLARE SECTION; */ 

/* End DECLARE Section */


/* The DECLARE Section */
/* EXEC SQL BEGIN DECLARE SECTION; */ 

    
/* VARCHAR  First_variable[128]; */ 
struct { unsigned short len; unsigned char arr[128]; } First_variable;

/* VARCHAR  Last_variable[128]; */ 
struct { unsigned short len; unsigned char arr[128]; } Last_variable;


/* EXEC SQL END DECLARE SECTION; */ 

/* End DECLARE Section */

/* This structure is used for storing data */

struct {
    char name[128]; 
    char val[128];
} elements[MAXQELEMENTS];


/* this is the structure we use
   for SQLCA */

struct sqlca
    {
    char sqlcaid[8];
    long sqlabc;
    long sqlcode;
    struct
        {
        unsigned short sqlerrml;
        char sqlerrmc[70];
        }  sqlerrm;
    char sqlerrp[8];
    long sqlerrd[6];
    char sqlwarn[8];
    char sqlext[8];
    };
struct sqlca sqlca;


void splitword(out,in,stop)
char *out;
char *in;
char stop;
{
int i,j;

for (i =0;in[i] && (in[i] != stop); i++)
    out[i] = in[i];

out[i] = '\0'; /* terminate it */
if (in[i])
    i++;

for (j = 0;in[j]; ) /* shift the rest of the in */
    in[j++] = in[i++];
}


char x2c(x)
char *x;
{
register char c;

/* note: (x & 0xdf) makes x upper case */
c = (x[0] >= 'A' ? ((x[0] & 0xdf) - 'A') + 10 : (x[0] - '0'));
c *= 16;
c += (x[1] >= 'A' ? ((x[1] & 0xdf) - 'A') + 10 : (x[1] - '0'));
return(c);
}

/* this function goes through the URL char-by-char and converts all the "escaped"
   (hex-encoded) sequences to characters
   this version also converts pluses to spaces. */


void unescape_url(url)
char *url;
{
register int i,j;

for (i = 0,j = 0;url[j];++i, ++j)
    {
    if ((url[i] = url[j]) == '%')
       {
        url[i] = x2c(&url[j+1]);
        j += 2;
       }
    else if (url[i] == '+')
       url[i] = ' ';
    }
url[i] = '\0'; /* terminate it at the new length */
}


void handle_error(void)
{
   sqlca.sqlerrm.sqlerrmc[sqlca.sqlerrm.sqlerrml] = '\0';
   
   /* Display error message */
   if (sqlca.sqlcode == -1) 
       {
       printf("<CENTER>");
       printf("<FONT SIZE=+2>REPORT : </FONT>Duplicate key value");
       printf("</CENTER>");
       }
   else
   if (sqlca.sqlcode == -1401) 
       {
       printf("<CENTER>");
       printf("<FONT SIZE=+2>REPORT : </FONT>Value too large");
       printf("</CENTER>");
       }
   else
       {
       printf("<CENTER>");
       printf("<FONT SIZE=+2>REPORT : </FONT>%s",sqlca.sqlerrm.sqlerrmc);
       printf("</CENTER>");
       }
   fflush(stdout);

   printf("<HR WIDTH=500 ALIGN=center SIZE=4>");

   printf("<BR>");
   printf("<CENTER>");
   printf("<A HREF=../../Project/right.html><IMG SRC=../../Project/home.jpg></A>");
   printf("<A HREF=../../Project/about.html><IMG SRC=../../Project/project.jpg></A>");
   printf("<A HREF=../../Project/member.html><IMG SRC=../../Project/member.jpg></A>");
   printf("<A HREF=../../Project/eng.html><IMG SRC=../../Project/comeng.jpg></A>");
   printf("</CENTER>");

   printf("<CENTER>");
   printf("<A HREF=../../Project/inst.html><IMG SRC=../../Project/ins_d.jpg></A>");
   printf("<A HREF=../../Project/upd.html><IMG SRC=../../Project/upd_d.jpg></A>");
   printf("<A HREF=../../Project/slt.html><IMG SRC=../../Project/sel_d.jpg></A>");
   printf("<A HREF=../../Project/del.html><IMG SRC=../../Project/del_d.jpg></A>");
   printf("</CENTER>");

   printf("<CENTER>");
   printf("<A HREF=select_lst.sh.cgi><IMG SRC=../../Project/lst_d.jpg></A>");
   printf("<A HREF=../../Project/query.html><IMG SRC=../../Project/query_d.jpg></A>");
   printf("</CENTER>"); 


   printf("<BR>");

   printf("</BODY>");
   printf("</HTML>");


   exit(0);
}

void handle_not_found(void)
{
   /* Display not found message */
   printf("<CENTER>");
   printf("<FONT SIZE=+2>REPORT : </FONT>Data not found");
   printf("</CENTER>");
   fflush(stdout);

   printf("<HR WIDTH=500 ALIGN=center SIZE=4>");

   printf("<BR>");
   printf("<CENTER>");
   printf("<A HREF=../../Project/right.html><IMG SRC=../../Project/home.jpg></A>");
   printf("<A HREF=../../Project/about.html><IMG SRC=../../Project/project.jpg></A>");
   printf("<A HREF=../../Project/member.html><IMG SRC=../../Project/member.jpg></A>");
   printf("<A HREF=../../Project/eng.html><IMG SRC=../../Project/comeng.jpg></A>");
   printf("</CENTER>");

   printf("<CENTER>");
   printf("<A HREF=../../Project/inst.html><IMG SRC=../../Project/ins_d.jpg></A>");
   printf("<A HREF=../../Project/upd.html><IMG SRC=../../Project/upd_d.jpg></A>");
   printf("<A HREF=../../Project/slt.html><IMG SRC=../../Project/sel_d.jpg></A>");
   printf("<A HREF=../../Project/del.html><IMG SRC=../../Project/del_d.jpg></A>");
   printf("</CENTER>");

   printf("<CENTER>");
   printf("<A HREF=select_lst.sh.cgi><IMG SRC=../../Project/lst_d.jpg></A>");
   printf("<A HREF=../../Project/query.html><IMG SRC=../../Project/query_d.jpg></A>");
   printf("</CENTER>"); 


   printf("<BR>");

   printf("</BODY>");
   printf("</HTML>");


   exit(0);
}



/* MAIN PROGRAM START HERE */
main()
{
char * ct; /* for content-type */
char * cl; /* for content-length */
int   icl; /* content-length */
char * qs; /* query string */
int rc;
int i;


/* The CGI header */

/* fprintf(stdout,"Content-type: text/plain\n"); */
/* fprintf(stdout,"\n\n"); */
/* fflush(stdout); */


printf("<HTML>");
printf("<BODY BGCOLOR=#FFFFFF TEXT=#000000 LINK =#FFFFFF VLINK=#FFFFFF>");

printf("<BR>");
printf("<CENTER>");
printf("<IMG SRC=../../Project/interest2.jpg ALT=Report Page>");
printf("</CENTER>");
printf("<BR>");
printf("<HR WIDTH=500 ALIGN=center SIZE=4>");



/* Set Oracle environment */
putenv("LD_LIBRARY_PATH=/oracle/app/oracle/product/7.3.2/lib"); 
putenv("ORACLE_HOME=/oracle/app/oracle/product/7.3.2"); 
putenv("ORACLE_SID=kmitl1"); 
putenv("ORACLE_TERM=vt100"); 
putenv("MENU5PATH=/oracle/app/oracle/product/7.3.2/forms30/admin/resource"); 
putenv("ORATERMPATH=/oracle/app/oracle/product/7.3.2/forms30/admin/resource");

/* grab the content-type and content-length 
   and check them for validity */

ct = getenv("CONTENT_TYPE");
cl = getenv("CONTENT_LENGTH");
if(cl == NULL)
  {
  printf("Content-length is undefined!%c",10);
  exit(1);
  }
icl = atoi(cl);

/* do we have a valid query? */
if(strcmp(ct, "application/x-www-form-urlencoded"))
  {
  printf("I don't understand the content-type %s%c",ct,10);
  exit(1);
  }
else if (icl == 0)
  {
  printf("Content-length is zero%c",10);
  exit(1);
  }

/* allocate memory for the input stream */
if((qs = malloc(icl + 1)) == NULL)
  {
  printf("Cannot allocate memory, contact the webmaster%c",10);
  exit(1);
  }

if((rc = fread(qs, icl, 1, stdin)) != 1)
  {
  printf("Cannot read the input stream (%d)! Contact the webmaster%c", rc,10);
  exit(1);
  }
qs[icl] = '\0';


/* split out each of the parameters from the 
   query stream */
for(i = 0; *qs && i < MAXQELEMENTS; i++) 
  {
  /* first divide by '&' for each parameter */
  splitword(elements[i].val, qs, '&');
  /* convert the string for hex characters and pluses */
  unescape_url(elements[i].val);
  /* now split out the name and value */
  splitword(elements[i].name, elements[i].val, '=');
  }

/* The CGI End Here */


/* The SQL Start Here */

/* The Implicit Handling */
/* EXEC SQL WHENEVER SQLERROR DO handle_error(); */ 

/* EXEC SQL WHENEVER SQLWARNING CONTINUE; */ 

/* EXEC SQL WHENEVER NOT FOUND DO handle_not_found(); */ 


strcpy(scUserName,"student");
strcpy(scPassword,"student123");
strcpy(scDatabaseName,"kmitl1");


/* Connections */
/* EXEC SQL CONNECT :scUserName IDENTIFIED BY :scPassword
         USING :scDatabaseName; */ 

{
struct sqlexd sqlstm;

sqlstm.sqlvsn = 8;
sqlstm.arrsiz = 3;
sqlstm.iters = (unsigned int  )10;
sqlstm.offset = (unsigned int  )2;
sqlstm.cud = sqlcud0;
sqlstm.sqlest = (unsigned char  *)&sqlca;
sqlstm.sqlety = (unsigned short)0;
sqlstm.sqhstv[0] = (unsigned char  *)scUserName;
sqlstm.sqhstl[0] = (unsigned int  )21;
sqlstm.sqindv[0] = (         short *)0;
sqlstm.sqharm[0] = (unsigned int  )0;
sqlstm.sqhstv[1] = (unsigned char  *)scPassword;
sqlstm.sqhstl[1] = (unsigned int  )21;
sqlstm.sqindv[1] = (         short *)0;
sqlstm.sqharm[1] = (unsigned int  )0;
sqlstm.sqhstv[2] = (unsigned char  *)scDatabaseName;
sqlstm.sqhstl[2] = (unsigned int  )21;
sqlstm.sqindv[2] = (         short *)0;
sqlstm.sqharm[2] = (unsigned int  )0;
sqlstm.sqphsv = sqlstm.sqhstv;
sqlstm.sqphsl = sqlstm.sqhstl;
sqlstm.sqpind = sqlstm.sqindv;
sqlstm.sqparm = sqlstm.sqharm;
sqlstm.sqparc = sqlstm.sqharc;
sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
if (sqlca.sqlcode < 0) handle_error();
}


          /* assign Host variables for input */

if (!strcmp(elements[0].val,"1d"))
{
       strcpy(First_variable.arr,elements[1].val);
       strcpy(Last_variable.arr,elements[2].val);
       First_variable.len = strlen(First_variable.arr);
       Last_variable.len = strlen(Last_variable.arr);
       
       /* EXEC SQL SELECT PHONE_NUM INTO :vcPhoneNum INDICATOR :indPhoneNum
                FROM STUDENT1D
                WHERE STUDENT1D.FIRST_NAME = :First_variable
                      AND STUDENT1D.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.stmt = "select PHONE_NUM into :b0:b1  from STUDENT1D where (ST\
UDENT1D.FIRST_NAME=:b2 and STUDENT1D.LAST_NAME=:b3)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )28;
       sqlstm.selerr = (unsigned short)1;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcPhoneNum;
       sqlstm.sqhstl[0] = (unsigned int  )22;
       sqlstm.sqindv[0] = (         short *)&indPhoneNum;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[1] = (unsigned int  )130;
       sqlstm.sqindv[1] = (         short *)0;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)0;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}



       /* EXEC SQL SELECT E_MAIL INTO :vcEmail INDICATOR :indEmail
                FROM STUDENT1D
                WHERE STUDENT1D.FIRST_NAME = :First_variable
                      AND STUDENT1D.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.stmt = "select E_MAIL into :b0:b1  from STUDENT1D where (STUDE\
NT1D.FIRST_NAME=:b2 and STUDENT1D.LAST_NAME=:b3)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )54;
       sqlstm.selerr = (unsigned short)1;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcEmail;
       sqlstm.sqhstl[0] = (unsigned int  )52;
       sqlstm.sqindv[0] = (         short *)&indEmail;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[1] = (unsigned int  )130;
       sqlstm.sqindv[1] = (         short *)0;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)0;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}


       
       /* EXEC SQL SELECT ADDRESS INTO :vcAddress INDICATOR :indAddress
                FROM STUDENT1D
                WHERE STUDENT1D.FIRST_NAME = :First_variable
                      AND STUDENT1D.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.stmt = "select ADDRESS into :b0:b1  from STUDENT1D where (STUD\
ENT1D.FIRST_NAME=:b2 and STUDENT1D.LAST_NAME=:b3)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )80;
       sqlstm.selerr = (unsigned short)1;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcAddress;
       sqlstm.sqhstl[0] = (unsigned int  )130;
       sqlstm.sqindv[0] = (         short *)&indAddress;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[1] = (unsigned int  )130;
       sqlstm.sqindv[1] = (         short *)0;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)0;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}



       /* EXEC SQL SELECT U_COMMENT INTO :vcComment INDICATOR :indComment
                FROM STUDENT1D
                WHERE STUDENT1D.FIRST_NAME = :First_variable 
                      AND STUDENT1D.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.stmt = "select U_COMMENT into :b0:b1  from STUDENT1D where (ST\
UDENT1D.FIRST_NAME=:b2 and STUDENT1D.LAST_NAME=:b3)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )106;
       sqlstm.selerr = (unsigned short)1;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcComment;
       sqlstm.sqhstl[0] = (unsigned int  )130;
       sqlstm.sqindv[0] = (         short *)&indComment;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[1] = (unsigned int  )130;
       sqlstm.sqindv[1] = (         short *)0;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)0;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}


       /* EXEC SQL COMMIT WORK RELEASE; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )132;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode < 0) handle_error();
}



}
if (!strcmp(elements[0].val,"2d"))
{
       strcpy(First_variable.arr,elements[1].val);
       strcpy(Last_variable.arr,elements[2].val);
       First_variable.len = strlen(First_variable.arr);
       Last_variable.len = strlen(Last_variable.arr);
       
       /* EXEC SQL SELECT PHONE_NUM INTO :vcPhoneNum INDICATOR :indPhoneNum
                FROM STUDENT2D
                WHERE STUDENT2D.FIRST_NAME = :First_variable
                      AND STUDENT2D.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.stmt = "select PHONE_NUM into :b0:b1  from STUDENT2D where (ST\
UDENT2D.FIRST_NAME=:b2 and STUDENT2D.LAST_NAME=:b3)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )146;
       sqlstm.selerr = (unsigned short)1;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcPhoneNum;
       sqlstm.sqhstl[0] = (unsigned int  )22;
       sqlstm.sqindv[0] = (         short *)&indPhoneNum;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[1] = (unsigned int  )130;
       sqlstm.sqindv[1] = (         short *)0;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)0;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}



       /* EXEC SQL SELECT E_MAIL INTO :vcEmail INDICATOR :indEmail
                FROM STUDENT2D
                WHERE STUDENT2D.FIRST_NAME = :First_variable
                      AND STUDENT2D.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.stmt = "select E_MAIL into :b0:b1  from STUDENT2D where (STUDE\
NT2D.FIRST_NAME=:b2 and STUDENT2D.LAST_NAME=:b3)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )172;
       sqlstm.selerr = (unsigned short)1;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcEmail;
       sqlstm.sqhstl[0] = (unsigned int  )52;
       sqlstm.sqindv[0] = (         short *)&indEmail;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[1] = (unsigned int  )130;
       sqlstm.sqindv[1] = (         short *)0;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)0;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}


       
       /* EXEC SQL SELECT ADDRESS INTO :vcAddress INDICATOR :indAddress
                FROM STUDENT2D
                WHERE STUDENT2D.FIRST_NAME = :First_variable
                      AND STUDENT2D.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.stmt = "select ADDRESS into :b0:b1  from STUDENT2D where (STUD\
ENT2D.FIRST_NAME=:b2 and STUDENT2D.LAST_NAME=:b3)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )198;
       sqlstm.selerr = (unsigned short)1;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcAddress;
       sqlstm.sqhstl[0] = (unsigned int  )130;
       sqlstm.sqindv[0] = (         short *)&indAddress;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[1] = (unsigned int  )130;
       sqlstm.sqindv[1] = (         short *)0;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)0;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}



       /* EXEC SQL SELECT U_COMMENT INTO :vcComment INDICATOR :indComment
                FROM STUDENT2D
                WHERE STUDENT2D.FIRST_NAME = :First_variable 
                      AND STUDENT2D.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.stmt = "select U_COMMENT into :b0:b1  from STUDENT2D where (ST\
UDENT2D.FIRST_NAME=:b2 and STUDENT2D.LAST_NAME=:b3)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )224;
       sqlstm.selerr = (unsigned short)1;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcComment;
       sqlstm.sqhstl[0] = (unsigned int  )130;
       sqlstm.sqindv[0] = (         short *)&indComment;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[1] = (unsigned int  )130;
       sqlstm.sqindv[1] = (         short *)0;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)0;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}


       /* EXEC SQL COMMIT WORK RELEASE; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )250;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode < 0) handle_error();
}



}
if (!strcmp(elements[0].val,"3d"))
{
       strcpy(First_variable.arr,elements[1].val);
       strcpy(Last_variable.arr,elements[2].val);
       First_variable.len = strlen(First_variable.arr);
       Last_variable.len = strlen(Last_variable.arr);
       
       /* EXEC SQL SELECT PHONE_NUM INTO :vcPhoneNum INDICATOR :indPhoneNum
                FROM STUDENT3D
                WHERE STUDENT3D.FIRST_NAME = :First_variable
                      AND STUDENT3D.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.stmt = "select PHONE_NUM into :b0:b1  from STUDENT3D where (ST\
UDENT3D.FIRST_NAME=:b2 and STUDENT3D.LAST_NAME=:b3)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )264;
       sqlstm.selerr = (unsigned short)1;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcPhoneNum;
       sqlstm.sqhstl[0] = (unsigned int  )22;
       sqlstm.sqindv[0] = (         short *)&indPhoneNum;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[1] = (unsigned int  )130;
       sqlstm.sqindv[1] = (         short *)0;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)0;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}



       /* EXEC SQL SELECT E_MAIL INTO :vcEmail INDICATOR :indEmail
                FROM STUDENT3D
                WHERE STUDENT3D.FIRST_NAME = :First_variable
                      AND STUDENT3D.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.stmt = "select E_MAIL into :b0:b1  from STUDENT3D where (STUDE\
NT3D.FIRST_NAME=:b2 and STUDENT3D.LAST_NAME=:b3)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )290;
       sqlstm.selerr = (unsigned short)1;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcEmail;
       sqlstm.sqhstl[0] = (unsigned int  )52;
       sqlstm.sqindv[0] = (         short *)&indEmail;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[1] = (unsigned int  )130;
       sqlstm.sqindv[1] = (         short *)0;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)0;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}


       
       /* EXEC SQL SELECT ADDRESS INTO :vcAddress INDICATOR :indAddress
                FROM STUDENT3D
                WHERE STUDENT3D.FIRST_NAME = :First_variable
                      AND STUDENT3D.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.stmt = "select ADDRESS into :b0:b1  from STUDENT3D where (STUD\
ENT3D.FIRST_NAME=:b2 and STUDENT3D.LAST_NAME=:b3)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )316;
       sqlstm.selerr = (unsigned short)1;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcAddress;
       sqlstm.sqhstl[0] = (unsigned int  )130;
       sqlstm.sqindv[0] = (         short *)&indAddress;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[1] = (unsigned int  )130;
       sqlstm.sqindv[1] = (         short *)0;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)0;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}



       /* EXEC SQL SELECT U_COMMENT INTO :vcComment INDICATOR :indComment
                FROM STUDENT3D
                WHERE STUDENT3D.FIRST_NAME = :First_variable 
                      AND STUDENT3D.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.stmt = "select U_COMMENT into :b0:b1  from STUDENT3D where (ST\
UDENT3D.FIRST_NAME=:b2 and STUDENT3D.LAST_NAME=:b3)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )342;
       sqlstm.selerr = (unsigned short)1;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcComment;
       sqlstm.sqhstl[0] = (unsigned int  )130;
       sqlstm.sqindv[0] = (         short *)&indComment;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[1] = (unsigned int  )130;
       sqlstm.sqindv[1] = (         short *)0;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)0;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}


       /* EXEC SQL COMMIT WORK RELEASE; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )368;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode < 0) handle_error();
}



}
if (!strcmp(elements[0].val,"4d"))
{
       strcpy(First_variable.arr,elements[1].val);
       strcpy(Last_variable.arr,elements[2].val);
       First_variable.len = strlen(First_variable.arr);
       Last_variable.len = strlen(Last_variable.arr);
       
       /* EXEC SQL SELECT PHONE_NUM INTO :vcPhoneNum INDICATOR :indPhoneNum
                FROM STUDENT4D
                WHERE STUDENT4D.FIRST_NAME = :First_variable
                      AND STUDENT4D.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.stmt = "select PHONE_NUM into :b0:b1  from STUDENT4D where (ST\
UDENT4D.FIRST_NAME=:b2 and STUDENT4D.LAST_NAME=:b3)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )382;
       sqlstm.selerr = (unsigned short)1;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcPhoneNum;
       sqlstm.sqhstl[0] = (unsigned int  )22;
       sqlstm.sqindv[0] = (         short *)&indPhoneNum;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[1] = (unsigned int  )130;
       sqlstm.sqindv[1] = (         short *)0;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)0;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}



       /* EXEC SQL SELECT E_MAIL INTO :vcEmail INDICATOR :indEmail
                FROM STUDENT4D
                WHERE STUDENT4D.FIRST_NAME = :First_variable
                      AND STUDENT4D.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.stmt = "select E_MAIL into :b0:b1  from STUDENT4D where (STUDE\
NT4D.FIRST_NAME=:b2 and STUDENT4D.LAST_NAME=:b3)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )408;
       sqlstm.selerr = (unsigned short)1;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcEmail;
       sqlstm.sqhstl[0] = (unsigned int  )52;
       sqlstm.sqindv[0] = (         short *)&indEmail;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[1] = (unsigned int  )130;
       sqlstm.sqindv[1] = (         short *)0;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)0;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}


       
       /* EXEC SQL SELECT ADDRESS INTO :vcAddress INDICATOR :indAddress
                FROM STUDENT4D
                WHERE STUDENT4D.FIRST_NAME = :First_variable
                      AND STUDENT4D.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.stmt = "select ADDRESS into :b0:b1  from STUDENT4D where (STUD\
ENT4D.FIRST_NAME=:b2 and STUDENT4D.LAST_NAME=:b3)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )434;
       sqlstm.selerr = (unsigned short)1;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcAddress;
       sqlstm.sqhstl[0] = (unsigned int  )130;
       sqlstm.sqindv[0] = (         short *)&indAddress;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[1] = (unsigned int  )130;
       sqlstm.sqindv[1] = (         short *)0;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)0;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}



       /* EXEC SQL SELECT U_COMMENT INTO :vcComment INDICATOR :indComment
                FROM STUDENT4D
                WHERE STUDENT4D.FIRST_NAME = :First_variable 
                      AND STUDENT4D.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.stmt = "select U_COMMENT into :b0:b1  from STUDENT4D where (ST\
UDENT4D.FIRST_NAME=:b2 and STUDENT4D.LAST_NAME=:b3)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )460;
       sqlstm.selerr = (unsigned short)1;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcComment;
       sqlstm.sqhstl[0] = (unsigned int  )130;
       sqlstm.sqindv[0] = (         short *)&indComment;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[1] = (unsigned int  )130;
       sqlstm.sqindv[1] = (         short *)0;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)0;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}


       /* EXEC SQL COMMIT WORK RELEASE; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )486;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode < 0) handle_error();
}



}
if (!strcmp(elements[0].val,"1p"))
{
       strcpy(First_variable.arr,elements[1].val);
       strcpy(Last_variable.arr,elements[2].val);
       First_variable.len = strlen(First_variable.arr);
       Last_variable.len = strlen(Last_variable.arr);
       
       /* EXEC SQL SELECT PHONE_NUM INTO :vcPhoneNum INDICATOR :indPhoneNum
                FROM STUDENT1P
                WHERE STUDENT1P.FIRST_NAME = :First_variable
                      AND STUDENT1P.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.stmt = "select PHONE_NUM into :b0:b1  from STUDENT1P where (ST\
UDENT1P.FIRST_NAME=:b2 and STUDENT1P.LAST_NAME=:b3)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )500;
       sqlstm.selerr = (unsigned short)1;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcPhoneNum;
       sqlstm.sqhstl[0] = (unsigned int  )22;
       sqlstm.sqindv[0] = (         short *)&indPhoneNum;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[1] = (unsigned int  )130;
       sqlstm.sqindv[1] = (         short *)0;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)0;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}



       /* EXEC SQL SELECT E_MAIL INTO :vcEmail INDICATOR :indEmail
                FROM STUDENT1P
                WHERE STUDENT1P.FIRST_NAME = :First_variable
                      AND STUDENT1P.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.stmt = "select E_MAIL into :b0:b1  from STUDENT1P where (STUDE\
NT1P.FIRST_NAME=:b2 and STUDENT1P.LAST_NAME=:b3)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )526;
       sqlstm.selerr = (unsigned short)1;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcEmail;
       sqlstm.sqhstl[0] = (unsigned int  )52;
       sqlstm.sqindv[0] = (         short *)&indEmail;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[1] = (unsigned int  )130;
       sqlstm.sqindv[1] = (         short *)0;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)0;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}


       
       /* EXEC SQL SELECT ADDRESS INTO :vcAddress INDICATOR :indAddress
                FROM STUDENT1P
                WHERE STUDENT1P.FIRST_NAME = :First_variable
                      AND STUDENT1P.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.stmt = "select ADDRESS into :b0:b1  from STUDENT1P where (STUD\
ENT1P.FIRST_NAME=:b2 and STUDENT1P.LAST_NAME=:b3)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )552;
       sqlstm.selerr = (unsigned short)1;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcAddress;
       sqlstm.sqhstl[0] = (unsigned int  )130;
       sqlstm.sqindv[0] = (         short *)&indAddress;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[1] = (unsigned int  )130;
       sqlstm.sqindv[1] = (         short *)0;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)0;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}



       /* EXEC SQL SELECT U_COMMENT INTO :vcComment INDICATOR :indComment
                FROM STUDENT1P
                WHERE STUDENT1P.FIRST_NAME = :First_variable 
                      AND STUDENT1P.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.stmt = "select U_COMMENT into :b0:b1  from STUDENT1P where (ST\
UDENT1P.FIRST_NAME=:b2 and STUDENT1P.LAST_NAME=:b3)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )578;
       sqlstm.selerr = (unsigned short)1;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcComment;
       sqlstm.sqhstl[0] = (unsigned int  )130;
       sqlstm.sqindv[0] = (         short *)&indComment;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[1] = (unsigned int  )130;
       sqlstm.sqindv[1] = (         short *)0;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)0;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}


       /* EXEC SQL COMMIT WORK RELEASE; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )604;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode < 0) handle_error();
}



}
if (!strcmp(elements[0].val,"2p"))
{
       strcpy(First_variable.arr,elements[1].val);
       strcpy(Last_variable.arr,elements[2].val);
       First_variable.len = strlen(First_variable.arr);
       Last_variable.len = strlen(Last_variable.arr);
       
       /* EXEC SQL SELECT PHONE_NUM INTO :vcPhoneNum INDICATOR :indPhoneNum
                FROM STUDENT2P
                WHERE STUDENT2P.FIRST_NAME = :First_variable
                      AND STUDENT2P.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.stmt = "select PHONE_NUM into :b0:b1  from STUDENT2P where (ST\
UDENT2P.FIRST_NAME=:b2 and STUDENT2P.LAST_NAME=:b3)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )618;
       sqlstm.selerr = (unsigned short)1;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcPhoneNum;
       sqlstm.sqhstl[0] = (unsigned int  )22;
       sqlstm.sqindv[0] = (         short *)&indPhoneNum;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[1] = (unsigned int  )130;
       sqlstm.sqindv[1] = (         short *)0;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)0;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}



       /* EXEC SQL SELECT E_MAIL INTO :vcEmail INDICATOR :indEmail
                FROM STUDENT2P
                WHERE STUDENT2P.FIRST_NAME = :First_variable
                      AND STUDENT2P.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.stmt = "select E_MAIL into :b0:b1  from STUDENT2P where (STUDE\
NT2P.FIRST_NAME=:b2 and STUDENT2P.LAST_NAME=:b3)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )644;
       sqlstm.selerr = (unsigned short)1;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcEmail;
       sqlstm.sqhstl[0] = (unsigned int  )52;
       sqlstm.sqindv[0] = (         short *)&indEmail;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[1] = (unsigned int  )130;
       sqlstm.sqindv[1] = (         short *)0;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)0;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}


       
       /* EXEC SQL SELECT ADDRESS INTO :vcAddress INDICATOR :indAddress
                FROM STUDENT2P
                WHERE STUDENT2P.FIRST_NAME = :First_variable
                      AND STUDENT2P.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.stmt = "select ADDRESS into :b0:b1  from STUDENT2P where (STUD\
ENT2P.FIRST_NAME=:b2 and STUDENT2P.LAST_NAME=:b3)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )670;
       sqlstm.selerr = (unsigned short)1;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcAddress;
       sqlstm.sqhstl[0] = (unsigned int  )130;
       sqlstm.sqindv[0] = (         short *)&indAddress;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[1] = (unsigned int  )130;
       sqlstm.sqindv[1] = (         short *)0;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)0;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}



       /* EXEC SQL SELECT U_COMMENT INTO :vcComment INDICATOR :indComment
                FROM STUDENT2P
                WHERE STUDENT2P.FIRST_NAME = :First_variable 
                      AND STUDENT2P.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.stmt = "select U_COMMENT into :b0:b1  from STUDENT2P where (ST\
UDENT2P.FIRST_NAME=:b2 and STUDENT2P.LAST_NAME=:b3)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )696;
       sqlstm.selerr = (unsigned short)1;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcComment;
       sqlstm.sqhstl[0] = (unsigned int  )130;
       sqlstm.sqindv[0] = (         short *)&indComment;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[1] = (unsigned int  )130;
       sqlstm.sqindv[1] = (         short *)0;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)0;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}


       /* EXEC SQL COMMIT WORK RELEASE; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )722;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode < 0) handle_error();
}



}
if (!strcmp(elements[0].val,"3p"))
{
       strcpy(First_variable.arr,elements[1].val);
       strcpy(Last_variable.arr,elements[2].val);
       First_variable.len = strlen(First_variable.arr);
       Last_variable.len = strlen(Last_variable.arr);
       
       /* EXEC SQL SELECT PHONE_NUM INTO :vcPhoneNum INDICATOR :indPhoneNum
                FROM STUDENT3P
                WHERE STUDENT3P.FIRST_NAME = :First_variable
                      AND STUDENT3P.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.stmt = "select PHONE_NUM into :b0:b1  from STUDENT3P where (ST\
UDENT3P.FIRST_NAME=:b2 and STUDENT3P.LAST_NAME=:b3)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )736;
       sqlstm.selerr = (unsigned short)1;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcPhoneNum;
       sqlstm.sqhstl[0] = (unsigned int  )22;
       sqlstm.sqindv[0] = (         short *)&indPhoneNum;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[1] = (unsigned int  )130;
       sqlstm.sqindv[1] = (         short *)0;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)0;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}



       /* EXEC SQL SELECT E_MAIL INTO :vcEmail INDICATOR :indEmail
                FROM STUDENT3P
                WHERE STUDENT3P.FIRST_NAME = :First_variable
                      AND STUDENT3P.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.stmt = "select E_MAIL into :b0:b1  from STUDENT3P where (STUDE\
NT3P.FIRST_NAME=:b2 and STUDENT3P.LAST_NAME=:b3)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )762;
       sqlstm.selerr = (unsigned short)1;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcEmail;
       sqlstm.sqhstl[0] = (unsigned int  )52;
       sqlstm.sqindv[0] = (         short *)&indEmail;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[1] = (unsigned int  )130;
       sqlstm.sqindv[1] = (         short *)0;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)0;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}


       
       /* EXEC SQL SELECT ADDRESS INTO :vcAddress INDICATOR :indAddress
                FROM STUDENT3P
                WHERE STUDENT3P.FIRST_NAME = :First_variable
                      AND STUDENT3P.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.stmt = "select ADDRESS into :b0:b1  from STUDENT3P where (STUD\
ENT3P.FIRST_NAME=:b2 and STUDENT3P.LAST_NAME=:b3)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )788;
       sqlstm.selerr = (unsigned short)1;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcAddress;
       sqlstm.sqhstl[0] = (unsigned int  )130;
       sqlstm.sqindv[0] = (         short *)&indAddress;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[1] = (unsigned int  )130;
       sqlstm.sqindv[1] = (         short *)0;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)0;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}



       /* EXEC SQL SELECT U_COMMENT INTO :vcComment INDICATOR :indComment
                FROM STUDENT3P
                WHERE STUDENT3P.FIRST_NAME = :First_variable 
                      AND STUDENT3P.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.stmt = "select U_COMMENT into :b0:b1  from STUDENT3P where (ST\
UDENT3P.FIRST_NAME=:b2 and STUDENT3P.LAST_NAME=:b3)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )814;
       sqlstm.selerr = (unsigned short)1;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcComment;
       sqlstm.sqhstl[0] = (unsigned int  )130;
       sqlstm.sqindv[0] = (         short *)&indComment;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[1] = (unsigned int  )130;
       sqlstm.sqindv[1] = (         short *)0;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)0;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}


       /* EXEC SQL COMMIT WORK RELEASE; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 3;
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )840;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode < 0) handle_error();
}



}


           /* Display Result */
       vcPhoneNum.arr[vcPhoneNum.len] = '\0';
       vcEmail.arr[vcEmail.len] = '\0';
       vcComment.arr[vcComment.len] = '\0';
       vcAddress.arr[vcAddress.len] = '\0';

       printf("<CENTER>");
       printf("<BR>");

       printf("<TABLE BORDER WIDTH=500 CELLSPACING=1 CELLPADDING=15>");
       printf("<TR>");
       printf("<TH BGCOLOR=#006666><Font Color = White> First Name</Font></TH>");
       printf("<TH BGCOLOR=#006666><Font Color = White> Last Name</Font></TH>");
       printf("<TH BGCOLOR=#006666><Font Color = White> Phone Number</Font></TH>");
       printf("<TH BGCOLOR=#006666><Font Color = White> Email Address</Font></TH>");
       printf("<TH BGCOLOR=#006666><Font Color = White> Address</Font></TH>");
       printf("<TH BGCOLOR=#006666><Font Color = White> Comment</Font></TH>");
       printf("</TR>");

       printf("<TR>");
       printf("<TD HEIGHT=60>%s</TD>",elements[1].val);
       printf("<TD>%s</TD>",elements[2].val);
       printf("<TD>%s</TD>",vcPhoneNum.arr);
       printf("<TD>%s",vcEmail.arr);
       printf("<TD>%s",vcAddress.arr);
       printf("<TD>%s",vcComment.arr);
       printf("</TR>");
       
       printf("</TABLE>");
       printf("</CENTER>");

       printf("<BR>");
       printf("<HR WIDTH=500 ALIGN=center SIZE=4>");

       printf("<BR>");
       printf("<CENTER>");
       printf("<A HREF=../../Project/right.html><IMG SRC=../../Project/home.jpg></A>");
       printf("<A HREF=../../Project/about.html><IMG SRC=../../Project/project.jpg></A>");
       printf("<A HREF=../../Project/member.html><IMG SRC=../../Project/member.jpg></A>");
       printf("<A HREF=../../Project/eng.html><IMG SRC=../../Project/comeng.jpg></A>");
       printf("</CENTER>");

       printf("<CENTER>");
       printf("<A HREF=../../Project/inst.html><IMG SRC=../../Project/ins_d.jpg></A>");
       printf("<A HREF=../../Project/upd.html><IMG SRC=../../Project/upd_d.jpg></A>");
       printf("<A HREF=../../Project/slt.html><IMG SRC=../../Project/sel_d.jpg></A>");
       printf("<A HREF=../../Project/del.html><IMG SRC=../../Project/del_d.jpg></A>");
       printf("</CENTER>");

       printf("<CENTER>");
       printf("<A HREF=select_lst.sh.cgi><IMG SRC=../../Project/lst_d.jpg></A>");
       printf("<A HREF=../../Project/query.html><IMG SRC=../../Project/query_d.jpg></A>");
       printf("</CENTER>"); 


       printf("<BR>");

       printf("</BODY>");
       printf("</HTML>");

       fflush(stdout);
       close(stdout); 
       close(stderr); 


}

