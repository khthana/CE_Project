
/* Result Sets Interface */
#ifndef SQL_CRSR
#  define SQL_CRSR
  struct sql_cursor
  {
    unsigned int curocn;
    void *ptr1;
    void *ptr2;
    unsigned long magic;
  };
  typedef struct sql_cursor sql_cursor;
  typedef struct sql_cursor SQL_CURSOR;
#endif /* SQL_CRSR */

/* Thread Safety */
typedef void * sql_context;
typedef void * SQL_CONTEXT;

/* File name & Package Name */
struct sqlcxp
{
  unsigned short fillen;
           char  filnam[13];
};
static struct sqlcxp sqlfpn =
{
    12,
    "update_v3.pc"
};


static unsigned long sqlctx = 327859;


static struct sqlexd {
   unsigned int   sqlvsn;
   unsigned int   arrsiz;
   unsigned int   iters;
   unsigned int   offset;
   unsigned short selerr;
   unsigned short sqlety;
   unsigned int   unused;
            short *cud;
   unsigned char  *sqlest;
            char  *stmt;
   unsigned char  **sqphsv;
   unsigned int   *sqphsl;
            short **sqpind;
   unsigned int   *sqparm;
   unsigned int   **sqparc;
   unsigned char  *sqhstv[6];
   unsigned int   sqhstl[6];
            short *sqindv[6];
   unsigned int   sqharm[6];
   unsigned int   *sqharc[6];
} sqlstm = {8,6};

/* Prototypes */
extern sqlcxt (/*_ void **, unsigned long *,
                   struct sqlexd *, struct sqlcxp * _*/);
extern sqlcx2t(/*_ void **, unsigned long *,
                   struct sqlexd *, struct sqlcxp * _*/);
extern sqlbuft(/*_ void **, char * _*/);
extern sqlgs2t(/*_ void **, char * _*/);
extern sqlorat(/*_ void **, unsigned long *, void * _*/);

/* Forms Interface */
static int IAPSUCC = 0;
static int IAPFAIL = 1403;
static int IAPFTL  = 535;
extern sqliem(/*_ char *, int * _*/);

typedef struct { unsigned short len; unsigned char arr[1]; } VARCHAR;
typedef struct { unsigned short len; unsigned char arr[1]; } varchar;

/* cud (compilation unit data) array */
static short sqlcud0[] =
{8,4130,
2,0,0,1,0,0,27,366,0,3,3,0,1,0,1,97,0,0,1,97,0,0,1,97,0,0,
28,0,0,2,185,0,5,389,0,6,6,0,1,0,1,9,0,0,1,9,0,0,1,9,0,0,1,9,0,0,1,9,0,0,1,9,0,
0,
66,0,0,3,0,0,30,396,0,0,0,0,1,0,
80,0,0,4,185,0,5,419,0,6,6,0,1,0,1,9,0,0,1,9,0,0,1,9,0,0,1,9,0,0,1,9,0,0,1,9,0,
0,
118,0,0,5,0,0,30,426,0,0,0,0,1,0,
132,0,0,6,185,0,5,449,0,6,6,0,1,0,1,9,0,0,1,9,0,0,1,9,0,0,1,9,0,0,1,9,0,0,1,9,
0,0,
170,0,0,7,0,0,30,456,0,0,0,0,1,0,
184,0,0,8,185,0,5,479,0,6,6,0,1,0,1,9,0,0,1,9,0,0,1,9,0,0,1,9,0,0,1,9,0,0,1,9,
0,0,
222,0,0,9,0,0,30,486,0,0,0,0,1,0,
236,0,0,10,185,0,5,509,0,6,6,0,1,0,1,9,0,0,1,9,0,0,1,9,0,0,1,9,0,0,1,9,0,0,1,9,
0,0,
274,0,0,11,0,0,30,516,0,0,0,0,1,0,
288,0,0,12,185,0,5,539,0,6,6,0,1,0,1,9,0,0,1,9,0,0,1,9,0,0,1,9,0,0,1,9,0,0,1,9,
0,0,
326,0,0,13,0,0,30,546,0,0,0,0,1,0,
340,0,0,14,185,0,5,569,0,6,6,0,1,0,1,9,0,0,1,9,0,0,1,9,0,0,1,9,0,0,1,9,0,0,1,9,
0,0,
378,0,0,15,0,0,30,576,0,0,0,0,1,0,
};


/*  INSERT VERSION 3.0 */

/*  The STUDENT TABLE 
**  FIRST_NAME  VARCHAR2(128) IS NOT NULL
**  LAST_NAME   VARCHAR2(128) IS NOT NULL
**  PHONE_NUM   VARCHAR2(128) IS NOT NULL
**  E_MAIL      VARCHAR2(128) IS NOT NULL
**  ADDRESS     VARCHAR2(128) IS NOT NULL
**  U_COMMENT   VARCHAR2(128) IS NOT NULL
**  (FIRST_NAME,LAST_NAME) IS PRIMARY KEY
*/

#include <stdio.h>
#include <stdlib.h>

/* This is the structure we use 
   for the query-string elements */

#define MAXQELEMENTS (7)


/* The DECLARE Section */
/* EXEC SQL BEGIN DECLARE SECTION; */ 


/*
** Host variables for accessing the STUDENT table.
*/

/* VARCHAR vcFName[30]; */ 
struct { unsigned short len; unsigned char arr[30]; } vcFName;

/* VARCHAR vcLName[30]; */ 
struct { unsigned short len; unsigned char arr[30]; } vcLName;

/* VARCHAR vcPhoneNum[20]; */ 
struct { unsigned short len; unsigned char arr[20]; } vcPhoneNum;

/* VARCHAR vcEmail[50]; */ 
struct { unsigned short len; unsigned char arr[50]; } vcEmail;

/* VARCHAR vcAddress[128]; */ 
struct { unsigned short len; unsigned char arr[128]; } vcAddress;

/* VARCHAR vcComment[128]; */ 
struct { unsigned short len; unsigned char arr[128]; } vcComment;


/*
** Indicator variables for the host variables defined above.
*/

short indFName;
short indLName;
short indPhoneNum;
short indEmail;
short indAddress;
short indComment;

/* EXEC SQL END DECLARE SECTION; */ 

/* End DECLARE Section */


/* The DECLARE Section */
/* EXEC SQL BEGIN DECLARE SECTION; */ 


/* Host variables for logging into the Oracle database */

char scUserName[21]; 
char scPassword[21];
char scDatabaseName[21];

/* EXEC SQL END DECLARE SECTION; */ 

/* End DECLARE Section */


/* The DECLARE Section */
/* EXEC SQL BEGIN DECLARE SECTION; */ 

    
/* VARCHAR  First_variable[128]; */ 
struct { unsigned short len; unsigned char arr[128]; } First_variable;

/* VARCHAR  Last_variable[128]; */ 
struct { unsigned short len; unsigned char arr[128]; } Last_variable;


/* EXEC SQL END DECLARE SECTION; */ 

/* End DECLARE Section */

/* This structure is used for storing data */

struct {
    char name[128]; 
    char val[128];
} elements[MAXQELEMENTS];


/* this is the structure we use
   for SQLCA */

struct sqlca
    {
    char sqlcaid[8];
    long sqlabc;
    long sqlcode;
    struct
        {
        unsigned short sqlerrml;
        char sqlerrmc[70];
        }  sqlerrm;
    char sqlerrp[8];
    long sqlerrd[6];
    char sqlwarn[8];
    char sqlext[8];
    };
struct sqlca sqlca;


void splitword(out,in,stop)
char *out;
char *in;
char stop;
{
int i,j;

for (i =0;in[i] && (in[i] != stop); i++)
    out[i] = in[i];

out[i] = '\0'; /* terminate it */
if (in[i])
    i++;

for (j = 0;in[j]; ) /* shift the rest of the in */
    in[j++] = in[i++];
}


char x2c(x)
char *x;
{
register char c;

/* note: (x & 0xdf) makes x upper case */
c = (x[0] >= 'A' ? ((x[0] & 0xdf) - 'A') + 10 : (x[0] - '0'));
c *= 16;
c += (x[1] >= 'A' ? ((x[1] & 0xdf) - 'A') + 10 : (x[1] - '0'));
return(c);
}

/* this function goes through the URL char-by-char and converts all the "escaped"
   (hex-encoded) sequences to characters
   this version also converts pluses to spaces. */


void unescape_url(url)
char *url;
{
register int i,j;

for (i = 0,j = 0;url[j];++i, ++j)
    {
    if ((url[i] = url[j]) == '%')
       {
        url[i] = x2c(&url[j+1]);
        j += 2;
       }
    else if (url[i] == '+')
       url[i] = ' ';
    }
url[i] = '\0'; /* terminate it at the new length */
}


void handle_error(void)
{
   sqlca.sqlerrm.sqlerrmc[sqlca.sqlerrm.sqlerrml] = '\0';
   
   /* Display error message */
   if (sqlca.sqlcode == -1)
       {
       printf("<CENTER>");
       printf("<FONT SIZE=+2>REPORT : </FONT>Duplicate key value");
       printf("</CENTER>");
       }
   else 
   if (sqlca.sqlcode == -1401) 
       {
       printf("<CENTER>");
       printf("<FONT SIZE=+2>REPORT : </FONT>Value too large");
       printf("</CENTER>");
       }
   else
       {
       printf("<CENTER>");
       printf("<FONT SIZE=+2>REPORT : </FONT>%s",sqlca.sqlerrm.sqlerrmc);
       printf("</CENTER>");
       }
   fflush(stdout);

   printf("<HR WIDTH=500 ALIGN=center SIZE=4>");

   printf("<BR>");
   printf("<CENTER>");
   printf("<A HREF=../../Project/right.html><IMG SRC=../../Project/home.jpg></A>");
   printf("<A HREF=../../Project/about.html><IMG SRC=../../Project/project.jpg></A>");
   printf("<A HREF=../../Project/member.html><IMG SRC=../../Project/member.jpg></A>");
   printf("<A HREF=../../Project/eng.html><IMG SRC=../../Project/comeng.jpg></A>");
   printf("</CENTER>");

   printf("<CENTER>");
   printf("<A HREF=../../Project/inst.html><IMG SRC=../../Project/ins_d.jpg></A>");
   printf("<A HREF=../../Project/upd.html><IMG SRC=../../Project/upd_d.jpg></A>");
   printf("<A HREF=../../Project/slt.html><IMG SRC=../../Project/sel_d.jpg></A>");
   printf("<A HREF=../../Project/del.html><IMG SRC=../../Project/del_d.jpg></A>");
   printf("</CENTER>");

   printf("<CENTER>");
   printf("<A HREF=../query/select_lst.sh.cgi><IMG SRC=../../Project/lst_d.jpg></A>");
   printf("<A HREF=../../Project/query.html><IMG SRC=../../Project/query_d.jpg></A>");
   printf("</CENTER>"); 


   printf("<BR>");

   printf("</BODY>");
   printf("</HTML>");


   exit(0);
}

void handle_not_found(void)
{
   /* Display not found message */
   printf("<CENTER>");
   printf("<FONT SIZE=+2>REPORT : </FONT>Data not found");
   printf("</CENTER>");
   fflush(stdout);

   printf("<HR WIDTH=500 ALIGN=center SIZE=4>");

   printf("<BR>");
   printf("<CENTER>");
   printf("<A HREF=../../Project/right.html><IMG SRC=../../Project/home.jpg></A>");
   printf("<A HREF=../../Project/about.html><IMG SRC=../../Project/project.jpg></A>");
   printf("<A HREF=../../Project/member.html><IMG SRC=../../Project/member.jpg></A>");
   printf("<A HREF=../../Project/eng.html><IMG SRC=../../Project/comeng.jpg></A>");
   printf("</CENTER>");

   printf("<CENTER>");
   printf("<A HREF=../../Project/inst.html><IMG SRC=../../Project/ins_d.jpg></A>");
   printf("<A HREF=../../Project/upd.html><IMG SRC=../../Project/upd_d.jpg></A>");
   printf("<A HREF=../../Project/slt.html><IMG SRC=../../Project/sel_d.jpg></A>");
   printf("<A HREF=../../Project/del.html><IMG SRC=../../Project/del_d.jpg></A>");
   printf("</CENTER>");

   printf("<CENTER>");
   printf("<A HREF=../query/select_lst.sh.cgi><IMG SRC=../../Project/lst_d.jpg></A>");
   printf("<A HREF=../../Project/query.html><IMG SRC=../../Project/query_d.jpg></A>");
   printf("</CENTER>"); 


   printf("<BR>");

   printf("</BODY>");
   printf("</HTML>");




   exit(0);
}



/* MAIN PROGRAM START HERE */
main()
{
char * ct; /* for content-type */
char * cl; /* for content-length */
int   icl; /* content-length */
char * qs; /* query string */
int rc;
int i;


/* The CGI header */

/* fprintf(stdout,"Content-type: text/plain\n"); */
/* fprintf(stdout,"\n\n"); */
/* fflush(stdout); */


printf("<HTML>");
printf("<BODY BGCOLOR=#FFFFFF TEXT=#000000 LINK =#FFFFFF VLINK=#FFFFFF>");

printf("<BR>");
printf("<CENTER>");
printf("<IMG SRC=../../Project/visit.jpg ALT=Report Page>");
printf("</CENTER>");
printf("<BR>");
printf("<HR WIDTH=500 ALIGN=center SIZE=4>");




/* Set Oracle environment */
putenv("LD_LIBRARY_PATH=/oracle/app/oracle/product/7.3.2/lib"); 
putenv("ORACLE_HOME=/oracle/app/oracle/product/7.3.2"); 
putenv("ORACLE_SID=kmitl1"); 
putenv("ORACLE_TERM=vt100"); 
putenv("MENU5PATH=/oracle/app/oracle/product/7.3.2/forms30/admin/resource"); 
putenv("ORATERMPATH=/oracle/app/oracle/product/7.3.2/forms30/admin/resource");

/* grab the content-type and content-length 
   and check them for validity */

ct = getenv("CONTENT_TYPE");
cl = getenv("CONTENT_LENGTH");
if(cl == NULL)
  {
  printf("Content-length is undefined!%c",10);
  exit(1);
  }
icl = atoi(cl);

/* do we have a valid query? */
if(strcmp(ct, "application/x-www-form-urlencoded"))
  {
  printf("I don't understand the content-type %s%c",ct,10);
  exit(1);
  }
else if (icl == 0)
  {
  printf("Content-length is zero%c",10);
  exit(1);
  }

/* allocate memory for the input stream */
if((qs = malloc(icl + 1)) == NULL)
  {
  printf("Cannot allocate memory, contact the webmaster%c",10);
  exit(1);
  }

if((rc = fread(qs, icl, 1, stdin)) != 1)
  {
  printf("Cannot read the input stream (%d)! Contact the webmaster%c", rc,10);
  exit(1);
  }
qs[icl] = '\0';


/* split out each of the parameters from the 
   query stream */
for(i = 0; *qs && i < MAXQELEMENTS; i++) 
  {
  /* first divide by '&' for each parameter */
  splitword(elements[i].val, qs, '&');
  /* convert the string for hex characters and pluses */
  unescape_url(elements[i].val);
  /* now split out the name and value */
  splitword(elements[i].name, elements[i].val, '=');
  }

/* The CGI End Here */



/* The SQL Start Here */

/* The Implicit Handling */
/* EXEC SQL WHENEVER SQLERROR DO handle_error(); */ 

/* EXEC SQL WHENEVER SQLWARNING CONTINUE; */ 

/* EXEC SQL WHENEVER NOT FOUND DO handle_not_found(); */ 


strcpy(scUserName,"student");
strcpy(scPassword,"student123");
strcpy(scDatabaseName,"kmitl1");


/* Connections */
/* EXEC SQL CONNECT :scUserName IDENTIFIED BY :scPassword
         USING :scDatabaseName; */ 

{
struct sqlexd sqlstm;

sqlstm.sqlvsn = 8;
sqlstm.arrsiz = 3;
sqlstm.iters = (unsigned int  )10;
sqlstm.offset = (unsigned int  )2;
sqlstm.cud = sqlcud0;
sqlstm.sqlest = (unsigned char  *)&sqlca;
sqlstm.sqlety = (unsigned short)0;
sqlstm.sqhstv[0] = (unsigned char  *)scUserName;
sqlstm.sqhstl[0] = (unsigned int  )21;
sqlstm.sqindv[0] = (         short *)0;
sqlstm.sqharm[0] = (unsigned int  )0;
sqlstm.sqhstv[1] = (unsigned char  *)scPassword;
sqlstm.sqhstl[1] = (unsigned int  )21;
sqlstm.sqindv[1] = (         short *)0;
sqlstm.sqharm[1] = (unsigned int  )0;
sqlstm.sqhstv[2] = (unsigned char  *)scDatabaseName;
sqlstm.sqhstl[2] = (unsigned int  )21;
sqlstm.sqindv[2] = (         short *)0;
sqlstm.sqharm[2] = (unsigned int  )0;
sqlstm.sqphsv = sqlstm.sqhstv;
sqlstm.sqphsl = sqlstm.sqhstl;
sqlstm.sqpind = sqlstm.sqindv;
sqlstm.sqparm = sqlstm.sqharm;
sqlstm.sqparc = sqlstm.sqharc;
sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
if (sqlca.sqlcode < 0) handle_error();
}


          /* assign Host variables for input */

if (!strcmp(elements[0].val,"1d"))
{
       strcpy(First_variable.arr,elements[1].val);
       strcpy(Last_variable.arr,elements[2].val);
       First_variable.len = strlen(First_variable.arr);
       Last_variable.len = strlen(Last_variable.arr);
           
       strcpy(vcPhoneNum.arr,elements[3].val);
       vcPhoneNum.len = strlen(vcPhoneNum.arr);
       strcpy(vcEmail.arr,elements[4].val);
       vcEmail.len = strlen(vcEmail.arr);
       strcpy(vcAddress.arr,elements[5].val);
       vcAddress.len = strlen(vcAddress.arr);
       strcpy(vcComment.arr,elements[6].val);
       vcComment.len = strlen(vcComment.arr);
       
           /* assign Indicator variables for input */
       indPhoneNum = indEmail = indAddress = indComment = 0;
           
       /* EXEC SQL UPDATE STUDENT1D
                SET STUDENT1D.PHONE_NUM = :vcPhoneNum INDICATOR :indPhoneNum,
                    STUDENT1D.E_MAIL = :vcEmail INDICATOR :indEmail,
                    STUDENT1D.ADDRESS = :vcAddress INDICATOR :indAddress,
                    STUDENT1D.U_COMMENT = :vcComment INDICATOR :indComment
                WHERE STUDENT1D.FIRST_NAME = :First_variable
                      AND STUDENT1D.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 6;
       sqlstm.stmt = "update STUDENT1D  set STUDENT1D.PHONE_NUM=:b0:b1,STUDE\
NT1D.E_MAIL=:b2:b3,STUDENT1D.ADDRESS=:b4:b5,STUDENT1D.U_COMMENT=:b6:b7 where (\
STUDENT1D.FIRST_NAME=:b8 and STUDENT1D.LAST_NAME=:b9)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )28;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcPhoneNum;
       sqlstm.sqhstl[0] = (unsigned int  )22;
       sqlstm.sqindv[0] = (         short *)&indPhoneNum;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&vcEmail;
       sqlstm.sqhstl[1] = (unsigned int  )52;
       sqlstm.sqindv[1] = (         short *)&indEmail;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&vcAddress;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)&indAddress;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqhstv[3] = (unsigned char  *)&vcComment;
       sqlstm.sqhstl[3] = (unsigned int  )130;
       sqlstm.sqindv[3] = (         short *)&indComment;
       sqlstm.sqharm[3] = (unsigned int  )0;
       sqlstm.sqhstv[4] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[4] = (unsigned int  )130;
       sqlstm.sqindv[4] = (         short *)0;
       sqlstm.sqharm[4] = (unsigned int  )0;
       sqlstm.sqhstv[5] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[5] = (unsigned int  )130;
       sqlstm.sqindv[5] = (         short *)0;
       sqlstm.sqharm[5] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}


       /* EXEC SQL COMMIT WORK RELEASE; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 6;
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )66;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode < 0) handle_error();
}




}
if (!strcmp(elements[0].val,"2d"))
{
       strcpy(First_variable.arr,elements[1].val);
       strcpy(Last_variable.arr,elements[2].val);
       First_variable.len = strlen(First_variable.arr);
       Last_variable.len = strlen(Last_variable.arr);
           
       strcpy(vcPhoneNum.arr,elements[3].val);
       vcPhoneNum.len = strlen(vcPhoneNum.arr);
       strcpy(vcEmail.arr,elements[4].val);
       vcEmail.len = strlen(vcEmail.arr);
       strcpy(vcAddress.arr,elements[5].val);
       vcAddress.len = strlen(vcAddress.arr);
       strcpy(vcComment.arr,elements[6].val);
       vcComment.len = strlen(vcComment.arr);
       
           /* assign Indicator variables for input */
       indPhoneNum = indEmail = indAddress = indComment = 0;
           
       /* EXEC SQL UPDATE STUDENT2D
                SET STUDENT2D.PHONE_NUM = :vcPhoneNum INDICATOR :indPhoneNum,
                    STUDENT2D.E_MAIL = :vcEmail INDICATOR :indEmail,
                    STUDENT2D.ADDRESS = :vcAddress INDICATOR :indAddress,
                    STUDENT2D.U_COMMENT = :vcComment INDICATOR :indComment
                WHERE STUDENT2D.FIRST_NAME = :First_variable
                      AND STUDENT2D.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 6;
       sqlstm.stmt = "update STUDENT2D  set STUDENT2D.PHONE_NUM=:b0:b1,STUDE\
NT2D.E_MAIL=:b2:b3,STUDENT2D.ADDRESS=:b4:b5,STUDENT2D.U_COMMENT=:b6:b7 where (\
STUDENT2D.FIRST_NAME=:b8 and STUDENT2D.LAST_NAME=:b9)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )80;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcPhoneNum;
       sqlstm.sqhstl[0] = (unsigned int  )22;
       sqlstm.sqindv[0] = (         short *)&indPhoneNum;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&vcEmail;
       sqlstm.sqhstl[1] = (unsigned int  )52;
       sqlstm.sqindv[1] = (         short *)&indEmail;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&vcAddress;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)&indAddress;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqhstv[3] = (unsigned char  *)&vcComment;
       sqlstm.sqhstl[3] = (unsigned int  )130;
       sqlstm.sqindv[3] = (         short *)&indComment;
       sqlstm.sqharm[3] = (unsigned int  )0;
       sqlstm.sqhstv[4] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[4] = (unsigned int  )130;
       sqlstm.sqindv[4] = (         short *)0;
       sqlstm.sqharm[4] = (unsigned int  )0;
       sqlstm.sqhstv[5] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[5] = (unsigned int  )130;
       sqlstm.sqindv[5] = (         short *)0;
       sqlstm.sqharm[5] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}


       /* EXEC SQL COMMIT WORK RELEASE; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 6;
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )118;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode < 0) handle_error();
}




}
if (!strcmp(elements[0].val,"3d"))
{
       strcpy(First_variable.arr,elements[1].val);
       strcpy(Last_variable.arr,elements[2].val);
       First_variable.len = strlen(First_variable.arr);
       Last_variable.len = strlen(Last_variable.arr);
           
       strcpy(vcPhoneNum.arr,elements[3].val);
       vcPhoneNum.len = strlen(vcPhoneNum.arr);
       strcpy(vcEmail.arr,elements[4].val);
       vcEmail.len = strlen(vcEmail.arr);
       strcpy(vcAddress.arr,elements[5].val);
       vcAddress.len = strlen(vcAddress.arr);
       strcpy(vcComment.arr,elements[6].val);
       vcComment.len = strlen(vcComment.arr);
       
           /* assign Indicator variables for input */
       indPhoneNum = indEmail = indAddress = indComment = 0;
           
       /* EXEC SQL UPDATE STUDENT3D
                SET STUDENT3D.PHONE_NUM = :vcPhoneNum INDICATOR :indPhoneNum,
                    STUDENT3D.E_MAIL = :vcEmail INDICATOR :indEmail,
                    STUDENT3D.ADDRESS = :vcAddress INDICATOR :indAddress,
                    STUDENT3D.U_COMMENT = :vcComment INDICATOR :indComment
                WHERE STUDENT3D.FIRST_NAME = :First_variable
                      AND STUDENT3D.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 6;
       sqlstm.stmt = "update STUDENT3D  set STUDENT3D.PHONE_NUM=:b0:b1,STUDE\
NT3D.E_MAIL=:b2:b3,STUDENT3D.ADDRESS=:b4:b5,STUDENT3D.U_COMMENT=:b6:b7 where (\
STUDENT3D.FIRST_NAME=:b8 and STUDENT3D.LAST_NAME=:b9)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )132;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcPhoneNum;
       sqlstm.sqhstl[0] = (unsigned int  )22;
       sqlstm.sqindv[0] = (         short *)&indPhoneNum;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&vcEmail;
       sqlstm.sqhstl[1] = (unsigned int  )52;
       sqlstm.sqindv[1] = (         short *)&indEmail;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&vcAddress;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)&indAddress;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqhstv[3] = (unsigned char  *)&vcComment;
       sqlstm.sqhstl[3] = (unsigned int  )130;
       sqlstm.sqindv[3] = (         short *)&indComment;
       sqlstm.sqharm[3] = (unsigned int  )0;
       sqlstm.sqhstv[4] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[4] = (unsigned int  )130;
       sqlstm.sqindv[4] = (         short *)0;
       sqlstm.sqharm[4] = (unsigned int  )0;
       sqlstm.sqhstv[5] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[5] = (unsigned int  )130;
       sqlstm.sqindv[5] = (         short *)0;
       sqlstm.sqharm[5] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}


       /* EXEC SQL COMMIT WORK RELEASE; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 6;
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )170;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode < 0) handle_error();
}




}
if (!strcmp(elements[0].val,"4d"))
{
       strcpy(First_variable.arr,elements[1].val);
       strcpy(Last_variable.arr,elements[2].val);
       First_variable.len = strlen(First_variable.arr);
       Last_variable.len = strlen(Last_variable.arr);
           
       strcpy(vcPhoneNum.arr,elements[3].val);
       vcPhoneNum.len = strlen(vcPhoneNum.arr);
       strcpy(vcEmail.arr,elements[4].val);
       vcEmail.len = strlen(vcEmail.arr);
       strcpy(vcAddress.arr,elements[5].val);
       vcAddress.len = strlen(vcAddress.arr);
       strcpy(vcComment.arr,elements[6].val);
       vcComment.len = strlen(vcComment.arr);
       
           /* assign Indicator variables for input */
       indPhoneNum = indEmail = indAddress = indComment = 0;
           
       /* EXEC SQL UPDATE STUDENT4D
                SET STUDENT4D.PHONE_NUM = :vcPhoneNum INDICATOR :indPhoneNum,
                    STUDENT4D.E_MAIL = :vcEmail INDICATOR :indEmail,
                    STUDENT4D.ADDRESS = :vcAddress INDICATOR :indAddress,
                    STUDENT4D.U_COMMENT = :vcComment INDICATOR :indComment
                WHERE STUDENT4D.FIRST_NAME = :First_variable
                      AND STUDENT4D.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 6;
       sqlstm.stmt = "update STUDENT4D  set STUDENT4D.PHONE_NUM=:b0:b1,STUDE\
NT4D.E_MAIL=:b2:b3,STUDENT4D.ADDRESS=:b4:b5,STUDENT4D.U_COMMENT=:b6:b7 where (\
STUDENT4D.FIRST_NAME=:b8 and STUDENT4D.LAST_NAME=:b9)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )184;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcPhoneNum;
       sqlstm.sqhstl[0] = (unsigned int  )22;
       sqlstm.sqindv[0] = (         short *)&indPhoneNum;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&vcEmail;
       sqlstm.sqhstl[1] = (unsigned int  )52;
       sqlstm.sqindv[1] = (         short *)&indEmail;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&vcAddress;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)&indAddress;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqhstv[3] = (unsigned char  *)&vcComment;
       sqlstm.sqhstl[3] = (unsigned int  )130;
       sqlstm.sqindv[3] = (         short *)&indComment;
       sqlstm.sqharm[3] = (unsigned int  )0;
       sqlstm.sqhstv[4] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[4] = (unsigned int  )130;
       sqlstm.sqindv[4] = (         short *)0;
       sqlstm.sqharm[4] = (unsigned int  )0;
       sqlstm.sqhstv[5] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[5] = (unsigned int  )130;
       sqlstm.sqindv[5] = (         short *)0;
       sqlstm.sqharm[5] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}


       /* EXEC SQL COMMIT WORK RELEASE; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 6;
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )222;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode < 0) handle_error();
}




}
if (!strcmp(elements[0].val,"1p"))
{
       strcpy(First_variable.arr,elements[1].val);
       strcpy(Last_variable.arr,elements[2].val);
       First_variable.len = strlen(First_variable.arr);
       Last_variable.len = strlen(Last_variable.arr);
           
       strcpy(vcPhoneNum.arr,elements[3].val);
       vcPhoneNum.len = strlen(vcPhoneNum.arr);
       strcpy(vcEmail.arr,elements[4].val);
       vcEmail.len = strlen(vcEmail.arr);
       strcpy(vcAddress.arr,elements[5].val);
       vcAddress.len = strlen(vcAddress.arr);
       strcpy(vcComment.arr,elements[6].val);
       vcComment.len = strlen(vcComment.arr);
       
           /* assign Indicator variables for input */
       indPhoneNum = indEmail = indAddress = indComment = 0;
           
       /* EXEC SQL UPDATE STUDENT1P
                SET STUDENT1P.PHONE_NUM = :vcPhoneNum INDICATOR :indPhoneNum,
                    STUDENT1P.E_MAIL = :vcEmail INDICATOR :indEmail,
                    STUDENT1P.ADDRESS = :vcAddress INDICATOR :indAddress,
                    STUDENT1P.U_COMMENT = :vcComment INDICATOR :indComment
                WHERE STUDENT1P.FIRST_NAME = :First_variable
                      AND STUDENT1P.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 6;
       sqlstm.stmt = "update STUDENT1P  set STUDENT1P.PHONE_NUM=:b0:b1,STUDE\
NT1P.E_MAIL=:b2:b3,STUDENT1P.ADDRESS=:b4:b5,STUDENT1P.U_COMMENT=:b6:b7 where (\
STUDENT1P.FIRST_NAME=:b8 and STUDENT1P.LAST_NAME=:b9)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )236;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcPhoneNum;
       sqlstm.sqhstl[0] = (unsigned int  )22;
       sqlstm.sqindv[0] = (         short *)&indPhoneNum;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&vcEmail;
       sqlstm.sqhstl[1] = (unsigned int  )52;
       sqlstm.sqindv[1] = (         short *)&indEmail;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&vcAddress;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)&indAddress;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqhstv[3] = (unsigned char  *)&vcComment;
       sqlstm.sqhstl[3] = (unsigned int  )130;
       sqlstm.sqindv[3] = (         short *)&indComment;
       sqlstm.sqharm[3] = (unsigned int  )0;
       sqlstm.sqhstv[4] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[4] = (unsigned int  )130;
       sqlstm.sqindv[4] = (         short *)0;
       sqlstm.sqharm[4] = (unsigned int  )0;
       sqlstm.sqhstv[5] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[5] = (unsigned int  )130;
       sqlstm.sqindv[5] = (         short *)0;
       sqlstm.sqharm[5] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}


       /* EXEC SQL COMMIT WORK RELEASE; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 6;
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )274;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode < 0) handle_error();
}




}
if (!strcmp(elements[0].val,"2p"))
{
       strcpy(First_variable.arr,elements[1].val);
       strcpy(Last_variable.arr,elements[2].val);
       First_variable.len = strlen(First_variable.arr);
       Last_variable.len = strlen(Last_variable.arr);
           
       strcpy(vcPhoneNum.arr,elements[3].val);
       vcPhoneNum.len = strlen(vcPhoneNum.arr);
       strcpy(vcEmail.arr,elements[4].val);
       vcEmail.len = strlen(vcEmail.arr);
       strcpy(vcAddress.arr,elements[5].val);
       vcAddress.len = strlen(vcAddress.arr);
       strcpy(vcComment.arr,elements[6].val);
       vcComment.len = strlen(vcComment.arr);
       
           /* assign Indicator variables for input */
       indPhoneNum = indEmail = indAddress = indComment = 0;
           
       /* EXEC SQL UPDATE STUDENT2P
                SET STUDENT2P.PHONE_NUM = :vcPhoneNum INDICATOR :indPhoneNum,
                    STUDENT2P.E_MAIL = :vcEmail INDICATOR :indEmail,
                    STUDENT2P.ADDRESS = :vcAddress INDICATOR :indAddress,
                    STUDENT2P.U_COMMENT = :vcComment INDICATOR :indComment
                WHERE STUDENT2P.FIRST_NAME = :First_variable
                      AND STUDENT2P.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 6;
       sqlstm.stmt = "update STUDENT2P  set STUDENT2P.PHONE_NUM=:b0:b1,STUDE\
NT2P.E_MAIL=:b2:b3,STUDENT2P.ADDRESS=:b4:b5,STUDENT2P.U_COMMENT=:b6:b7 where (\
STUDENT2P.FIRST_NAME=:b8 and STUDENT2P.LAST_NAME=:b9)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )288;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcPhoneNum;
       sqlstm.sqhstl[0] = (unsigned int  )22;
       sqlstm.sqindv[0] = (         short *)&indPhoneNum;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&vcEmail;
       sqlstm.sqhstl[1] = (unsigned int  )52;
       sqlstm.sqindv[1] = (         short *)&indEmail;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&vcAddress;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)&indAddress;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqhstv[3] = (unsigned char  *)&vcComment;
       sqlstm.sqhstl[3] = (unsigned int  )130;
       sqlstm.sqindv[3] = (         short *)&indComment;
       sqlstm.sqharm[3] = (unsigned int  )0;
       sqlstm.sqhstv[4] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[4] = (unsigned int  )130;
       sqlstm.sqindv[4] = (         short *)0;
       sqlstm.sqharm[4] = (unsigned int  )0;
       sqlstm.sqhstv[5] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[5] = (unsigned int  )130;
       sqlstm.sqindv[5] = (         short *)0;
       sqlstm.sqharm[5] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}


       /* EXEC SQL COMMIT WORK RELEASE; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 6;
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )326;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode < 0) handle_error();
}




}
if (!strcmp(elements[0].val,"3p"))
{
       strcpy(First_variable.arr,elements[1].val);
       strcpy(Last_variable.arr,elements[2].val);
       First_variable.len = strlen(First_variable.arr);
       Last_variable.len = strlen(Last_variable.arr);
           
       strcpy(vcPhoneNum.arr,elements[3].val);
       vcPhoneNum.len = strlen(vcPhoneNum.arr);
       strcpy(vcEmail.arr,elements[4].val);
       vcEmail.len = strlen(vcEmail.arr);
       strcpy(vcAddress.arr,elements[5].val);
       vcAddress.len = strlen(vcAddress.arr);
       strcpy(vcComment.arr,elements[6].val);
       vcComment.len = strlen(vcComment.arr);
       
           /* assign Indicator variables for input */
       indPhoneNum = indEmail = indAddress = indComment = 0;
           
       /* EXEC SQL UPDATE STUDENT3P
                SET STUDENT3P.PHONE_NUM = :vcPhoneNum INDICATOR :indPhoneNum,
                    STUDENT3P.E_MAIL = :vcEmail INDICATOR :indEmail,
                    STUDENT3P.ADDRESS = :vcAddress INDICATOR :indAddress,
                    STUDENT3P.U_COMMENT = :vcComment INDICATOR :indComment
                WHERE STUDENT3P.FIRST_NAME = :First_variable
                      AND STUDENT3P.LAST_NAME = :Last_variable; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 6;
       sqlstm.stmt = "update STUDENT3P  set STUDENT3P.PHONE_NUM=:b0:b1,STUDE\
NT3P.E_MAIL=:b2:b3,STUDENT3P.ADDRESS=:b4:b5,STUDENT3P.U_COMMENT=:b6:b7 where (\
STUDENT3P.FIRST_NAME=:b8 and STUDENT3P.LAST_NAME=:b9)";
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )340;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlstm.sqhstv[0] = (unsigned char  *)&vcPhoneNum;
       sqlstm.sqhstl[0] = (unsigned int  )22;
       sqlstm.sqindv[0] = (         short *)&indPhoneNum;
       sqlstm.sqharm[0] = (unsigned int  )0;
       sqlstm.sqhstv[1] = (unsigned char  *)&vcEmail;
       sqlstm.sqhstl[1] = (unsigned int  )52;
       sqlstm.sqindv[1] = (         short *)&indEmail;
       sqlstm.sqharm[1] = (unsigned int  )0;
       sqlstm.sqhstv[2] = (unsigned char  *)&vcAddress;
       sqlstm.sqhstl[2] = (unsigned int  )130;
       sqlstm.sqindv[2] = (         short *)&indAddress;
       sqlstm.sqharm[2] = (unsigned int  )0;
       sqlstm.sqhstv[3] = (unsigned char  *)&vcComment;
       sqlstm.sqhstl[3] = (unsigned int  )130;
       sqlstm.sqindv[3] = (         short *)&indComment;
       sqlstm.sqharm[3] = (unsigned int  )0;
       sqlstm.sqhstv[4] = (unsigned char  *)&First_variable;
       sqlstm.sqhstl[4] = (unsigned int  )130;
       sqlstm.sqindv[4] = (         short *)0;
       sqlstm.sqharm[4] = (unsigned int  )0;
       sqlstm.sqhstv[5] = (unsigned char  *)&Last_variable;
       sqlstm.sqhstl[5] = (unsigned int  )130;
       sqlstm.sqindv[5] = (         short *)0;
       sqlstm.sqharm[5] = (unsigned int  )0;
       sqlstm.sqphsv = sqlstm.sqhstv;
       sqlstm.sqphsl = sqlstm.sqhstl;
       sqlstm.sqpind = sqlstm.sqindv;
       sqlstm.sqparm = sqlstm.sqharm;
       sqlstm.sqparc = sqlstm.sqharc;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode == 1403) handle_not_found();
       if (sqlca.sqlcode < 0) handle_error();
}


       /* EXEC SQL COMMIT WORK RELEASE; */ 

{
       struct sqlexd sqlstm;

       sqlstm.sqlvsn = 8;
       sqlstm.arrsiz = 6;
       sqlstm.iters = (unsigned int  )1;
       sqlstm.offset = (unsigned int  )378;
       sqlstm.cud = sqlcud0;
       sqlstm.sqlest = (unsigned char  *)&sqlca;
       sqlstm.sqlety = (unsigned short)0;
       sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
       if (sqlca.sqlcode < 0) handle_error();
}




}


           /* Display Complete */
       printf("<CENTER>");
       printf("<FONT SIZE=+2>REPORT : </FONT>Update Complete");
       printf("</CENTER>");

       printf("<HR WIDTH=500 ALIGN=center SIZE=4>");

       printf("<BR>");
       printf("<CENTER>");
       printf("<A HREF=../../Project/right.html><IMG SRC=../../Project/home.jpg></A>");
       printf("<A HREF=../../Project/about.html><IMG SRC=../../Project/project.jpg></A>");
       printf("<A HREF=../../Project/member.html><IMG SRC=../../Project/member.jpg></A>");
       printf("<A HREF=../../Project/eng.html><IMG SRC=../../Project/comeng.jpg></A>");
       printf("</CENTER>");

       printf("<CENTER>");
       printf("<A HREF=../../Project/inst.html><IMG SRC=../../Project/ins_d.jpg></A>");
       printf("<A HREF=../../Project/upd.html><IMG SRC=../../Project/upd_d.jpg></A>");
       printf("<A HREF=../../Project/slt.html><IMG SRC=../../Project/sel_d.jpg></A>");
       printf("<A HREF=../../Project/del.html><IMG SRC=../../Project/del_d.jpg></A>");
       printf("</CENTER>");

       printf("<CENTER>");
       printf("<A HREF=../query/select_lst.sh.cgi><IMG SRC=../../Project/lst_d.jpg></A>");
       printf("<A HREF=../../Project/query.html><IMG SRC=../../Project/query_d.jpg></A>");
       printf("</CENTER>"); 


       printf("<BR>");

       printf("</BODY>");
       printf("</HTML>");



       fflush(stdout);
       close(stdout); 
       close(stderr); 

}

