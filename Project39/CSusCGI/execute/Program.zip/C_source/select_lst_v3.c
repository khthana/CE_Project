
/* Result Sets Interface */
#ifndef SQL_CRSR
#  define SQL_CRSR
  struct sql_cursor
  {
    unsigned int curocn;
    void *ptr1;
    void *ptr2;
    unsigned long magic;
  };
  typedef struct sql_cursor sql_cursor;
  typedef struct sql_cursor SQL_CURSOR;
#endif /* SQL_CRSR */

/* Thread Safety */
typedef void * sql_context;
typedef void * SQL_CONTEXT;

/* File name & Package Name */
struct sqlcxp
{
  unsigned short fillen;
           char  filnam[17];
};
static struct sqlcxp sqlfpn =
{
    16,
    "select_lst_v3.pc"
};


static unsigned long sqlctx = 5068019;


static struct sqlexd {
   unsigned int   sqlvsn;
   unsigned int   arrsiz;
   unsigned int   iters;
   unsigned int   offset;
   unsigned short selerr;
   unsigned short sqlety;
   unsigned int   unused;
            short *cud;
   unsigned char  *sqlest;
            char  *stmt;
   unsigned char  **sqphsv;
   unsigned int   *sqphsl;
            short **sqpind;
   unsigned int   *sqparm;
   unsigned int   **sqparc;
   unsigned char  *sqhstv[6];
   unsigned int   sqhstl[6];
            short *sqindv[6];
   unsigned int   sqharm[6];
   unsigned int   *sqharc[6];
} sqlstm = {8,6};

/* Prototypes */
extern sqlcxt (/*_ void **, unsigned long *,
                   struct sqlexd *, struct sqlcxp * _*/);
extern sqlcx2t(/*_ void **, unsigned long *,
                   struct sqlexd *, struct sqlcxp * _*/);
extern sqlbuft(/*_ void **, char * _*/);
extern sqlgs2t(/*_ void **, char * _*/);
extern sqlorat(/*_ void **, unsigned long *, void * _*/);

/* Forms Interface */
static int IAPSUCC = 0;
static int IAPFAIL = 1403;
static int IAPFTL  = 535;
extern sqliem(/*_ char *, int * _*/);

 static char *sq0002 = 
"select STUDENT1D.FIRST_NAME ,STUDENT1D.LAST_NAME ,STUDENT1D.PHONE_NUM ,STUDE\
NT1D.E_MAIL ,STUDENT1D.ADDRESS ,STUDENT1D.U_COMMENT  from STUDENT1D           \
 ";
 static char *sq0003 = 
"select STUDENT2D.FIRST_NAME ,STUDENT2D.LAST_NAME ,STUDENT2D.PHONE_NUM ,STUDE\
NT2D.E_MAIL ,STUDENT2D.ADDRESS ,STUDENT2D.U_COMMENT  from STUDENT2D           \
 ";
 static char *sq0004 = 
"select STUDENT3D.FIRST_NAME ,STUDENT3D.LAST_NAME ,STUDENT3D.PHONE_NUM ,STUDE\
NT3D.E_MAIL ,STUDENT3D.ADDRESS ,STUDENT3D.U_COMMENT  from STUDENT3D           \
 ";
 static char *sq0005 = 
"select STUDENT4D.FIRST_NAME ,STUDENT4D.LAST_NAME ,STUDENT4D.PHONE_NUM ,STUDE\
NT4D.E_MAIL ,STUDENT4D.ADDRESS ,STUDENT4D.U_COMMENT  from STUDENT4D           \
 ";
 static char *sq0006 = 
"select STUDENT1P.FIRST_NAME ,STUDENT1P.LAST_NAME ,STUDENT1P.PHONE_NUM ,STUDE\
NT1P.E_MAIL ,STUDENT1P.ADDRESS ,STUDENT1P.U_COMMENT  from STUDENT1P           \
 ";
 static char *sq0007 = 
"select STUDENT2P.FIRST_NAME ,STUDENT2P.LAST_NAME ,STUDENT2P.PHONE_NUM ,STUDE\
NT2P.E_MAIL ,STUDENT2P.ADDRESS ,STUDENT2P.U_COMMENT  from STUDENT2P           \
 ";
 static char *sq0008 = 
"select STUDENT3P.FIRST_NAME ,STUDENT3P.LAST_NAME ,STUDENT3P.PHONE_NUM ,STUDE\
NT3P.E_MAIL ,STUDENT3P.ADDRESS ,STUDENT3P.U_COMMENT  from STUDENT3P           \
 ";
typedef struct { unsigned short len; unsigned char arr[1]; } VARCHAR;
typedef struct { unsigned short len; unsigned char arr[1]; } varchar;

/* cud (compilation unit data) array */
static short sqlcud0[] =
{8,4130,
2,0,0,1,0,0,27,244,0,3,3,0,1,0,1,97,0,0,1,97,0,0,1,97,0,0,
28,0,0,2,155,0,9,261,0,0,0,0,1,0,
42,0,0,2,0,0,13,268,0,6,0,0,1,0,2,9,0,0,2,9,0,0,2,9,0,0,2,9,0,0,2,9,0,0,2,9,0,
0,
80,0,0,2,0,0,15,287,0,0,0,0,1,0,
94,0,0,3,155,0,9,302,0,0,0,0,1,0,
108,0,0,3,0,0,13,309,0,6,0,0,1,0,2,9,0,0,2,9,0,0,2,9,0,0,2,9,0,0,2,9,0,0,2,9,0,
0,
146,0,0,3,0,0,15,328,0,0,0,0,1,0,
160,0,0,4,155,0,9,343,0,0,0,0,1,0,
174,0,0,4,0,0,13,350,0,6,0,0,1,0,2,9,0,0,2,9,0,0,2,9,0,0,2,9,0,0,2,9,0,0,2,9,0,
0,
212,0,0,4,0,0,15,369,0,0,0,0,1,0,
226,0,0,5,155,0,9,384,0,0,0,0,1,0,
240,0,0,5,0,0,13,391,0,6,0,0,1,0,2,9,0,0,2,9,0,0,2,9,0,0,2,9,0,0,2,9,0,0,2,9,0,
0,
278,0,0,5,0,0,15,410,0,0,0,0,1,0,
292,0,0,6,155,0,9,425,0,0,0,0,1,0,
306,0,0,6,0,0,13,432,0,6,0,0,1,0,2,9,0,0,2,9,0,0,2,9,0,0,2,9,0,0,2,9,0,0,2,9,0,
0,
344,0,0,6,0,0,15,451,0,0,0,0,1,0,
358,0,0,7,155,0,9,466,0,0,0,0,1,0,
372,0,0,7,0,0,13,473,0,6,0,0,1,0,2,9,0,0,2,9,0,0,2,9,0,0,2,9,0,0,2,9,0,0,2,9,0,
0,
410,0,0,7,0,0,15,492,0,0,0,0,1,0,
424,0,0,8,155,0,9,507,0,0,0,0,1,0,
438,0,0,8,0,0,13,514,0,6,0,0,1,0,2,9,0,0,2,9,0,0,2,9,0,0,2,9,0,0,2,9,0,0,2,9,0,
0,
476,0,0,8,0,0,15,533,0,0,0,0,1,0,
};


/*  SELECT LIST VERSION 3.0 */

/*  The STUDENT TABLE 
**  FIRST_NAME  VARCHAR2(128) IS NOT NULL
**  LAST_NAME   VARCHAR2(128) IS NOT NULL
**  PHONE_NUM   VARCHAR2(128) IS NOT NULL
**  E_MAIL      VARCHAR2(128) IS NOT NULL
**  ADDRESS     VARCHAR2(128) IS NOT NULL
**  U_COMMENT   VARCHAR2(128) IS NOT NULL
**  (FIRST_NAME,LAST_NAME) IS PRIMARY KEY
*/

#include <stdio.h>
#include <stdlib.h>


short iRowCount=0;
short iRow=0;

/* The DECLARE Section */
/* EXEC SQL BEGIN DECLARE SECTION; */ 


/*
** Host variables for accessing the STUDENT table.
*/

/* VARCHAR avcFName[10][30]; */ 
struct { unsigned short len; unsigned char arr[30]; } avcFName[10];

/* VARCHAR avcLName[10][30]; */ 
struct { unsigned short len; unsigned char arr[30]; } avcLName[10];

/* VARCHAR avcPhoneNum[10][30]; */ 
struct { unsigned short len; unsigned char arr[30]; } avcPhoneNum[10];

/* VARCHAR avcEmail[10][30]; */ 
struct { unsigned short len; unsigned char arr[30]; } avcEmail[10];

/* VARCHAR avcAddress[10][128]; */ 
struct { unsigned short len; unsigned char arr[130]; } avcAddress[10];

/* VARCHAR avcUcomment[10][128]; */ 
struct { unsigned short len; unsigned char arr[130]; } avcUcomment[10];


/*
** Indicator variables for the host variables defined above.
*/

short aindFName[10];
short aindLName[10];
short aindPhoneNum[10];
short aindEmail[10];
short aindAddress[10];
short aindUcomment[10];

/* EXEC SQL END DECLARE SECTION; */ 

/* End DECLARE Section */


/* The DECLARE Section */
/* EXEC SQL BEGIN DECLARE SECTION; */ 


/* Host variables for logging into the Oracle database */

char scUserName[21]; 
char scPassword[21];
char scDatabaseName[21];

/* EXEC SQL END DECLARE SECTION; */ 

/* End DECLARE Section */




/* this is the structure we use
   for SQLCA */

struct sqlca
    {
    char sqlcaid[8];
    long sqlabc;
    long sqlcode;
    struct
        {
        unsigned short sqlerrml;
        char sqlerrmc[70];
        }  sqlerrm;
    char sqlerrp[8];
    long sqlerrd[6];
    char sqlwarn[8];
    char sqlext[8];
    };
struct sqlca sqlca;


void handle_error(void)
{
   sqlca.sqlerrm.sqlerrmc[sqlca.sqlerrm.sqlerrml] = '\0';
   
   /* Display error message */
   if (sqlca.sqlcode == -1) 
       {
       printf("<CENTER>");
       printf("<FONT SIZE=+2>REPORT : </FONT>Duplicate key value");
       printf("</CENTER>");
       }
   else
   if (sqlca.sqlcode == -1401) 
       {
       printf("<CENTER>");
       printf("<FONT SIZE=+2>REPORT : </FONT>Value too large");
       printf("</CENTER>");
       }
   else
       {
       printf("<CENTER>");
       printf("<FONT SIZE=+2>REPORT : </FONT>%s",sqlca.sqlerrm.sqlerrmc);
       printf("</CENTER>");
       }
   fflush(stdout);

   printf("<HR WIDTH=500 ALIGN=center SIZE=4>");

   printf("<BR>");
   printf("<CENTER>");
   printf("<A HREF=../../Project/right.html><IMG SRC=../../Project/home.jpg></A>");
   printf("<A HREF=../../Project/about.html><IMG SRC=../../Project/project.jpg></A>");
   printf("<A HREF=../../Project/member.html><IMG SRC=../../Project/member.jpg></A>");
   printf("<A HREF=../../Project/eng.html><IMG SRC=../../Project/comeng.jpg></A>");
   printf("</CENTER>");

   printf("<CENTER>");
   printf("<A HREF=../../Project/inst.html><IMG SRC=../../Project/ins_d.jpg></A>");
   printf("<A HREF=../../Project/upd.html><IMG SRC=../../Project/upd_d.jpg></A>");
   printf("<A HREF=../../Project/slt.html><IMG SRC=../../Project/sel_d.jpg></A>");
   printf("<A HREF=../../Project/del.html><IMG SRC=../../Project/del_d.jpg></A>");
   printf("</CENTER>");

   printf("<CENTER>");
   printf("<A HREF=select_lst.sh.cgi><IMG SRC=../../Project/lst_d.jpg></A>");
   printf("<A HREF=../../Project/query.html><IMG SRC=../../Project/query_d.jpg></A>");
   printf("</CENTER>");
   printf("<BR>");

   printf("</BODY>");
   printf("</HTML>");


   exit(0);

}

void handle_not_found(void)
{
   /* Display not found message */
   printf("<BR>");
   printf("<CENTER>");
   printf("<FONT SIZE=+2>REPORT : </FONT>Data not found");
   printf("</CENTER>");
   fflush(stdout);

   printf("<HR WIDTH=500 ALIGN=center SIZE=4>");

}

void display_data(n)
short n;
{
short iRowIndex;

   printf("<BR>");
   printf("<CENTER>");
   printf("<TABLE BORDER WIDTH=500,500 CELLSPACING=1 CELLPADDING=15>");
   printf("<TR>");
   printf("<TH BGCOLOR=Blue><Font Color=White>First Name </Font></TH>");
   printf("<TH BGCOLOR=Blue><Font Color=White>Last Name </Font></TH>");
   printf("</TR>");

   iRow = iRow+1;
   for (iRowIndex = 0;iRowIndex < n;++iRowIndex)
     {
      if (aindFName[iRowIndex] != 0)
         {
          printf("First Name = NULL");
         }
         else if (aindLName[iRowIndex] != 0)
             {
              printf("Last Name = NULL");
             } else
                 {
                 avcFName[iRowIndex].arr[avcFName[iRowIndex].len] = '\0';
                 avcLName[iRowIndex].arr[avcLName[iRowIndex].len] = '\0';     

                 /* Display key result */
                 printf("<TR height=40>");
                 printf("<TD>%s</TD>",avcFName[iRowIndex].arr);
                 printf("<TD>%s</TD>",avcLName[iRowIndex].arr);
                 printf("</TR>");
                 }
          
  }
  printf("</TABLE>");
  printf("<BR>");
  printf("<HR WIDTH=500 ALIGN=center SIZE=4>");
  printf("</CENTER>");
}



/* MAIN PROGRAM START HERE */
main()
{
/* The CGI header */

/* fprintf(stdout,"Content-type: text/plain\n"); */
/* fprintf(stdout,"\n\n"); */
/* fflush(stdout); */

printf("<HTML>");
printf("<BODY BGCOLOR=#FFFFFF TEXT=#000000 LINK =#FFFFFF VLINK=#FFFFFF>");

printf("<BR>");
printf("<CENTER>");
printf("<IMG SRC=../../Project/lst.jpg ALT=Report Page>");
printf("</CENTER>");
printf("<BR>");
printf("<HR WIDTH=500 ALIGN=center SIZE=4>");





/* Set Oracle environment */
putenv("LD_LIBRARY_PATH=/oracle/app/oracle/product/7.3.2/lib"); 
putenv("ORACLE_HOME=/oracle/app/oracle/product/7.3.2"); 
putenv("ORACLE_SID=kmitl1"); 
putenv("ORACLE_TERM=vt100"); 
putenv("MENU5PATH=/oracle/app/oracle/product/7.3.2/forms30/admin/resource"); 
putenv("ORATERMPATH=/oracle/app/oracle/product/7.3.2/forms30/admin/resource");


/* The SQL Start Here */

/* The Implicit Handling */
/* EXEC SQL WHENEVER SQLERROR DO handle_error(); */ 

/* EXEC SQL WHENEVER SQLWARNING CONTINUE; */ 

/* EXEC SQL WHENEVER NOT FOUND DO handle_not_found(); */ 


strcpy(scUserName,"student");
strcpy(scPassword,"student123");
strcpy(scDatabaseName,"kmitl1");


/* Connections */
/* EXEC SQL CONNECT :scUserName IDENTIFIED BY :scPassword
         USING :scDatabaseName; */ 

{
struct sqlexd sqlstm;

sqlstm.sqlvsn = 8;
sqlstm.arrsiz = 3;
sqlstm.iters = (unsigned int  )10;
sqlstm.offset = (unsigned int  )2;
sqlstm.cud = sqlcud0;
sqlstm.sqlest = (unsigned char  *)&sqlca;
sqlstm.sqlety = (unsigned short)0;
sqlstm.sqhstv[0] = (unsigned char  *)scUserName;
sqlstm.sqhstl[0] = (unsigned int  )21;
sqlstm.sqindv[0] = (         short *)0;
sqlstm.sqharm[0] = (unsigned int  )0;
sqlstm.sqhstv[1] = (unsigned char  *)scPassword;
sqlstm.sqhstl[1] = (unsigned int  )21;
sqlstm.sqindv[1] = (         short *)0;
sqlstm.sqharm[1] = (unsigned int  )0;
sqlstm.sqhstv[2] = (unsigned char  *)scDatabaseName;
sqlstm.sqhstl[2] = (unsigned int  )21;
sqlstm.sqindv[2] = (         short *)0;
sqlstm.sqharm[2] = (unsigned int  )0;
sqlstm.sqphsv = sqlstm.sqhstv;
sqlstm.sqphsl = sqlstm.sqhstl;
sqlstm.sqpind = sqlstm.sqindv;
sqlstm.sqparm = sqlstm.sqharm;
sqlstm.sqparc = sqlstm.sqharc;
sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
if (sqlca.sqlcode < 0) handle_error();
}


          /* assign Host variables for input */



/* STUDENT1D */
printf("<CENTER>");
printf("<FONT SIZE=+2>CLASS 1D</FONT>");
printf("</CENTER>");
/* Declare Cursor */
/* EXEC SQL DECLARE student_cursor1 CURSOR FOR
         SELECT STUDENT1D.FIRST_NAME,STUDENT1D.LAST_NAME,STUDENT1D.PHONE_NUM,
              STUDENT1D.E_MAIL,STUDENT1D.ADDRESS,STUDENT1D.U_COMMENT
         FROM STUDENT1D; */ 



/* EXEC SQL OPEN student_cursor1; */ 

{
struct sqlexd sqlstm;

sqlstm.sqlvsn = 8;
sqlstm.arrsiz = 3;
sqlstm.stmt = sq0002;
sqlstm.iters = (unsigned int  )1;
sqlstm.offset = (unsigned int  )28;
sqlstm.cud = sqlcud0;
sqlstm.sqlest = (unsigned char  *)&sqlca;
sqlstm.sqlety = (unsigned short)0;
sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
if (sqlca.sqlcode < 0) handle_error();
}



iRowCount = 0;

for(;;) /* Loop until the end of the data is reached */
{
/* EXEC SQL WHENEVER NOT FOUND DO break; */ 

/* EXEC SQL FETCH student_cursor1
     INTO :avcFName:aindFName,
          :avcLName:aindLName,
          :avcPhoneNum:aindPhoneNum,
          :avcEmail:aindEmail,
          :avcAddress:aindAddress,
          :avcUcomment:aindUcomment; */ 

{
struct sqlexd sqlstm;

sqlstm.sqlvsn = 8;
sqlstm.arrsiz = 6;
sqlstm.iters = (unsigned int  )10;
sqlstm.offset = (unsigned int  )42;
sqlstm.cud = sqlcud0;
sqlstm.sqlest = (unsigned char  *)&sqlca;
sqlstm.sqlety = (unsigned short)0;
sqlstm.sqhstv[0] = (unsigned char  *)avcFName;
sqlstm.sqhstl[0] = (unsigned int  )32;
sqlstm.sqindv[0] = (         short *)aindFName;
sqlstm.sqharm[0] = (unsigned int  )0;
sqlstm.sqharc[0] = (unsigned int   *)0;
sqlstm.sqhstv[1] = (unsigned char  *)avcLName;
sqlstm.sqhstl[1] = (unsigned int  )32;
sqlstm.sqindv[1] = (         short *)aindLName;
sqlstm.sqharm[1] = (unsigned int  )0;
sqlstm.sqharc[1] = (unsigned int   *)0;
sqlstm.sqhstv[2] = (unsigned char  *)avcPhoneNum;
sqlstm.sqhstl[2] = (unsigned int  )32;
sqlstm.sqindv[2] = (         short *)aindPhoneNum;
sqlstm.sqharm[2] = (unsigned int  )0;
sqlstm.sqharc[2] = (unsigned int   *)0;
sqlstm.sqhstv[3] = (unsigned char  *)avcEmail;
sqlstm.sqhstl[3] = (unsigned int  )32;
sqlstm.sqindv[3] = (         short *)aindEmail;
sqlstm.sqharm[3] = (unsigned int  )0;
sqlstm.sqharc[3] = (unsigned int   *)0;
sqlstm.sqhstv[4] = (unsigned char  *)avcAddress;
sqlstm.sqhstl[4] = (unsigned int  )132;
sqlstm.sqindv[4] = (         short *)aindAddress;
sqlstm.sqharm[4] = (unsigned int  )0;
sqlstm.sqharc[4] = (unsigned int   *)0;
sqlstm.sqhstv[5] = (unsigned char  *)avcUcomment;
sqlstm.sqhstl[5] = (unsigned int  )132;
sqlstm.sqindv[5] = (         short *)aindUcomment;
sqlstm.sqharm[5] = (unsigned int  )0;
sqlstm.sqharc[5] = (unsigned int   *)0;
sqlstm.sqphsv = sqlstm.sqhstv;
sqlstm.sqphsl = sqlstm.sqhstl;
sqlstm.sqpind = sqlstm.sqindv;
sqlstm.sqparm = sqlstm.sqharm;
sqlstm.sqparc = sqlstm.sqharc;
sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
if (sqlca.sqlcode == 1403) break;
if (sqlca.sqlcode < 0) handle_error();
}



display_data(sqlca.sqlerrd[2] - iRowCount);
iRowCount = sqlca.sqlerrd[2];
}

if ((sqlca.sqlerrd[2]-iRowCount)>0)
    display_data(sqlca.sqlerrd[2]-iRowCount);

if (iRow == 0)
      handle_not_found();


/* EXEC SQL CLOSE student_cursor1; */ 

{
struct sqlexd sqlstm;

sqlstm.sqlvsn = 8;
sqlstm.arrsiz = 6;
sqlstm.iters = (unsigned int  )1;
sqlstm.offset = (unsigned int  )80;
sqlstm.cud = sqlcud0;
sqlstm.sqlest = (unsigned char  *)&sqlca;
sqlstm.sqlety = (unsigned short)0;
sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
if (sqlca.sqlcode < 0) handle_error();
}



iRowCount = 0;
iRow = 0;
/* STUDENT2D */
printf("<CENTER>");
printf("<FONT SIZE=+2>CLASS 2D</FONT>");
printf("</CENTER>");
/* Declare Cursor */
/* EXEC SQL DECLARE student_cursor2 CURSOR FOR
         SELECT STUDENT2D.FIRST_NAME,STUDENT2D.LAST_NAME,STUDENT2D.PHONE_NUM,
              STUDENT2D.E_MAIL,STUDENT2D.ADDRESS,STUDENT2D.U_COMMENT
         FROM STUDENT2D; */ 



/* EXEC SQL OPEN student_cursor2; */ 

{
struct sqlexd sqlstm;

sqlstm.sqlvsn = 8;
sqlstm.arrsiz = 6;
sqlstm.stmt = sq0003;
sqlstm.iters = (unsigned int  )1;
sqlstm.offset = (unsigned int  )94;
sqlstm.cud = sqlcud0;
sqlstm.sqlest = (unsigned char  *)&sqlca;
sqlstm.sqlety = (unsigned short)0;
sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
if (sqlca.sqlcode < 0) handle_error();
}



iRowCount = 0;

for(;;) /* Loop until the end of the data is reached */
{
/* EXEC SQL WHENEVER NOT FOUND DO break; */ 

/* EXEC SQL FETCH student_cursor2
     INTO :avcFName:aindFName,
          :avcLName:aindLName,
          :avcPhoneNum:aindPhoneNum,
          :avcEmail:aindEmail,
          :avcAddress:aindAddress,
          :avcUcomment:aindUcomment; */ 

{
struct sqlexd sqlstm;

sqlstm.sqlvsn = 8;
sqlstm.arrsiz = 6;
sqlstm.iters = (unsigned int  )10;
sqlstm.offset = (unsigned int  )108;
sqlstm.cud = sqlcud0;
sqlstm.sqlest = (unsigned char  *)&sqlca;
sqlstm.sqlety = (unsigned short)0;
sqlstm.sqhstv[0] = (unsigned char  *)avcFName;
sqlstm.sqhstl[0] = (unsigned int  )32;
sqlstm.sqindv[0] = (         short *)aindFName;
sqlstm.sqharm[0] = (unsigned int  )0;
sqlstm.sqharc[0] = (unsigned int   *)0;
sqlstm.sqhstv[1] = (unsigned char  *)avcLName;
sqlstm.sqhstl[1] = (unsigned int  )32;
sqlstm.sqindv[1] = (         short *)aindLName;
sqlstm.sqharm[1] = (unsigned int  )0;
sqlstm.sqharc[1] = (unsigned int   *)0;
sqlstm.sqhstv[2] = (unsigned char  *)avcPhoneNum;
sqlstm.sqhstl[2] = (unsigned int  )32;
sqlstm.sqindv[2] = (         short *)aindPhoneNum;
sqlstm.sqharm[2] = (unsigned int  )0;
sqlstm.sqharc[2] = (unsigned int   *)0;
sqlstm.sqhstv[3] = (unsigned char  *)avcEmail;
sqlstm.sqhstl[3] = (unsigned int  )32;
sqlstm.sqindv[3] = (         short *)aindEmail;
sqlstm.sqharm[3] = (unsigned int  )0;
sqlstm.sqharc[3] = (unsigned int   *)0;
sqlstm.sqhstv[4] = (unsigned char  *)avcAddress;
sqlstm.sqhstl[4] = (unsigned int  )132;
sqlstm.sqindv[4] = (         short *)aindAddress;
sqlstm.sqharm[4] = (unsigned int  )0;
sqlstm.sqharc[4] = (unsigned int   *)0;
sqlstm.sqhstv[5] = (unsigned char  *)avcUcomment;
sqlstm.sqhstl[5] = (unsigned int  )132;
sqlstm.sqindv[5] = (         short *)aindUcomment;
sqlstm.sqharm[5] = (unsigned int  )0;
sqlstm.sqharc[5] = (unsigned int   *)0;
sqlstm.sqphsv = sqlstm.sqhstv;
sqlstm.sqphsl = sqlstm.sqhstl;
sqlstm.sqpind = sqlstm.sqindv;
sqlstm.sqparm = sqlstm.sqharm;
sqlstm.sqparc = sqlstm.sqharc;
sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
if (sqlca.sqlcode == 1403) break;
if (sqlca.sqlcode < 0) handle_error();
}



display_data(sqlca.sqlerrd[2] - iRowCount);
iRowCount = sqlca.sqlerrd[2];
}

if ((sqlca.sqlerrd[2]-iRowCount)>0)
    display_data(sqlca.sqlerrd[2]-iRowCount);

if (iRow == 0)
      handle_not_found();


/* EXEC SQL CLOSE student_cursor2; */ 

{
struct sqlexd sqlstm;

sqlstm.sqlvsn = 8;
sqlstm.arrsiz = 6;
sqlstm.iters = (unsigned int  )1;
sqlstm.offset = (unsigned int  )146;
sqlstm.cud = sqlcud0;
sqlstm.sqlest = (unsigned char  *)&sqlca;
sqlstm.sqlety = (unsigned short)0;
sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
if (sqlca.sqlcode < 0) handle_error();
}



iRowCount = 0;
iRow = 0;
/* STUDENT3D */
printf("<CENTER>");
printf("<FONT SIZE=+2>CLASS 3D</FONT>");
printf("</CENTER>");
/* Declare Cursor */
/* EXEC SQL DECLARE student_cursor3 CURSOR FOR
         SELECT STUDENT3D.FIRST_NAME,STUDENT3D.LAST_NAME,STUDENT3D.PHONE_NUM,
              STUDENT3D.E_MAIL,STUDENT3D.ADDRESS,STUDENT3D.U_COMMENT
         FROM STUDENT3D; */ 



/* EXEC SQL OPEN student_cursor3; */ 

{
struct sqlexd sqlstm;

sqlstm.sqlvsn = 8;
sqlstm.arrsiz = 6;
sqlstm.stmt = sq0004;
sqlstm.iters = (unsigned int  )1;
sqlstm.offset = (unsigned int  )160;
sqlstm.cud = sqlcud0;
sqlstm.sqlest = (unsigned char  *)&sqlca;
sqlstm.sqlety = (unsigned short)0;
sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
if (sqlca.sqlcode < 0) handle_error();
}



iRowCount = 0;

for(;;) /* Loop until the end of the data is reached */
{
/* EXEC SQL WHENEVER NOT FOUND DO break; */ 

/* EXEC SQL FETCH student_cursor3
     INTO :avcFName:aindFName,
          :avcLName:aindLName,
          :avcPhoneNum:aindPhoneNum,
          :avcEmail:aindEmail,
          :avcAddress:aindAddress,
          :avcUcomment:aindUcomment; */ 

{
struct sqlexd sqlstm;

sqlstm.sqlvsn = 8;
sqlstm.arrsiz = 6;
sqlstm.iters = (unsigned int  )10;
sqlstm.offset = (unsigned int  )174;
sqlstm.cud = sqlcud0;
sqlstm.sqlest = (unsigned char  *)&sqlca;
sqlstm.sqlety = (unsigned short)0;
sqlstm.sqhstv[0] = (unsigned char  *)avcFName;
sqlstm.sqhstl[0] = (unsigned int  )32;
sqlstm.sqindv[0] = (         short *)aindFName;
sqlstm.sqharm[0] = (unsigned int  )0;
sqlstm.sqharc[0] = (unsigned int   *)0;
sqlstm.sqhstv[1] = (unsigned char  *)avcLName;
sqlstm.sqhstl[1] = (unsigned int  )32;
sqlstm.sqindv[1] = (         short *)aindLName;
sqlstm.sqharm[1] = (unsigned int  )0;
sqlstm.sqharc[1] = (unsigned int   *)0;
sqlstm.sqhstv[2] = (unsigned char  *)avcPhoneNum;
sqlstm.sqhstl[2] = (unsigned int  )32;
sqlstm.sqindv[2] = (         short *)aindPhoneNum;
sqlstm.sqharm[2] = (unsigned int  )0;
sqlstm.sqharc[2] = (unsigned int   *)0;
sqlstm.sqhstv[3] = (unsigned char  *)avcEmail;
sqlstm.sqhstl[3] = (unsigned int  )32;
sqlstm.sqindv[3] = (         short *)aindEmail;
sqlstm.sqharm[3] = (unsigned int  )0;
sqlstm.sqharc[3] = (unsigned int   *)0;
sqlstm.sqhstv[4] = (unsigned char  *)avcAddress;
sqlstm.sqhstl[4] = (unsigned int  )132;
sqlstm.sqindv[4] = (         short *)aindAddress;
sqlstm.sqharm[4] = (unsigned int  )0;
sqlstm.sqharc[4] = (unsigned int   *)0;
sqlstm.sqhstv[5] = (unsigned char  *)avcUcomment;
sqlstm.sqhstl[5] = (unsigned int  )132;
sqlstm.sqindv[5] = (         short *)aindUcomment;
sqlstm.sqharm[5] = (unsigned int  )0;
sqlstm.sqharc[5] = (unsigned int   *)0;
sqlstm.sqphsv = sqlstm.sqhstv;
sqlstm.sqphsl = sqlstm.sqhstl;
sqlstm.sqpind = sqlstm.sqindv;
sqlstm.sqparm = sqlstm.sqharm;
sqlstm.sqparc = sqlstm.sqharc;
sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
if (sqlca.sqlcode == 1403) break;
if (sqlca.sqlcode < 0) handle_error();
}



display_data(sqlca.sqlerrd[2] - iRowCount);
iRowCount = sqlca.sqlerrd[2];
}

if ((sqlca.sqlerrd[2]-iRowCount)>0)
    display_data(sqlca.sqlerrd[2]-iRowCount);

if (iRow == 0)
      handle_not_found();


/* EXEC SQL CLOSE student_cursor3; */ 

{
struct sqlexd sqlstm;

sqlstm.sqlvsn = 8;
sqlstm.arrsiz = 6;
sqlstm.iters = (unsigned int  )1;
sqlstm.offset = (unsigned int  )212;
sqlstm.cud = sqlcud0;
sqlstm.sqlest = (unsigned char  *)&sqlca;
sqlstm.sqlety = (unsigned short)0;
sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
if (sqlca.sqlcode < 0) handle_error();
}



iRowCount = 0;
iRow = 0;
/* STUDENT4D */
printf("<CENTER>");
printf("<FONT SIZE=+2>CLASS 4D</FONT>");
printf("</CENTER>");
/* Declare Cursor */
/* EXEC SQL DECLARE student_cursor4 CURSOR FOR
         SELECT STUDENT4D.FIRST_NAME,STUDENT4D.LAST_NAME,STUDENT4D.PHONE_NUM,
              STUDENT4D.E_MAIL,STUDENT4D.ADDRESS,STUDENT4D.U_COMMENT
         FROM STUDENT4D; */ 



/* EXEC SQL OPEN student_cursor4; */ 

{
struct sqlexd sqlstm;

sqlstm.sqlvsn = 8;
sqlstm.arrsiz = 6;
sqlstm.stmt = sq0005;
sqlstm.iters = (unsigned int  )1;
sqlstm.offset = (unsigned int  )226;
sqlstm.cud = sqlcud0;
sqlstm.sqlest = (unsigned char  *)&sqlca;
sqlstm.sqlety = (unsigned short)0;
sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
if (sqlca.sqlcode < 0) handle_error();
}



iRowCount = 0;

for(;;) /* Loop until the end of the data is reached */
{
/* EXEC SQL WHENEVER NOT FOUND DO break; */ 

/* EXEC SQL FETCH student_cursor4
     INTO :avcFName:aindFName,
          :avcLName:aindLName,
          :avcPhoneNum:aindPhoneNum,
          :avcEmail:aindEmail,
          :avcAddress:aindAddress,
          :avcUcomment:aindUcomment; */ 

{
struct sqlexd sqlstm;

sqlstm.sqlvsn = 8;
sqlstm.arrsiz = 6;
sqlstm.iters = (unsigned int  )10;
sqlstm.offset = (unsigned int  )240;
sqlstm.cud = sqlcud0;
sqlstm.sqlest = (unsigned char  *)&sqlca;
sqlstm.sqlety = (unsigned short)0;
sqlstm.sqhstv[0] = (unsigned char  *)avcFName;
sqlstm.sqhstl[0] = (unsigned int  )32;
sqlstm.sqindv[0] = (         short *)aindFName;
sqlstm.sqharm[0] = (unsigned int  )0;
sqlstm.sqharc[0] = (unsigned int   *)0;
sqlstm.sqhstv[1] = (unsigned char  *)avcLName;
sqlstm.sqhstl[1] = (unsigned int  )32;
sqlstm.sqindv[1] = (         short *)aindLName;
sqlstm.sqharm[1] = (unsigned int  )0;
sqlstm.sqharc[1] = (unsigned int   *)0;
sqlstm.sqhstv[2] = (unsigned char  *)avcPhoneNum;
sqlstm.sqhstl[2] = (unsigned int  )32;
sqlstm.sqindv[2] = (         short *)aindPhoneNum;
sqlstm.sqharm[2] = (unsigned int  )0;
sqlstm.sqharc[2] = (unsigned int   *)0;
sqlstm.sqhstv[3] = (unsigned char  *)avcEmail;
sqlstm.sqhstl[3] = (unsigned int  )32;
sqlstm.sqindv[3] = (         short *)aindEmail;
sqlstm.sqharm[3] = (unsigned int  )0;
sqlstm.sqharc[3] = (unsigned int   *)0;
sqlstm.sqhstv[4] = (unsigned char  *)avcAddress;
sqlstm.sqhstl[4] = (unsigned int  )132;
sqlstm.sqindv[4] = (         short *)aindAddress;
sqlstm.sqharm[4] = (unsigned int  )0;
sqlstm.sqharc[4] = (unsigned int   *)0;
sqlstm.sqhstv[5] = (unsigned char  *)avcUcomment;
sqlstm.sqhstl[5] = (unsigned int  )132;
sqlstm.sqindv[5] = (         short *)aindUcomment;
sqlstm.sqharm[5] = (unsigned int  )0;
sqlstm.sqharc[5] = (unsigned int   *)0;
sqlstm.sqphsv = sqlstm.sqhstv;
sqlstm.sqphsl = sqlstm.sqhstl;
sqlstm.sqpind = sqlstm.sqindv;
sqlstm.sqparm = sqlstm.sqharm;
sqlstm.sqparc = sqlstm.sqharc;
sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
if (sqlca.sqlcode == 1403) break;
if (sqlca.sqlcode < 0) handle_error();
}



display_data(sqlca.sqlerrd[2] - iRowCount);
iRowCount = sqlca.sqlerrd[2];
}

if ((sqlca.sqlerrd[2]-iRowCount)>0)
    display_data(sqlca.sqlerrd[2]-iRowCount);

if (iRow == 0)
      handle_not_found();


/* EXEC SQL CLOSE student_cursor4; */ 

{
struct sqlexd sqlstm;

sqlstm.sqlvsn = 8;
sqlstm.arrsiz = 6;
sqlstm.iters = (unsigned int  )1;
sqlstm.offset = (unsigned int  )278;
sqlstm.cud = sqlcud0;
sqlstm.sqlest = (unsigned char  *)&sqlca;
sqlstm.sqlety = (unsigned short)0;
sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
if (sqlca.sqlcode < 0) handle_error();
}



iRowCount = 0;
iRow = 0;
/* STUDENT1P */
printf("<CENTER>");
printf("<FONT SIZE=+2>CLASS 1P</FONT>");
printf("</CENTER>");
/* Declare Cursor */
/* EXEC SQL DECLARE student_cursor5 CURSOR FOR
         SELECT STUDENT1P.FIRST_NAME,STUDENT1P.LAST_NAME,STUDENT1P.PHONE_NUM,
              STUDENT1P.E_MAIL,STUDENT1P.ADDRESS,STUDENT1P.U_COMMENT
         FROM STUDENT1P; */ 



/* EXEC SQL OPEN student_cursor5; */ 

{
struct sqlexd sqlstm;

sqlstm.sqlvsn = 8;
sqlstm.arrsiz = 6;
sqlstm.stmt = sq0006;
sqlstm.iters = (unsigned int  )1;
sqlstm.offset = (unsigned int  )292;
sqlstm.cud = sqlcud0;
sqlstm.sqlest = (unsigned char  *)&sqlca;
sqlstm.sqlety = (unsigned short)0;
sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
if (sqlca.sqlcode < 0) handle_error();
}



iRowCount = 0;

for(;;) /* Loop until the end of the data is reached */
{
/* EXEC SQL WHENEVER NOT FOUND DO break; */ 

/* EXEC SQL FETCH student_cursor5
     INTO :avcFName:aindFName,
          :avcLName:aindLName,
          :avcPhoneNum:aindPhoneNum,
          :avcEmail:aindEmail,
          :avcAddress:aindAddress,
          :avcUcomment:aindUcomment; */ 

{
struct sqlexd sqlstm;

sqlstm.sqlvsn = 8;
sqlstm.arrsiz = 6;
sqlstm.iters = (unsigned int  )10;
sqlstm.offset = (unsigned int  )306;
sqlstm.cud = sqlcud0;
sqlstm.sqlest = (unsigned char  *)&sqlca;
sqlstm.sqlety = (unsigned short)0;
sqlstm.sqhstv[0] = (unsigned char  *)avcFName;
sqlstm.sqhstl[0] = (unsigned int  )32;
sqlstm.sqindv[0] = (         short *)aindFName;
sqlstm.sqharm[0] = (unsigned int  )0;
sqlstm.sqharc[0] = (unsigned int   *)0;
sqlstm.sqhstv[1] = (unsigned char  *)avcLName;
sqlstm.sqhstl[1] = (unsigned int  )32;
sqlstm.sqindv[1] = (         short *)aindLName;
sqlstm.sqharm[1] = (unsigned int  )0;
sqlstm.sqharc[1] = (unsigned int   *)0;
sqlstm.sqhstv[2] = (unsigned char  *)avcPhoneNum;
sqlstm.sqhstl[2] = (unsigned int  )32;
sqlstm.sqindv[2] = (         short *)aindPhoneNum;
sqlstm.sqharm[2] = (unsigned int  )0;
sqlstm.sqharc[2] = (unsigned int   *)0;
sqlstm.sqhstv[3] = (unsigned char  *)avcEmail;
sqlstm.sqhstl[3] = (unsigned int  )32;
sqlstm.sqindv[3] = (         short *)aindEmail;
sqlstm.sqharm[3] = (unsigned int  )0;
sqlstm.sqharc[3] = (unsigned int   *)0;
sqlstm.sqhstv[4] = (unsigned char  *)avcAddress;
sqlstm.sqhstl[4] = (unsigned int  )132;
sqlstm.sqindv[4] = (         short *)aindAddress;
sqlstm.sqharm[4] = (unsigned int  )0;
sqlstm.sqharc[4] = (unsigned int   *)0;
sqlstm.sqhstv[5] = (unsigned char  *)avcUcomment;
sqlstm.sqhstl[5] = (unsigned int  )132;
sqlstm.sqindv[5] = (         short *)aindUcomment;
sqlstm.sqharm[5] = (unsigned int  )0;
sqlstm.sqharc[5] = (unsigned int   *)0;
sqlstm.sqphsv = sqlstm.sqhstv;
sqlstm.sqphsl = sqlstm.sqhstl;
sqlstm.sqpind = sqlstm.sqindv;
sqlstm.sqparm = sqlstm.sqharm;
sqlstm.sqparc = sqlstm.sqharc;
sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
if (sqlca.sqlcode == 1403) break;
if (sqlca.sqlcode < 0) handle_error();
}



display_data(sqlca.sqlerrd[2] - iRowCount);
iRowCount = sqlca.sqlerrd[2];
}

if ((sqlca.sqlerrd[2]-iRowCount)>0)
    display_data(sqlca.sqlerrd[2]-iRowCount);

if (iRow == 0)
      handle_not_found();


/* EXEC SQL CLOSE student_cursor5; */ 

{
struct sqlexd sqlstm;

sqlstm.sqlvsn = 8;
sqlstm.arrsiz = 6;
sqlstm.iters = (unsigned int  )1;
sqlstm.offset = (unsigned int  )344;
sqlstm.cud = sqlcud0;
sqlstm.sqlest = (unsigned char  *)&sqlca;
sqlstm.sqlety = (unsigned short)0;
sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
if (sqlca.sqlcode < 0) handle_error();
}



iRowCount = 0;
iRow = 0;
/* STUDENT2P */
printf("<CENTER>");
printf("<FONT SIZE=+2>CLASS 2P</FONT>");
printf("</CENTER>");
/* Declare Cursor */
/* EXEC SQL DECLARE student_cursor6 CURSOR FOR
         SELECT STUDENT2P.FIRST_NAME,STUDENT2P.LAST_NAME,STUDENT2P.PHONE_NUM,
              STUDENT2P.E_MAIL,STUDENT2P.ADDRESS,STUDENT2P.U_COMMENT
         FROM STUDENT2P; */ 



/* EXEC SQL OPEN student_cursor6; */ 

{
struct sqlexd sqlstm;

sqlstm.sqlvsn = 8;
sqlstm.arrsiz = 6;
sqlstm.stmt = sq0007;
sqlstm.iters = (unsigned int  )1;
sqlstm.offset = (unsigned int  )358;
sqlstm.cud = sqlcud0;
sqlstm.sqlest = (unsigned char  *)&sqlca;
sqlstm.sqlety = (unsigned short)0;
sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
if (sqlca.sqlcode < 0) handle_error();
}



iRowCount = 0;

for(;;) /* Loop until the end of the data is reached */
{
/* EXEC SQL WHENEVER NOT FOUND DO break; */ 

/* EXEC SQL FETCH student_cursor6
     INTO :avcFName:aindFName,
          :avcLName:aindLName,
          :avcPhoneNum:aindPhoneNum,
          :avcEmail:aindEmail,
          :avcAddress:aindAddress,
          :avcUcomment:aindUcomment; */ 

{
struct sqlexd sqlstm;

sqlstm.sqlvsn = 8;
sqlstm.arrsiz = 6;
sqlstm.iters = (unsigned int  )10;
sqlstm.offset = (unsigned int  )372;
sqlstm.cud = sqlcud0;
sqlstm.sqlest = (unsigned char  *)&sqlca;
sqlstm.sqlety = (unsigned short)0;
sqlstm.sqhstv[0] = (unsigned char  *)avcFName;
sqlstm.sqhstl[0] = (unsigned int  )32;
sqlstm.sqindv[0] = (         short *)aindFName;
sqlstm.sqharm[0] = (unsigned int  )0;
sqlstm.sqharc[0] = (unsigned int   *)0;
sqlstm.sqhstv[1] = (unsigned char  *)avcLName;
sqlstm.sqhstl[1] = (unsigned int  )32;
sqlstm.sqindv[1] = (         short *)aindLName;
sqlstm.sqharm[1] = (unsigned int  )0;
sqlstm.sqharc[1] = (unsigned int   *)0;
sqlstm.sqhstv[2] = (unsigned char  *)avcPhoneNum;
sqlstm.sqhstl[2] = (unsigned int  )32;
sqlstm.sqindv[2] = (         short *)aindPhoneNum;
sqlstm.sqharm[2] = (unsigned int  )0;
sqlstm.sqharc[2] = (unsigned int   *)0;
sqlstm.sqhstv[3] = (unsigned char  *)avcEmail;
sqlstm.sqhstl[3] = (unsigned int  )32;
sqlstm.sqindv[3] = (         short *)aindEmail;
sqlstm.sqharm[3] = (unsigned int  )0;
sqlstm.sqharc[3] = (unsigned int   *)0;
sqlstm.sqhstv[4] = (unsigned char  *)avcAddress;
sqlstm.sqhstl[4] = (unsigned int  )132;
sqlstm.sqindv[4] = (         short *)aindAddress;
sqlstm.sqharm[4] = (unsigned int  )0;
sqlstm.sqharc[4] = (unsigned int   *)0;
sqlstm.sqhstv[5] = (unsigned char  *)avcUcomment;
sqlstm.sqhstl[5] = (unsigned int  )132;
sqlstm.sqindv[5] = (         short *)aindUcomment;
sqlstm.sqharm[5] = (unsigned int  )0;
sqlstm.sqharc[5] = (unsigned int   *)0;
sqlstm.sqphsv = sqlstm.sqhstv;
sqlstm.sqphsl = sqlstm.sqhstl;
sqlstm.sqpind = sqlstm.sqindv;
sqlstm.sqparm = sqlstm.sqharm;
sqlstm.sqparc = sqlstm.sqharc;
sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
if (sqlca.sqlcode == 1403) break;
if (sqlca.sqlcode < 0) handle_error();
}



display_data(sqlca.sqlerrd[2] - iRowCount);
iRowCount = sqlca.sqlerrd[2];
}

if ((sqlca.sqlerrd[2]-iRowCount)>0)
    display_data(sqlca.sqlerrd[2]-iRowCount);

if (iRow == 0)
      handle_not_found();


/* EXEC SQL CLOSE student_cursor6; */ 

{
struct sqlexd sqlstm;

sqlstm.sqlvsn = 8;
sqlstm.arrsiz = 6;
sqlstm.iters = (unsigned int  )1;
sqlstm.offset = (unsigned int  )410;
sqlstm.cud = sqlcud0;
sqlstm.sqlest = (unsigned char  *)&sqlca;
sqlstm.sqlety = (unsigned short)0;
sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
if (sqlca.sqlcode < 0) handle_error();
}



iRowCount = 0;
iRow = 0;
/* STUDENT3P */
printf("<CENTER>");
printf("<FONT SIZE=+2>CLASS 3P</FONT>");
printf("</CENTER>");
/* Declare Cursor */
/* EXEC SQL DECLARE student_cursor7 CURSOR FOR
         SELECT STUDENT3P.FIRST_NAME,STUDENT3P.LAST_NAME,STUDENT3P.PHONE_NUM,
              STUDENT3P.E_MAIL,STUDENT3P.ADDRESS,STUDENT3P.U_COMMENT
         FROM STUDENT3P; */ 



/* EXEC SQL OPEN student_cursor7; */ 

{
struct sqlexd sqlstm;

sqlstm.sqlvsn = 8;
sqlstm.arrsiz = 6;
sqlstm.stmt = sq0008;
sqlstm.iters = (unsigned int  )1;
sqlstm.offset = (unsigned int  )424;
sqlstm.cud = sqlcud0;
sqlstm.sqlest = (unsigned char  *)&sqlca;
sqlstm.sqlety = (unsigned short)0;
sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
if (sqlca.sqlcode < 0) handle_error();
}



iRowCount = 0;

for(;;) /* Loop until the end of the data is reached */
{
/* EXEC SQL WHENEVER NOT FOUND DO break; */ 

/* EXEC SQL FETCH student_cursor7
     INTO :avcFName:aindFName,
          :avcLName:aindLName,
          :avcPhoneNum:aindPhoneNum,
          :avcEmail:aindEmail,
          :avcAddress:aindAddress,
          :avcUcomment:aindUcomment; */ 

{
struct sqlexd sqlstm;

sqlstm.sqlvsn = 8;
sqlstm.arrsiz = 6;
sqlstm.iters = (unsigned int  )10;
sqlstm.offset = (unsigned int  )438;
sqlstm.cud = sqlcud0;
sqlstm.sqlest = (unsigned char  *)&sqlca;
sqlstm.sqlety = (unsigned short)0;
sqlstm.sqhstv[0] = (unsigned char  *)avcFName;
sqlstm.sqhstl[0] = (unsigned int  )32;
sqlstm.sqindv[0] = (         short *)aindFName;
sqlstm.sqharm[0] = (unsigned int  )0;
sqlstm.sqharc[0] = (unsigned int   *)0;
sqlstm.sqhstv[1] = (unsigned char  *)avcLName;
sqlstm.sqhstl[1] = (unsigned int  )32;
sqlstm.sqindv[1] = (         short *)aindLName;
sqlstm.sqharm[1] = (unsigned int  )0;
sqlstm.sqharc[1] = (unsigned int   *)0;
sqlstm.sqhstv[2] = (unsigned char  *)avcPhoneNum;
sqlstm.sqhstl[2] = (unsigned int  )32;
sqlstm.sqindv[2] = (         short *)aindPhoneNum;
sqlstm.sqharm[2] = (unsigned int  )0;
sqlstm.sqharc[2] = (unsigned int   *)0;
sqlstm.sqhstv[3] = (unsigned char  *)avcEmail;
sqlstm.sqhstl[3] = (unsigned int  )32;
sqlstm.sqindv[3] = (         short *)aindEmail;
sqlstm.sqharm[3] = (unsigned int  )0;
sqlstm.sqharc[3] = (unsigned int   *)0;
sqlstm.sqhstv[4] = (unsigned char  *)avcAddress;
sqlstm.sqhstl[4] = (unsigned int  )132;
sqlstm.sqindv[4] = (         short *)aindAddress;
sqlstm.sqharm[4] = (unsigned int  )0;
sqlstm.sqharc[4] = (unsigned int   *)0;
sqlstm.sqhstv[5] = (unsigned char  *)avcUcomment;
sqlstm.sqhstl[5] = (unsigned int  )132;
sqlstm.sqindv[5] = (         short *)aindUcomment;
sqlstm.sqharm[5] = (unsigned int  )0;
sqlstm.sqharc[5] = (unsigned int   *)0;
sqlstm.sqphsv = sqlstm.sqhstv;
sqlstm.sqphsl = sqlstm.sqhstl;
sqlstm.sqpind = sqlstm.sqindv;
sqlstm.sqparm = sqlstm.sqharm;
sqlstm.sqparc = sqlstm.sqharc;
sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
if (sqlca.sqlcode == 1403) break;
if (sqlca.sqlcode < 0) handle_error();
}



display_data(sqlca.sqlerrd[2] - iRowCount);
iRowCount = sqlca.sqlerrd[2];
}

if ((sqlca.sqlerrd[2]-iRowCount)>0)
    display_data(sqlca.sqlerrd[2]-iRowCount);

if (iRow == 0)
      handle_not_found();


/* EXEC SQL CLOSE student_cursor7; */ 

{
struct sqlexd sqlstm;

sqlstm.sqlvsn = 8;
sqlstm.arrsiz = 6;
sqlstm.iters = (unsigned int  )1;
sqlstm.offset = (unsigned int  )476;
sqlstm.cud = sqlcud0;
sqlstm.sqlest = (unsigned char  *)&sqlca;
sqlstm.sqlety = (unsigned short)0;
sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
if (sqlca.sqlcode < 0) handle_error();
}




  printf("<BR>");
  printf("<CENTER>");
  printf("<A HREF=../../Project/right.html><IMG SRC=../../Project/home.jpg></A>");
  printf("<A HREF=../../Project/about.html><IMG SRC=../../Project/project.jpg></A>");
  printf("<A HREF=../../Project/member.html><IMG SRC=../../Project/member.jpg></A>");
  printf("<A HREF=../../Project/eng.html><IMG SRC=../../Project/comeng.jpg></A>");
  printf("</CENTER>");

  printf("<CENTER>");
  printf("<A HREF=../../Project/inst.html><IMG SRC=../../Project/ins_d.jpg></A>");
  printf("<A HREF=../../Project/upd.html><IMG SRC=../../Project/upd_d.jpg></A>");
  printf("<A HREF=../../Project/slt.html><IMG SRC=../../Project/sel_d.jpg></A>");
  printf("<A HREF=../../Project/del.html><IMG SRC=../../Project/del_d.jpg></A>");
  printf("</CENTER>");

  printf("<CENTER>");
  printf("<A HREF=select_lst.sh.cgi><IMG SRC=../../Project/lst_d.jpg></A>");
  printf("<A HREF=../../Project/query.html><IMG SRC=../../Project/query_d.jpg></A>");
  printf("</CENTER>"); 


  printf("<BR>");

  printf("</BODY>");
  printf("</HTML>");

       close(stdout);
       close(stderr); 
}

