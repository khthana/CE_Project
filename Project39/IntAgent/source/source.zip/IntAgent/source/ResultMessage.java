package agent.util;

import java.awt.*;
import java.lang.*;
import agent.util.*;
import java.util.*;
import java.net.*;
import java.io.*;

/** A results message, sent from running Agent back to
AgentLauncher and containing a URL that holds the results of
the Agent's work.
// Format of the results command:
// The command  Resu  4 bytes
// The length   10 bytes ascii int
// The arguments
            ID
// Field hdr  ID__  4 bytes
// length   4 bytes ascii int
// ID data  length bytes

            URL
// Field hdr  URL_  4 bytes
// The length   4 bytes
// The URL data   length bytes

            Price
// Field hdr  Pric_ 4 bytes
// length   4 bytes ascii int
// Price data  length bytes

            Comment
// Field hdr  Comm_ 4 bytes
// length   4 bytes ascii int
// Comment data  length bytes

            Server name
// Field hdr  Srv_  4 bytes
// The length   4 bytes
// The Server data    length bytes
@see Message
*/
public class ResultMessage extends Message{
  public static final int PREFIX_SIZE=4;
  public static final int LOADLEN_SIZE=10;
  public static final int IDLEN_SIZE = 4;
  public static final int PRICELEN_SIZE = 4;
  public static final int URLLEN_SIZE = 4;
  public static final int COMMENTLEN_SIZE = 4;
  public static final int SERVERLEN_SIZE = 4;
  public static final String ClassPath = 
     new String( "/agent/classes/rel/" );

  public static final String ID_PREFIX=new String( "ID__" );
  public static final String PRICE_PREFIX=new String("Pric");
  public static final String COMMENT_PREFIX=new String("Comm");
  public static final String URL_PREFIX=new String("URL_");
  public static final String RESULT_PREFIX=new String("Resu");
  public static final String SERVER_PREFIX=new String("Serv");

  public String sid;
  public String comment;
  public int price;
  public String theURL = null;
  public String server;

  byte burl[];
  byte bcomment[];
  byte bprice[];
  byte bsid[];
  byte bserver[];

  public ResultMessage() { };
  public ResultMessage(String AgentID, String u, int p,
         String c,String srv)
    {
    System.out.println( "resultmsg "+AgentID+" u "+u );
    sid = new String( AgentID );
    if( u != null )
      theURL = new String( u );     
    price = p;
    comment = new String( c );
    server = new String( srv );
    }

/** Parse the ResultsMessage passed in as a byte array.  Simply
fills in the public instance variables:
  sid
  comment
  price
  theURL
  server
which the caller can then use as he sees fit.
@param b The array of bytes containing ResultsMessage data.
@param currentOffset The offset of the SECOND field in the
message, i.e. the first Results-specific field.  We've already
parsed the message type field, that's how we got here.
*/
public void parse(byte b[], int currentOffset) {
String command;
byte sig[];
byte clas[];
String s;

    
  // Followed by some number of byte array arguments
  s = new String( b, 0, currentOffset, PREFIX_SIZE );
  System.out.println( "next field "+s);
  currentOffset += PREFIX_SIZE;

  if( s.compareTo( ID_PREFIX ) == 0 )
    {
    String sl = new String( b, 0, currentOffset,IDLEN_SIZE );
    currentOffset += IDLEN_SIZE;
    Integer length = new Integer( sl );
    System.out.println( "got id of length "+length );
    bsid = new byte[length.intValue()];
    for( int i = 0; i < length.intValue(); i++ ) {
      bsid[i] = b[currentOffset++]; 
      }
    sid = new String( bsid, 0 );
    }
  else
    System.out.println( "out of sync at ID" );


  s = new String( b, 0, currentOffset, PREFIX_SIZE );
  currentOffset += PREFIX_SIZE;
  System.out.println( "next field "+s);

  if( s.compareTo( URL_PREFIX ) == 0 )
    {
    String sl = new String( b, 0, currentOffset,URLLEN_SIZE);
    currentOffset += URLLEN_SIZE;
    Integer length = new Integer( sl );
    System.out.println( "got url of length "+length );
    burl = new byte[length.intValue()];
    for( int i = 0; i < length.intValue(); i++ ) {
      burl[i] = b[currentOffset++]; 
      }
    theURL = new String( burl, 0 );

    s = new String( b, 0, currentOffset, PREFIX_SIZE );
    currentOffset += PREFIX_SIZE;
    System.out.println( "next field "+s);
    }
  else
    System.out.println( "No results here!" );

  if( s.compareTo( PRICE_PREFIX ) == 0 )
    {
    String sl = new String( b, 0, currentOffset,PRICELEN_SIZE);
    currentOffset += PRICELEN_SIZE;
    Integer length = new Integer( sl );
    System.out.println( "got price of length "+length );
    bprice = new byte[length.intValue()];
    for( int i = 0; i < length.intValue(); i++ ) {
      bprice[i] = b[currentOffset++]; 
      }
    String sprice = new String( bprice, 0 );
    try {
      Integer J = new Integer( sprice );
      price = J.intValue();
      } 
    catch( NumberFormatException e ) {
       System.out.println( "price number format error" );
       }
    }
  else
    System.out.println( "out of sync at price" );

/*
  if( s.compareTo( PRICE_PREFIX ) == 0 )
    {
    String sl = new String( b, 0, currentOffset,PRICELEN_SIZE);
    currentOffset += PRICELEN_SIZE;
    Integer length = new Integer( sl );
    System.out.println( "got price of length "+length );
    bprice = new byte[length.intValue()];

    boolean bError = false;
    for( int i = 0; i < length.intValue(); i++ ) {
      bprice[i] = b[currentOffset++]; 
      if( bprice[i] < '0' || bprice[i] > '9' )
		bError = true;
      }
    String sprice = new String( bprice, 0 );
    if( bError == true )
      System.out.println( "price number format error" );
    else {
      Integer J = new Integer( sprice );
      price = J.intValue();
      }
    }
  else
    System.out.println( "out of sync at price" );
*/

  s = new String( b, 0, currentOffset, PREFIX_SIZE );
  currentOffset += PREFIX_SIZE;
  System.out.println( "next field "+s);

  if( s.compareTo( COMMENT_PREFIX ) == 0 )
    {
    String sl = new String(b,0,currentOffset,COMMENTLEN_SIZE);
    currentOffset += COMMENTLEN_SIZE;
    Integer length = new Integer( sl );
    System.out.println( "got comment of length "+length );
    bcomment = new byte[length.intValue()];
    for( int i = 0; i < length.intValue(); i++ ) {
      bcomment[i] = b[currentOffset++]; 
      }
    comment = new String( bcomment, 0 );
    }
  else
    System.out.println( "out of sync at comment" );

  s = new String( b, 0, currentOffset, PREFIX_SIZE );
  currentOffset += PREFIX_SIZE;
  System.out.println( "next field "+s);

  if( s.compareTo( SERVER_PREFIX ) == 0 )
    {
    String sl = new String(b,0,currentOffset,SERVERLEN_SIZE);
    currentOffset += SERVERLEN_SIZE;
    Integer length = new Integer( sl );
    System.out.println( "got server of length "+length );
    bserver = new byte[length.intValue()];
    for( int i = 0; i < length.intValue(); i++ ) {
      bserver[i] = b[currentOffset++];  
      }
    server = new String( bserver, 0 );
    }
  else
    System.out.println( "out of sync at server" );
  }

/** Create the message byte array using the public instance
variables:
  sid
  comment
  price
  theURL
  server
that must already have been filled in.  When this method is
through, the byte array msg is ready to be sent over the net.
*/
public void createMessage() {
  String s;
  int totallength = 0;

// the load command
  totallength = PREFIX_SIZE+LOADLEN_SIZE;

// the AgentID
  s = makePrefix( ID_PREFIX, sid.length(), IDLEN_SIZE );
  bsid = new byte[s.length()+sid.length()];
  s.getBytes(0,s.length(),bsid, 0 );
  sid.getBytes(0,sid.length(), bsid, s.length());
  totallength += bsid.length; 

// the URL
  if( theURL != null ) {
    s = makePrefix( URL_PREFIX, theURL.length(), URLLEN_SIZE );
    burl = new byte[s.length()+theURL.length()];
    s.getBytes(0,s.length(),burl, 0 );
    theURL.getBytes(0,theURL.length(), burl, s.length());
    totallength += burl.length; 
    }

// the price
  String sprice = new String( new Integer(price).toString());
  s = makePrefix( PRICE_PREFIX, sprice.length(),PRICELEN_SIZE);
  bprice = new byte[s.length()+sprice.length()];
  s.getBytes(0,s.length(),bprice, 0 );
  sprice.getBytes(0,sprice.length(), bprice, s.length());
  totallength += bprice.length; 

// the comment
  s = makePrefix(COMMENT_PREFIX,comment.length(),
             COMMENTLEN_SIZE);
  bcomment = new byte[s.length()+comment.length()];
  s.getBytes(0,s.length(),bcomment, 0 );
  comment.getBytes(0,comment.length(), bcomment, s.length());
  totallength += bcomment.length;
  
// the server
  s = makePrefix( SERVER_PREFIX, server.length(), 
      SERVERLEN_SIZE );
  bserver = new byte[s.length()+server.length()];
  s.getBytes(0,s.length(),bserver, 0 );
  server.getBytes(0,server.length(), bserver, s.length());
  totallength += bserver.length;  

// the raw class data is already set via LoadClassFromFile
    
  s = makePrefix( RESULT_PREFIX, totallength, 10 );
  command = new byte[s.length()];
  s.getBytes( 0, s.length(), command, 0 );

  msg = new byte[totallength];
  int currentOffset = 0;
  for( i = 0; i < command.length; i++ )
    msg[currentOffset++] = command[i];
  for( i = 0; i < bsid.length; i++ )
    msg[currentOffset++] = bsid[i];
  if( theURL != null ) {
    for( i = 0; i < burl.length; i++ )
      msg[currentOffset++] = burl[i];
    }
  for( i = 0; i < bprice.length; i++ )
    msg[currentOffset++] = bprice[i];
  for( i = 0; i < bcomment.length; i++ )
    msg[currentOffset++] = bcomment[i];
  for( i = 0; i < bserver.length; i++ )
    msg[currentOffset++] = bserver[i];
  }
}


