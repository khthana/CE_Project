package agent.Agent;

import java.lang.*;
import java.util.*;
import java.awt.*;
import agent.Agent.*;

// To catch the definition of AgentContext
import agent.Server.AgentContext;   

/** The base class for all Agents in the agent system. An
almost purely abstract class, with the only bit of
implementation embodied in the setAgentContext method.

@see agent.AgentContext
@see agent.AgentServer
*/
public abstract class Agent extends Thread {

/** The Agent's interface to the AgentServer.  If the Agent is
loaded on an AgentLauncher, as it will be when it is being
configured, this will be null.
*/
   public AgentContext ac;

/** Called by the AgentServer to set an AgentContext for this
agent to use when reporting status or creating/reporting
results.

@param agentContext An object implementing the AgentContext
interface.  Usually the AgentServer itself.
*/
   public void setAgentContext(AgentContext a) { ac = a; }

/** Called by the AgentLauncher to get the arguments needed
for this run of this agent.  Usually creates a Dialog to get
input from the browser user.

@param frame A Frame object, usually the Frame of the browser.
*/
   public abstract void configure( Frame frame );

/** Called by the AgentLauncher to get the arguments that were
set via configure.
@return A Vector of Strings that will be passed back to the
Agent when the AgentServer instantiates it on a server.  The
Strings can contain any data that might be meaningful to the
Agent.  There is no limit on the number of arguments.
@see awt.Dialog
*/
   public abstract Vector getArguments();

/** Called by the AgentServer to set the arguments this run of
this agent will use.  The arguments obtained from the browser
user are stuffed into a portion of the agent load message.  The
AgentServer extracts the args from the message, creates a
Vector of Strings and passes that Vector to the agent via this
call.

@param args A Vector of Strings that are exactly what the
AgentLauncher returned to the AgentLauncher from getArguments.
*/
   public abstract void setArguments( Vector args );
}


