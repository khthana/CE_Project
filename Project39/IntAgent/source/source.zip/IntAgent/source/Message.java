package agent.util;

import java.awt.*;
import java.lang.*;
import agent.util.*;
import java.util.*;
import java.net.*;
import java.io.*;

/** An abstract class for the messages that AgentServers
exchange with each other and with AgentLaunchers.  Provides a
couple of utility functions to aid in message construction.

*/
public abstract class Message {
  protected byte command[];
  byte sig[];
  int i, j;
  protected byte msg[];
  public static final int PREFIX_SIZE=4;

/** Message senders call this function to force the
construction of an actual message within the msg instance
variable.  Implementors MAY put message creation into the
constructor if they wish, and leave createMessage as an empty
method.  Current implementations put all message creation code
here.
*/
public abstract void createMessage();

/** Make a string that is a valid field prefix in the format:
  FieldName
  Length of length
@return String  String representation of the field prefix.  Use
String.getBytes on this String and resulting bytes go straight
into the message right before the field data.
*/
public String makePrefix( String prefix, 
         int fieldlen, int lensize ) {
  String s = 
      new String(prefix+ZeroPadToLength(fieldlen,lensize));
  return( s );
  }

/** All field and message length indicators are sent as
zero-padded ascii integers.  This turns the supplied number
into a string and zero pads it to the specified length.
@param  int the number that needs to be converted to a string
@param  int
@return String  
*/
public String ZeroPadToLength( int num, int length ) {
  char c[] = new char[length+1];
  for( int i = 0; i < c.length; i++ )
   c[i] = '0';
  String s = new String( c );

  byte b[] = new byte[length];
  Integer I = new Integer( num );
  String s1 = new String( I.toString());
  if( s1.length() >= length )
    return( s1 );
  int pad = length - s1.length();
  s.getBytes( 0, pad, b, 0 );
  s1.getBytes( 0, s1.length(), b, pad );
  String s3 = new String( b, 0 );
  return( s3 );
  }

/** Return a lump of bytes that is a valid message of this
type.  Depends on createMessage to fill in the instance
variable msg. 
@return A lump of message bytes, suitable for transmission.
*/
public byte[] getMessageBytes() {
  createMessage();
  return( msg );
  }
}
