package agent.Server;

import agent.*;
import java.lang.*;
import java.net.*;

/** The Agents interface into the environment in which it is 
running.  This is implemented only by the AgentServer.  An Agent should
never run any server side functions unless it has a valid AgentContext.
@see agent.Agent

*/
public interface AgentContext {


/** This is called by the Agent to re-dispatch this Agent to all the servers in
the Servers list. 
@return true if the Agent was dispatched to ANY servers, false otherwise
*/
   public boolean dispatch();

/** This is called by the Agent to write a String of result text to the
results HTML file.  
*/
   public boolean writeOutput( String HTMLString );
   
/** This is called by the Agent to write a String of result text to the
results HTML file. 
@param HTMLString This is a string of text in HTML that will appear in
the results page for this Agent run.
@return true if the string was written to the output file, false
otherwise.
*/
   public boolean writeOutput( byte b[] );
   
/** Called by the Agent to get the URL of the file that writeOutput has
been writing our result strings to.  Agent uses this to pass to
reportFinish.  
@see reportFinish
@return the URL of the results file as a String.  Result files must have Web-accessible
URLs.
*/
   public String getResultsURL(String AgentID);
   
/** Called by the Agent to make the AgentServer tell the dispatching
AgentServer that this Agent has begun working.  Receipt of this message
by the AgentLauncher should cause it to create an entry in its agent
list for this agent.
@param AgentID The ID of this agent
@see agent.Launcher
@see agent.Server
*/
   public void reportStart( String AgentID );
   
/** Called by the Agent to make the AgentServer tell the dispatching
AgentServer that this Agent has finished work and has created the
following result file. 

@param AgentID The ID of this agent
@param url The URL of the results file.  If null, there were no results.
@param price The price this AgentServer will charge to view the results
file.
@param comment Any comment the Agent might wish to make about this
result - including its size, running time ...
@see agent.Launcher
@see agent.Server
*/
   public void reportFinish( String AgentID, String url, int price, String comment );
}

