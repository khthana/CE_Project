package agent.util;

import java.awt.*;
import java.lang.*;
import agent.util.*;
import java.util.*;
import java.net.*;
import java.io.*;

/** A message that supplies the receiver with a list of
dispatchable agents available on this server.  It is sent to
provoke a responding AgentListMessage. Message format:

 Description  Data  Length
 The command  Load  4 bytes
 The length   10 bytes ascii int

Class contains both message construction and message parsing
methods. 


@see QueryAgentListMessage
@see Message
*/
public class QueryAgentListMessage extends Message{
  public static final int PREFIX_SIZE=4;
  public static final String QALS_PREFIX = new String("QALs");

  public static final int QALSLEN_SIZE=10;

/** There is nothing to parse in a QueryAgentList message. 
The message prefix, QALs is the message.
*/
public void parse(byte b[], int currentOffset) { return; }

/** Actually fill the byte array 'msg' with ALL the bytes that
make up this load message.  Expects NO intance variables to
already be filled with valid data.
*/
public void createMessage() {
  String s;
  int totallength = 0;

  totallength = PREFIX_SIZE+QALSLEN_SIZE;
  s = makePrefix( QALS_PREFIX, totallength, 10 );
  command = new byte[s.length()];
  s.getBytes( 0, s.length(), command, 0 );

  msg = new byte[totallength];
  int currentOffset = 0;
  for( i = 0; i < command.length; i++ )
    msg[currentOffset++] = command[i];
  }
}
