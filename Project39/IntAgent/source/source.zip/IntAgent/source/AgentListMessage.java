package agent.util;

import java.awt.*;
import java.lang.*;
import agent.util.*;
import java.util.*;
import java.net.*;
import java.io.*;

/** A message that supplies the receiver with a list of
dispatchable agents available on this server.  It is sent in
response to a QueryAgentListMessage. Message format:

 Description  Data  Length
 The command  Load  4 bytes
 The length   10 bytes ascii int

 filename FNam  4 bytes
 length     4 bytes ascii int
 filename   length bytes
 description  Desc  4 bytes
 length     4 bytes ascii int
 description    length bytes

Class contains both message construction and message parsing
methods. 


@see QueryAgentListMessage
@see Message
*/
public class AgentListMessage extends Message{
  public static final int PREFIX_SIZE=4;
  public static final String ALST_PREFIX = new String("ALst");
  public static final String FNAM_PREFIX = new String("FNam");
  public static final String DESC_PREFIX = new String("Desc");

  public static final int ALSTLEN_SIZE=10;
  public static final int FNAMLEN_SIZE=4;
  public static final int DESCLEN_SIZE=4;
  public Vector filenames;
  public Vector descriptions;
  byte bfnam[];
  byte bdesc[];

  public AgentListMessage() { };

/** This is the constructor used by an AgentServer that wishes
to SEND a AgentList message.  Supply the name of the lead
class, the id, the signature, arguments, dispatching server
and port.
*/
  public AgentListMessage( Vector fnames, Vector descs ) {
    filenames = fnames;
    descriptions = descs;
    }

/** parse the supplied byte array as if it were an AgentList
message.  Fills the instance variables:
  filenames
  descriptions
with data from the message.  
*/
public void parse(byte b[], int currentOffset) {
String command;
String s;

filenames = new Vector(1);
descriptions = new Vector(1);

while( currentOffset < b.length ) {
  s = new String( b, 0, currentOffset, PREFIX_SIZE );
  System.out.println( "next field "+s);
  currentOffset += PREFIX_SIZE;

  if( s.compareTo( FNAM_PREFIX ) == 0 )
    {
    String sl = new String( b, 0, currentOffset, FNAMLEN_SIZE);
    System.out.println("currOff "+currentOffset+" sl = "+sl);
    currentOffset+=FNAMLEN_SIZE;
    Integer length = new Integer( sl );
    bfnam = new byte[length.intValue()];
    for( int i = 0; i < length.intValue(); i++ )
      bfnam[i] = b[currentOffset++];  
    filenames.addElement( new String( bfnam, 0 ));
    s = new String( b, 0, currentOffset, PREFIX_SIZE );
    System.out.println( "next field "+s);
    currentOffset += PREFIX_SIZE;
    }
  else {
    System.out.println( "out of sync at FNAM" );
    break;
    }

  if( s.compareTo( DESC_PREFIX ) == 0 )
    {
    String sl = new String( b, 0, currentOffset, FNAMLEN_SIZE);
    System.out.println("currOff "+currentOffset+" sl = "+sl);
    currentOffset+=DESCLEN_SIZE;
    Integer length = new Integer( sl );
    bdesc = new byte[length.intValue()];
    for( int i = 0; i < length.intValue(); i++ )
      bdesc[i] = b[currentOffset++];  
    descriptions.addElement( new String( bdesc, 0 ));
    s = new String( b, 0, currentOffset, PREFIX_SIZE );
    System.out.println( "next field "+s);
    currentOffset += PREFIX_SIZE;
    }
  else {
    System.out.println( "out of sync at DESC" );
    break;
    }
  }
}

/** Actually fill the byte array 'msg' with ALL the bytes that
make up this load message.  Expects the intance variables:
  filenames
  descriptions
to already be filled with valid data.
*/
public void createMessage() {
  String s;
  int totallength = 0;

  if(filenames == null || descriptions == null) {
    System.out.println( "No msg data loaded" );
    return;
    }

  totallength = PREFIX_SIZE+ALSTLEN_SIZE;
  byte bbfnam[][] = new byte[filenames.size()][];
  byte bbdesc[][] = new byte[filenames.size()][];
  for( int i = 0; i < filenames.size(); i++ ) {
    String sf = (String)filenames.elementAt(i);
    s = makePrefix( FNAM_PREFIX, sf.length(), FNAMLEN_SIZE );
    bbfnam[i] = new byte[s.length()+sf.length()];
    s.getBytes(0,s.length(),bbfnam[i], 0 );
    sf.getBytes(0,sf.length(), bbfnam[i], s.length());
    totallength += bbfnam[i].length;  

    sf = (String)descriptions.elementAt(i);
    s = makePrefix( DESC_PREFIX, sf.length(), DESCLEN_SIZE );
    bbdesc[i] = new byte[s.length()+sf.length()];
    s.getBytes(0,s.length(),bbdesc[i], 0 );
    sf.getBytes(0,sf.length(), bbdesc[i], s.length());
    totallength += bbdesc[i].length;  
    }
    
  s = makePrefix( ALST_PREFIX, totallength, 10 );
  command = new byte[s.length()];
  s.getBytes( 0, s.length(), command, 0 );

  msg = new byte[totallength];
  int currentOffset = 0;
  for( i = 0; i < command.length; i++ )
    msg[currentOffset++] = command[i];

  for( j = 0; j < bbfnam.length; j++ ) {
    for( i = 0; i < bbfnam[j].length; i++ )
      msg[currentOffset++] = bbfnam[j][i];
    for( i = 0; i < bbdesc[j].length; i++ )
      msg[currentOffset++] = bbdesc[j][i];
    }
  }
}
