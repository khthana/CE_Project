package agent.Server;

import java.awt.*;
import java.lang.*;
import agent.util.*;
import agent.Agent.*;
import agent.Server.*;
import java.util.*;
import java.net.*;
import java.io.*;

/** A standalone application for loading and running Agents
that are sent to it over the net.

*/
public class AgentServer extends Thread {
public static ServerFrame f;
static public boolean bRun = true;
public static AgentServer currentAgentServer;
static Panel p;
MenuBar m;
SrvSocket s;
Acceptor acceptor;
File resultFile;
static AgentServerSecurityManager assm;
public static int ServerPort;

Vector runningAgents;
Vector dispatchedAgents;
static String PropertiesFile;

public static Vector serverList = new Vector( 1 );

/** The main loop for this standalone application.  Creates one
AgentServer, then sets it running via Thread.start.
@see Thread
*/
public static void main(String argv[] ) {
  if( argv.length > 0 ) {
   PropertiesFile = new String( argv[0]+"properties" );
   }
  else
   PropertiesFile = new String( "/users/default/.hotjava/properties" );

  System.out.println( "setting properties file to "+PropertiesFile );

  AgentServer as = new AgentServer();
  assm = new AgentServerSecurityManager();
  System.setSecurityManager(assm);
  as.start();
  }

/** Constructor, builds the list of AgentServers, builds all
the screen elements, including menu and menu items.  For now,
this app only handles exit from the menu.  Instantiates an
acceptor thread that listens to the AgentServer port where
agents to be loaded will come in.
@see Frame
@see Panel
@see MenuBar
@see MenuItem
@see Acceptor
*/
public AgentServer() {
  LoadServerList();
  runningAgents = new Vector(1);
  dispatchedAgents = new Vector(1);
  System.out.println( "AgentServer constructor" );
  currentAgentServer = this;
  f = new ServerFrame();
  f.resize(300, 300);
  f.show();
  p = new Panel();
  p.reshape( 0, 0, 300, 300 );
  p.setLayout( new FlowLayout());
  f.add( p );
  m = new MenuBar();
  f.setMenuBar( m );
  Menu m1 = new Menu("File");
  m.add(m1);
  MenuItem m2;
//  MenuItem m2 = new MenuItem( "Load test" );
//  m1.add( m2 );
  m2 = new MenuItem( "Exit" );
  m1.add( m2 );
  m1 = new Menu("Options");
  m.add(m1);
  m2 = new MenuItem( "Configure" );
  m1.add( m2 );
  acceptor = new Acceptor( this );
  acceptor.start();

    String sPort = System.getProperty( "agent.ServerPort" );
    if( sPort == null ) {
      System.out.println( "agent.ServerPort not found in properties file - using 1037" );
      System.out.println( "set agent.ServerPort to the port number of whatever port you wish to use, as in \"agent.ServerPort=1036\"" );
      ServerPort = 1037;
      }
    else {
      System.out.println( "got "+sPort+" for agent.ServerPort");
      ServerPort = (new Integer( sPort )).intValue();
    }

  }

/** Add this Agents results to the cumulative results page that
we've been amassing for the whole run of this Agent.
@param  r The ResultMessage that the Agent is sending back to
the AgentLauncher.
*/
public void reportResults( ResultMessage r ) {
  // If this search has already been cancelled, don't bother
  if( resultFile == null )
    return;
  if( r.theURL == null ) {
    try {
      FileOutputStream fos =
        new FileOutputStream( resultFile );
      PrintStream ps = new PrintStream( fos );
      synchronized( ps ) {
        ps.println( "<P>" );
        ps.println( "Results from server <A HREF=\""+r.theURL+
            "\">"+r.server+"</A>");
        ps.println( "\tprice "+r.price);
        if( r.comment != null )
          ps.println( "\t"+r.comment );
        }
      }
    catch( IOException ioe ) {
      System.out.println( "reportResults ioexc "+ioe );
      }
    }
  }

/** Load the list of agent servers we know about from the file
servers.lst in the directory specified by acl.read in the
properties file.
*/
void LoadServerList() {
  Properties p = System.getProperties();

  try {
  p.load(
   new FileInputStream(PropertiesFile));
  System.out.println( "system properties "+p );
  } catch( IOException e ) {System.out.println("Couldn't load properties file "+PropertiesFile ); }

    String topDirectory = System.getProperty( "acl.read" );
    if( topDirectory == null ) {
      System.out.println( "acl.read not found in properties file" );
      }
    else
      System.out.println( "got "+topDirectory+" for acl.read");

  try {
    File f = new File( topDirectory+"/servers.lst" );
    FileInputStream fis = new FileInputStream( f );
    DataInputStream dis = new DataInputStream( fis );
    while( true ) {
      try {
        String s = dis.readLine();
        StringTokenizer st;
        // All lines or of the form "<servername>:<port>"
        st = new StringTokenizer( s, ":" );
   try {
          String server = (String)st.nextElement();
          Integer IPort=new Integer((String)st.nextElement());
          System.out.println( "adding "+server+":"+IPort );
          serverList.addElement(
              new ServerEntry( server, IPort.intValue()));
        } catch( NoSuchElementException e ) { break; }
      } catch( IOException e ) { break; }
    }
  } catch( IOException e )
    { System.out.println( "Couldn't find servers.lst file in directory "+topDirectory );
      return; }
}

/** Test the loading of classes at this site by allowing the
user to choose a class file to load, then creating/parsing a
LoadMessage from that class file.  DEBUGGING method.
@see LoadMessage
@see FileDialog
*/
public void LoadTest() {
  System.out.println( "Load test" );

//  The FileDialog doesn't work in W95 or NT
  FileDialog fd = new FileDialog(f, "LoadTest");
  fd.setDirectory( "/agent/classes/beta/agent" );
  fd.show();
  if( fd.getFile() != null ) {
    System.out.println( "Load test - "+fd.getFile() );
    try {
      System.out.println( "button ok hit" );
      LoadMessage lm = new LoadMessage();
      lm.LoadClassFromFile( fd.getFile() );
      byte[] b = lm.getMessageBytes();
//      SocketHandler.ClientProcess( b, b.length );
      } catch( Exception e )
        { System.out.println( "exception "+e ); }
    }
  else
    System.out.println( "getFile == null" );
  }

/** Notify the AgentLauncher, via the dispatching agent server
that the agent has finished running and has the specified
results to report.
@param rm A results message containing the results page URL
@see ResultsMessage
*/
public void notifyResults( ResultMessage rm ) {
  for( int i = 0; i < dispatchedAgents.size(); i++ ) {
    DispatchedAgent da =
      (DispatchedAgent)dispatchedAgents.elementAt(i);
    if( da.id.compareTo(rm.sid) == 0 ) {
      try {
        da.sh.as.outputStream.write(rm.getMessageBytes());
        return;
      } catch( IOException e )
        {System.out.println("exception "+e ); }
      break;
      }
    }
  System.out.println( "No launcher to notify "+rm.sid );
  }

/** Notify the AgentLauncher, via the dispatching agent server
that the agent has started running.
@param sm A StartMessage
@see StartMessage
*/
public void notifyStart( StartMessage sm ) {
  for( int i = 0; i < dispatchedAgents.size(); i++ ) {
    DispatchedAgent da =
      (DispatchedAgent)dispatchedAgents.elementAt(i);
    if( da.id.compareTo(sm.sid) == 0 ) {
      try {
        da.sh.as.outputStream.write(sm.getMessageBytes());
        return;
      } catch( IOException e )
        {System.out.println("exception "+e ); }
      break;
      }
    }
  System.out.println( "No launcher to notify "+sm.sid );
  }

/** Add an Agent to the list, using the specified ID and
SocketHandler.
@see SocketHandler
*/
public void addDispatchedAgent( String id, SocketHandler sh ) {
  dispatchedAgents.addElement( new DispatchedAgent( id, sh ));
  }

/** Delete an agent from the list of dispatched agents
because he's ended.
@param id The String id of the terminating Agent.
*/
public void deleteDispatchedAgent( String id ) {
  for( int i = 0; i < dispatchedAgents.size(); i++ ) {
    DispatchedAgent da =
       (DispatchedAgent)dispatchedAgents.elementAt(i);
    if( da.id.compareTo(id) == 0 ) {
      da.sh.stop();
      dispatchedAgents.removeElementAt(i);
      break;
      }
    }
  }

/** Delete an agent from the list of dispatched agents
because of a socket exception.
@param sh The SocketHandler that generated the exception.
*/
public void deleteDispatchedAgent( SocketHandler sh ) {
  for( int i = 0; i < dispatchedAgents.size(); i++ ) {
    DispatchedAgent da =
      (DispatchedAgent)dispatchedAgents.elementAt(i);
    if( da.sh == sh ) {
      da.sh.stop();
      dispatchedAgents.removeElementAt(i);
      break;
      }
    }
  }

/** Add an agent to the list of agents running on this machine.
@param id The String ID of this running agent.
*/
public void addRunningAgent( String id ) {
  System.out.println( "addAgent ("+runningAgents.size()+")");
  runningAgents.addElement(new RunningAgent( id ));
  p.layout();
  f.layout();
  f.show();
  }

/** Delete an agent from the list of running agents.  The
Agent thread MUST BE STOPPED already when you get here.
@param id The String id of the running agent.
*/
public void deleteRunningAgent( String id ) {
  System.out.println("deleteAgent ("+runningAgents.size()+")");
  for( int i = 0; i < runningAgents.size(); i++ )
    {
    RunningAgent ra =
       (RunningAgent )runningAgents.elementAt(i);
    if( ra.id.compareTo(id) == 0 )
      {
      runningAgents.removeElementAt(i);
      p.show();
      p.layout();
      System.out.println( "deleting runningAgent at "+i );
      break;
      }
    }
  System.out.println( "end deleteAgent ("+
       runningAgents.size()+")");
  }

/** The main loop for the AgentServer.  Sits in a loop,
sleeping for 1 second, then waking up to check whether the user
interface has been terminated.
*/
public void run() {
  while( bRun == true ) {
    try {
    f.setTitle( "AgentServer: "+
      runningAgents.size()+" agents running" );
    Thread.sleep( 1000 );
      } catch( Exception e ) { }
    }
  System.out.println( "out of run loop" );
  f.dispose();
  System.exit(0);
  }
}


/** The main window functionality - window creationg/refresh
handling, application exit handling ...
@see Frame
*/
class ServerFrame extends Frame {

/** Handle any events that might come up.  Right now, only
deals with WINDOW_DESTROY, which is what happens when the user
tries to close the application via the system menu.
*/
 public synchronized boolean handleEvent(Event evt) {
  if( evt.id == Event.MOUSE_UP ) {
    return( true );
    }
  else
    {
    if( evt.target instanceof Frame ) {
      if( evt.id == Event.WINDOW_DESTROY ) {
        AgentServer.currentAgentServer.bRun = false;
        System.out.println( "window destroy "+evt );
        return( true );
        }
      else
        return super.handleEvent(evt);
      }
    else
      return super.handleEvent(evt);
    }
  }

/** Handle any menu item picks.  Right now, only has two, Exit
and Load Test.  Exit sets the agentServers bRun flag to false,
causing the AgentServer.run to fall out of the endless while
loop.
@see AgentServer
*/
public boolean action( Event evt, Object o ) {
  if( evt.target instanceof MenuItem )
    {
    if( evt.arg.toString().compareTo( "Exit" ) == 0 )
      {
      AgentServer.currentAgentServer.bRun = false;
      System.out.println( "action event "+evt );
      }
    else
      {
      if(evt.arg.toString().compareTo( "Load test" ) == 0 )
        {
        AgentServer.currentAgentServer.LoadTest();
        System.out.println( "action event "+evt );
        }
      else
        {
        if(evt.arg.toString().compareTo( "Configure" ) == 0 )
          {
          AgentServer.assm.configure();
          System.out.println( "action event "+evt );
          }
        }
      }
    }
  return( true );
  }

  }

/** A class that encapsulates the AgentContext interface
routines that the AgentServer needs to implement.
@see AgentContext
*/
class SepContext implements AgentContext {
  FileOutputStream outputFile;
  PrintStream printStream;
  DataOutputStream outputData;
  String dispatchingHost;
  int port;
  String AgentID;
  boolean bDispatched = false;
  boolean bReportedResults = false;

/** Creates an interface to the AgentServer that knows the
Agents ID and dispatching host.
*/
  public SepContext( String id, String dHost, int dport ) {
    AgentID = new String( id );
    dispatchingHost = new String( dHost );
    port = dport;
    }

/** Send a lump of bytes to the dispatching host for this
Agent.
@param msg A byte array, usually obtained via
Message.getBytes().
@see Message
@see Socket
*/
public void sendMessage( byte msg[] ) {
  try {
  Socket s = new Socket( dispatchingHost, port );
  s.getOutputStream().write( msg );
  } catch( IOException e ) {System.out.println("except "+e ); }
  }

/*** The AgentContext Interface Implementation ***********/

/** Report this agent starting work on this AgentServer.
Implementation of AgentContext interface method.
*/
public void reportStart( String dummy ) {
  String fname =
    new String( System.getProperty("acl.write")+"test.html" );
  try {
    outputFile = new FileOutputStream( fname );
    printStream = new PrintStream(outputFile);
    outputData = new DataOutputStream( outputFile );
    try {
      InetAddress in = InetAddress.getLocalHost();
      String server = new String(in.getHostName());
      StartMessage sm = new StartMessage(AgentID, server);
      sm.createMessage();
      sendMessage( sm.getMessageBytes() );
    } catch( UnknownHostException e )
       {System.out.println("UNK ex"+e);}
  } catch( IOException e )
    {System.out.println("exception "+e);return;}

  return;
  }

/** Report this Agent finishing work on this AgentServer.
Implementation of AgentContext method.
@param url The string url of the results file.  If null, then
there were no results generated.
@param price The price that will be charged to view the results
file.
@param comment Whatever comment the Agent wants to make about
this particular run.
*/
public void reportFinish( String dummy, String url, int price,
          String comment ){
  try {
    outputFile.close();
  } catch( IOException e ) {System.out.println("Except "+e ); }
  outputFile = null;
  outputData = null;
  try {
    InetAddress in = InetAddress.getLocalHost();
    String server = new String(in.getHostName());
    ResultMessage rm = new ResultMessage(AgentID, url, price,
        comment, server);
    rm.createMessage();
    sendMessage( rm.getMessageBytes() );
  } catch( UnknownHostException e )
    {System.out.println("UNK ex"+e);}
  bReportedResults = true;
  if( bDispatched == true )
    AgentServer.currentAgentServer.deleteRunningAgent(AgentID);
  return;
  }

/** Return the string url of the results file that this Agent
has been using.  This url will eventually be passed to
reportFinish.
@param AgentID The string id of this agent.
*/
public String getResultsURL( String AgentID ) {
  try {
    InetAddress in = InetAddress.getLocalHost();
    StringTokenizer st = new StringTokenizer(
                                     in.toString(), "/");
    st.nextElement();
    String sipaddr = (String)st.nextElement();
    String furl = new String( "http://"+sipaddr+
       System.getProperty("acl.write")+"test.html" );
    return( furl );
    } catch( UnknownHostException e ) { return( null ); }
  }

/** Write a string to the results file.
@param resultString The string to write to the output file.
Should be valid HTML.
@return True if success, false otherwise.
*/
public boolean writeOutput( String resultString ) {
  if( outputFile == null || outputData == null )
    return( false );
  printStream.println( resultString );
  return( true );
  }

/** Write a byte array to the results file.
@param resultBytes The bytes to write, should be valid HTML.
@return true if success, false otherwise.
*/
public boolean writeOutput( byte resultBytes[] ) {
  if( outputFile == null || outputData == null )
    return( false );
  try {
    outputData.write( resultBytes, 0, resultBytes.length);
    return( true );
  } catch( IOException e ) {return( false ); }
  }

/** Dispatch this agent to all the servers on this AgentServers
list.  If this Agent has already reported results, we terminate
him and forget about him.
@return false
*/
public boolean dispatch() {
  bDispatched = true;
  if( bReportedResults == true )
    AgentServer.currentAgentServer.deleteRunningAgent( AgentID );
  return( false );
  }
  }

/** A thread that handles the connection to a clients socket.
This is the thread that actually reads the socket and processes
incoming messages.
*/
class SocketHandler extends Thread {
  public Label label;
  public AcceptedSocket as;
  FileOutputStream outputFile;
  boolean bDispatcher = false;

/** Constructor takes a socket to which a client has already
connected.
@param so A socket that is already connected and ready for
read/write.
*/
  public SocketHandler( Socket so ) {
    as = new AcceptedSocket( so );
    label = new Label( "This is the label" );
    }

/** The main run loop for the socket handler, reads the socket
until the client disconnects.
*/
  public void run() {
    byte buffer[] = new byte[8192];
    boolean bContinue = true;
    try {
      while( bContinue == true ) {
        int ret;
        if(( ret = as.read( buffer, buffer.length )) != 0 )
          {
          if( ret < 0 )
            {
            if( bDispatcher )
              AgentServer.currentAgentServer.deleteDispatchedAgent(this);
            System.out.println( "connection lost");
            break;
            }
          bContinue = ClientProcess( buffer, ret );
          }
        }
    } catch( ThreadDeath td ) {
        System.out.println( "Caught ThreadDeath "+td );
        as.close();
        throw( td );
        }
    as.close();
    }

/** Send a message to all the agent servers on the list.  Used
by dispatch, which creates a LoadMessage, then passes that
messages byte array here.
@param msg The lump of bytes to send to everyone.
*/
public static void SendToAll( byte msg[] ) {
  Vector v = AgentServer.currentAgentServer.serverList;
  for( int i = 0; i < v.size(); i++ ) {
    ServerEntry s = (ServerEntry )v.elementAt( i );
    s.send( msg );
    }

  System.out.println( "sending message to all" );
  }

/** parse and process a message from the client.  Follows the
basic system of: read 4 bytes and figure out the message type,
instantiate a message class appropriate to the type, then tell
that new instance to parse the lump.  Deal with the parsed
message by looking at public members of the new class and
acting appropriately.
@param b An array of bytes read over the socket.
@param numbytes The number of read-bytes in b.

*/
public boolean ClientProcess( byte b[], int numbytes ) {

String command;
int currentOffset = 0;
String s;
int messageStart;
boolean bret = false;

while( currentOffset != numbytes ) {
  messageStart = currentOffset;
  System.out.println( "currentOffset "+currentOffset+
      " numbytes "+numbytes );
  // Every message starts with 4 bytes of command
  command = new String( b, 0, currentOffset, 4 );
  currentOffset += LoadMessage.PREFIX_SIZE;

  // Followed by 10 bytes ascii length - length of the whole message
  // including command
  String sLength = new String( b, 0, currentOffset, 10 );
  currentOffset += LoadMessage.LOADLEN_SIZE;
  System.out.println( "got "+command+" of length "+sLength );

  if( command.compareTo( LoadMessage.LOAD_PREFIX ) == 0 ) {
    LoadMessage lm = new LoadMessage();
    Object o = lm.parse( b, currentOffset );
    if( o instanceof Agent ) {
      Agent a = (Agent)o;
      AgentServer.currentAgentServer.addRunningAgent(lm.sid);
      a.setAgentContext( new SepContext( lm.sid,
        lm.dispatching_server_name,
          lm.dispatching_server_port ));
      a.setArguments( lm.vargs );
      a.start();
      }
    }
  else
    {
    if( command.compareTo( KillMessage.KILL_PREFIX ) == 0 ) {
      KillMessage km = new KillMessage( "" );
      String id = km.parse( b, currentOffset );
      System.out.println( "got kill message for agent "+id );
      AgentServer.currentAgentServer.deleteRunningAgent( id );
      AgentServer.currentAgentServer.deleteDispatchedAgent(id);
      }
    else {
      if(command.compareTo(DispatchMessage.DISPATCH_PREFIX)==0)
        {
        bDispatcher = true;
        DispatchMessage dm = new DispatchMessage("","", null);
        if( dm.parse( b, currentOffset ) == true ){
          System.out.println("got good dispatch message");
          AgentServer.currentAgentServer.addDispatchedAgent(
                  dm.id, this);
          try {
            InetAddress in = InetAddress.getLocalHost();
            StringTokenizer st = new StringTokenizer(
                                     in.toString(), "/");
            st.nextElement();
            String sipaddr = (String)st.nextElement();
            LoadMessage lm = new LoadMessage( dm.name,
              dm.id,dm.sig,dm.args,sipaddr,AgentServer.ServerPort );
            byte msg[] = lm.getMessageBytes();
            SendToAll( msg );
            bret = true;
            } catch( UnknownHostException e ) {
              System.out.println( "inet problem" ); }
          }
        else {
          System.out.println( "got bad dispatch message" );
          }
        }
      else
        {
        if(command.compareTo(ResultMessage.RESULT_PREFIX)==0)
          {
          ResultMessage rm = new ResultMessage();
          rm.parse( b, currentOffset );
          AgentServer.currentAgentServer.notifyResults( rm );
          }
        else
          {
          if(command.compareTo(StartMessage.START_PREFIX )==0)
            {
            System.out.println("starting");
            StartMessage sm = new StartMessage();
            sm.parse( b, currentOffset );
            AgentServer.currentAgentServer.notifyStart( sm );
            }
          else
            System.out.println( "Message is BOGUS");
          }
        }
      }
    }
  Integer il = new Integer( sLength );
  currentOffset = messageStart + il.intValue();
  } // while bytesused
  return( bret );
}
}

/** A class that sits accepting connections on a port, spawning
a SocketHandler for each client connection that comes in.  Each
AgentServer should only create one of these.
*/
class Acceptor extends Thread {
  AgentServer as;
  SrvSocket s;

/** Constructor -
@param a An agent server for us to call back to.
*/
  public Acceptor( AgentServer a ) {
    setDaemon( true );
    as = a;
    }

/** Main run loop for acceptor.  Creates the server socket,
then sits in a SrvSocket.Accept loop forever.
@see SrvSocket
*/
  public void run() {
    // set up the server socket
    s = new SrvSocket( AgentServer.ServerPort );
    while( true ) {
      Socket newS = s.Accept();
      SocketHandler a = new SocketHandler( newS );
      a.start();
      }
    }
}

/** A class representing an AgentServer server socket.  All
this really does for now is eat exceptions.
*/
class SrvSocket {
ServerSocket s;
Socket newS;

/** Class representing a socket.  This can be either a network
socket, or a local pipe.  If the network socket can't be
connected to, a local pipe is created along with a robot.

*/
public SrvSocket( int port ) {
  int i = 0;

  s = null;
  while( s == null ) {
    System.out.println( "Accepting on host port:"+port );
    try {
      s = new ServerSocket( port );
      } catch( IOException e )
        { System.out.println( "exception "+e ); }
    }
  }

public Socket Accept() {
  try {
    newS = s.accept();
    System.out.println( "Accepted on host port" );
    } catch( IOException e )
      { System.out.println( "exception "+e ); }
  return( newS );
  }
}


/** A socket that has been accepted, and is thus connected.  We
create one of these from the return from SrvSocket.Accept.
*/
class AcceptedSocket {
public InputStream inputStream;
public OutputStream outputStream;
Socket s;

/** Cnstructor, save the Socket, and gets input and output
streams from it for future use.
@param so This is usually the return from SrvSocket.Accept, a
connected Socket.
@see Socket
@see SrvSocket
@see ServerSocket
*/
public AcceptedSocket( Socket so ) {
  s = so;
  try {
    inputStream = s.getInputStream();
    outputStream = s.getOutputStream();
    } catch( IOException e )
      { System.out.println( "exception "+e); }
  }

/** Read an array of bytes from the socket/pipe. */
public int read(byte buffer[], int length) {
  try {
    return( inputStream.read(buffer));
    } catch( IOException e )
      { System.out.println("exception "+e); return( -1 ); }
  }

/** Write an array of bytes to the socket/pipe. */
public void write(byte buffer[], int length) {
  try {
    outputStream.write(buffer, 0, length);
    } catch( IOException e )
      { System.out.println( "exception "+e); }
  }

/** Close the socket/pipe. */
public void close() {
  try {
    s.close();
    } catch( IOException e )
      { System.out.println( "exception "+e); }
  }
}

/** An entry in the list of AgentServers.  A list of these is
used to dispatch Agents.

*/
class ServerEntry {
  String hostname;
  int port;

/** Save the hostname and port of the AgentServer. */
  public ServerEntry( String host, int pt ) {
    hostname = new String( host );
    port = pt;
    }

/** Send a lump of bytes to this AgentServer */
  public void send( byte msg[] ) {
    System.out.println( "sending to "+hostname+":"+port );
    try {
      Socket so = new Socket( hostname, port );
      so.getOutputStream().write( msg );
    } catch( IOException e)
      { System.out.println( "io exception"+e ); }
    }
  }

/** An Agent running on this machine.

*/
class RunningAgent {
  public String id;
  public RunningAgent( String AgentID ) {
    id = new String( AgentID );
    }
  }

/** An Agent dispatched from this machine. */
class DispatchedAgent {
  public String id;
  public SocketHandler sh;
  public DispatchedAgent(String AgentID, SocketHandler s ) {
    id = new String( AgentID );
    sh = s;
    }
  }

/** A class that implements security for the AgentServer.
Brute-force strategy that simply uses a flag for each of the
methods in SecurityManager.  Can configure itself using a
SecurityDialog. Initializes with ALL ACCESS ALLOWED.
*/
class AgentServerSecurityManager extends SecurityManager {
  public static Vector v = new Vector(1);

/** Build a vector of SecurityItems, one for each of the check
methods in SecurityManager.  Initialize each SecurityItem to
true (access allowed).  Can be changed later using configure.
*/
  public AgentServerSecurityManager() {
    v.addElement( new SecurityItem( "Accept", true ));
    v.addElement( new SecurityItem( "AccessThread", true ));
    v.addElement( new SecurityItem( "AccessThreadGroup", true ));
    v.addElement( new SecurityItem( "Connect", true ));
    v.addElement( new SecurityItem( "ConnectBoth", true ));
    v.addElement( new SecurityItem( "CreateClassLoader", true ));
    v.addElement( new SecurityItem( "Delete", true ));
    v.addElement( new SecurityItem( "Exec", true ));
    v.addElement( new SecurityItem( "Exit", true ));
    v.addElement( new SecurityItem( "Link", true ));
    v.addElement( new SecurityItem( "Listen", true ));
    v.addElement( new SecurityItem( "PackageAccess", true ));
    v.addElement( new SecurityItem( "PackageDefinition", true ));
    v.addElement( new SecurityItem( "PropertiesAccess", true ));
    v.addElement( new SecurityItem( "PropertyAccess", true ));
    v.addElement( new SecurityItem( "ReadFD", true ));
    v.addElement( new SecurityItem( "ReadName", true ));
    v.addElement( new SecurityItem( "ReadBoth", true ));
    v.addElement( new SecurityItem( "SetFactory", true ));
    v.addElement( new SecurityItem( "Window", true ));
    v.addElement( new SecurityItem( "WriteFD", true ));
    v.addElement( new SecurityItem( "WriteName", true ));
    }

/** Change the state of a SecurityItem based on the name of the
item.  This is called for each SecurityItem by the
SecurityDialog when the the OK button is hit.
@param  name  The name of the SecurityItem.
@param  state The state true/false we want to set the
SecurityItem to.
*/
  public void setFlagState( String name, boolean state ) {
    for( int i = 0; i < v.size(); i++ ) {
      SecurityItem si = (SecurityItem)v.elementAt(i);
      if( si.name.compareTo(name) == 0 ) {
        si.state = state;
        break;
        }
      }
    }
/** Return the true/false state of the named SecurityItem.
@param  name  The name of the item we want to query.
*/
  boolean isSet( String name ) {
    for( int i = 0; i < v.size(); i++ ) {
      SecurityItem si = (SecurityItem)v.elementAt(i);
      if( si.name.compareTo(name) == 0 )
        return si.state;
      }
    return( false );
    }

/** Allow the user to configure this security manager by
filling out a SecurityDialog.
*/
  public void configure() {
//    dumpContext();
    SecurityDialog sd = new SecurityDialog(AgentServer.f);
    sd.ShowAndLayout();
    }


/** Return true if Agent is on the stack.  This means we were
called from somewhere within an Agent.
@return true if an instance of Agent is somewhere on the stack.
*/
boolean isAgent() {
  Class c[] = getClassContext();
  for( int i = 0; i < c.length; i++ ) {
    if( subclassesAgent( c[i] )) {
      int AgentIndex = classDepth( c[i].getName() );
      if( AgentIndex >= 0 )
        return( true );
      }
    }
  return( false );
  }

/** Return true if the specified class subclasses
agent.Agent.Agent.  All agents run over the net should subclass
Agent.  Runs through all the superclasses of c checking their
name against agent.Agent.Agent.
@param  c The class we're inquiring about.
@return true if c is a subclass of Agent, false otherwise.
*/
boolean subclassesAgent( Class c ) {
  Class cNext = c;
  while( true ) {
    Class c1 = cNext.getSuperclass();
    if( c1 == null )
      break;
    if( c1.getName().compareTo( "agent.Agent.Agent" ) == 0 )
      return( true );
    cNext = c1;
    }
  return( false );
  }

/** Return true if the Agent is calling us through the
AgentContext. false otherwise.  Accomplish this by looking at
the stack.  If the "classDepth" of the Agent is lower than that
of the AgentContext, or if the AgentContext isn't on the stack,
then the Agent is trying to go around us.
*/
boolean isAgentGoingThroughAgentContext() {
  Class c[] = getClassContext();
  for( int i = 0; i < c.length; i++ ) {
    if( subclassesAgent( c[i] )) {
      int AContextIndex = classDepth( "agent.Server.SepContext" );
      int AgentIndex = classDepth( c[i].getName() );
      // This is where we should catch an agent calling
      // File.write directly.
      if( AContextIndex < 0 )
        return( false );

      // This should never happen.  Indicates SepContext
      // calling back to Agent!!
      if( AgentIndex < AContextIndex )
        return( false );
      else
        return( true );
      }
    }
  System.out.println( "NO AGENT!!" );
  return( true );
  }

/**  Checks to see if a socket connection to the specified
port on the specified host has been accepted.
*/
  public void checkAccept(String host, int port) {
    if( isSet( "Accept" ))
        return;
    throw new AgentServerSecurityException();
    }

/** Checks to see if the specified Thread is allowed to
modify the Thread group.
*/
  public void checkAccess(Thread t) {
    if( isSet( "AccessThread" ))
        return;
    throw new AgentServerSecurityException();
    }

/**     Checks to see if the specified Thread group is allowed
to modify this group.
*/
  public void checkAccess(ThreadGroup tg) {
    if( isSet( "AccessThreadGroup" ))
        return;
    throw new AgentServerSecurityException();
    }

/**     Checks to see if a socket has connected to the specified
port on the the specified host.
*/
  public void checkConnect(String host, int port) {
    if( isSet( "Connect" ))
        return;
    throw new AgentServerSecurityException();
    }

/**     Checks to see if the current execution context and the
indicated execution context are both allowed to connect to the
     indicated host and port.
*/
  public void checkConnect(String host, int port, Object o) {
    if( isSet( "ConnectBoth" ))
        return;
    throw new AgentServerSecurityException();
    }

/**     Checks to see if the ClassLoader has been created.
*/
  public void checkCreateClassLoader() {
    if( isSet( "CreateClassLoader" ))
        return;
    throw new AgentServerSecurityException();
    }

/**     Checks to see if a file with the specified system
dependent file name can be deleted.
*/
  public void checkDelete(String filename) {
    if( isSet( "Delete" ))
        return;
    throw new AgentServerSecurityException();
    }

/**     Checks to see if the system command is executed by
trusted code.
*/
  public void checkExec(String cmdname) {
    if( isSet( "Exec" ))
        return;
    throw new AgentServerSecurityException();
    }

/**     Checks to see if the system has exited the virtual
machine with an exit code.
*/
  public void checkExit(int i) {
    if( isSet( "Exit" ))
        return;
    throw new AgentServerSecurityException();
    }

/**     Checks to see if the specified linked library exists.
*/
  public void  checkLink(String libname) {
    if( isSet( "Link" ))
        return;
    throw new AgentServerSecurityException();
    }

/**     Checks to see if a server socket is listening to the
specified local port that it is bounded to.
*/
  public void  checkListen(int port) {
    if( isSet( "Listen" ))
        return;
    throw new AgentServerSecurityException();
    }

/**     Checks to see if an applet can access a package.
*/
  public void  checkPackageAccess(String pkgname) {
    if( isSet( "PackageAccess" ))
        return;
    throw new AgentServerSecurityException();
    }

/**     Checks to see if an applet can define classes in a
package.
*/
  public void  checkPackageDefinition(String pkgname)  {
    if( isSet( "PackageDefinition" ))
        return;
    throw new AgentServerSecurityException();
    }

/**     Checks to see who has access to the System properties.
*/
  public void  checkPropertiesAccess() {
    if( isSet( "PropertiesAccess" ))
        return;
    throw new AgentServerSecurityException();
    }

/**     Checks to see who has access to the System property
named by key.
*/
  public void  checkPropertyAccess(String property) {
    if( isSet( "PropertyAccess" ))
        return;
    throw new AgentServerSecurityException();
    }

/**     Checks to see who has access to the System property
named by key and def.
*/
  public void  checkPropertyAccess(String property, String s) {
    if( isSet( "PropertyAccess" ))
        return;
    throw new AgentServerSecurityException();
    }

/**     Checks to see if an input file with the specified file
descriptor object gets created.
*/
  public void  checkRead(FileDescriptor fd) {
    if( isSet( "ReadFD" ))
        return;
    throw new AgentServerSecurityException();
    }

/**     Checks to see if an input file with the specified
system dependent file name gets created.
*/
  public void  checkRead(String filename) {
    if( isSet( "ReadName" ))
        return;
    throw new AgentServerSecurityException();
    }

/**     Checks to see if the current context or the indicated
context are both allowed to read the given file name.
*/
  public void  checkRead(String filename, Object o) {
    if( isSet( "ReadBoth" ))
        return;
    throw new AgentServerSecurityException();
    }

/**     Checks to see if an applet can set a
networking-related object factory.
*/
  public void  checkSetFactory() {
    if( isSet( "SetFactory" ))
        return;
    throw new AgentServerSecurityException();
    }

/**     Checks to see if top-level windows can be created by
the caller.
*/
  public boolean  checkTopLevelWindow(Object o) {
    if( isSet( "Window" ))
        return true;
    throw new AgentServerSecurityException();
    }

/**     Checks to see if an output file with the specified
file descriptor object gets created.
*/
  public void  checkWrite(FileDescriptor fd)  {
 //   dumpContext();
    if( isAgent()) {
      if( isAgentGoingThroughAgentContext())
        return;
      }
    else
      return;
//    if( isSet( "WriteFD" ))
//        return;
    throw new AgentServerSecurityException();
    }

/**     Checks to see if an output file with the specified
system dependent file name gets created.
*/
  public void  checkWrite(String filename)  {
    if( isAgent()) {
      if( isAgentGoingThroughAgentContext())
        return;
      }
    else
      return;
    throw new AgentServerSecurityException();
    }

  }

/** A class representing a violation of the AgentServer's
security strategy.
*/
class AgentServerSecurityException
                    extends SecurityException {
  public AgentServerSecurityException() {
    super( "AgentServerSecurityException" );
    }
  }

/** A class for holding the name and current state of a
Security property.
*/
class SecurityItem {
/** The name of the resource this security item is protecting. */
  public String name;
/** Set to true if the access to this resource is ALLOWED. */
  public boolean state;

/** constructor - force the user to initialize the name and
state of this property.
@param  label The name of this property.
@param  initState The initial state of this property.
*/
  public SecurityItem( String label, boolean initState ) {
    name = new String( label );
    state = initState;
    }
  }

/** A modal dialog box that allows the user to set the security
strategy for the AgentServer.

*/
class SecurityDialog extends Dialog {
   int selectIndex = -1;
   Frame parent;
   Panel ButtonPanel;
   public boolean bFinished = false;
  Vector cbV = new Vector(1);

/** Constructor.
*/
  public SecurityDialog(Frame p) {
   super(p, "Setup AgentServer Security", true);
     parent = p;

    // Set up all the graphical elements
    // Split the dialog main panel into three elements, top,
    // bottom and middle, via the BorderLayout.  The top and
    // bottom size themselves according to the preferred sizes
    // of the text on the top and the buttons on the bottom.
    // The Center panel, which the List fills, uses all the
    // space left in the middle.
     setLayout(new BorderLayout());
     ButtonPanel = new Panel();
   add( "South", ButtonPanel );

    Panel checkPanel = new Panel();
    checkPanel.setLayout( new GridLayout( 8, 3 ));

    Vector v = AgentServerSecurityManager.v;
    for( int i = 0; i < v.size(); i++ ) {
      Checkbox cb = new Checkbox(
        ((SecurityItem)v.elementAt(i)).name,
        null, ((SecurityItem)v.elementAt(i)).state);
      checkPanel.add( cb );
      cbV.addElement(cb );
      }

   add( "Center", checkPanel );

     Button okbutton = new Button("OK");
   ButtonPanel.add( okbutton );
   Button cancelbutton = new Button( "Cancel" );
   ButtonPanel.add( cancelbutton );
   }


/** Size the dialog to something appropriate, then make it
non-resizeable so that users don't go resizing it themselves.
*/
  public void ShowAndLayout() {
   show();
   resize( 600, 300 );
   layout();
   setResizable(false);
   }

/** Process the OK and cancel buttons.  This also gets called
every time the user changes the state of one of our Checkboxes
so we explicitly ignore that case.  When OK is hit, roll
through the SecurityItem Vector setting the state of each of
the items based on the checkbox state.
*/
public boolean action(Event e, Object o) {

  if( e.target instanceof Checkbox ) {
    return false;
    }
   if( e.target instanceof Button ) {
    if( ((Button)e.target).getLabel().compareTo("OK") == 0 ) {
      for( int i = 0; i < cbV.size(); i++ ) {
        AgentServer.assm.setFlagState(
          ((Checkbox)cbV.elementAt(i)).getLabel(),
            ((Checkbox)cbV.elementAt(i)).getState());
        }
      }
      }
   bFinished = true;
   dispose();
   return true;
   }
}

