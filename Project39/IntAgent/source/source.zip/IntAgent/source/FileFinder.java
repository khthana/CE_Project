package agent.FileFinder;

import java.lang.*;
import java.util.*;
import java.awt.*;
import java.io.*;
import agent.Agent.*;
import agent.FileFinder.*;
// To catch the definition of AgentContext
import agent.Server.AgentContext;   

/** An Agent subclass for finding files that match a particular
set of filename filters.

*/
public class FileFinder extends Agent {
   ConfigurationDialog cfd;
   Vector args;

/** Constructor - does nothing by design, but it's useful to
leave the println in there just to convince yourself that the
Agent has been instantiated on the AgentServer.
*/
   public FileFinder() {
      System.out.println( "FileFinder constructor" );
      }

/** Put up a ConfigurationDialog that gets the arguments this
Agent needs to run on an AgentServer.
@param  frame The frame window of the browser, needed for the
dialog constructor.
*/
   public void configure( Frame frame ) {
      cfd = new ConfigurationDialog( frame );
      cfd.show();
      }

/** Return whatever arguments the configure method got from the
user as a Vector of Strings.
@return A Vector of Strings that are only meaningful to the
Agent itself, not to either the AgentLauncher or AgentServer.
*/
   public Vector getArguments() {
      return( cfd.args );     
      }

/** Configure the Agent with the specified Vector of Strings as
'arguments'. Called by the AgentLauncher, passing the arguments
it pried out of the LoadMessage.
@param  ar  A Vector of Strings identical to the one returned
to the AgentLauncher by getArguments.  
*/
   public void setArguments( Vector ar ) {
      args = ar;
      }

/** The run loop for this Agent.  Gets the top-level directory
which this Agent is allowed to read from the properties file
via the key acl.read, and checks all the files in that
directory against the filenamefilter specified by the user back
on the AgentLauncher.
*/
   public void run() {
      String topDirectory = System.getProperty( "acl.read" );
      if( topDirectory == null ) {
         System.out.println( "can't read this machine" );
         return;
         }
      System.out.println( "got value "+topDirectory
                      +" for property acl.read" );
      boolean keepGoing = true;
      String currentDirectory = new String(topDirectory);
      ac.reportStart( "" );
      while( keepGoing ) {
         System.out.println( "currentDirectory = "+currentDirectory );
         File f = new File(currentDirectory); 
         System.out.println( "f = "+f );
         AgainstArgs aa = new AgainstArgs( args );
         System.out.println( "aa = "+aa );
         String filelist[] = f.list( aa );
         System.out.println( "filelist = "+filelist );
         keepGoing =false;
         if( filelist.length == 0 ) {
            ac.reportFinish( "XXXXX", null, 0, "no results, sorry" );
            }
         else {
            // Start the HTML file
            ac.writeOutput( 
  "<HTML><HEAD><TITLE>FileFinderOutput</TITLE></HEAD><BODY>" );
            // Start an unordered list
            ac.writeOutput( "<UL>" );  
            for( int i = 0; i < filelist.length; i++ ) {
               System.out.println( "filelist["+i+"] = "+filelist[i] );
               String s = new String("<LI><A HREF="+filelist[i]+"</A>"+filelist[i]+"</LI>" );
               ac.writeOutput( s );
               }
            // End the unordered list
            ac.writeOutput( "</UL>" );
            // End the HTML file
            String s = new String( "</BODY></HTML>" );
            ac.writeOutput( s );
            try {
               Thread.sleep( 10000 );
            } catch( InterruptedException e ){System.out.println("ex "+e); }
            keepGoing =false;
            ac.reportFinish( "XXXXX", ac.getResultsURL(""), 100, 
            "This is the comment" ); 
            }
         }
      ac.dispatch();
      }
  }

/** A dialog box for configuring a FileFinder Agent.  Allows
the user to enter up to 7 filenames to search for.
@see Dialog
*/
class ConfigurationDialog extends Dialog {
  Label theLabel;
  Button theButton;
  TextField tf[] = new TextField[7];
  Panel ButtonPanel;
  Panel TextFieldPanel;
  public Vector args;

/** constructor create a dialog with a certain title, lay it
out border style, add a prompt, 7 TextFields for entering the
file specs and OK and Cancel buttons.
@param  parent  The Frame that is the parent of this dialog.
*/
  public ConfigurationDialog(Frame parent) {
   super(parent, "Configure File Finder", true);
     setLayout(new BorderLayout());
   theLabel = new Label( "Enter up to 7 file specifications:" );
     add("North",theLabel);
   TextFieldPanel = new Panel();
     TextFieldPanel.setLayout( new GridLayout(7, 1 ));
   add("Center", TextFieldPanel );
     for( int i = 0; i < 7; i++ ) {
        tf[i] = new TextField( "", 25 );
      TextFieldPanel.add( tf[i] );
      }
   Dimension d = tf[0].preferredSize();
   ButtonPanel = new Panel();
     add( "South", ButtonPanel );
   theButton = new Button( "Ok" );
     ButtonPanel.add( theButton );
   setResizable(false);
    }

/** Deal with the user hitting either OK or Cancel.  In either
case, fill the argument Vector with whatever's in the
TextFields and dispose of the dialog.
*/
  public boolean action(Event e, Object o) {
   if( e.target instanceof Button )
      {
      args = new Vector(1);
      for( int i = 0; i < 7; i++ ) {
           if( tf[i].getText().length() > 0 && 
                  (tf[i].getText().compareTo("") != 0 ))
            {
            byte b[] = new byte[tf[i].getText().length()];
            tf[i].getText().getBytes( 0, b.length, b, 0 );  
            args.addElement( b );
            }
         }
        }
   dispose();
     return true;
   }
   }





/** A FilenameFilter to use to screen files against the file
specs the user has configured this FileFinder Agent with. 
Accepts the file if it's in the list, rejects it otherwise.
*/
class AgainstArgs implements FilenameFilter {
   Vector args;

/** constructor, stores the filename list Vector for later use
by accept.
@param  arglist The Vector of filenames.
*/
   public AgainstArgs( Vector arglist ) {
      args = arglist;
      }

/** Return true if the filename supplied matches one of the
files named in the Vector of filenames the user configured this
Agent with.
@param  f The file as a File object.
@param  filename  The name of the file.
*/
   public boolean accept( File f, String filename ) {
      for( int i = 0; i < args.size(); i++ ) {
         String s = new String( (byte [])args.elementAt(i), 0);
         if( filename.compareTo(s) == 0 ){
            return( true );
            }
         }
      return( false );
      }
   }
