package agent.util;

import java.util.*;
import java.io.*;
import java.net.*;
import java.applet.*;
import java.awt.*;
import agent.util.*;
import agent.Launcher.*;
import agent.Agent.*;

/** A message from an AgentLauncher telling the AgentServer
recipient to dispatch the agent named in the message to all
the AgentServers in his list. Format:

Message hdr Disp 4 bytes
length of length  4 bytes ascii integer
length  length bytes ascii integer

         Class File Name
Field hdr Name 4 bytes
length  4 bytes ascii integer
Name data  length bytes

         Agent ID
Field hdr ID__ 4 bytes
length 4 bytes ascii integer
ID data  length bytes

         Argument
Field hdr Arg_ 4 bytes
length 4 bytes ascii integer
Argument data  length bytes


*/
public class DispatchMessage extends Message  {
 public static final String DISPATCH_PREFIX=new String("Disp");
 public static final String ID_PREFIX = new String( "ID__" );
 public static final String NAME_PREFIX = new String( "Name" );
 public static final int IDLEN_SIZE = 4;
 public static final int NAMELEN_SIZE = 4;
 public static final int ARGLEN_SIZE = 4;
 public static final String ARG_PREFIX = new String( "Arg_" );
 String s;
 public String name;
 public String id;
 public String sig = new String("XXX");
 byte bname[];
 byte bid[];
 public Vector args;

/** Save the name, id and arguments for future use in
createMessage.
@param Name The String filename of the lead .class file.
@param ID The id of this Agent, set by AgentLauncher
@param Args A vector of argument data, significant ONLY to the
Agent himself.
*/
  public DispatchMessage( String Name, String ID, Vector Args )
    {
    name = new String( Name );
    id = new String( ID );
    args = Args;  
    }

/** Create a useable message from the instance variables:
 id
 args
 name
When this method is done, the msg byte array contains a message
that can be sent over the wire.
*/
  public void createMessage() {
    int totallength = 0;
    s = makePrefix( DISPATCH_PREFIX, totallength, 10 );
    totallength = s.length();
    s = makePrefix( ID_PREFIX, id.length(), IDLEN_SIZE );
    bid = new byte[s.length()+id.length()];
    s.getBytes( 0, s.length(), bid, 0 );
    id.getBytes( 0, id.length(), bid, s.length());
    totallength += s.length();
    totallength += id.length();

    s = makePrefix( NAME_PREFIX, name.length(), NAMELEN_SIZE );
    bname = new byte[s.length()+name.length()];
    s.getBytes( 0, s.length(), bname, 0 );
    name.getBytes( 0, name.length(), bname, s.length());
    totallength += s.length();
    totallength += name.length();

// the arguments
    byte bargs[][] = new byte[args.size()][];
    for( i = 0; i < args.size(); i++ ) {
      byte arg[] = (byte[])args.elementAt(i);
      s = makePrefix( ARG_PREFIX, arg.length, ARGLEN_SIZE );
      bargs[i] = new byte[arg.length+s.length()];
      s.getBytes( 0, s.length(), bargs[i], 0 );
      for( int k = 0; k < arg.length; k++ )
        bargs[i][k+s.length()] = arg[k];
      totallength += s.length();
      totallength += arg.length;
      }

// redo the message header with proper totallength
    s = makePrefix( DISPATCH_PREFIX, totallength, 10 );
    command = new byte[s.length()];
    s.getBytes( 0, s.length(), command, 0 );
    msg = new byte[totallength];

    int currentOffset = 0;
    for( i = 0; i < command.length; i++ )
      msg[currentOffset++] = command[i];
    for( i = 0; i < bid.length; i++ )
      msg[currentOffset++] = bid[i];
    for( i = 0; i < bname.length; i++ )
      msg[currentOffset++] = bname[i];
    for( i = 0; i < args.size(); i++ )
      for( j = 0; j < bargs[i].length; j++ )
        msg[currentOffset++] = bargs[i][j];
    }

/** Parse the supplied byte array as if it were a dispatch
message. 
@param b An array of bytes containing message data.  
@param co The offset of the SECOND field in the message.
@return true if successful, false otherwise
*/
  public boolean parse(byte b[], int co) {
    int currentOffset = co;

    args = new Vector(1);
    name = null;
    // We enter here with byte[currentOffset] at the byte
    // right after the length.
    byte prefix[] = new byte[4];
    for( int i = 0; i < 4; i++ )
      prefix[i] = b[currentOffset++];
    String sprefix = new String( prefix, 0 );
    if( sprefix.compareTo( ID_PREFIX ) == 0 ) {
      byte bsize[] = new byte[IDLEN_SIZE];
      for( i = 0; i < IDLEN_SIZE; i++ ) {   
        bsize[i] = b[currentOffset++];
        }
      String ssize = new String( bsize, 0 );
      Integer isize = new Integer( ssize );
      byte bid[] = new byte[isize.intValue()];
      for( i = 0; i < isize.intValue(); i++ ) {
        bid[i] = b[currentOffset++];
        }
      id = new String( bid, 0 );
      }
    else {
      System.out.println( "out of sync at prefix " );
      return (false);
      }

    // Followed by some number of byte array arguments
    sprefix = new String( b, 0, currentOffset, PREFIX_SIZE );
    currentOffset += PREFIX_SIZE;

    if( sprefix.compareTo( NAME_PREFIX ) == 0 ) {
      byte bsize[] = new byte[NAMELEN_SIZE];
      for( i = 0; i < NAMELEN_SIZE; i++ ) {   
        bsize[i] = b[currentOffset++];
        }
      String ssize = new String( bsize, 0 );
      Integer isize = new Integer( ssize );
      byte bname[] = new byte[isize.intValue()];
      for( i = 0; i < isize.intValue(); i++ ) {
        bname[i] = b[currentOffset++];
        }
      name = new String( bname, 0 );
      }
    else {
      System.out.println( "out of sync at name " );
      return(false);
      }

    // Followed by some number of byte array arguments
    s = new String( b, 0, currentOffset, PREFIX_SIZE );
    currentOffset += PREFIX_SIZE;

    while( s.compareTo( ARG_PREFIX ) == 0 )
      {
      // the next thing is ASCII 4 bytes of length
      String sl = new String( b, 0, currentOffset,ARGLEN_SIZE);
      currentOffset+=ARGLEN_SIZE;
      Integer length = new Integer( sl );
      byte arg[] = new byte[length.intValue()];
      for( int i = 0; i < length.intValue(); i++ )
        arg[i] = b[currentOffset++];        
      args.addElement( arg );
  
      if( currentOffset >= b.length )
        break;

      s = new String( b, 0, currentOffset, PREFIX_SIZE );
      currentOffset += PREFIX_SIZE;
      }
    System.out.println("Successfully parsed dispatch message");
    return( true );
    }

  }


