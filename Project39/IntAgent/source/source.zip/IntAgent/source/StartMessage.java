package agent.util;

import java.awt.*;
import java.lang.*;
import agent.util.*;
import java.util.*;
import java.net.*;
import java.io.*;

/** A message telling an AgentLauncher that the named Agent has
started work on the named server.  This message will be
followed at some point by a ResultsMessage, telling the
AgentLauncher that the Agent has finished.  Format:

Message hdr Star 4 bytes
length of length  4 bytes ascii integer
length   length bytes ascii integer

          Agent ID
Field hdr ID__ 4 bytes
length  4 bytes ascii integer
ID data  length bytes

          Name of Server
Field hdr Serv 4 bytes
length  4 bytes ascii integer
Server data  length bytes

@see Message
*/
public class StartMessage extends Message{
  public static final int PREFIX_SIZE=4;
  public static final int LOADLEN_SIZE=10;
  public static final int IDLEN_SIZE = 4;
  public static final int SERVERLEN_SIZE = 4;

  public static final String START_PREFIX = new String( "Star" );
  public static final String ID_PREFIX = new String( "ID__" );
  public static final String SERVER_PREFIX = new String( "Serv" );

  public String sid;
  public String server;

  byte bsid[];
  byte bserver[];

  public StartMessage() { };
  public StartMessage(String AgentID, String srv){
    System.out.println( "startmsg "+AgentID+"  "+srv );
    sid = new String( AgentID );
    server = new String( srv );
    }


/** Parse the specified byte array as a Start message.  Fill in
the public instance variables:
  sid
  server
from the message data.
*/
public void parse(byte b[], int currentOffset) {
String command;
byte sig[];
byte clas[];
String s;

    
  // Followed by some number of byte array arguments
  s = new String( b, 0, currentOffset, PREFIX_SIZE );
  System.out.println( "next field "+s);
  currentOffset += PREFIX_SIZE;

  if( s.compareTo( ID_PREFIX ) == 0 )
    {
    String sl = new String( b, 0, currentOffset,IDLEN_SIZE );
    currentOffset += IDLEN_SIZE;
    Integer length = new Integer( sl );
    System.out.println( "got id of length "+length );
    bsid = new byte[length.intValue()];
    for( int i = 0; i < length.intValue(); i++ ) {
      bsid[i] = b[currentOffset++]; 
      }
    sid = new String( bsid, 0 );
    }
  else
    System.out.println( "out of sync at ID" );


  s = new String( b, 0, currentOffset, PREFIX_SIZE );
  currentOffset += PREFIX_SIZE;
  System.out.println( "next field "+s);

  if( s.compareTo( SERVER_PREFIX ) == 0 )
    {
    String sl = new String( b, 0, currentOffset,SERVERLEN_SIZE );
    currentOffset += SERVERLEN_SIZE;
    Integer length = new Integer( sl );
    System.out.println( "got server of length "+length );
    bserver = new byte[length.intValue()];
    for( int i = 0; i < length.intValue(); i++ ) {
      bserver[i] = b[currentOffset++];  
      }
    server = new String( bserver, 0 );
    }
  else
    System.out.println( "out of sync at server" );
  }

/** Create a start message from the instance variables:
  sid
  server
which must have already been set via the constructor, or a call
to parse.  When this method is done, the msg byte array
contains a valid start message that can be sent out over the
wire. 
*/
public void createMessage() {
  String s;
  int totallength = 0;

// the load command
  totallength = PREFIX_SIZE+LOADLEN_SIZE;

// the AgentID
  s = makePrefix( ID_PREFIX, sid.length(), IDLEN_SIZE );
  bsid = new byte[s.length()+sid.length()];
  s.getBytes(0,s.length(),bsid, 0 );
  sid.getBytes(0,sid.length(), bsid, s.length());
  totallength += bsid.length; 

// the server
  s = makePrefix(SERVER_PREFIX,server.length(),SERVERLEN_SIZE);
  bserver = new byte[s.length()+server.length()];
  s.getBytes(0,s.length(),bserver, 0 );
  server.getBytes(0,server.length(), bserver, s.length());
  totallength += bserver.length;  

// the raw class data is already set via LoadClassFromFile
    
  s = makePrefix( START_PREFIX, totallength, 10 );
  command = new byte[s.length()];
  s.getBytes( 0, s.length(), command, 0 );

  msg = new byte[totallength];
  int currentOffset = 0;
  for( i = 0; i < command.length; i++ )
    msg[currentOffset++] = command[i];
  for( i = 0; i < bsid.length; i++ )
    msg[currentOffset++] = bsid[i];
  for( i = 0; i < bserver.length; i++ )
    msg[currentOffset++] = bserver[i];
  }
}


