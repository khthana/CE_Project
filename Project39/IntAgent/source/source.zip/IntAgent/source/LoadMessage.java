package agent.util;

import java.awt.*;
import java.lang.*;
import agent.util.*;
import java.util.*;
import java.net.*;
import java.io.*;

/** A message that tells the receiver to load, instantiate and
run the class that is supplied in the message.  Message
format:

 The command  Load  4 bytes
 The length   10 bytes ascii int


         The dispatching agent server
Field hdr   Dsrv  4 bytes
length            4 bytes
server-name:port  length bytes

         The arguments (unlimited repetitions)
Field hdr Arg_    4 bytes
length            4 bytes ascii int
Argument data     length bytes

         The signature
Field hdr Sig_    4 bytes
The length        4 bytes
The sig data     length bytes

         The run id
Field hdr ID__    4 bytes
The length        4 bytes
The run id        length bytes

         The class data (unlimited repetitions)
Field hdr Clas    4 bytes
length            10 bytes ascii int
the class data    length bytes

Class contains both message construction and message parsing
methods. Also contains some message processing in the form of
class loading.  Essentially, the receiver of a load message is
looking to receive a Java Class, so the parse method
implements this.


@see DispatchMessage
@see Message
*/
public class LoadMessage extends Message{
  byte args[][];
  public Vector vargs;
  byte sig[];
  byte leadclas[];
  Vector otherclasses = new Vector(1);
  byte id[];
  byte bdsrv[];

  String ssig;
  public String sid;
  String sname;
  public String dispatching_server_name;
  public int dispatching_server_port;

  int i, j;
  public static final int PREFIX_SIZE=4;
  public static final String LOAD_PREFIX = new String("Load");
  public static final String ARG_PREFIX = new String("Arg_");
  public static final String CLASS_PREFIX = new String("Clas");
  public static final String SIG_PREFIX = new String("Sig_");
  public static final String ID_PREFIX = new String("ID__");
  public static final String DSRV_PREFIX = new String("DSrv");

  public static final int LOADLEN_SIZE=10;
  public static final int ARGLEN_SIZE=4;
  public static final int CLASSLEN_SIZE=10;
  public static final int SIGLEN_SIZE=4;
  public static final int IDLEN_SIZE = 4;
  public static final int DSRVLEN_SIZE = 4;
  public String ClassPath =
       new String( "/agent/classes/rel/" );

/** The do-nothing constructor.  Called when parsing a Load
Message */
  public LoadMessage() { };

/** This is the constructor used by an AgentServer that wishes
to SEND a load message.  Supply the name of the lead class,
the id, the signature, arguments, dispatching server and port.
*/
  public LoadMessage( String name, String ID, String thesig,
      Vector args, String dispatchServer, int dispatchPort )
   {
    ClassPath = System.getProperty( "agent.LoadClassPath" );
    if( ClassPath == null ) {
      System.out.println( "can't read this machine" );
      }
    else
      System.out.println( "got "+ClassPath+" for agent.LoadClassPath");

    StringTokenizer st = new StringTokenizer( name, "." );
    Vector v = new Vector(1);
    while( st.hasMoreElements())
      v.addElement( st.nextElement());
    String filename = new String("");
    for( int i = 0; i < v.size(); i++ ) {
      filename = new String(filename+(String)v.elementAt(i));
      if( i < (v.size()-1))
        filename = filename+"/";
      System.out.println( "filename = "+filename );
      }
    // filename is the name of the root class of this Agent
    // the class that needs to be instantiated on the AgentServer
    filename = filename+".class";
    leadclas = LoadClassFromFile( ClassPath+filename );
    LoadClassesFromDirectory( ClassPath+filename );
    vargs = new Vector(1);
    for( int i = 0; i < args.size(); i++ )
      vargs.addElement( args.elementAt(i) );
    sid = new String( ID );
    ssig = new String( thesig );
    dispatching_server_name = dispatchServer;
    dispatching_server_port = dispatchPort;
    }

/** parse the supplied byte array as if it were a load
message.  Start parsing at the supplied currentOffset.
currentOffset should point to the FIRST byte of the SECOND
field in a load message, i.e. to the first character in the
word "DSrv".  Fills the instance variables:
  dispatching_server_name
  dispatching_server_port
  vargs
  leadclass
  otherclasses
  ssig
  sid
with data from the message.  Instantiates the lead class if
the message is OK, but does not call the run method.
*/
public Object parse(byte b[], int currentOffset) {
String command;
byte sig[];
String s;
Class leadC = null;


  // Followed by some number of byte array arguments
  s = new String( b, 0, currentOffset, PREFIX_SIZE );
  currentOffset += PREFIX_SIZE;

  if( s.compareTo( DSRV_PREFIX ) == 0 )
    {
    // the next thing is ASCII 4 bytes of length
    String sl = new String( b, 0, currentOffset, DSRVLEN_SIZE);
    currentOffset+=DSRVLEN_SIZE;
    Integer length = new Integer( sl );
    bdsrv = new byte[length.intValue()];
    for( int i = 0; i < length.intValue(); i++ )
      bdsrv[i] = b[currentOffset++];
    StringTokenizer st =
          new StringTokenizer( new String(bdsrv,0), ":" );
    dispatching_server_name =
          new String( (String)st.nextElement());
    Integer iport = new Integer( (String)st.nextElement());
    dispatching_server_port = iport.intValue();

    s = new String( b, 0, currentOffset, PREFIX_SIZE );
    currentOffset += PREFIX_SIZE;
    }
  else {
    System.out.println( "out of sync at DSRV" );
    return( null );
    }

  vargs = new Vector(1);
  int numargs = 0;
  while( s.compareTo( ARG_PREFIX ) == 0 )
    {
    // the next thing is ASCII 4 bytes of length
    String sl =
        new String( b, 0, currentOffset, ARGLEN_SIZE);
    currentOffset+=ARGLEN_SIZE;
    Integer length = new Integer( sl );
    byte arg[] = new byte[length.intValue()];
    for( int i = 0; i < length.intValue(); i++ )
      arg[i] = b[currentOffset++];
    vargs.addElement( arg );

    s = new String( b, 0, currentOffset, PREFIX_SIZE );
    currentOffset += PREFIX_SIZE;
    }

// s is already set to the command name
  if( s.compareTo( SIG_PREFIX ) == 0 ) {
    // the next thing is ASCII 4 bytes of length
    String sl = new String( b, 0, currentOffset, SIGLEN_SIZE );
    currentOffset+=SIGLEN_SIZE;
    Integer length = new Integer( sl );
    sig = new byte[length.intValue()];
    for( int i = 0; i < length.intValue(); i++ )
      sig[i] = b[currentOffset++];
    ssig = new String( sig, 0 );
    }
  else {
    System.out.println( "out of sync at sig" );
    return( null );
    }

  s = new String( b, 0, currentOffset, PREFIX_SIZE );
  currentOffset += PREFIX_SIZE;
  if( s.compareTo( ID_PREFIX ) == 0 )
    {
    String sl = new String( b, 0, currentOffset,IDLEN_SIZE );
    currentOffset += IDLEN_SIZE;
    Integer length = new Integer( sl );
    id = new byte[length.intValue()];
    for( int i = 0; i < length.intValue(); i++ ) {
      id[i] = b[currentOffset++];
      }
    sid = new String( id, 0 );
    }
  else {
    System.out.println( "out of sync at ID" );
    return( null );
    }

  s = new String( b, 0, currentOffset, PREFIX_SIZE );
  currentOffset += PREFIX_SIZE;
  int classnum = 0;
  otherclasses = new Vector(1);
  while( s.compareTo( CLASS_PREFIX ) == 0 )
    {
    // the next thing is ASCII 10 bytes of length
    String sl = new String( b, 0, currentOffset,CLASSLEN_SIZE);
    currentOffset += CLASSLEN_SIZE;
    Integer length = new Integer( sl );
    byte bclas[] = new byte[length.intValue()];
    for( int i = 0; i < length.intValue(); i++ ) {
      bclas[i] = b[currentOffset++];
      }
    // Only instantiate the first class in the message
    if( classnum == 0 )
      leadclas = bclas;
    else {
      otherclasses.addElement(bclas);
      }
    s = new String( b, 0, currentOffset, PREFIX_SIZE );
    currentOffset += PREFIX_SIZE;
    classnum++;
    }
  if( classnum == 0 )
    System.out.println( "out of sync at class" );
  else {
    AgentLoader al = new AgentLoader(otherclasses);
    leadC = al.loadFromByteLump(leadclas, true);
    try {
      Object o = leadC.newInstance();
      return( o );
      } catch( Exception e1 )
        { System.out.println( "new instance exception" ); }
    }
  return( null );
  }

/** Load the instance variable otherclasses with byte arrays
that are filled from ALL the class files (except the lead
class) in the directory embedded in the supplied class name.
*/
public void LoadClassesFromDirectory( String leadclass ) {
  System.out.println( "LoadClassesFromDir "+leadclass);

  int j = leadclass.lastIndexOf('/');
  String absoluteDir = leadclass.substring(0,j);
  System.out.println( "absoluteDir = "+absoluteDir );
  File f = new File( absoluteDir );
  if( f.isDirectory() != true ) {
    System.out.println( absoluteDir+" not a directory" );
    return;
    }
  ExtensionFilter ef = new ExtensionFilter( ".class" );
  String sa[] = f.list( ef );
  for( int i = 0; i < sa.length; i++ ) {
    if( leadclass.compareTo(absoluteDir+"/"+sa[i]) == 0 )
      // lead class is already loaded
      {
      System.out.println( "Skipping leadclass "+sa[i] );
      continue;
      }
    otherclasses.addElement(
         LoadClassFromFile( absoluteDir+"/"+sa[i] ));
    }
  }

/** Load the specified class file into a byte array and return
that byte array.  All class files are read into the load
message via this method.
*/
public byte[] LoadClassFromFile( String name ) {
  byte bret[] = null;
  System.out.println( "Loading class from file "+name );
  try {
    FileInputStream fi = new FileInputStream( name );
    int filesize = fi.available();
    byte[] lump = new byte[filesize];
    fi.read( lump );
    String prefix = makePrefix( CLASS_PREFIX,
                            filesize, CLASSLEN_SIZE );
    bret = new byte[prefix.length()+lump.length];
    prefix.getBytes( 0, prefix.length(), bret, 0 );
    for( i = 0; i < lump.length; i++ )
      bret[prefix.length()+i] = lump[i];
    } catch( IOException e ) {
      System.out.println("LoadClass "+name+" ex "+e );}
  return( bret );
  }

/** Actually fill the byte array 'msg' with ALL the bytes that
make up this load message.  Expects the intance variables:
  dispatching_server_name
  dispatching_server_port
  vargs
  leadclass
  otherclasses
  ssig
  sid
to already be filled with valid data.
*/
public void createMessage() {
  String s;
  int totallength = 0;

  if( leadclas == null )
    System.out.println( "No lead class loaded" );

// the load command
  totallength = PREFIX_SIZE+LOADLEN_SIZE;

// the dispatching server
  String srv = new String( dispatching_server_name+":"+
                      dispatching_server_port );
  s = makePrefix( DSRV_PREFIX, srv.length(), DSRVLEN_SIZE );
  bdsrv = new byte[s.length()+srv.length()];
  s.getBytes(0,s.length(),bdsrv, 0 );
  srv.getBytes(0,srv.length(), bdsrv, s.length());
  totallength += bdsrv.length;

// the arguments
  args = new byte[vargs.size()][];
  for( i = 0; i < vargs.size(); i++ ) {
    byte ba[] = (byte [])vargs.elementAt(i);
    s = makePrefix( ARG_PREFIX, ba.length, ARGLEN_SIZE );
    args[i] = new byte[s.length()+ba.length];
    s.getBytes( 0, s.length(), args[i], 0 );
    for( int k = 0; k < ba.length; k++ )
      args[i][k+s.length()] = ba[k];
    totallength += args[i].length;
    }

// the signature
  s = makePrefix( SIG_PREFIX, 40, SIGLEN_SIZE );
  sig = new byte[s.length()+40];
  s.getBytes( 0, s.length(), sig, 0 );
  totallength += sig.length;

// the ID
  s = makePrefix( ID_PREFIX, sid.length(), IDLEN_SIZE );
  id = new byte[s.length()+sid.length()];
  s.getBytes( 0, s.length(), id, 0 );
  sid.getBytes( 0, sid.length(), id, s.length());
  totallength += id.length;

// the raw class data is already set via LoadClassFromFile
  totallength += leadclas.length;
  for( i = 0; i < otherclasses.size(); i++ ) {
    byte ba[] = (byte [])otherclasses.elementAt(i);
    totallength += ba.length;
    }

  s = makePrefix( LOAD_PREFIX, totallength, 10 );
  command = new byte[s.length()];
  s.getBytes( 0, s.length(), command, 0 );

  msg = new byte[totallength];
  int currentOffset = 0;
  for( i = 0; i < command.length; i++ )
    msg[currentOffset++] = command[i];
  for( i = 0; i < bdsrv.length; i++ )
    msg[currentOffset++] = bdsrv[i];
  for( j = 0; j < args.length; j++ ) {
    for( i = 0; i < args[j].length; i++ )
      msg[currentOffset++] = args[j][i];
    }
  for( i = 0; i < sig.length; i++ )
    msg[currentOffset++] = sig[i];
  for( i = 0; i < id.length; i++ )
    msg[currentOffset++] = id[i];
  for( i = 0; i < leadclas.length; i++ )
    msg[currentOffset++] = leadclas[i];
  for( i = 0; i < otherclasses.size(); i++ ) {
    byte ba[] = (byte [])otherclasses.elementAt(i);
    for( j = 0; j < ba.length; j++ )
      msg[currentOffset++] = ba[j];
    }

  }
}

/** A class to implement a class loader for loading agents on
an AgentServer.  The AgentServer uses this classloader to
resolve references that occur when it loads an Agent from a
load message.
@see LoadMessage

*/
class AgentLoader extends ClassLoader {
        static Hashtable cache = new Hashtable();
  Vector otherclasses;
  Vector classes = new Vector(1);

/** Take a vector of byte arrays filled with all the classes
UNIQUE TO THIS AGENT (except the lead class) and create a
class for each one, without resolving the references in those
classes.  Reference resolution is only done when the lead
class is instantiated.
*/
  public AgentLoader(Vector oc) {
    super();
    otherclasses = oc;
    for( int i = 0; i < otherclasses.size(); i++ ) {
      Class c = loadFromByteLump(
           (byte[])otherclasses.elementAt(i), false );
      classes.addElement(c);
      }
    }

/** Load the specified class into the Java system.  This
should only happen ONCE for any class.  Ideally, we shouldn't
be loading all the classes every time this gets called,but
we're boxed into this by the fact that the message design
doesn't 'label' the class bytecodes with the class name, thus
we can't pick an individual byte lump to load.  Message
structure should be revisited in light of this.

Resolves references for the named class, but not for other
classes.  Any other classes referenced by the named class will
have their references resolved automatically by the single
call to resolveClass.
*/
  private byte loadClassData(String name)[] {
    for( int i = 0; i < otherclasses.size(); i++ )
      {
      Class c = loadFromByteLump(
                 (byte[])otherclasses.elementAt(i), false );
      System.out.println( "loaded "+c );
      if( c.getName().compareTo(name) == 0 )
        {
        System.out.println( "match "+c );
        resolveClass(c);
        return( (byte[])otherclasses.elementAt(i) );
        }
      else
        System.out.println( "no match "+c );
      }
    return( null );
    }

/** Create a Class from an array of bytes.  Defines the class,
adds the class name to the hashtable so that we only load it
once, and resolve references if specified.
*/
  public synchronized Class loadFromByteLump( byte[] lump,
                                        boolean resolve ) {
    Class c;
    c = defineClass(lump, 0, lump.length);
    cache.put(c.getName(), c );
    if( resolve )
      resolveClass( c );
    return( c );
    }

/** Top-level method called by Java when classes within an
Agent need to be loaded.  We call it once for the lead class,
any other calls are generated internally by Java via the call
we make to resolveClass when loading the lead class.  The
return value is a fully resolved Class that can be instantiated.
This is the implementation of a ClassLoader method.
*/
  public synchronized Class loadClass(String name,
                                 boolean resolve) {
    Class c;

    System.out.println( "loadClass("+name+")");
    try {
      c = findSystemClass( name );
      System.out.println( "Resolved "+name+" locally" );
    } catch( ClassNotFoundException e ) {
      System.out.println( "Resolving "+name+" remotely" );
                  c = (Class)cache.get(name);
                  if (c == null) {
        byte data[] = loadClassData(name);
        c = loadFromByteLump( data, resolve );
        }
      resolveClass(c);
      }
                return c;
    }
  }


/** A filename filter that simply looks for file names with a
particular extension.  If the extension of the file name
supplied  to accept matches the extension supplied to the
constructor, the file is accepted.


*/
class ExtensionFilter implements FilenameFilter {
  String soughtExtension;
  public ExtensionFilter(String ext) {
    soughtExtension = new String(ext);
    }

/** If the extension of the file name supplied
to accept matches soughtExtension the file is
accepted - accept returns true.
*/
  public boolean accept( File f, String name ) {
    int i = name.lastIndexOf( '.' );
    if( i > 0 ) {
      String extension = name.substring(i);
      if( extension.compareTo(soughtExtension) == 0 ) {
        System.out.println( "accepting "+name);
        return( true );
        }
      }
    System.out.println( "rejecting "+name );
    return( false );
    }
  }

