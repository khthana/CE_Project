package agent.util;

import java.util.*;
import java.io.*;
import java.net.*;
import java.applet.*;
import java.awt.*;
import agent.util.*;
import agent.Launcher.*;
import agent.Agent.*;

/** A message telling the recipient to terminate with extreme
prejudice any instance of the named Agent that might be running
on his server. Format:
 
Message hdr Kill 4 bytes
Length of length  4 bytes ascii integer
Length  length bytes, ascii integer

          ID
Field hdr ID__ 4 bytes
length  4 bytes ascii integer
ID data  length bytes


*/
public class KillMessage extends Message  {
public static final String KILL_PREFIX = new String( "Kill" );
public static final String ID_PREFIX = new String( "ID__" );
public static int IDLEN_SIZE = 4;
String s;
String aid;
byte baid[];

/** Save the agent id for later use */
  public KillMessage( String AgentID ) {
    aid = new String( AgentID );  
    }

/** Build a kill message in the byte array msg from the
previously constructed instance variables:
 aid
When this method is done, the byte array msg contains a valid
kill message that can be sent over the wire.
*/
  public void createMessage() {
    int totallength = 0;
    s = makePrefix( KILL_PREFIX, totallength, 10 );
    totallength = s.length();
    s = makePrefix( ID_PREFIX, aid.length(), IDLEN_SIZE );
    baid = new byte[s.length()+aid.length()];
    s.getBytes( 0, s.length(), baid, 0 );
    aid.getBytes( 0, aid.length(), baid, s.length());
    totallength += s.length();
    totallength += aid.length();
    s = makePrefix( KILL_PREFIX, totallength, 10 );
    command = new byte[s.length()];
    s.getBytes( 0, s.length(), command, 0 );
    msg = new byte[totallength];
    int currentOffset = 0;
    for( int i = 0; i < command.length; i++ )
      msg[currentOffset++] = command[i];
    for( int i = 0; i < baid.length; i++ )
      msg[currentOffset++] = baid[i];
    }

/** Parse a kill message.  
@param b The byte array containing the kill message data
@param co The length of the message.
*/
  public String parse(byte b[], int co) {
    int currentOffset = co;

    System.out.println( "KillMessage.parse" );
    // We enter here with byte[currentOffset] at the byte
    // right after the length.
    byte prefix[] = new byte[4];
    for( int i = 0; i < 4; i++ )
      prefix[i] = b[currentOffset++];
    String sprefix = new String( prefix, 0 );
    System.out.println( "sprefix = "+sprefix );
    if( sprefix.compareTo( ID_PREFIX ) == 0 ) {
      byte bsize[] = new byte[IDLEN_SIZE];
      for( i = 0; i < IDLEN_SIZE; i++ ) {   
        bsize[i] = b[currentOffset++];
        }
      String ssize = new String( bsize, 0 );
      Integer isize = new Integer( ssize );
      byte bid[] = new byte[isize.intValue()];
      for( i = 0; i < isize.intValue(); i++ ) {
        bid[i] = b[currentOffset++];
        }
      String sid = new String( bid, 0 );
      return( sid );
      }
    return( null );
    }

  }

