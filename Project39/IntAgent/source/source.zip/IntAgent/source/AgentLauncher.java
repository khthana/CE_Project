package agent.Launcher;

import java.util.*;
import java.io.*;
import java.net.*;
import java.applet.*;
import java.awt.*;
import agent.util.*;
import agent.Launcher.*;
import agent.Agent.*;

/** An applet that allows users to launch Agents out into the
Agent system network.  Gives the user a list of Agents to
choose from, then allows him to launch it, view the results,
and/or kill the dispatched Agent.

*/

public final class AgentLauncher extends Applet implements Runnable {

/** The main thread */
Thread myThread = null;

boolean bSelecting = false;

public Vector ALVector;
/* Vector of AgentFaces - one per existing   agent */
String BaseImageURL;
public String sBadImage;

public PipedInputStream inpipeStream;
public PipedOutputStream outpipeStream;

public final int TEXT_ONLY = 0;
public final int ANIMATED = 1;

int DisplayType = ANIMATED;

public ResultFile resultFile = null;

// Thread priorities
public final int LOWPRIORITY=0;
public final int MEDIUMPRIORITY=10;
public final int HIGHPRIORITY=20;

String disServerName = new String( "" );
int disServerPort = 1037;
Thread animationThread;

ImageLoader ImageLoaderThread[];
public final int MAX_ANIMATOR_THREADS = 5;
Graphics prefetchGC = null;
Panel buttonPanel;
Panel textPanel;
Panel controlsPanel;
Button textOnlyButton;
Button pickButton;
Button dispatchButton;
Button stopButton;
Button resultButton;
Button killButton;
int currentAgentFaceY = 0;
boolean bDiscardHelpMenu = false;
Menu helpMenu;
MenuBar menuBar;
HelpButton helpButton;
static Agent currentAgent = null;
static AgentDispatcher currentDispatcher = null;
static String currentClassName = null;
static String currentID = null;

AgentFace agentFaces[];

public static final int DISABLE_ALL = -1;
public static final int NO_AGENT = 0;
public static final int AGENT_PICKED = 1;
public static final int AGENT_DISPATCHED = 2;
public static final int AGENT_STOPPED = 3;
static int app_state = NO_AGENT;
static AgentLauncher currentAgentLauncher;
public final static String TEXT_ONLY_STRING = new String("Text-only Display");
public final static String ANIMATED_STRING  = new String("Animated Display");
public final static String DISPATCH_STRING = new String("Dispatch");
public final static String STOP_STRING = new String("Stop");
public final static String PICK_STRING = new String( "Pick" );
public final static String RESULT_STRING = new String( "Results Page" );
public final static String KILL_STRING = new String( "Kill Launcher" );

void changeAppState(int new_state) {
   app_state = new_state;
   switch( app_state ) {
      case DISABLE_ALL:
         pickButton.disable();
         dispatchButton.disable();
      resultButton.disable();
      killButton.disable();
         stopButton.disable();
         break;
      case NO_AGENT:
         pickButton.enable();
         dispatchButton.disable();
      resultButton.disable();
      killButton.disable();
         stopButton.disable();
         break;
      case AGENT_PICKED:
         pickButton.enable();
         dispatchButton.enable();
      resultButton.disable();
      killButton.disable();
         stopButton.disable();
         break;
      case AGENT_DISPATCHED:
         pickButton.enable();
         dispatchButton.disable();
      resultButton.enable();
         stopButton.enable();
         break;
      case AGENT_STOPPED:
         pickButton.enable();
         dispatchButton.enable();
      killButton.disable();
      resultButton.enable();
         stopButton.disable();
         break;
      default:
         System.out.println( "bad app_state "+app_state );
         break;
      }
   layout();
   }

/** start - Whenever a user visits our page, Applet calls this.  This is
an override of an Applet method.  Creates a thread and passes this
AgentLauncher into it.  Works because we implement the Runnable method. */
public void start() {
   int i;
   currentAgentLauncher = this;
   if( myThread == null )
      {
//    showProperties();
      myThread = new Thread( this );
      myThread.setName( "AgentLauncher" );
      myThread.start();
      }
}

public void showProperties() {
// try {
//    Properties p = System.getProperties();
//    Enumeration e = p.propertyNames();
//    while( e.hasMoreElements())
//       {
//       String name = (String)e.nextElement();
//       System.out.println( "Property ("+name+") value ("+p.getProperty(name,"default")+")");
//       }
//    return;
// }
// catch( Throwable o ) {
//    System.out.println( "Can't read properties list "+o );
      System.out.println( "Property (os.name) value ("+System.getProperty("os.name")+")");
      System.out.println( "Property (os.arch) value ("+System.getProperty("os.arch")+")");
      System.out.println( "Property (java.version) value ("+System.getProperty("java.version")+")");
      System.out.println( "Property (java.vendor) value ("+System.getProperty("java.vendor")+")");
//    System.out.println( "Property (java.vendorURL) value ("+System.getProperty("java.vendorURL")+")");
//    System.out.println( "Property (java.class.version) value ("+System.getProperty("java.class.version")+")");
      System.out.println( "Property (acl.read) value ("+System.getProperty("acl.read")+")");
      System.out.println( "Property (acl.write) value ("+System.getProperty("acl.write")+")");
//    }
   }

/** Dispatch the current Agent.  currentAgent is an instance of
the Agent we wish to dispatch, and he has already configured
himself via Agent.configure.  We need to get his arguments as a
Vector of Strings, create a dispatcher, then tell the
dispatcher to dispatch using the currentAgent with those
arguments.
@see Agent
@see AgentDispatcher
*/
public void Dispatch() {
   Vector v = currentAgent.getArguments();
   currentDispatcher =
      new AgentDispatcher( disServerName, disServerPort );
   currentDispatcher.start();
   currentDispatcher.Dispatch( currentClassName, currentID, v );
   changeAppState( AGENT_DISPATCHED );
   }

public static void LoadAgentClass( Frame f, String selected ) {
   System.out.println( "LoadAgentClass selected = "+selected );
   if( selected != null ) {
      StringTokenizer st = new StringTokenizer( selected );
      currentClassName = new String( st.nextToken());
      currentID = new String( currentClassName+new Date());
      System.out.println( "loading class name "+currentClassName );
      try {
      Class c = Class.forName( currentClassName );
      Object o = c.newInstance();
      if( o instanceof Agent ){
         currentAgent = (Agent)o;
         currentAgent.configure(f);
         currentAgentLauncher.changeAppState( AGENT_PICKED );
         }
      } catch( Exception e ) { System.out.println( "exception "+e ); }
      }
   }

public void StopAgent(String cid) {
   currentDispatcher.StopAgent(cid);
   changeAppState( AGENT_STOPPED );
   }

public void LoadTest() {
   System.out.println( "Load test" );

   FileDialog fd = new FileDialog(getFrame(), "Load Class");
   fd.setDirectory( "c:/temp" );
   fd.show();
   if( fd.getFile() != null ) {
      System.out.println( "Load test - "+fd.getFile() );
      try {
         System.out.println( "button ok hit" );
         LoadMessage lm = new LoadMessage();
         lm.LoadClassFromFile( fd.getFile() );
         byte[] b = lm.getMessageBytes();
         Agent a = (Agent)lm.parse( b, 0 );
         a.getArguments();
         } catch( Exception e ) { System.out.println( "exception "+e ); }
      }
   else
      System.out.println( "getFile == null" );
   }

/** Get the Frame window that is the parent of all the windows
currently on the screen.  Every application has ONE Frame that
can be found by trolling through the tree of Containers that
makes up the hierarchy of windows in a Java application.
@return The Frame that is the ultimate parent of the current
Component.
*/
public Frame getFrame() {
   Component c = (Component)this;
   Frame theFrame = null;
   Component parent = (Component)this;
   while( parent != null ) {
      if( parent instanceof Frame ) {
         theFrame = (Frame)parent;
         break;
         }
      parent = parent.getParent();
      }
   return( theFrame );
   }
   


/** A method called by the message processing code
(AgentDispatcher) to change an agents state from running to
finished with or without results.
@param  url The URL of the results file.  If null, there were
no results.
@param  server  The name of the server.  We find the AgentFace
we need to change by searching on this name.
*/
  public void reportResult( String server, String url ) {
     for( int i = 0; i < ALVector.size(); i++ )
      {
      AgentFace af = (AgentFace)ALVector.elementAt(i);
        if( af.serverName.compareTo(server) == 0 )
           {
         if( url != null )
            af.returnedResults(url);
           else
              af.returnedNoResults();
         p.replaceAnimation( af.index, af.getCurrentAnimation());
         return;
         }
      }
   }

public void setRunning( int index ) {
   AgentFace a = (AgentFace)ALVector.elementAt( index );
   a.running();
   p.replaceAnimation( index, a.getCurrentAnimation());
   }

/** Stop this thread. */
public void stop() {
   System.out.println( "AgentLauncher stop - user is leaving my page" );
   myThread = null;
  animationThread.suspend();
}

/** The main loop for the main thread. */
public void run() {
   int i;

   layout();
   Rectangle r = textPanel.bounds();
   p.resize( 600, 600 );
   p.move( 0, r.y+r.height );

   System.out.println( "falling into run-while loop" );
  animationThread = new Thread( p );
  animationThread.start();
   showStatus( "Ready" );

   changeAppState( NO_AGENT );
   while( myThread != null )
      {
      try {
      Thread.sleep( 5000 );
      }
    catch( Exception e ) {
      System.out.println( "exception" );
      break;
      }
      repaint();
      p.repaint();
      }
   }

   public boolean clicked( int x, int y ) {
      // The reported X and Y are relative to the Panel we're in right
      // now, so we have to trim them to AnimationPanel relative coords.
      int relativeX = x - p.location().x;
      int relativeY = y - p.location().y;

      for( int i = 0; i < ALVector.size(); i++ ) {
         AgentFace af = (AgentFace)ALVector.elementAt(i);
//       if( af.inside( relativeX, relativeY )) {
//          af.clicked();
//          return( true );
//          }
         }
      return( false );
      }



    public boolean handleEvent(Event e) {

   if (e.id == Event.ACTION_EVENT) {
      System.out.println( "action" );
      if( e.target instanceof Button ) {
         if(((Button)e.target).getLabel().compareTo(PICK_STRING) == 0 )
            {
            Frame frame = getFrame();
            Vector agentList = new Vector(1);
            AgentListItemDescription alid = new AgentListItemDescription(
"agent.EvilAgent.EvilAgent", "Provoke the AgentServer security" );
            agentList.addElement( alid.line );
            alid = new AgentListItemDescription(
"agent.FileFinder.FileFinder", "Find up to 7 files by filespec" );
            agentList.addElement( alid.line );
            alid = new AgentListItemDescription(
"agent.Users.FindUser       ","Find user by name" );
            agentList.addElement( alid.line );
            alid = new AgentListItemDescription(
"agent.SQL.SQLQuery         ","Run an SQL query" );
            agentList.addElement( alid.line );
            alid = new AgentListItemDescription(
"agent.Math.FindPrimes      ","Prime number finding algorithm" );
            agentList.addElement( alid.line );
            PickDialog d = new PickDialog(this, frame, agentList, alid.header);
      //    a.LoadTest();
            d.ShowAndLayout();
            }
         if(((Button)e.target).getLabel().compareTo(DISPATCH_STRING) == 0 )
            Dispatch();
         if(((Button)e.target).getLabel().compareTo(STOP_STRING) == 0 )
            StopAgent(currentID);
         if(((Button)e.target).getLabel().compareTo(TEXT_ONLY_STRING) == 0 )
            {
            DisplayType = TEXT_ONLY;
            textOnlyButton.setLabel(ANIMATED_STRING);
            }
         else {
            if(((Button)e.target).getLabel().compareTo(ANIMATED_STRING) == 0 )
               {
               DisplayType = ANIMATED;
               textOnlyButton.setLabel(TEXT_ONLY_STRING);
               }
            }
         }
      }
   else {
      if( e.id == Event.MOUSE_UP )
         clicked( e.x, e.y );
      }
   return false;
   }
    /**
     * Initialize the applet. Resize and load images.
     */
public void init() {
   int i,j;

      disServerName = getCodeBase().getHost();
      System.out.println( "setting dispatching agent server to  "+disServerName );
      setLayout( new BorderLayout());
      controlsPanel = new Panel();
      controlsPanel.setLayout( new GridLayout( 2, 1 ));
      add( "North", controlsPanel );

      buttonPanel = new Panel();
      pickButton = new Button(PICK_STRING);
      dispatchButton = new Button(DISPATCH_STRING);
      stopButton = new Button(STOP_STRING);
      textOnlyButton = new Button( TEXT_ONLY_STRING );
      helpButton = new HelpButton( this );
      resultButton = new Button( RESULT_STRING );
    killButton = new Button( KILL_STRING );
//    TestButton testButton = new TestButton( this );
//    TestButton1 testButton1 = new TestButton1( this );
      buttonPanel.add( pickButton );
      buttonPanel.add( dispatchButton );
      buttonPanel.add( stopButton );
      buttonPanel.add( resultButton );
    buttonPanel.add( killButton );
//    buttonPanel.add( textOnlyButton );
      buttonPanel.add( helpButton );
//    buttonPanel.add( testButton );
//    buttonPanel.add( testButton1 );
      controlsPanel.add( buttonPanel );

      textPanel = new Panel();
      Label textLabel = new Label( "My ID", Label.LEFT );
      textPanel.add( textLabel );
      TextField textField = new TextField(30);
      textPanel.add( textField );
      controlsPanel.add( textPanel );

      p = new AnimationPanel();
//    p.add( new Button("testing" ));
      add( "Center", p );
//    p.resize( 600, 600 );

   changeAppState( DISABLE_ALL );

    System.out.println( "getting base from  "+getCodeBase());
    int ix = getCodeBase().toString().indexOf( "AgentLauncher" );
    if( ix > 0 )
      BaseImageURL = new String( getCodeBase().toString().substring(0,ix)+"images" );
    else
        BaseImageURL = new String( getCodeBase().toString()+"/images" );

    ix = BaseImageURL.indexOf( "//images" );
    if( ix > 0 )
        BaseImageURL = new String( BaseImageURL.substring( 0, ix )+"/images");

   System.out.println( "BaseImageURL = " + BaseImageURL );
// resize( 400, 4000 );
   ALVector = new Vector(1);
   
    }

/** startDispatch - Called when the user has chosen to dispatch an
Agent. Sends the Agent to our ServerList and opens the ResultFile.
*/
public void startDispatch() {
   try {
   resultFile = new ResultFile();
   } catch( IOException e ) { System.out.println( "exception e "+e
); }
}

/** endDispatch - Called when the user has decided to call off this
search.  Closes the results file and notifies the connectionHandler to
kill off any Agents that report in after this point.
*/
public void endDispatch() {
   resultFile.close();
   resultFile = null;
   }




public void MessageBox( String s ) {
  return;
  }

/** showResults -
*/
public void showResults( String s, String urls ) {
}

/** showNoResults -
*/
public void showNoResults( String s ) {
}

/** reportResults - When an Agent sends the result of a search to the
AgentConnectionHandler, the handler calls this to place the results
pointer into the results HTML doc and to visually notify the user that
this server has finished with whatever results.
*/
public void reportResults( Result r ) {
   System.out.println( "reporting results" );
   // If this search has already been cancelled, don't bother.
   if( resultFile == null )
      return;

   if( r.quantity == null )
      showNoResults( r.server );
   else
      showResults( r.server, r.resultURL );
   synchronized( resultFile ) {
      resultFile.println( "<P>" );
      resultFile.println( "Results from server <A HREF=\""+r.resultURL+"\">"+r.server+"</A>");
      resultFile.println( "\tTime elapsed "+r.elapsed+" qty - "+r.quantity+" - price "+r.price);
      if( r.comment != null )
         resultFile.println( "\t"+r.comment );
      }
   }



/** Paint the border surrounding the entire game.  There is no border
around the board itself. */
public void paintBorder( Graphics g ) {
   Color BorderColor = new Color( 5, 5, 5 );
   g.setColor( BorderColor );
   g.drawLine( 0, 50, 400, 50 );
   g.drawLine( 400, 50, 400, 4000 );
   g.drawLine( 0, 4000, 400, 4000 );
   g.drawLine( 0, 50, 0, 4000 );
   }


/** Update the window, erasing things from their old positions and
painting them anew at their current positions. */
public void update(Graphics g) {
   int i;
// System.out.println( "update: g == window.default.graphics = "+g==g.drawSurface.graphics );
// System.out.println( "upd: thread - "+myThread.getName() );
   for( i = 0; i < MAX_ANIMATOR_THREADS; i++ )
      {
//    imageA[i].paint(g);
      }
    }


public void AddToState( String inputLine ) {
   String s = "";
   StringTokenizer st = new StringTokenizer( inputLine,"," );
   try {
      s = st.nextToken();
      }
   catch( NoSuchElementException e ) { System.out.println( "empty line:"+inputLine );
      return;
      }
   if( s == "Agent" )
      setAgentURL( st.nextToken());
   else
      {
      if( s == "Result" )
         {
         try {
            String resultURL = st.nextToken();
            String server = st.nextToken();
            String quantity = st.nextToken();
            String comment = st.nextToken();
            String price = st.nextToken();
            String elapsed = st.nextToken();
            Result r = new Result(resultURL, server, quantity,comment, price, elapsed);
            reportResults(r);
            }
         catch( NoSuchElementException e ) {
            System.out.println( "incomplete state line:"+inputLine);
            return;
            }
         }
      else
         System.out.println( "bad token: "+s);
      }
   }

public void setAgentURL( String s ) {
   System.out.println( "Setting agentURL to "+s);
   }

    public boolean mouseUp(Event evt, int x, int y) {
   System.out.println( "mouseup in applet" );
   repaint();
   return false;
    }
}

   

class AgentButton extends Button {
  String l;
  Applet applet;

   public AgentButton( Applet ap, String label ) {
      super( label );
      l = new String(label);
      applet = ap;
      }

  public boolean action(Event e, Object o) {
     System.out.println( "Action in button at "+e.x+","+e.y );
   return clicked();
     }

  public boolean clicked() {
    System.out.println("superclicked");
    return false;
    }
}

class TestButton extends AgentButton {

   public TestButton( Applet ap ) {
      super( ap, "addanimation" );
      }

   public boolean clicked() {
      System.out.println( "addanimation clicked" );
      AgentLauncher ap = (AgentLauncher)applet;
      ap.addAgentFace("server");
      return true;
      }
}

class AgentListItemDescription {
   public static String header;
   static int maxDescChars = 0;
   static int maxFNameChars = 0;
   static final String separator = new String("          ");
   String Description;
   String FileName;
   public String line;
   static final String fn = new String( "File name" );
   static final String ds = new String( "Description" );

   public AgentListItemDescription( String file, String desc ) {
      FileName = new String( file );
      Description = new String( desc );
      if( FileName.length() > maxDescChars )
         maxDescChars = FileName.length();
      if( Description.length() > maxFNameChars )
         maxFNameChars = Description.length();
      int padlen = maxFNameChars - ds.length();
      String padString = new String( "" );
      if( padlen > 0 ) {
         padlen+=2;
         byte b[] = new byte[padlen];
         for( int i = 0; i < padlen; i++ )
            b[i] = ' ';
         padString = new String( b, 0 );
         }
      header = new String( fn+padString+separator+ds );
      line = new String( FileName+separator+Description );
      System.out.println( "line   = "+line );
      System.out.println( "header = "+header );
   }
}


/** A dialog box that contains ONE string, and ONE button. The
button is an OK button, and the string is an informational
string

*/
class MessageBox extends Dialog {
  Label theLabel;
  Button theButton;
  Panel labelPanel;
  Panel buttonPanel;

/** Constructor, creates a BorderLayout with the string on the
top, and the ok button on the bottom, nothing in the Center.
@param parent The frame, for passing to the Dialog constructor.
@param msg  A string that will be the main 'message' of this
dialog box.
*/
  public MessageBox(Frame parent, String msg) {
   super(parent, "Agent Message", true);
     setLayout(new BorderLayout());
   theLabel = new Label( msg );
     labelPanel = new Panel();
   add( "North", labelPanel );
     labelPanel.add( theLabel );
   theButton = new Button( "Ok" );
     buttonPanel = new Panel();
   add( "South", buttonPanel );
     buttonPanel.add( theButton );
   setResizable(false);
    }

/** Display the dialog. */
  public void ShowAndLayout() {
     layout();
   show();
     }

/** Destroy the dialog if any action happens.
@return true
*/
  public boolean action(Event e, Object o) {
     dispose();
   return true;
   }
}


/** A modal dialog box that allows the user to pick one item
from a Vector of strings.

*/
class PickDialog extends Dialog {
   List l;
   int selectIndex = -1;
   Frame parent;
   Vector agentList;
   Panel ListPanel;
   Panel ButtonPanel;
   Label label;
   String selectedItem = null;
   public boolean bFinished = false;
   AgentLauncher agentLauncher;

/** Constructor, save the frame, AgentLauncher, String Vector
and header string for future use.  The AgentLauncher is used to
callback when the user hits ok.
@param a  An AgentLauncher to call back to when OK is hit
@param  p The parent frame of this dialog, needed for the
Dialog constructor
@param  al  The Vector of Strings that will appear in the list
box for the user to choose from.
@param header The String which will appear as a header OVER the
list of possible choices.
*/
  public PickDialog(AgentLauncher a, Frame p, Vector al, String header) {
   super(p, "Pick an Agent", true);
     parent = p;
   agentList = al;
     label = new Label( header );
   agentLauncher = a;

    // Set up all the graphical elements
    // Split the dialog main panel into three elements, top,
    // bottom and middle, via the BorderLayout.  The top and
    // bottom size themselves according to the preferred sizes
    // of the text on the top and the buttons on the bottom.
    // The Center panel, which the List fills, uses all the
    // space left in the middle.
     setLayout(new BorderLayout());
   add( "North", label );
     ButtonPanel = new Panel();
   add( "South", ButtonPanel );

   l = new List( agentList.size(), false );
   for( int i = 0; i < agentList.size(); i++ )
      l.addItem((String) agentList.elementAt(i) );
   if( agentList.size() > 0 )
      l.select( 0 );
   add( "Center", l );

     Button okbutton = new Button("OK");
   ButtonPanel.add( okbutton );
   Button cancelbutton = new Button( "Cancel" );
   ButtonPanel.add( cancelbutton );
   }

/** Return the String item which was selected from the list by
the user.
@return String  The String item that was selected from the
Vector displayed in the dialog.
*/
  public String getSelected() {
      return( selectedItem );
      }

/** Size the dialog to something appropriate, then make it
non-resizeable so that users don't go resizing it themselves.
*/
  public void ShowAndLayout() {
   show();
   resize( 600, 300 );
   layout();
   setResizable(false);
   }

/** Deal with the user either hitting the OK/Cancel button or
selecting an item from the list.  Shows a nag box if the user
hits ok without an item selected.  Tells the AgentLauncher to
load the class if the user hits OK.
@return false if the user hasn't selected a proper item, false
otherwise.
*/
public boolean action(Event e, Object o) {

   if( e.target instanceof Button )
      {
    // If this is the OK button, deal with it, else return.
    if(((Button)e.target).getLabel().compareTo("OK") == 0 ) {
      selectIndex = l.getSelectedIndex();
      if( selectIndex == -1 )
         {
           MessageBox m =
          new MessageBox( parent,
            "You have to pick something, or hit Cancel");
         m.ShowAndLayout();
         return false;
         }
      else
         {
         selectedItem = new String( l.getSelectedItem());
           agentLauncher.LoadAgentClass( parent, selectedItem );
         }
      }
      }
   bFinished = true;
   dispose();
   return true;
   }
}

class TestButton1 extends AgentButton {

   public TestButton1( Applet ap ) {
      super( ap, "addanimation" );
      }

   public boolean clicked() {
      System.out.println( "addanimation clicked" );
      AgentLauncher ap = (AgentLauncher)applet;
      ap.setRunning( 3 );
      return true;
      }
}

class HelpButton extends AgentButton {
Applet applet;
   public HelpButton( Applet ap ) {
      super( ap, "Help" );
      applet = ap;
      }

   public boolean clicked() {
      return true;
      }
}




/** There is one AgentDispatcher active at any one time.  It
maintains a CONSTANT connection from the AgentLauncher to the
Dispatching AgentServer.

*/
class AgentDispatcher extends Thread {
   Socket s;
   boolean bConnected = false;

   public AgentDispatcher( String ServerName, int port ) {
    setDaemon(true);
      try {
          System.out.println( "Connecting to dispatching AgentServer at "+ServerName+":"+port );
         s = new Socket( InetAddress.getByName(ServerName),port );
         bConnected = true;
         } catch( IOException e )
        {
          System.out.println( "No AgentServer at "+ServerName+":"+port );
      }
   }

/** Dispatch a kill message to all servers telling them to
terminate the named Agent with prejudice.
*/
   public void StopAgent(String id) {
       if( !bConnected ) {
           System.out.println( "Can't StopAgent, not connected." );
           return;
       }
      KillMessage km = new KillMessage(id);
      try { s.getOutputStream().write( km.getMessageBytes()); }
      catch( IOException e )
        { System.out.println( "stop output exception "+e); }
      try { s.close(); }
      catch( IOException e1 )
        { System.out.println( "stop close exception "+e1); }
      }

/** Tell the dispatching agent server to dispatch this agent.
*/
   public void Dispatch( String Name, String ID, Vector Args ) {
       if( !bConnected ) {
           System.out.println( "Can't Dispatch, not connected." );
           return;
       }
      DispatchMessage dm = new DispatchMessage(Name,ID,Args);
      try { s.getOutputStream().write( dm.getMessageBytes()); }
      catch( IOException e )
       { System.out.println( "dispatch out exception "+e); }
      }

/** The main run loop for this thread.  Sits in a loop reading
the socket and processing messages.  The only messages that
should come in over this socket are StartMessage and
ResultsMessage.
*/
   public void run() {
       if( !bConnected ) {
           System.out.println( "Can't run, not connected." );
           return;
       }
      byte buffer[] = new byte[8192];
      while( true ) {
         try {
         int ret;
         if(( ret = s.getInputStream().read( buffer )) != 0 )
            {
            if( ret < 0 )  {
               System.out.println( "connection lost");
               break;
               }
            System.out.println( "read from dispatching AgentServer "+buffer );
            ClientProcess( buffer, ret );
            }
         } catch( IOException e ) {
            System.out.println( "IOexception "+e );
            break;
            }
         }
      try{s.close();}
    catch(Exception e)
        { System.out.println("run close exception "+e);}
      }

/** Parse a message from the dispatching agent server.  Only
valid message types are Start and Results.  Take appropriate
action for each message type, updating the AgentLauncher
display.
*/
  public void ClientProcess( byte b[], int numbytes ) {

  String command;
  int currentOffset = 0;
  String s;
  int messageStart;
  boolean bret = false;

  while( currentOffset != numbytes ) {
   messageStart = currentOffset;
     // Every message starts with 4 bytes of command
   command = new String( b, 0, currentOffset, 4 );
     currentOffset += LoadMessage.PREFIX_SIZE;

   // Followed by 10 bytes ascii length of the whole message
     // including command
   String sLength = new String( b, 0, currentOffset, 10 );
     currentOffset += LoadMessage.LOADLEN_SIZE;

   if( command.compareTo(ResultMessage.RESULT_PREFIX ) == 0 )
      {
        ResultMessage rm = new ResultMessage();
      rm.parse( b, currentOffset );
      AgentLauncher.currentAgentLauncher.reportResult(
             rm.server, rm.theURL);
        }
   else
      {
        if( command.compareTo(StartMessage.START_PREFIX ) == 0 )
           {
         StartMessage sm = new StartMessage();
         sm.parse( b, currentOffset );
         AgentLauncher.currentAgentLauncher.addAgentFace(sm.server);
           }
      else {
         System.out.println( "Message is BOGUS "+b);
        return;
        }
      }
     Integer il = new Integer( sLength );
   currentOffset = messageStart + il.intValue();
     }   // while bytesused
   }
}



