import java.awt.*;
import java.applet.Applet;
import java.net.URL;
import java.net.URLConnection;
import java.net.MalformedURLException;

public class bodyline extends Applet implements Runnable {
    int frameNumber = -1;
    int delay;
    Thread animatorThread;
    boolean frozen = false;
    int st_pic=0;
    Dimension offDimension;
    Image offImage;
    Graphics offGraphics;
    Image[] body=new Image[6];
    Image button;
    int cnt1,cnt2;
    String st;
    int o_sh,sh,cx,cy;
    boolean ok=false;
    Bookmark next_page;

    public void init() {

        //How many milliseconds between frames?
        delay =500;

        //Get the images.
        button=getImage(getDocumentBase(),"http://161.246.6.102/pic/button.jpg");
        for(cnt1=0;cnt1<6;cnt1++){
           st=String.valueOf(cnt1);
           st="http://161.246.6.102/pic/body"+st+".jpg";
           body[cnt1] = getImage(getDocumentBase(),st);
        }
    }

    public void start() {
        if (frozen) {
            //Do nothing.  The user has requested that we
            //stop changing the image.
        } else {
            //Start animating!
            if (animatorThread == null) {
                animatorThread = new Thread(this);
            }
            animatorThread.start();
        }
    }

    public void stop() {
        //Stop the animating thread.
        animatorThread = null;

        //Get rid of the objects necessary for double buffering.
        offGraphics = null;
        offImage = null;
    }

    public boolean mouseDown(Event e, int x, int y) {
        if(frameNumber==0){
           cx=x;
           cy=y;
           if (frozen) {
               frozen = false;
               start();
           } else {
               frozen = true;
               //Instead of calling stop(), which destroys the
               //backbuffer, just stop the animating thread.
               animatorThread = null;
           }
        }
        repaint();
        return true;
    }

    public void run() {
        //Just to be nice, lower this thread's priority
        //so it can't interfere with other processing going on.
        Thread.currentThread().setPriority(Thread.MIN_PRIORITY);
 
        //Remember the starting time.
        long startTime = System.currentTimeMillis();

        //This is the animation loop.
        while (Thread.currentThread() == animatorThread) {
            //Advance the animation frame.
            if(!frozen) frameNumber++;

            //Display it.
            repaint();

            //Delay depending on how far we are behind.
            try {
                startTime += delay;
                Thread.sleep(Math.max(0, 
                                      startTime-System.currentTimeMillis()));
            } catch (InterruptedException e) {
                break;
            }
        }
    }

    public void paint(Graphics g) {
        update(g);
    }

    public void update(Graphics g) {
        Dimension d = size();

        //Create the offscreen graphics context, if no good one exists.
        if ( (offGraphics == null)
          || (d.width != offDimension.width)
          || (d.height != offDimension.height) ) {
            offDimension = d;
            offImage = createImage(d.width, d.height);
            offGraphics = offImage.getGraphics();
        }

        //Erase the previous image.
        offGraphics.setColor(getBackground());
        offGraphics.fillRect(0, 0, d.width, d.height);
        offGraphics.setColor(Color.black);

        //Paint the frame into the image.
        paintFrame(offGraphics);

        //Paint the image onto the screen.
        g.drawImage(offImage, 0, 0, this);
    }

    void paintFrame(Graphics g) {
       ok=false;
       if((cx>=st_pic+338)&&(cx<=st_pic+338+60)){
          if((cy>=10)&&(cy<=45)) sh=0;
          if((cy>=10+50)&&(cy<=45+50)) sh=1;
          if((cy>=10+100)&&(cy<=45+100)) sh=2;
          if((cy>=10+150)&&(cy<=45+150)) sh=3;
          if((cy>=10+200)&&(cy<=45+200)) sh=4;
          if((cy>=10+250)&&(cy<=45+250)) sh=5;
          if((cy>=10+300)&&(cy<=45+300)) ok=true;
       }
       if(ok){
          next_page=new Bookmark("shape"+String.valueOf(sh+1),"http://161.246.6.102/"+String.valueOf(sh+1)+"test.htm");
          LinkTo(next_page.name);
       }
       if(frameNumber>1) frameNumber=0;
       if(sh==o_sh) frameNumber=0;
       showStatus("sh = "+sh+",x = "+cx+",y = "+cy+",frame = "+frameNumber+".");
       if(ok) showStatus("OK. button is pressed.");
       Color bk_color=new Color(255,255,255);
       g.setColor(bk_color);
       g.fillRect(0,0,350,350);
       //image size=260x300
       if((frameNumber % 2)==0){
          g.drawImage(body[sh],st_pic+20,20,this);
          frozen=true;
          o_sh=sh;
       }
       if((frameNumber % 2)==1){
          g.drawImage(body[o_sh],st_pic-130,20,this);
          g.drawImage(body[sh],st_pic+170,20,this);
       }

       //clear the image which over the frame
       g.fillRect(st_pic+303,0,130,350);
       g.fillRect(st_pic,0,3,250);

       //draw frame
       bk_color=new Color(0,0,0);
       g.setColor(bk_color);
       g.drawRect(st_pic+3,3,300,344);

       //draw button
       for(cnt1=0;cnt1<7;cnt1++){
          g.drawImage(button,st_pic+338,10+cnt1*50,this);
       }

       //write button number
       bk_color=new Color(25,25,25);
       g.setColor(bk_color);
       for(cnt1=0;cnt1<6;cnt1++){
          st=st.valueOf(cnt1+1);
          g.drawString(st,st_pic+338+27,cnt1*50+30);
       }
       g.drawString("OK",st_pic+338+22,6*50+30);
    }
    void LinkTo(String name) {
      URL theURL = null;
      theURL = next_page.url;

      if (theURL != null){
	System.out.println("now loading: " + theURL);
	getAppletContext().showDocument(theURL);
      }
    }
}
class Bookmark{
  String name;
  URL url;
   
  Bookmark(String name, String theURL) {
     this.name = name;
     try { this.url = new URL(theURL); }
     catch ( MalformedURLException e) {
	System.out.println("Bad URL: " + theURL);
     }
  }
}
