import java.awt.*;
import java.io.InputStream;
import java.io.DataInputStream;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.net.MalformedURLException;


public class ScoreBoard extends java.applet.Applet implements Runnable
{
  URL theURL;
  Thread runner;
  InputStream conn;
  DataInputStream data;
  String line;
  StringBuffer buf = new StringBuffer();
  int i,j,k;						//for move text
  Font f = new Font("TimesRoman",Font.PLAIN,18); 	//make font object

  public void init()
  {
    setBackground(Color.white);
    String url="file:///C:/PRJ/Demo2/ScoreBoardText.txt";
    try { this.theURL = new URL(url); }
    catch ( MalformedURLException e )
      {
        System.out.println(" Bad URL: "+theURL);
      }
  }

  public void start()
  {
    if (runner == null)
    {
      runner = new Thread(this);
      runner.start();
    }
  }

  public void stop()
  {
    if (runner != null)
    {
      runner.stop();
      runner = null;
    }
  }

  public void run()
  {
    try
    {
      conn = theURL.openStream();
      data = new DataInputStream(new BufferedInputStream(conn));
      i=0;
      while ((line=data.readLine()) != null)
      {
        buf.append(line);
        i=i+510;					//number of moving text in
						//a line, sample is in 
						//"ScoreBoardText.txt"
      }
      conn.close();
      while (true)
      {
        j=i+500;
        k=500;                                                                	//for point at the start point
        while (j>0)					//loop for move message
        {
          repaint();
          --j;
          --k;
        }
      }
    }
    catch (IOException e)
    {
      System.out.println("IO Error: "+ e.getMessage());
    }
  }

  public void paint(Graphics g)
  {
    g.setFont(f);					//set font type
    g.drawString(buf.toString(),k,17);			//type message start at right
    pause(50);					//delay
    g.clearRect(0,0,size().width,size().height);		//clear whole applet once
  }

  void pause(int time)				//method delay time
  {
    try { Thread.sleep(time); }
    catch (InterruptedException e) { }
  }
}