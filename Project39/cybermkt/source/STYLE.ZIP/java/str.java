import java.applet.*;
import java.awt.*;
public class str extends Applet{
   double  d;
   int     cnt;
   public void delay(int dt){
      int cnt1,cnt2;
      for(cnt1=0;cnt1<dt;cnt1++){
         for(cnt2=0;cnt2<5000;cnt2++){
         }
      }
   }
   public void start(){
      for(cnt=0;cnt<360;cnt++){
         d=Math.sin(cnt*Math.PI/180);
         repaint();
         delay(5000);
      }
   }
   public void paint(Graphics g){
      String s;  
      s=String.valueOf(d);
      g.drawString(s,10,10);
      showStatus("sin("+cnt+") = "+s);
   }
}
