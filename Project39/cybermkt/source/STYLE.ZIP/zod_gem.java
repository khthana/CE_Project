import java.awt.*;
import java.net.URL;
import java.net.URLConnection;
import java.net.MalformedURLException;

public class zod_gem extends java.applet.Applet{
    Dimension od;
    Image oi;
    Graphics og;
    int cnt;
    Image point,scroll,indicate;
    Image[] zodi=new Image[12];
    Image[] zodi_pic=new Image[12];
    int tab_rad=120;
    int scr_st=0;
    int app_st=0;
    int ax,bx;
    int cx,cy;
    int scr;    
    int[] px1=new int[12];
    int[] py1=new int[12];
    Button b1;
    Double temp;
    
    Bookmark next_page=new Bookmark("Test","http://style4u.ce.kmitl.ac.th/test.htm");

    public void init() {
                    /*��˹��������������Ѻ graphic component*/
	for(cnt=0;cnt<12;cnt++){
	   temp=new Double((app_st+180)-(tab_rad*Math.cos((cnt*30)*Math.PI/180))-27);
	   px1[cnt]=temp.intValue();
	   temp=new Double(150-(tab_rad*Math.sin((cnt*30)*Math.PI/180))-15);
	   py1[cnt]=temp.intValue();
	}
	scr   =1;
	try { 
	   String st;  
	   for(cnt=0;cnt<12;cnt++){
	      st=String.valueOf(cnt+1);
	      st=st+"sign.gif";
                          st="http://style4u.ce.kmitl.ac.th/pic/"+st;
 	      zodi[cnt]=getImage(new URL(st));
	      
	      st=String.valueOf(cnt+1);
	      st=st+"zodi.gif";
                          st="http://style4u.ce.kmitl.ac.th/pic/"+st;
	      zodi_pic[cnt]=getImage(new URL(st));
	   }
	   point      = getImage(new URL("http://style4u.ce.kmitl.ac.th/pic/point.jpg"));
	   scroll     = getImage(new URL("http://style4u.ce.kmitl.ac.th/pic/scroll.jpg"));
	   indicate   = getImage(new URL("http://style4u.ce.kmitl.ac.th/pic/indicat.jpg"));
	}catch ( MalformedURLException e ){
	   System.out.println("Can't load images");
	}
	b1         = new Button("Ok");
	add(b1);
    }

    public void stop() {
        /*�׹ memory ���Ѻ�к��������ش�������͹���*/ 
             animatorThread = null;
             og = null;
             oi = null;
    }

    public boolean action(Event e,Object arg){
        /*�ӡ�� check  user-input*/ 
       Object target=e.target;
       String s1;
       if (target==b1){
          s1=String.valueOf(scr);
          s1="month"+s1+".html";
          s1="http://style4u.ce.kmitl.ac.th/"+s1;
          next_page=new Bookmark("The gem for month "+String.valueOf(scr),s1);
	  chooselink();
       }
       return true;
    }

    public boolean mouseDown(Event e, int x, int y) {
           /*check ���˹� mouse  ����� mouse �١��  ���� update ˹�Ҩ�*/    
                    /*check ��ҵ��˹���� mouse ���ç������ٻ scroll bar �������*/
	if((y>=300)&&(y<=300+40)){
	   if((x>=scr_st+5)&&(x<=scr_st+45)){
	      if(scr!=1){
		 scr=scr-1;
	      }else{
		 scr=12;
	      }
	   }
	   if((x>=scr_st+305)&&(x<=scr_st+345)){
	      if(scr!=12){
		 scr=scr+1;
	      }else{
		 scr=1;
	      }
	   }
	   repaint();
	}else{
	    if((y>=300)&&(y<=300+40)){
	       if((x>=scr_st+5)&&(x<=scr_st+45)){
		  if(scr!=1){
		    scr=scr-1;
		  }else{
		    scr=9;
		  }
	       }
	       if((x>=scr_st+305)&&(x<=scr_st+345)){
		  if(scr!=9){
		    scr=scr+1;
		  }else{
		    scr=1;
		  }
	       }        
	    }
	    repaint();
	}
	return true;
    }

    public void paint(Graphics g) {
	update(g);
    }

    public void update(Graphics g) {
                    /*���ҧ graphic user interface ���  buffer ������¹ŧ screen*/
	Dimension d = size(); 

	if ( (og==null)||(d.width!=od.width)||(d.height != od.height)){
	    od = d;
	    oi = createImage(d.width, d.height);
	    og = oi.getGraphics();
	}
	Color bk=new Color(255,255,255);
	og.setColor(bk);
	og.fillRect(0, 0, d.width, d.height);
	og.setColor(Color.black);
	paintFrame(og);
	g.drawImage(oi, 0, 0, this);
    }

    void paintFrame(Graphics g) {
                    /*���ҧ graphic user interface ���  buffer ��͹������¹ŧ screen*/
	Dimension d = size();
	int posi;
	int w=d.width;
	int h=d.height;
	g.drawImage(scroll,scr_st,295,this);
	g.drawImage(indicate,scr_st+43+(scr*20),306,this);
	g.drawImage(point,px1[3]-4,py1[3]-3,this);
	for(cnt=0;cnt<12;cnt++){
                         posi=(scr+cnt+8);
                         g.drawImage(zodi[posi],px1[cnt],py1[cnt],this);
	}
	g.drawImage(zodi_pic[scr-1],148,105,this);
	b1.reshape(app_st+153,220,50,20);
    }

    /*�ʴ� http document ����ͧ���*/
    void LinkTo(String name) {
                    URL theURL = null;
                    theURL = next_page.url;
                    if (theURL != null){
                         System.out.println("now loading: " + theURL);
                         getAppletContext().showDocument(theURL);
	}
    }

    void chooselink(){
              LinkTo(next_page.name);
    }

}

/*class ��������ª��㹡���ʴ� http document*/
class Bookmark{
   String name;
   URL url;
   Bookmark(String name, String theURL) {
       this.name = name;
       try { this.url = new URL(theURL); }
       catch ( MalformedURLException e) {
            System.out.println("Bad URL: " + theURL);
       }
   }
}
