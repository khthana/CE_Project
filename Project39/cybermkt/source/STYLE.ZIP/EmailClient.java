import java.applet.Applet;
import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.*;

public class EmailClient extends Applet{
    boolean DEBUG = false;
    boolean already_send=false;
    InetAddress address;
    TextField email,other;
    TextArea comment;
    DatagramSocket socket;
    Choice sex,know_from,age;
    String know_from_st,sex_st,age_st;
    Button send;

    public void init(){
        /*��˹��������������Ѻ����÷������Ǣ�ͧ�Ѻ network                     */
        /*��˹��������������Ѻ graphic user interface components */
        String host = getCodeBase().getHost();
        try {
            address = InetAddress.getByName(host);
        }catch (UnknownHostException e){
            showStatus("Couldn't get Internet address: Unknown host");
        }
        try{
            socket = new DatagramSocket();
        } catch(IOException e){
            showStatus("Couldn't create new DatagramSocket");
            return;
        }
        sex_st=new String("Male");
        age_st=new String("Les than 15  ");
        know_from_st=new String("Friend");
        email=new TextField("Please enter your email-address here.",70);
        add(email);
        send   =new Button("Send");
        add(send);
        sex  =new Choice();
        sex.addItem("Male");
        sex.addItem("Female");
        add(sex);
        know_from=new Choice();
        know_from.addItem("Your Friend");
        know_from.addItem("Email");
        know_from.addItem("News Group");
        know_from.addItem("Publishings");
        know_from.addItem("Search Engine");
        know_from.addItem("Others");
        add(know_from);
        other=new TextField("This for 'Others choice'.");
        add(other);
        other.setEditable(false);
        age=new Choice();
        age.addItem("Les than 15");
        age.addItem("      15-20");
        age.addItem("      21-25");
        age.addItem("More than 25");
        add(age);
        comment=new TextArea("");
        add(comment);
        comment.setEditable(true);
    }

    public void paint(Graphics g) {
         /*���ҧ graphics user interface*/
        Dimension d = size();
        Color bg = getBackground();
        g.setColor(bg);
        g.draw3DRect(0,0,700,200,true);
        g.draw3DRect(3,3,700-7,200-7,false);
        bg=new Color(0,0,0);
        g.setColor(bg);
        /*�ӡ�� check ��� user ��ӡ�á����� send �����ѧ                                               */
        /*��ҡ���������ͧ�ʴ�Ẻ�����㹡���觢������ա���������ʴ���ͤ����ͺ�س      */
        if(!already_send){ 
             /*�ҴẺ�����㹡���觢�����*/
             g.drawString("Your email-address",15,26);
             email.reshape(205,10,375,30);
             g.drawString("Your sex is                 ",15,60);
             sex.reshape(205,44,120,30);
             g.drawString("Your age is                ",15,94);
             age.reshape(205,78,120,30);
             g.drawString("You know this web site from ",15,128);
             know_from.reshape(205,112,120,30);
             other.reshape(330,112,250,30);
             g.drawString("Your comment",15,162);
             comment.reshape(205,146,375,45);
             send.reshape(620,150,60,40);
       }else{
             /*�ʴ���ͤ����ͺ�س*/
             remove(email);
             remove(sex);
             remove(age);
             remove(know_from);
             remove(other);
             remove(comment);
             remove(send);
             g.drawString("Your information has sent already.",255,80);
             g.drawString("              Thank you very much.",255,120);
       }
    }

    void doIt(int port){
        /*�ӡ���觢�����*/ 
        DatagramPacket packet;
        String send_str;
        byte[] sendBuf=new byte[256];
        int long_st;

        /*�á����������㹵���÷���� send bufffer*/
        send_str=email.getText();
        send_str=send_str+"�";
        send_str.getBytes(0,send_str.length(),sendBuf,0);
        long_st=send_str.length();

        send_str=sex_st;
        send_str=send_str+"�";
        send_str.getBytes(0,send_str.length(),sendBuf,long_st);
        long_st=long_st+send_str.length();

        send_str=age_st;
        send_str=send_str+"�";
        send_str.getBytes(0,send_str.length(),sendBuf,long_st);
        long_st=long_st+send_str.length();

        send_str=know_from_st;
        send_str=send_str+"�";
        send_str.getBytes(0,send_str.length(),sendBuf,long_st);
        long_st=long_st+send_str.length();

        send_str=other.getText();
        send_str=send_str+"�";
        send_str.getBytes(0,send_str.length(),sendBuf,long_st);
        long_st=long_st+send_str.length();

        send_str=comment.getText();
        send_str=send_str+"�";
        send_str.getBytes(0,send_str.length(),sendBuf,long_st);

        /*�觢�����*/
        packet = new DatagramPacket(sendBuf,sendBuf.length, address, port);
        try{
           if(DEBUG){
              showStatus("Applet about to send packet to address "+address+" at port "+port);
           }
           socket.send(packet);
           if (DEBUG) {
              showStatus("Applet sent packet.");
           }
        } catch (IOException e) {
           showStatus("Applet socket.send failed:");
           e.printStackTrace();
           return;
        }
    }

    public boolean action(Event event, Object arg) {
        /*�ӡ�� check  user-input*/ 
        int port=0;
        String html_port;
        Object target=event.target;
        if(target==age){
            age_st=(String) arg;
        }
        if(target==send){
           try{
               html_port=getParameter("port");
               port = Integer.parseInt(html_port);
               doIt(port);
               already_send=true;
               repaint();
           }catch(NumberFormatException e){
               showStatus("Invalid parameter 'port'.");
               return true;
           }
        }
        if(target==sex){
           sex_st=(String) arg;
        }
        if(target==know_from){
           know_from_st=(String) arg;
           if(know_from_st!="Others"){
              other.setEditable(false);
           }else{
              other.setEditable(true);
           }
        }
        return true;
    }
}
