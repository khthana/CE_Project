class EmailServer {
    /*���ҧ EmailServerThread()*/
    public static void main(String[] args) {
        new EmailServerThread().start();
    }
}
