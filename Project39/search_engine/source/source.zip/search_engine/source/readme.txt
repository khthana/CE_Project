This component is for windows 95, with the MS Winsock 1.1 installed.

Put the following files in a place where Delphi can find them (the directory
where you keep your own added components and stuff):

WSExtra.pas
MSIcmp.pas
MSPing.pas
MSPing.dcr

Put the help file somewhere where you can access it easily (sorry, no F1
help keyword file yet. I can't seem to get kwgen to work as it should)

Choose 'Install' from the Component menu, and browse to the directory
where you put the files. Choose MSPing.pas (not the other ones) and
click ok, and build the library. This will install two components called
TMSPing and TMSTrace on the component palette.

Also included is an example how to use the components.

Martien Verbruggen
tgtcmv@chem.tue.nl
http://www.tcp.chem.tue.nl/~tgtcmv/

Copyright:	

(c) Copyright Martien Verbruggen, 1996. All Rights Reserved

This component is released as freeware/public domain software. You are
allowed to use this code or parts of it, provided:

- You do not use it in any application or any other distribution that
  has a commercial purpose without prior consent of the author, 
  Martien Verbruggen.
- You credit the author, Martien Verbruggen, for the work he put into
  this component, as well in any help files, printed documentation as in
  any accompanying �readme� files.

In other words: If you plan to make money out of my work, ask me. 
If you use my work, credit me.

Support sharing of code.

