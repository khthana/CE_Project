#include "jlib.h"

long dos_tell (Jfile f)
{
return(dos_seek (f, 0L, 1) );
}

