#include "aascreen.h"

void aa_copy_screen(Vscreen *s, Vscreen *d)
{
i86_wcopy(s->p, d->p, d->psize>>1);
i86_wcopy(s->cmap, d->cmap, (AA_COLORS*3)>>1);
}

void aa_copy_line_screen(Vscreen *s, Vscreen *d)
{
  int i;
  Pixel *p1,*p2;
  p1 = s->p;
  p2 = d->p;
  for (i=0; i<s->h; i+=2)
  {
    i86_bcopy(p1,p2,s->bpr);
    p1 += 2*s->bpr;
    p2 += 2*s->bpr;
  }
}

void aa_clear_screen(Vscreen *vs)
{
i86_wzero(vs->p, vs->psize>>1);
}
