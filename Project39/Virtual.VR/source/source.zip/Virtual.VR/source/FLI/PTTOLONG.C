long i86_ptr_to_long(offset, seg)
unsigned offset, seg;
{
long result;

result = seg;
result <<= 4;
result += offset;
return(result);
}

