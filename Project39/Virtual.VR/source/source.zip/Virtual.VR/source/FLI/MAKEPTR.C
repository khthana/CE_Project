void *i86_make_ptr(void *p)
{
return(p);
}

