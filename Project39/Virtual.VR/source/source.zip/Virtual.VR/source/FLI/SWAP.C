#include <stdio.h>
#include <conio.h>
#include "aafli.h"
void main(int argc,char *argv[])
{
  int ivmode;
  Errval err;

  outp(0x301,0);
  if (argc != 3)
  {
    puts("swap - play fli 2 file by swap frame of file1 & file2.");
    puts("usage : swap file1.fli file2.fli");
    exit(0);
  }
  ivmode = dos_get_vmode();
  dos_set_vmode(0x13);
  if (dos_get_vmode() == 0x13)
  {
    err = fli_play_swap(argv[1],argv[2]);
    outp(0x301,0);
    dos_set_vmode(ivmode);
    if (err < AA_SUCCESS) {
      puts(fli_error_message(err) );
    }
  }
  else
    puts("Not a vga/mcga display");
}
