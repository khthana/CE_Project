#include "jlib.h"


Jfile dos_open (title, mode)
char *title;
int mode;
{
union i86_regs reg;

reg.b.ah = 0x3d;
reg.b.al = mode;
reg.w.dx = i86_ptr_offset(title);
reg.w.ds = i86_ptr_seg(title);
if (i86_sysint(0x21,&reg,&reg)&1)
	return(0);
else
	return(reg.w.ax);
}

