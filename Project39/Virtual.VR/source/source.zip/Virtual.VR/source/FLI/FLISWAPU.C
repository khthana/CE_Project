#include "aafli.h"
#include "aaclock.h"
#include "dos.h"
#include "conio.h"

Errval fli_until_swap(char *fliname1,char *fliname2,
	int speed,
	AAivec until)
{
Jfile ff1,ff2;
Fli_head fhead1,fhead2;
long frame1off1,frame1off2;
int err;
int frame1,frame2;
int loop = 0;
int i;
int cur_frame;
Vscreen *bs1,*bs2;
if ((ff1 = fli_open(fliname1, &fhead1)) < 0)
	return((Errval)ff1);
if ((ff2 = fli_open(fliname2, &fhead2)) < 0)
	return((Errval)ff2);
if ((bs1=aa_alloc_mem_screen()) == NULL)
{
  err = AA_ERR_NOMEM;
  goto OUT;
}
if ((bs2=aa_alloc_mem_screen()) == NULL)
{
  err = AA_ERR_NOMEM;
  goto OUT;
}
cur_frame = 0;
if (!(*until)(cur_frame, (int)fhead1.frame_count, loop))
	goto OUT;
if (!(*until)(cur_frame, (int)fhead2.frame_count, loop))
	goto OUT;
if ((err = fli_next_frame(ff1)) >= AA_SUCCESS)
	{
	frame1off1 = dos_tell (ff1);
	}
  outp(0x301,1);
  aa_copy_screen(&aa_screen,bs1);
if ((err = fli_next_frame(ff2)) >= AA_SUCCESS)
	{
	frame1off2 = dos_tell (ff2);
	}
  outp(0x301,5);
  aa_copy_screen(&aa_screen,bs2);
if (speed < 0)
	speed = fhead1.speed;
speed *= AA_CLOCK_SCALE;
for (;;)
	{
	dos_seek (ff1, frame1off1, DOS_SEEK_START);
	dos_seek (ff2, frame1off2, DOS_SEEK_START);
	for (i=0;i<fhead1.frame_count;i++)
		{
		cur_frame++;
			outp(0x301,1);
			aa_copy_screen(bs1,&aa_screen);
			aa_set_colors(0,256,bs1->cmap);
			outp(0x301,5);
			aa_copy_screen(bs2,&aa_screen);
			aa_set_colors(0,256,bs2->cmap);
			if (!(*until)(cur_frame, (int)fhead1.frame_count, loop))
				goto OUT;
			if (!(*until)(cur_frame, (int)fhead2.frame_count, loop))
				goto OUT;
		outp(0x301,1);
		aa_copy_screen(bs1,&aa_screen);
		aa_set_colors(0,256,bs1->cmap);
		if ((err = fli_next_frame(ff1)) < AA_SUCCESS)
			goto OUT;
		aa_copy_screen(&aa_screen,bs1);
		outp(0x301,5);
		aa_copy_screen(bs2,&aa_screen);
		aa_set_colors(0,256,bs2->cmap);
		if ((err = fli_next_frame(ff2)) < AA_SUCCESS)
			goto OUT;
		aa_copy_screen(&aa_screen,bs2);
		}
	loop++;
	}
OUT:
aa_free_mem_screen(bs1);
aa_free_mem_screen(bs2);
dos_close (ff1);
dos_close (ff2);
return(err);
}