#include "jlib.h"
#include "aafli.h"
#include "aafii.h"

void fli_uncomp(Vscreen *f, Fli_frame *frame, Cbuf *cbuf, Boolean see_colors)
{
int j;
struct fli_chunk *chunk;
Cbuf *cb1;

if (see_colors)
	aa_wait_vblank();
for (j=0;j<frame->chunks;j++)
	{
	chunk = (struct fli_chunk *)cbuf;
	cb1 = (Cbuf *)(chunk+1);
	switch (chunk->type)
		{
		case FLI_COLOR:
			if (see_colors)
				{
				fii_reg_fcuncomp(cb1);
				}
			fii_mem_fcuncomp(cb1,f->cmap);
			break;
		case FLI_LC:
			fii_unlccomp(cb1, f->p);
			break;
		case FLI_BLACK:
			i86_wzero(f->p, 32000);
			break;
		case FLI_BRUN:
			fii_unbrun(cb1, f->p, f->h);
			break;
		case FLI_COPY:
			i86_wcopy(cb1,f->p,32000);
			break;
		}
	cbuf = i86_norm_ptr(cbuf + chunk->size);
	}
}

