#include "aafli.h"

Boolean fli_until_key(int cur_frame, int frame_count, int cur_loop)
{
if (kbhit())
	{
	return(FALSE);
	}
else
	return(TRUE);
}

Errval fli_play_swap(char *fliname1,char *fliname2)
{
return(fli_until_swap(fliname1,fliname2, -1, fli_until_key));
}

