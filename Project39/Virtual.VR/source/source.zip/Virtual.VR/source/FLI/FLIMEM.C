extern void *malloc();

void *aa_malloc(unsigned size)
{
return(malloc(size));
}

aa_free(void *pt)
{
free(pt);
}

