DROP TABLE match_sdogeom;
DROP TABLE match_sdolayer;
DROP TABLE match_sdodim;
DROP TABLE match_sdoindex;

CREATE OR REPLACE TYPE match_geometry AS OBJECT (
	sdo_gid	number(10,0),
	sdo_eseq	number(10,0),
	sdo_etype	number(4,0),
	sdo_seq	number(10,0),
	sdo_x1	number(10,5),
	sdo_y1	number(10,5),

	member procedure setpoint(x1 in number,y1 in number)
--	member procedure deletepoint
)
/

CREATE TABLE match_sdogeom OF match_geometry ;
CREATE TABLE match_sdolayer (
	sdo_ordcnt		number(4,0),
	sdo_level		number(4,0),
	sdo_numtiles 	number(4,0)
);
CREATE TABLE match_sdodim (
	sdo_dimnum		number(4,0),
	sdo_lb		number(4,0),
	sdo_ub		number(4,0),
	sdo_tolerance	number(10,10),
	sdo_dimname		varchar2(10)
);
CREATE TABLE match_sdoindex (
	sdo_gid		number(10,0),
	sdo_groupcode	raw(50),
	sdo_code		raw(50),
	sdo_maxcode		raw(50),
	sdo_meta		raw(50)
);

INSERT INTO match_sdolayer VALUES(2,2,null);
INSERT INTO	match_sdodim VALUES(1,-180,180,0.000000005,'X');
INSERT INTO	match_sdodim VALUES(2,-180,180,0.000000005,'Y');
COMMIT;


CREATE OR REPLACE TYPE BODY match_geometry AS
	member procedure setpoint(x1 in number,y1 in number)
	is
	begin
		update match_sdogeom set sdo_x1 = x1,sdo_y1 = y1
		where sdo_gid = 1;
		if SQL%NOTFOUND then
			insert into match_sdogeom values(1,0,1,0,sdo_x1,sdo_y1);
		end if;
		commit;
	end setpoint;
	
--	member procedure deletepoint	is
--	begin
--		delete from match_sdogeom;
--		commit;
--	end deletepoint;

END;
/
