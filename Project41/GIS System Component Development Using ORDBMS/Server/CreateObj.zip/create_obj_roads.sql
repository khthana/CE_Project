DROP TABLE roads_sdolayer;
DROP TABLE roads_sdogeom;
DROP TABLE roads_sdodim;
DROP TABLE roads_sdoindex;
DROP TABLE roads_attr;
CREATE OR REPLACE TYPE roads_geometry AS OBJECT (
	sdo_gid	number(10,0),
	sdo_eseq	number(10,0),
	sdo_etype	number(4,0),
	sdo_seq	number(10,0),
	sdo_x1	number(10,5),
	sdo_y1	number(10,5),
	sdo_x2	number(10,5),
	sdo_y2	number(10,5),
	
	member procedure add_roads(sdo_gid in number ,sdo_x1 in number,
					sdo_y1 in number , sdo_x2 in number:=null,sdo_y2 in number:=null,sdo_x3 in number:=null,sdo_y3 in number:=null,
                  		sdo_x4 in number:=null,sdo_y4 in number:=null,
					sdo_x5 in number:=null,sdo_y5 in number:=null,
					sdo_x6 in number:=null,sdo_y6 in number:=null,
					sdo_x7 in number:=null,sdo_y7 in number:=null,
					sdo_x8 in number:=null,sdo_y8 in number:=null,
					sdo_x9 in number:=null,sdo_y9 in number:=null,
					sdo_x10 in number:=null,sdo_y10 in number:=null,
					sdo_x11 in number:=null,sdo_y11 in number:=null,
					sdo_x12 in number:=null,sdo_y12 in number:=null,
					sdo_x13 in number:=null,sdo_y13 in number:=null,
					sdo_x14 in number:=null,sdo_y14 in number:=null,
					sdo_x15 in number:=null,sdo_y15 in number:=null,
					sdo_x16 in number:=null,sdo_y16 in number:=null,
					sdo_x17 in number:=null,sdo_y17 in number:=null,
					sdo_x18 in number:=null,sdo_y18 in number:=null,
					sdo_x19 in number:=null,sdo_y19 in number:=null,
					sdo_x20 in number:=null,sdo_y20 in number:=null,
					sdo_x21 in number:=null,sdo_y21 in number:=null,
					sdo_x22 in number:=null,sdo_y22 in number:=null,
					sdo_x23 in number:=null,sdo_y23 in number:=null,
					sdo_x24 in number:=null,sdo_y24 in number:=null,
					sdo_x25 in number:=null,sdo_y25 in number:=null,
					sdo_x26 in number:=null,sdo_y26 in number:=null,
					sdo_x27 in number:=null,sdo_y27 in number:=null,
					sdo_x28 in number:=null,sdo_y28 in number:=null,
					sdo_x29 in number:=null,sdo_y29 in number:=null,
					sdo_x30 in number:=null,sdo_y30 in number:=null,
					sdo_x31 in number:=null,sdo_y31 in number:=null,
					sdo_x32 in number:=null,sdo_y32 in number:=null,
					sdo_x33 in number:=null,sdo_y33 in number:=null,
					sdo_x34 in number:=null,sdo_y34 in number:=null,
					sdo_x35 in number:=null,sdo_y35 in number:=null,
					sdo_x36 in number:=null,sdo_y36 in number:=null,
					sdo_x37 in number:=null,sdo_y37 in number:=null,
					sdo_x38 in number:=null,sdo_y38 in number:=null,
					sdo_x39 in number:=null,sdo_y39 in number:=null,
					sdo_x40 in number:=null,sdo_y40 in number:=null,
					sdo_x41 in number:=null,sdo_y41 in number:=null,
					sdo_x42 in number:=null,sdo_y42 in number:=null,
					sdo_x43 in number:=null,sdo_y43 in number:=null,
					sdo_x44 in number:=null,sdo_y44 in number:=null,
					sdo_x45 in number:=null,sdo_y45 in number:=null,
					sdo_x46 in number:=null,sdo_y46 in number:=null,
					sdo_x47 in number:=null,sdo_y47 in number:=null,
					sdo_x48 in number:=null,sdo_y48 in number:=null,
					sdo_x49 in number:=null,sdo_y49 in number:=null,
					sdo_x50 in number:=null,sdo_y50 in number:=null,
					sdo_x51 in number:=null,sdo_y51 in number:=null,
					sdo_x52 in number:=null,sdo_y52 in number:=null,
					sdo_x53 in number:=null,sdo_y53 in number:=null,
					sdo_x54 in number:=null,sdo_y54 in number:=null,
					sdo_x55 in number:=null,sdo_y55 in number:=null,
					sdo_x56 in number:=null,sdo_y56 in number:=null,
					sdo_x57 in number:=null,sdo_y57 in number:=null,
					sdo_x58 in number:=null,sdo_y58 in number:=null,
					sdo_x59 in number:=null,sdo_y59 in number:=null,
					sdo_x60 in number:=null,sdo_y60 in number:=null,
					sdo_x61 in number:=null,sdo_y61 in number:=null,
     				      sdo_x62 in number:=null,sdo_y62 in number:=null,
					sdo_x63 in number:=null,sdo_y63 in number:=null,
					sdo_x64 in number:=null,sdo_y64 in number:=null,
					sdo_x65 in number:=null,sdo_y65 in number:=null,
					sdo_x66 in number:=null,sdo_y66 in number:=null,
					sdo_x67 in number:=null,sdo_y67 in number:=null,
					sdo_x68 in number:=null,sdo_y68 in number:=null,
					sdo_x69 in number:=null,sdo_y69 in number:=null,
					sdo_x70 in number:=null,sdo_y70 in number:=null,
					sdo_x71 in number:=null,sdo_y71 in number:=null,
					sdo_x72 in number:=null,sdo_y72 in number:=null,
					sdo_x73 in number:=null,sdo_y73 in number:=null,
					sdo_x74 in number:=null,sdo_y74 in number:=null,
					sdo_x75 in number:=null,sdo_y75 in number:=null,
					sdo_x76 in number:=null,sdo_y76 in number:=null,
					sdo_x77 in number:=null,sdo_y77 in number:=null,
					sdo_x78 in number:=null,sdo_y78 in number:=null,
					sdo_x79 in number:=null,sdo_y79 in number:=null,
					sdo_x80 in number:=null,sdo_y80 in number:=null,
					sdo_x81 in number:=null,sdo_y81 in number:=null,
					sdo_x82 in number:=null,sdo_y82 in number:=null,
					sdo_x83 in number:=null,sdo_y83 in number:=null,
					sdo_x84 in number:=null,sdo_y84 in number:=null,
					sdo_x85 in number:=null,sdo_y85 in number:=null,
					sdo_x86 in number:=null,sdo_y86 in number:=null,
					sdo_x87 in number:=null,sdo_y87 in number:=null,
					sdo_x88 in number:=null,sdo_y88 in number:=null,
					sdo_x89 in number:=null,sdo_y89 in number:=null,
					sdo_x90 in number:=null,sdo_y90 in number:=null,
					sdo_x91 in number:=null,sdo_y91 in number:=null,
					sdo_x92 in number:=null,sdo_y92 in number:=null,
					sdo_x93 in number:=null,sdo_y93 in number:=null,
					sdo_x94 in number:=null,sdo_y94 in number:=null,
					sdo_x95 in number:=null,sdo_y95 in number:=null,
					sdo_x96 in number:=null,sdo_y96 in number:=null,
					sdo_x97 in number:=null,sdo_y97 in number:=null,
					sdo_x98 in number:=null,sdo_y98 in number:=null,
					sdo_x99 in number:=null,sdo_y99 in number:=null,
					sdo_x100 in number:=null,sdo_y100 in number:=null,
					sdo_x101 in number:=null,sdo_y101 in number:=null,
					sdo_x102 in number:=null,sdo_y102 in number:=null,
					sdo_x103 in number:=null,sdo_y103 in number:=null,
					sdo_x104 in number:=null,sdo_y104 in number:=null,
					sdo_x105 in number:=null,sdo_y105 in number:=null,
					sdo_x106 in number:=null,sdo_y106 in number:=null,
					sdo_x107 in number:=null,sdo_y107 in number:=null,
					sdo_x108 in number:=null,sdo_y108 in number:=null,
					sdo_x109 in number:=null,sdo_y109 in number:=null,
					sdo_x110 in number:=null,sdo_y110 in number:=null,
					sdo_x111 in number:=null,sdo_y111 in number:=null,
					sdo_x112 in number:=null,sdo_y112 in number:=null,
					sdo_x113 in number:=null,sdo_y113 in number:=null,
					sdo_x114 in number:=null,sdo_y114 in number:=null,
					sdo_x115 in number:=null,sdo_y115 in number:=null,
					sdo_x116 in number:=null,sdo_y116 in number:=null,
					sdo_x117 in number:=null,sdo_y117 in number:=null,
					sdo_x118 in number:=null,sdo_y118 in number:=null,
					sdo_x119 in number:=null,sdo_y119 in number:=null,
					sdo_x120 in number:=null,sdo_y120 in number:=null,
					sdo_x121 in number:=null,sdo_y121 in number:=null,
					sdo_x122 in number:=null,sdo_y122 in number:=null,
					sdo_x123 in number:=null,sdo_y123 in number:=null,
					sdo_x124 in number:=null,sdo_y124 in number:=null,
					sdo_x125 in number:=null,sdo_y125 in number:=null) ,
        member procedure delete_roads(gid number),
        member procedure create_roads,
        member procedure getinfo(found in out number,x in number,y in number,
						rid in out number,rname out varchar2,
						rlength out number,rwidth out number,
						rtype out varchar2),
        member procedure setinfo(rid in number,
					rname in varchar2,
					rlength in number,
					rwidth in number,
					rtype in varchar2),

	member procedure updateinfo(rid in number,
					rname in varchar2,
					rlength in number,
					rwidth in number,
					rtype in varchar2),

	member procedure deleteinfo(rid in number)

)
/

CREATE TABLE roads_sdogeom OF roads_geometry ;
CREATE TABLE roads_attr(
	sdo_gid	number(10,0),
	name		varchar2(30),
	length	number(10,8),
	width		number(10,8),
	type		varchar2(30));

ALTER TABLE roads_attr ADD (UNIQUE ("SDO_GID"));
/

CREATE OR REPLACE TYPE BODY roads_geometry AS
	member procedure add_roads(sdo_gid in number,sdo_x1 in number,
					sdo_y1 in number , sdo_x2 in number:=null,sdo_y2 in number:=null,sdo_x3 in number:=null,sdo_y3 in number:=null,
                  		sdo_x4 in number:=null,sdo_y4 in number:=null,
					sdo_x5 in number:=null,sdo_y5 in number:=null,
					sdo_x6 in number:=null,sdo_y6 in number:=null,
					sdo_x7 in number:=null,sdo_y7 in number:=null,
					sdo_x8 in number:=null,sdo_y8 in number:=null,
					sdo_x9 in number:=null,sdo_y9 in number:=null,
					sdo_x10 in number:=null,sdo_y10 in number:=null,
					sdo_x11 in number:=null,sdo_y11 in number:=null,
					sdo_x12 in number:=null,sdo_y12 in number:=null,
					sdo_x13 in number:=null,sdo_y13 in number:=null,
					sdo_x14 in number:=null,sdo_y14 in number:=null,
					sdo_x15 in number:=null,sdo_y15 in number:=null,
					sdo_x16 in number:=null,sdo_y16 in number:=null,
					sdo_x17 in number:=null,sdo_y17 in number:=null,
					sdo_x18 in number:=null,sdo_y18 in number:=null,
					sdo_x19 in number:=null,sdo_y19 in number:=null,
					sdo_x20 in number:=null,sdo_y20 in number:=null,
					sdo_x21 in number:=null,sdo_y21 in number:=null,
					sdo_x22 in number:=null,sdo_y22 in number:=null,
					sdo_x23 in number:=null,sdo_y23 in number:=null,
					sdo_x24 in number:=null,sdo_y24 in number:=null,
					sdo_x25 in number:=null,sdo_y25 in number:=null,
					sdo_x26 in number:=null,sdo_y26 in number:=null,
					sdo_x27 in number:=null,sdo_y27 in number:=null,
					sdo_x28 in number:=null,sdo_y28 in number:=null,
					sdo_x29 in number:=null,sdo_y29 in number:=null,
					sdo_x30 in number:=null,sdo_y30 in number:=null,
					sdo_x31 in number:=null,sdo_y31 in number:=null,
					sdo_x32 in number:=null,sdo_y32 in number:=null,
					sdo_x33 in number:=null,sdo_y33 in number:=null,
					sdo_x34 in number:=null,sdo_y34 in number:=null,
					sdo_x35 in number:=null,sdo_y35 in number:=null,
					sdo_x36 in number:=null,sdo_y36 in number:=null,
					sdo_x37 in number:=null,sdo_y37 in number:=null,
					sdo_x38 in number:=null,sdo_y38 in number:=null,
					sdo_x39 in number:=null,sdo_y39 in number:=null,
					sdo_x40 in number:=null,sdo_y40 in number:=null,
					sdo_x41 in number:=null,sdo_y41 in number:=null,
					sdo_x42 in number:=null,sdo_y42 in number:=null,
					sdo_x43 in number:=null,sdo_y43 in number:=null,
					sdo_x44 in number:=null,sdo_y44 in number:=null,
					sdo_x45 in number:=null,sdo_y45 in number:=null,
					sdo_x46 in number:=null,sdo_y46 in number:=null,
					sdo_x47 in number:=null,sdo_y47 in number:=null,
					sdo_x48 in number:=null,sdo_y48 in number:=null,
					sdo_x49 in number:=null,sdo_y49 in number:=null,
					sdo_x50 in number:=null,sdo_y50 in number:=null,
					sdo_x51 in number:=null,sdo_y51 in number:=null,
					sdo_x52 in number:=null,sdo_y52 in number:=null,
					sdo_x53 in number:=null,sdo_y53 in number:=null,
					sdo_x54 in number:=null,sdo_y54 in number:=null,
					sdo_x55 in number:=null,sdo_y55 in number:=null,
					sdo_x56 in number:=null,sdo_y56 in number:=null,
					sdo_x57 in number:=null,sdo_y57 in number:=null,
					sdo_x58 in number:=null,sdo_y58 in number:=null,
					sdo_x59 in number:=null,sdo_y59 in number:=null,
					sdo_x60 in number:=null,sdo_y60 in number:=null,
					sdo_x61 in number:=null,sdo_y61 in number:=null,
     				      sdo_x62 in number:=null,sdo_y62 in number:=null,
					sdo_x63 in number:=null,sdo_y63 in number:=null,
					sdo_x64 in number:=null,sdo_y64 in number:=null,
					sdo_x65 in number:=null,sdo_y65 in number:=null,
					sdo_x66 in number:=null,sdo_y66 in number:=null,
					sdo_x67 in number:=null,sdo_y67 in number:=null,
					sdo_x68 in number:=null,sdo_y68 in number:=null,
					sdo_x69 in number:=null,sdo_y69 in number:=null,
					sdo_x70 in number:=null,sdo_y70 in number:=null,
					sdo_x71 in number:=null,sdo_y71 in number:=null,
					sdo_x72 in number:=null,sdo_y72 in number:=null,
					sdo_x73 in number:=null,sdo_y73 in number:=null,
					sdo_x74 in number:=null,sdo_y74 in number:=null,
					sdo_x75 in number:=null,sdo_y75 in number:=null,
					sdo_x76 in number:=null,sdo_y76 in number:=null,
					sdo_x77 in number:=null,sdo_y77 in number:=null,
					sdo_x78 in number:=null,sdo_y78 in number:=null,
					sdo_x79 in number:=null,sdo_y79 in number:=null,
					sdo_x80 in number:=null,sdo_y80 in number:=null,
					sdo_x81 in number:=null,sdo_y81 in number:=null,
					sdo_x82 in number:=null,sdo_y82 in number:=null,
					sdo_x83 in number:=null,sdo_y83 in number:=null,
					sdo_x84 in number:=null,sdo_y84 in number:=null,
					sdo_x85 in number:=null,sdo_y85 in number:=null,
					sdo_x86 in number:=null,sdo_y86 in number:=null,
					sdo_x87 in number:=null,sdo_y87 in number:=null,
					sdo_x88 in number:=null,sdo_y88 in number:=null,
					sdo_x89 in number:=null,sdo_y89 in number:=null,
					sdo_x90 in number:=null,sdo_y90 in number:=null,
					sdo_x91 in number:=null,sdo_y91 in number:=null,
					sdo_x92 in number:=null,sdo_y92 in number:=null,
					sdo_x93 in number:=null,sdo_y93 in number:=null,
					sdo_x94 in number:=null,sdo_y94 in number:=null,
					sdo_x95 in number:=null,sdo_y95 in number:=null,
					sdo_x96 in number:=null,sdo_y96 in number:=null,
					sdo_x97 in number:=null,sdo_y97 in number:=null,
					sdo_x98 in number:=null,sdo_y98 in number:=null,
					sdo_x99 in number:=null,sdo_y99 in number:=null,
					sdo_x100 in number:=null,sdo_y100 in number:=null,
					sdo_x101 in number:=null,sdo_y101 in number:=null,
					sdo_x102 in number:=null,sdo_y102 in number:=null,
					sdo_x103 in number:=null,sdo_y103 in number:=null,
					sdo_x104 in number:=null,sdo_y104 in number:=null,
					sdo_x105 in number:=null,sdo_y105 in number:=null,
					sdo_x106 in number:=null,sdo_y106 in number:=null,
					sdo_x107 in number:=null,sdo_y107 in number:=null,
					sdo_x108 in number:=null,sdo_y108 in number:=null,
					sdo_x109 in number:=null,sdo_y109 in number:=null,
					sdo_x110 in number:=null,sdo_y110 in number:=null,
					sdo_x111 in number:=null,sdo_y111 in number:=null,
					sdo_x112 in number:=null,sdo_y112 in number:=null,
					sdo_x113 in number:=null,sdo_y113 in number:=null,
					sdo_x114 in number:=null,sdo_y114 in number:=null,
					sdo_x115 in number:=null,sdo_y115 in number:=null,
					sdo_x116 in number:=null,sdo_y116 in number:=null,
					sdo_x117 in number:=null,sdo_y117 in number:=null,
					sdo_x118 in number:=null,sdo_y118 in number:=null,
					sdo_x119 in number:=null,sdo_y119 in number:=null,
					sdo_x120 in number:=null,sdo_y120 in number:=null,
					sdo_x121 in number:=null,sdo_y121 in number:=null,
					sdo_x122 in number:=null,sdo_y122 in number:=null,
					sdo_x123 in number:=null,sdo_y123 in number:=null,
					sdo_x124 in number:=null,sdo_y124 in number:=null,
					sdo_x125 in number:=null,sdo_y125 in number:=null)  is
      value number; 
	begin
            value:=sdo_geom.init_element('roads',sdo_gid);
		sdo_geom.add_nodes('roads',sdo_gid,value,3,sdo_x1,sdo_y1,sdo_x2,sdo_y2,sdo_x3,sdo_y3,sdo_x4,sdo_y4,sdo_x5,sdo_y5,sdo_x6,sdo_y6,sdo_x7,sdo_y7,sdo_x8,sdo_y8,sdo_x9,sdo_y9,sdo_x10,sdo_y10,
				   sdo_x11,sdo_y11,sdo_x12,sdo_y12,sdo_x13,sdo_y13,sdo_x14,sdo_y14,sdo_x15,sdo_y15,sdo_x16,sdo_y16,sdo_x17,sdo_y17,sdo_x18,sdo_y18,sdo_x19,sdo_y19,sdo_x20,sdo_y20,
				   sdo_x21,sdo_y21,sdo_x22,sdo_y22,sdo_x23,sdo_y23,sdo_x24,sdo_y24,sdo_x25,sdo_y25,sdo_x26,sdo_y26,sdo_x27,sdo_y27,sdo_x28,sdo_y28,sdo_x29,sdo_y29,sdo_x30,sdo_y30,
				   sdo_x31,sdo_y31,sdo_x32,sdo_y32,sdo_x33,sdo_y33,sdo_x34,sdo_y34,sdo_x35,sdo_y35,sdo_x36,sdo_y36,sdo_x37,sdo_y37,sdo_x38,sdo_y38,sdo_x39,sdo_y39,sdo_x40,sdo_y40,
				   sdo_x41,sdo_y41,sdo_x42,sdo_y42,sdo_x43,sdo_y43,sdo_x44,sdo_y44,sdo_x45,sdo_y45,sdo_x46,sdo_y46,sdo_x47,sdo_y47,sdo_x48,sdo_y48,sdo_x49,sdo_y49,sdo_x50,sdo_y50,
				   sdo_x51,sdo_y51,sdo_x52,sdo_y52,sdo_x53,sdo_y53,sdo_x54,sdo_y54,sdo_x55,sdo_y55,sdo_x56,sdo_y56,sdo_x57,sdo_y57,sdo_x58,sdo_y58,sdo_x59,sdo_y59,sdo_x60,sdo_y60,
				   sdo_x61,sdo_y61,sdo_x62,sdo_y62,sdo_x63,sdo_y63,sdo_x64,sdo_y64,sdo_x65,sdo_y65,sdo_x66,sdo_y66,sdo_x67,sdo_y67,sdo_x68,sdo_y68,sdo_x69,sdo_y69,sdo_x70,sdo_y70,
				   sdo_x71,sdo_y71,sdo_x72,sdo_y72,sdo_x73,sdo_y73,sdo_x74,sdo_y74,sdo_x75,sdo_y75,sdo_x76,sdo_y76,sdo_x77,sdo_y77,sdo_x78,sdo_y78,sdo_x79,sdo_y79,sdo_x80,sdo_y80,
				   sdo_x81,sdo_y81,sdo_x82,sdo_y82,sdo_x83,sdo_y83,sdo_x84,sdo_y84,sdo_x85,sdo_y85,sdo_x86,sdo_y86,sdo_x87,sdo_y87,sdo_x88,sdo_y88,sdo_x89,sdo_y89,sdo_x90,sdo_y90,
				   sdo_x91,sdo_y91,sdo_x92,sdo_y92,sdo_x93,sdo_y93,sdo_x94,sdo_y94,sdo_x95,sdo_y95,sdo_x96,sdo_y96,sdo_x97,sdo_y97,sdo_x98,sdo_y98,sdo_x99,sdo_y99,sdo_x100,sdo_y100,
				   sdo_x101,sdo_y101,sdo_x102,sdo_y102,sdo_x103,sdo_y103,sdo_x104,sdo_y104,sdo_x105,sdo_y105,sdo_x106,sdo_y106,sdo_x107,sdo_y107,sdo_x108,sdo_y108,sdo_x109,sdo_y109,sdo_x110,sdo_y110,
                                   sdo_x121,sdo_y121,sdo_x122,sdo_y122,sdo_x123,sdo_y123,sdo_x124,sdo_y124,sdo_x125,sdo_y125);
	end add_roads;

	member procedure create_roads is
	begin
            create_table('create table roads_sdolayer(
		 sdo_ordcnt   NUMBER(4),
		 sdo_level    NUMBER(4),
		 sdo_numtiles NUMBER(4))');
		
            create_table('create table roads_sdodim(
		 sdo_dimnum    NUMBER(4),
		 sdo_lb        NUMBER(4),
		 sdo_ub        NUMBER(4),
		 sdo_tolerance NUMBER(10,10),
		 sdo_dimname   VARCHAR2(10))');
		
	    create_table('create table roads_sdoindex(
		 sdo_gid       NUMBER(10),
		 sdo_groupcode RAW(50),
		 sdo_code      RAW(50),
		 sdo_maxcode   RAW(50),
		 sdo_meta      RAW(50))');
            insert_table('insert into roads_sdolayer values(4,2,null)');
		insert_table('insert into roads_sdodim values(1,-180,180,0.000005,null)');
		insert_table('insert into roads_sdodim values(2,-180,180,0.000005,null)');
       end create_roads;

      member procedure delete_roads(gid number) is
      begin
           delete from roads_sdogeom
	     where sdo_gid=gid;
      end delete_roads;
	
	member procedure getinfo(found in out number,x in number,y in number,
						rid in out number,rname out varchar2,
						rlength out number,rwidth out number,
						rtype out varchar2) is

	mt	match_geometry;
	CURSOR c1 IS select sdo_gid,name,length,width,type from roads_attr
			 where sdo_geom.relate('match',1,'ANYINTERACT','roads',sdo_gid) = 'TRUE';
	begin
		mt.setpoint(x,y);
		OPEN c1;
		FETCH c1 INTO rid,rname,rlength,rwidth,rtype;
		if c1%FOUND then
			found := 1;
		else 
			found := 0;
		end if;
		CLOSE c1;
	end getinfo;
      
        	member procedure setinfo(rid in number,rname in varchar2,rlength in number,rwidth in number,rtype in varchar2) is
	begin
		INSERT INTO roads_attr VALUES(rid,rname,rlength,rwidth,rtype);
		COMMIT;
	end setInfo;

	member procedure updateinfo(rid in number,rname in varchar2,rlength in number,rwidth in number,rtype in varchar2) is
	begin
		UPDATE roads_attr SET name = rname,
					length = rlength,
					width = rwidth,
					type = rtype 
		WHERE sdo_gid = rid;
		COMMIT;
	end updateinfo;

	member procedure deleteinfo(rid in number) is
	begin
		DELETE FROM roads_attr
		WHERE	sdo_gid = rid;
		COMMIT;
	end deleteinfo;
END;
/