//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "REP_BILL0.h"
#include "Main.h"
#include "REP_BILL_00.h"
#include "inx.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TREP_BILL *REP_BILL;
//---------------------------------------------------------------------------
__fastcall TREP_BILL::TREP_BILL(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TREP_BILL::BitBtn1Click(TObject *Sender)
{
      float temp,temp2,temp3,dec,temp4,temp5;
   // temp1 = dec IK ,temp2 = sum all temp3 = dec no IK
   // temp4 = sum back IK ,temp5 = sum back non IK
   // dec = IK dec,No IK dec
      REP_PRE_BILL->NAME0->Caption    =  NAMES->Text;
      REP_PRE_BILL->ADDRESS0->Caption =  ADDRESSS->Text;
      REP_PRE_BILL->MONTH0->Caption   =  MONTHS->Items->Strings[MONTHS->ItemIndex];
      REP_PRE_BILL->YEAR0->Caption    =  YEARS->Text;
      REP_PRE_BILL->ID0->Caption      =  IDS->Text;
      FIND_NAMEQuery->Close();
      FIND_NAMEQuery->Params->Items[0]->AsString = IDS->Text;
      FIND_NAMEQuery->ExecSQL();
      FIND_NAMEQuery->Open();
      REP_PRE_BILL->FIRSTNAME0->Caption  =  FIRSTNAMES->Text;
      REP_PRE_BILL->LASTNAME0->Caption   =  LASTNAMES->Text;
      REP_BILL->Close();

     // Count back bill IK AND sum it
      SUM_BK_IK->Close();
      SUM_BK_IK->Params->Items[0]->AsString  = IDS->Text;
      SUM_BK_IK->Params->Items[1]->AsInteger = MONTHS->ItemIndex+1;
      SUM_BK_IK->Params->Items[2]->AsString  = YEARS->Text;
      SUM_BK_IK->ExecSQL();
      SUM_BK_IK->Open();
      temp4 = atof(SUMBK_IK->Text.c_str());

     // Count send bill  IK AND sum it
      SUM_IK->Close();
      SUM_IK->Params->Items[0]->AsString  = IDS->Text;
      SUM_IK->Params->Items[1]->AsInteger = MONTHS->ItemIndex+1;
      SUM_IK->Params->Items[2]->AsString  = YEARS->Text;
      SUM_IK->ExecSQL();
      SUM_IK->Open();
      temp = atof(SUM_SE_IK->Text.c_str());
      REP_PRE_BILL->DE->Caption = DEC_PS->Text;
      dec  = atof(DEC_PS->Text.c_str());
      dec  = dec / 100;
      temp = temp - temp4;      // sum ik - dec %
      temp = temp * dec;
      //------------------- FloatToStrF(temp,ffFixed,15,2);
      REP_PRE_BILL->SUM_SE_IK->Caption = FloatToStrF(temp,ffNumber,15,2);
      SUM_IK->Close();

     // Count back bill and NO IK AND sum it
      SUM_BK_NIK->Close();
      SUM_BK_NIK->Params->Items[0]->AsString  = IDS->Text;
      SUM_BK_NIK->Params->Items[1]->AsInteger = MONTHS->ItemIndex+1;
      SUM_BK_NIK->Params->Items[2]->AsString  = YEARS->Text;
      SUM_BK_NIK->ExecSQL();
      SUM_BK_NIK->Open();
      temp5 = atof(SUMBK_NIK->Text.c_str());

     // Count send bill and NO IK AND sum it
      SUM_NIK->Close();
      SUM_NIK->Params->Items[0]->AsString  = IDS->Text;
      SUM_NIK->Params->Items[1]->AsInteger = MONTHS->ItemIndex+1;
      SUM_NIK->Params->Items[2]->AsString  = YEARS->Text;
      SUM_NIK->ExecSQL();
      SUM_NIK->Open();
      REP_PRE_BILL->GS->Caption = DEC_GS->Text;
      temp3 = atof(SUM_NOIK->Text.c_str());
      dec  = atof(DEC_GS->Text.c_str());
      dec  = dec / 100;
      temp3 = temp3 - temp5;        //sum of non ik - dec %
      temp3 = temp3 * dec;          //send to report for no IK dec
      REP_PRE_BILL->SUM_DEC_GS->Caption = FloatToStrF(temp3,ffNumber,15,2);
      SUM_IK->Close();

     // Count send bill
      Count_S->Close();
      Count_S->Params->Items[0]->AsString  = IDS->Text;
      Count_S->Params->Items[1]->AsInteger = MONTHS->ItemIndex+1;
      Count_S->Params->Items[2]->AsString  = YEARS->Text;
      Count_S->ExecSQL();
      Count_S->Open();
      REP_PRE_BILL->COUNT_SEND_TEMP->Caption = COUNT_SE->Text;
      REP_PRE_BILL->TOTAL_SE->Caption = SUM_SE->Text;

     // Count back Bill -------------------------------
      SUM_BACK->Close();
      SUM_BACK->Params->Items[0]->AsString  = IDS->Text;
      SUM_BACK->Params->Items[1]->AsInteger = MONTHS->ItemIndex+1;
      SUM_BACK->Params->Items[2]->AsString  = YEARS->Text;
      SUM_BACK->ExecSQL();
      SUM_BACK->Open();
      REP_PRE_BILL->COUNT_REC->Caption = SUM_BA->Text;
      // ---------Calculate Summary of Report
      SUM_CAL->Close();
      SUM_CAL->Close();
      SUM_CAL->Params->Items[0]->AsString  = IDS->Text;
      SUM_CAL->Params->Items[1]->AsInteger = MONTHS->ItemIndex+1;
      SUM_CAL->Params->Items[2]->AsString  = YEARS->Text;
      SUM_CAL->ExecSQL();
      SUM_CAL->Open();
      temp2 = atof(SUM_SE2->Text.c_str());
      temp  = temp2 - temp - temp3 - temp5 - temp4;
      REP_PRE_BILL->SUM_DEC->Caption = FloatToStrF(temp,ffNumber,15,2);
//------------------------------------------------------------------
//             SECTION DETAIL IN REPORT
//------------------------------------------------------------------
     //============for send Bill save to file "Send.db"
     TTable *myOutPut = new TTable(this);
     TBatchMove *myBatch = new TBatchMove(this);
      SAV_SE_Q->Close();
      SAV_SE_Q->Params->Items[0]->AsString  = IDS->Text;
      SAV_SE_Q->Params->Items[1]->AsInteger = MONTHS->ItemIndex+1;
      SAV_SE_Q->Params->Items[2]->AsString  = YEARS->Text;
      SAV_SE_Q->ExecSQL();
      SAV_SE_Q->Open();
      myOutPut->TableName = "Send.db";
      myBatch->Source = SAV_SE_Q;
      myBatch->Destination = myOutPut;
      myBatch->Mode = batCopy;
      myBatch->Execute();
      SAV_SE_Q->Close();
      delete myOutPut;
      delete myBatch;
    //========For back Bill save to file "Back.db"
      TTable *myOutPut2 = new TTable(this);
      TBatchMove *myBatch2 = new TBatchMove(this);
      SAV_BK_Q->Close();
      SAV_BK_Q->Params->Items[0]->AsString  = IDS->Text;
      SAV_BK_Q->Params->Items[1]->AsInteger = MONTHS->ItemIndex+1;
      SAV_BK_Q->Params->Items[2]->AsString  = YEARS->Text;
      SAV_BK_Q->ExecSQL();
      SAV_BK_Q->Open();
      myOutPut2->TableName = "Back.db";
      myBatch2->Source = SAV_BK_Q;
      myBatch2->Destination = myOutPut2;
      myBatch2->Mode = batCopy;
      myBatch2->Execute();
      SAV_BK_Q->Close();
      delete myOutPut2;
      delete myBatch2;
    // Detail in report
    /*  BILLQuery->Close();
      BILLQuery->Params->Items[0]->AsString  = IDS->Text;
      BILLQuery->Params->Items[1]->AsInteger = MONTHS->ItemIndex+1;
      BILLQuery->Params->Items[2]->AsString  = YEARS->Text;
      BILLQuery->ExecSQL();
      BILLQuery->Open();*/
      Table1->Active = false;
      REP_BILL->Close();
      GEN_REP->Show();
      /*REP_PRE_BILL->BILLREPORT->Preview();*/

}
//---------------------------------------------------------------------------
void __fastcall TREP_BILL::BitBtn2Click(TObject *Sender)
{
      REP_BILL->Close();
}
//---------------------------------------------------------------------------

