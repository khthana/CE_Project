//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("TEST_REPORT.res");
USEFORM("Main.cpp", MainForm);
USEFORM("POP_INSERT.cpp", INSERT_FORM);
USEFORM("POP_DELETE.cpp", DELETE_FORM);
USEFORM("POP_EDIT_EMP.cpp", EDIT_FORM);
USEFORM("REP_EMP_ALL.cpp", REPORT_ALL);
USEFORM("REP_EMP_PRIVATE.cpp", PRIVATE_EMP);
USEFORM("POP_GOODS_IN.cpp", INSERT_GOODS);
USEFORM("POP_GOODS_DELETE.cpp", DELETE_GOODS_FORM);
USEFORM("POP_GOODS_EDIT.cpp", EDIT_GOODS_FORM);
USEFORM("REP_GOODS_ALL.cpp", REPORT_GOODS);
USEFORM("POP_BILL_INSERT.cpp", IN_BILL);
USEFORM("POP_BILL_DELETE.cpp", BILL_DELETE);
USEFORM("POP_BILL_EDIT.cpp", EDIT_BILL);
USEFORM("REP_BILL0.cpp", REP_BILL);
USEFORM("REP_BILL_00.cpp", REP_PRE_BILL);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
    try
    {
        Application->Initialize();
        Application->CreateForm(__classid(TMainForm), &MainForm);
        Application->CreateForm(__classid(TINSERT_FORM), &INSERT_FORM);
        Application->CreateForm(__classid(TDELETE_FORM), &DELETE_FORM);
        Application->CreateForm(__classid(TEDIT_FORM), &EDIT_FORM);
        Application->CreateForm(__classid(TREPORT_ALL), &REPORT_ALL);
        Application->CreateForm(__classid(TPRIVATE_EMP), &PRIVATE_EMP);
        Application->CreateForm(__classid(TINSERT_GOODS), &INSERT_GOODS);
        Application->CreateForm(__classid(TDELETE_GOODS_FORM), &DELETE_GOODS_FORM);
        Application->CreateForm(__classid(TEDIT_GOODS_FORM), &EDIT_GOODS_FORM);
        Application->CreateForm(__classid(TREPORT_GOODS), &REPORT_GOODS);
        Application->CreateForm(__classid(TIN_BILL), &IN_BILL);
        Application->CreateForm(__classid(TBILL_DELETE), &BILL_DELETE);
        Application->CreateForm(__classid(TEDIT_BILL), &EDIT_BILL);
        Application->CreateForm(__classid(TREP_BILL), &REP_BILL);
        Application->CreateForm(__classid(TREP_PRE_BILL), &REP_PRE_BILL);
        Application->Run();
    }
    catch (Exception &exception)
    {
        Application->ShowException(&exception);
    }
    return 0;
}
//---------------------------------------------------------------------------
