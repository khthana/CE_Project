//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "REP_EMP_PRIVATE.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TPRIVATE_EMP *PRIVATE_EMP;
//---------------------------------------------------------------------------
__fastcall TPRIVATE_EMP::TPRIVATE_EMP(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TPRIVATE_EMP::PRI_OKClick(TObject *Sender)
{
      PRIVATE_EMPQuery->Close();
      PRIVATE_EMPQuery->Params->Items[0]->AsString = EDIT1_PRIVATE->Text;
      PRIVATE_EMPQuery->ExecSQL();
      PRIVATE_EMPQuery->Open();
      QuickRep1->Preview();
}
//---------------------------------------------------------------------------
void __fastcall TPRIVATE_EMP::PRI_CANCLEClick(TObject *Sender)
{
       PRIVATE_EMP->Hide();
}
//---------------------------------------------------------------------------
