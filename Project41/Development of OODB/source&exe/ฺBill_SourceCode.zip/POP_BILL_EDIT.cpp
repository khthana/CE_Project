//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "POP_BILL_EDIT.h"
#include "Main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TEDIT_BILL *EDIT_BILL;
//---------------------------------------------------------------------------
__fastcall TEDIT_BILL::TEDIT_BILL(TComponent* Owner)
    : TForm(Owner)
{
    DAY_ED->Text    =   DAY_b->Text;
    YEAR_ED->Text   =   YEAR_b->Text;
    GOODS_ED->Text  =   GOODS_b->Text;
    TOTAL_ED->Text  =   TOTAL_b->Text;

}
//---------------------------------------------------------------------------
void __fastcall TEDIT_BILL::BitBtn1Click(TObject *Sender)
{
   ED_BILLQuery->Close();
   // INSERT VALUE
   ED_BILLQuery->Params->Items[0]->AsString  = GOODS_ED->Text;
   ED_BILLQuery->Params->Items[1]->AsString  = TOTAL_ED->Text;
   ED_BILLQuery->Params->Items[2]->AsString  = DAY_ED->Text;
   ED_BILLQuery->Params->Items[3]->AsString  = YEAR_ED->Text;
   ED_BILLQuery->Params->Items[4]->AsInteger = atoi(DATA_ENTRY->Text.c_str());
   ED_BILLQuery->ExecSQL();
   ED_BILLQuery->Close();
   //Update Screen
   EDIT_BILL->Close();
   MainForm->BILL_SEQuery->SQL->Clear();
   MainForm->BILL_SEQuery->SQL->Add("SELECT *");
   MainForm->BILL_SEQuery->SQL->Add("FROM BILLING Billing");
   MainForm->BILL_SEQuery->SQL->Add("WHERE ID = :ID_ AND MONTH = :MONTH_ AND YEAR = :YEAR_ AND BACK = '��'");
   MainForm->BILL_SEQuery->Params->Items[0]->AsString   = MainForm->ID_SEND->Text;
   MainForm->BILL_SEQuery->Params->Items[1]->AsInteger  = MainForm->MONTH_SEND->ItemIndex+1;
   MainForm->BILL_SEQuery->Params->Items[2]->AsString   = MainForm->YEAR_SEND->Text;
   MainForm->BILL_SEQuery->ExecSQL();
   MainForm->BILL_SEQuery->Active = true;
}
//---------------------------------------------------------------------------
void __fastcall TEDIT_BILL::BitBtn2Click(TObject *Sender)
{
    EDIT_BILL->Close();
}
//---------------------------------------------------------------------------
