//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("BillingSystem.res");
USEFORM("Main.cpp", MainForm);
USEFORM("POP_INSERT.cpp", INSERT_FORM);
USEFORM("POP_DELETE.cpp", DELETE_FORM);
USEFORM("POP_EDIT_EMP.cpp", EDIT_FORM);
USEFORM("EMP_PRI_REPORT.cpp", Form1);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
    try
    {
        Application->Initialize();
        Application->CreateForm(__classid(TMainForm), &MainForm);
        Application->CreateForm(__classid(TINSERT_FORM), &INSERT_FORM);
        Application->CreateForm(__classid(TDELETE_FORM), &DELETE_FORM);
        Application->CreateForm(__classid(TEDIT_FORM), &EDIT_FORM);
        Application->CreateForm(__classid(TForm1), &Form1);
        Application->Run();
    }
    catch (Exception &exception)
    {
        Application->ShowException(&exception);
    }
    return 0;
}
//---------------------------------------------------------------------------
