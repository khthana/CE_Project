//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "POP_BB_DELETE.h"
#include "Main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TBB_DELETE *BB_DELETE;
//---------------------------------------------------------------------------
__fastcall TBB_DELETE::TBB_DELETE(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TBB_DELETE::BitBtn1Click(TObject *Sender)
{
   DELETE_BAQuery->Close();
   // INSERT VALUE
   DELETE_BAQuery->Params->Items[0]->AsInteger =  atoi(DELETE_ENTRY_BILL->Text.c_str());
   DELETE_BAQuery->ExecSQL();
   DELETE_BAQuery->Close();
   BB_DELETE->Close();
 // Update Screen for refresh data new entry*/
   MainForm->BILL_BAQuery->SQL->Clear();
   MainForm->BILL_BAQuery->SQL->Add("SELECT *");
   MainForm->BILL_BAQuery->SQL->Add("FROM BILLING Billing");
   MainForm->BILL_BAQuery->SQL->Add("WHERE ID = :ID_ AND MONTH = :MONTH_ AND YEAR = :YEAR_ AND BACK = '�׹'");
   MainForm->BILL_BAQuery->Params->Items[0]->AsString   = MainForm->ID_BACK->Text;
   MainForm->BILL_BAQuery->Params->Items[1]->AsInteger  = MainForm->MONTH_BACK->ItemIndex+1;
   MainForm->BILL_BAQuery->Params->Items[2]->AsString   = MainForm->YEAR_BACK->Text;
   MainForm->BILL_BAQuery->ExecSQL();
   MainForm->BILL_BAQuery->Active = true;
}
//---------------------------------------------------------------------------
void __fastcall TBB_DELETE::BitBtn2Click(TObject *Sender)
{
   BB_DELETE->Close();
}
//---------------------------------------------------------------------------
