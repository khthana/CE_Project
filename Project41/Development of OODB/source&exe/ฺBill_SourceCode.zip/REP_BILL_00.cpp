//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "REP_BILL_00.h"
#include "REP_BILL0.h"
#include "inx.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TREP_PRE_BILL *REP_PRE_BILL;
//---------------------------------------------------------------------------
__fastcall TREP_PRE_BILL::TREP_PRE_BILL(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------



