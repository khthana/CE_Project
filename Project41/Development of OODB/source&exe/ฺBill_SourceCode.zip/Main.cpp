//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#include <math.h>
#pragma hdrstop

#include "Main.h"
#include "POP_INSERT.h"
#include "POP_DELETE.h"
#include "POP_EDIT_EMP.h"
#include "REP_EMP_ALL.h"
#include "REP_EMP_PRIVATE.h"
#include "POP_GOODS_IN.h"
#include "POP_GOODS_DELETE.h"
#include "POP_GOODS_EDIT.h"
#include "REP_GOODS_ALL.h"
#include "POP_BILL_INSERT.h"
#include "POP_BILL_DELETE.h"
#include "POP_BILL_EDIT.h"
#include "REP_BILL0.h"
#include "POP_BB_INSERT.h"
#include "POP_BB_DELETE.h"
#include "POP_BB_EDIT.h"
#include "POP_DEL_ALL.h"
#include "warning.h"
#include "About.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TMainForm *MainForm;
//---------------------------------------------------------------------------
__fastcall TMainForm::TMainForm(TComponent* Owner)
	: TForm(Owner)
{
}
//----------------------------------------------------------------------------
void __fastcall TMainForm::FormCreate(TObject *Sender)
{
	Application->OnHint = ShowHint;
}
//----------------------------------------------------------------------------
void __fastcall TMainForm::ShowHint(TObject *Sender)
{
	StatusLine->SimpleText = Application->Hint;
}
//----------------------------------------------------------------------------
void __fastcall TMainForm::EditUndo(TObject *Sender)
{
	//---- Add code to perform Edit Undo ----
}
//----------------------------------------------------------------------------
void __fastcall TMainForm::EditCut(TObject *Sender)
{
	//---- Add code to perform Edit Cut ----
}
//----------------------------------------------------------------------------
void __fastcall TMainForm::EditCopy(TObject *Sender)
{
	//--- Add code to perform Edit Copy ----
}
//----------------------------------------------------------------------------
void __fastcall TMainForm::EditPaste(TObject *Sender)
{
	//---- Add code to perform Edit Paste ----
}
//----------------------------------------------------------------------------
void __fastcall TMainForm::HelpContents(TObject *Sender)
{
	Application->HelpCommand(HELP_CONTENTS, 0);
}
//----------------------------------------------------------------------------
void __fastcall TMainForm::HelpSearch(TObject *Sender)
{
	Application->HelpCommand(HELP_PARTIALKEY, Longint(""));
}
//----------------------------------------------------------------------------
void __fastcall TMainForm::HelpHowToUse(TObject *Sender)
{
	Application->HelpCommand(HELP_HELPONHELP, 0);
}
//----------------------------------------------------------------------------
void __fastcall TMainForm::HelpAbout(TObject *Sender)
{
	//---- show program's About Box ----
        Work-> Show();
}
//----------------------------------------------------------------------------





void __fastcall TMainForm::ENDPROGRAMClick(TObject *Sender)
{
     Close();    
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::DISPLAY_BILL_SENDClick(TObject *Sender)
{
  BILL_SEQuery->SQL->Clear();
  BILL_SEQuery->SQL->Add("SELECT *");
  BILL_SEQuery->SQL->Add("FROM BILLING Billing");
  BILL_SEQuery->SQL->Add("WHERE ID = :ID_ AND MONTH = :MONTH_ AND YEAR = :YEAR_ AND BACK = '��'");
  BILL_SEQuery->Params->Items[0]->AsString   = ID_SEND->Text;
  BILL_SEQuery->Params->Items[1]->AsInteger  = MONTH_SEND->ItemIndex+1;
  BILL_SEQuery->Params->Items[2]->AsString   = YEAR_SEND->Text;
  BILL_SEQuery->ExecSQL();
  BILL_SEQuery->Active = true;
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::BitBtn4Click(TObject *Sender)
{
     EMPQuery->Close();
     EMPQuery->SQL->Clear();
     EMPQuery->SQL->Add("SELECT * FROM EMPLOYEE ");
     EMPQuery->SQL->Add("WHERE ID = :ID_");
     EMPQuery->Params->Items[0]->AsString = ID_EMP->Text;
     EMPQuery->ExecSQL();
     EMPQuery->Open();
     DataSource3->DataSet = EMPQuery;
     DBGrid2->DataSource = DataSource3;
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::BitBtn5Click(TObject *Sender)
{
     EMPQuery->Close();
     EMPQuery->SQL->Clear();
     EMPQuery->SQL->Add("SELECT * FROM EMPLOYEE ");
     EMPQuery->SQL->Add("WHERE FIRSTNAME = :FIRSTNAME_");
     EMPQuery->Params->Items[0]->AsString = NAME_EMP->Text;
     EMPQuery->ExecSQL();
     EMPQuery->Open();
     DataSource3->DataSet = EMPQuery;
     DBGrid2->DataSource = DataSource3;
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::BitBtn6Click(TObject *Sender)
{
     EMPQuery->Close();
     EMPQuery->SQL->Clear();
     EMPQuery->SQL->Add("SELECT * FROM EMPLOYEE ");
     EMPQuery->SQL->Add("WHERE LASTNAME = :LASTTNAME_");
     EMPQuery->Params->Items[0]->AsString = LASTNAME_EMP->Text;
     EMPQuery->ExecSQL();
     EMPQuery->Open();
     DataSource3->DataSet = EMPQuery;
     DBGrid2->DataSource = DataSource3;
}
//---------------------------------------------------------------------------



void __fastcall TMainForm::DISPLAY_EMP_ALLClick(TObject *Sender)
{
     EMPQuery->Close();
     EMPQuery->SQL->Clear();
     EMPQuery->SQL->Add("SELECT * FROM EMPLOYEE ");
     EMPQuery->ExecSQL();
     EMPQuery->Open();
     DataSource3->DataSet = EMPQuery;
     DBGrid2->DataSource = DataSource3;
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::INSERT_EMPClick(TObject *Sender)
{
     INSERT_FORM -> Show();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::DELETE_EMPClick(TObject *Sender)
{
     DELETE_FORM -> Show();
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::EDIT_EMPClick(TObject *Sender)
{
  EDIT_FORM->Show();
  EDIT_FORM->EDIT_EMP_ID->Text        = EDIT_FORM->TEMP_EDIT_ID_EMP->Text;
  EDIT_FORM->EDIT_EMP_FIRSTNAME->Text = EDIT_FORM->TEMP_EDIT_FIRSTNAME_EMP->Text;
  EDIT_FORM->EDIT_EMP_LASTNAME->Text  = EDIT_FORM->TEMP_EDIT_LASTNAME_EMP->Text;
  EDIT_FORM->EDIT_EMP_TELEPHONE->Text = EDIT_FORM->TEMP_EDIT_TELEPHONE_EMP->Text;
  EDIT_FORM->EDIT_EMP_INFO->Text      = EDIT_FORM->TEMP_EDIT_INFO_EMP->Text;
}
//---------------------------------------------------------------------------



void __fastcall TMainForm::PRINT_ALL_EMPClick(TObject *Sender)
{
      REPORT_ALL->QuickRep1->Preview();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::PRINT_PRI_EMPClick(TObject *Sender)
{
         PRIVATE_EMP->Show();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::BitBtn8Click(TObject *Sender)
{
       GQuery->Close();
       GQuery->Params->Items[0]->AsString =  GOODS_SEARCH->Text;
       GQuery->ExecSQL();
       GQuery->Open();
       DataSource4->DataSet = GQuery;
       DBGrid3->DataSource =  DataSource4;
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::ALL_GOODSClick(TObject *Sender)
{
      G_DATAQuery->Close();
      G_DATAQuery->SQL->Clear();
      G_DATAQuery->SQL->Add("SELECT * FROM GOODS_INFO ");
      G_DATAQuery->ExecSQL();
      G_DATAQuery->Open();
      DataSource4->DataSet = G_DATAQuery;
      DBGrid3->DataSource = DataSource4;
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::INSERT_GOOD_DATAClick(TObject *Sender)
{
      INSERT_GOODS->Show();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::DELETE_GOODS_DATAClick(TObject *Sender)
{
        DELETE_GOODS_FORM->Show();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::EDIT_GOODS_DATAClick(TObject *Sender)
{
  EDIT_GOODS_FORM->Show();
  EDIT_GOODS_FORM->EDIT_GOODS_GOODS->Text = EDIT_GOODS_FORM->TEMP_EDIT_GOODS_GOODS->Text;
  EDIT_GOODS_FORM->EDIT_GOODS_INFO->Text  = EDIT_GOODS_FORM->TEMP_EDIT_GOODS_INFO->Text;
  EDIT_GOODS_FORM->EDIT_GOODS_PRICE->Text = EDIT_GOODS_FORM->TEMP_EDIT_GOODS_PRICE->Text;
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::PRINT_GOODSClick(TObject *Sender)
{
          REPORT_GOODS->QuickRep1->Preview();
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::BitBtn9Click(TObject *Sender)
{
       NAME->Visible    = true;
       ADDRESS->Visible = true;
       EDIT_PUB_OK->Visible     = true;
       EDIT_PUB_CANCEL->Visible = true;
       EDIT_PUB_NAME->Visible   = true;
       EDIT_ADDRESS->Visible    = true;
       EDIT_PUB_NAME->Text  = NAME_CONFIG->Text;
       EDIT_ADDRESS->Text   = ADDRESS_CONFIG->Text;
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::EDIT_PUB_OKClick(TObject *Sender)
{
   PUBQuery->Close();
   // INSERT VALUE
   PUBQuery->Params->Items[0]->AsString = EDIT_ADDRESS->Text;
   PUBQuery->Params->Items[1]->AsString = EDIT_PUB_NAME->Text;
   PUBQuery->Params->Items[2]->AsString = NAME_CONFIG->Text;
   PUBQuery->ExecSQL();
   PUBQuery->Close();
   NAME->Visible    = false;
   ADDRESS->Visible = false;
   EDIT_PUB_OK->Visible     = false;
   EDIT_PUB_CANCEL->Visible = false;
   EDIT_PUB_NAME->Visible   = false;
   EDIT_ADDRESS->Visible    = false;
   CONFIGURE_TABLE->Active  = false;
   CONFIGURE_TABLE->Active  = true;

}
//---------------------------------------------------------------------------

void __fastcall TMainForm::EDIT_PUB_CANCELClick(TObject *Sender)
{
   NAME->Visible    = false;
   ADDRESS->Visible = false;
   EDIT_PUB_OK->Visible     = false;
   EDIT_PUB_CANCEL->Visible = false;
   EDIT_PUB_NAME->Visible   = false;
   EDIT_ADDRESS->Visible    = false;
   CONFIGURE_TABLE->Active  = false;
   CONFIGURE_TABLE->Active  = true;

}
//---------------------------------------------------------------------------

void __fastcall TMainForm::BitBtn1Click(TObject *Sender)
{
      IN_BILL->ID_TO_IN->Text = ID_SEND->Text;
      IN_BILL->Show();
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::BitBtn2Click(TObject *Sender)
{
      BILL_DELETE->Show();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::BitBtn3Click(TObject *Sender)
{

    EDIT_BILL->DAY_ED->Text    =   EDIT_BILL->DAY_b->Text;
    EDIT_BILL->YEAR_ED->Text   =   EDIT_BILL->YEAR_b->Text;
    EDIT_BILL->GOODS_ED->Text  =   EDIT_BILL->GOODS_b->Text;
    EDIT_BILL->TOTAL_ED->Text  =   EDIT_BILL->TOTAL_b->Text;
    EDIT_BILL->Show();

                         //  ComboBox1->Items->Strings[ComboBox1->ItemIndex];

  }
//---------------------------------------------------------------------------

void __fastcall TMainForm::BitBtn7Click(TObject *Sender)
{
       REP_BILL->Show();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::DISPLAY_BILL_BACKClick(TObject *Sender)
{
  BILL_BAQuery->SQL->Clear();
  BILL_BAQuery->SQL->Add("SELECT *");
  BILL_BAQuery->SQL->Add("FROM BILLING Billing");
  BILL_BAQuery->SQL->Add("WHERE ID = :ID_ AND MONTH = :MONTH_ AND YEAR = :YEAR_ AND BACK = '�׹'");
  BILL_BAQuery->Params->Items[0]->AsString   = ID_BACK->Text;
  BILL_BAQuery->Params->Items[1]->AsInteger  = MONTH_BACK->ItemIndex+1;
  BILL_BAQuery->Params->Items[2]->AsString   = YEAR_BACK->Text;
  BILL_BAQuery->ExecSQL();
  BILL_BAQuery->Active = true;
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::BitBtn10Click(TObject *Sender)
{
        BACK_BILL->ID_TO_IN->Text = ID_BACK->Text;
        BACK_BILL -> Show();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::BitBtn11Click(TObject *Sender)
{
        BB_DELETE -> Show();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::BitBtn12Click(TObject *Sender)
{
     EDIT_BABILL->DAY_ED->Text    =   EDIT_BABILL->DAY_b->Text;
     EDIT_BABILL->YEAR_ED->Text   =   EDIT_BABILL->YEAR_b->Text;
     EDIT_BABILL->GOODS_ED->Text  =   EDIT_BABILL->GOODS_b->Text;
     EDIT_BABILL->TOTAL_ED->Text  =   EDIT_BABILL->TOTAL_b->Text;
     EDIT_BABILL -> Show();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Bill1Click(TObject *Sender)
{
       PageControl1->ActivePage = TabSheet1;
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Bill4Click(TObject *Sender)
{
   PageControl1->ActivePage = TabSheet2; 
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::N4Click(TObject *Sender)
{
    PageControl1->ActivePage = TabSheet3;
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::N5Click(TObject *Sender)
{
     PageControl1->ActivePage = TabSheet4;
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::N6Click(TObject *Sender)
{
     PageControl1->ActivePage = TabSheet5;
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::N31Click(TObject *Sender)
{
     IN_BILL->Show();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::N35Click(TObject *Sender)
{
     REP_BILL->Show();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::N8Click(TObject *Sender)
{
       BACK_BILL -> Show();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::N2Click(TObject *Sender)
{
     PageControl1->ActivePage = TabSheet3;
     EMPQuery->Close();
     EMPQuery->SQL->Clear();
     EMPQuery->SQL->Add("SELECT * FROM EMPLOYEE ");
     EMPQuery->ExecSQL();
     EMPQuery->Open();
     DataSource3->DataSet = EMPQuery;
     DBGrid2->DataSource = DataSource3;
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::N13Click(TObject *Sender)
{
     INSERT_FORM -> Show();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::N16Click(TObject *Sender)
{
      PRIVATE_EMP->Show();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::N17Click(TObject *Sender)
{
      REPORT_ALL->QuickRep1->Preview();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::N9Click(TObject *Sender)
{
      PageControl1->ActivePage = TabSheet4;
      G_DATAQuery->Close();
      G_DATAQuery->SQL->Clear();
      G_DATAQuery->SQL->Add("SELECT * FROM GOODS_INFO ");
      G_DATAQuery->ExecSQL();
      G_DATAQuery->Open();
      DataSource4->DataSet = G_DATAQuery;
      DBGrid3->DataSource = DataSource4;
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::N28Click(TObject *Sender)
{
      REPORT_GOODS->QuickRep1->Preview();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::N19Click(TObject *Sender)
{
      INSERT_GOODS->Show();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::N7Click(TObject *Sender)
{
      PageControl1->ActivePage = TabSheet5;
      NAME->Visible    = true;
      ADDRESS->Visible = true;
      EDIT_PUB_OK->Visible     = true;
      EDIT_PUB_CANCEL->Visible = true;
      EDIT_PUB_NAME->Visible   = true;
      EDIT_ADDRESS->Visible    = true;
      EDIT_PUB_NAME->Text  = NAME_CONFIG->Text;
      EDIT_ADDRESS->Text   = ADDRESS_CONFIG->Text;
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Bill3Click(TObject *Sender)
{
        POP_DEL_CFG->Show();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::N27Click(TObject *Sender)
{
    warn -> Show();
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::BitBtn13Click(TObject *Sender)
{
    PRIVATE_SUM->Close();
    PRIVATE_SUM->Params->Items[0]->AsString   = ID_SUM->Text;
    PRIVATE_SUM->ExecSQL();
    PRIVATE_SUM->Open();
    //-----------------------------PINE CHART FOR SELECT ID
    PRI_GOODS->Close();
    PRI_GOODS->Params->Items[0]->AsString   = ID_SUM->Text;
    PRI_GOODS->ExecSQL();
    PRI_GOODS->Open();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::BitBtn15Click(TObject *Sender)
{
    Close();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::BitBtn14Click(TObject *Sender)
{
        SUM_ALL_GBACK->Close();
        SUM_ALL_GOODS->Close();
        SUM_ALL_GOODS->ExecSQL();
        SUM_ALL_GOODS->Open();
        SUM_ALL_GBACK->ExecSQL();
        SUM_ALL_GBACK->Open();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::BitBtn16Click(TObject *Sender)
{ float tik,tikb,tnik,tnikb,tsum,tdik,tdnik;;
  // tik = temp sum IK send , tikb = temp sum IK back
  // tnik  = temp sum Non IK , tnikb = temp sum non IK back
  // tdik = temp dec % of IK , tdnik = temp dec % of non IK
     DELETE_SUM->Close();
     DELETE_SUM->ExecSQL(); 
     ID_LIST->First();
     while (!ID_LIST->Eof)
      {
       tdik   = atof(DIK->Text.c_str());
       tdik   = (100 - tdik)/100;
       tdnik  = atof(DNIK->Text.c_str());
       tdnik  = (100 - tdnik)/100;
       LIST_NIK->Close();
       LIST_NIK->Params->Items[0]->AsString   = S_ID->Text;
       LIST_NIK->Params->Items[1]->AsInteger  = SCOM_MON->ItemIndex+1;
       LIST_NIK->Params->Items[2]->AsString   = SCOM_YEAR->Text;
       LIST_NIK->ExecSQL();
       LIST_NIK->Open();
       tnik = atof(SUMNIKS->Text.c_str());
     //-----------------------------------------
       LIST_NIKB->Close();
       LIST_NIKB->Params->Items[0]->AsString   = S_ID->Text;
       LIST_NIKB->Params->Items[1]->AsInteger  = SCOM_MON->ItemIndex+1;
       LIST_NIKB->Params->Items[2]->AsString   = SCOM_YEAR->Text;
       LIST_NIKB->ExecSQL();
       LIST_NIKB->Open();
       tnikb = atof(SUMNIKB->Text.c_str());
     //-----------------------------------------
       LIST_IK->Close();
       LIST_IK->Params->Items[0]->AsString   = S_ID->Text;
       LIST_IK->Params->Items[1]->AsInteger  = SCOM_MON->ItemIndex+1;
       LIST_IK->Params->Items[2]->AsString   = SCOM_YEAR->Text;
       LIST_IK->ExecSQL();
       LIST_IK->Open();
       tik = atof(SUMIKS->Text.c_str());
     //-----------------------------------------
       LIST_IKB->Close();
       LIST_IKB->Params->Items[0]->AsString   = S_ID->Text;
       LIST_IKB->Params->Items[1]->AsInteger  = SCOM_MON->ItemIndex+1;
       LIST_IKB->Params->Items[2]->AsString   = SCOM_YEAR->Text;
       LIST_IKB->ExecSQL();
       LIST_IKB->Open();
       tikb = atof(SUMIKB->Text.c_str());
      //-----------------------------------------
       tnik = tnik - tnikb;
       tnik = tnik * tdnik;
       tik  = tik - tikb;
       tik  = tik * tdik;
       tsum = tik+tnik;
       SUMMER->Text = FloatToStrF(tsum,ffNumber,15,2);
     //--------------------INSERT VALUE TO TABLE SUMEMP
       IN_SUM->Close();
       IN_SUM->Params->Items[0]->AsString  = S_ID->Text;
       IN_SUM->Params->Items[1]->AsString  = S_FIRST->Text;
       IN_SUM->Params->Items[2]->AsFloat   = tsum;
       IN_SUM->Params->Items[3]->AsInteger = SCOM_MON->ItemIndex+1;
       IN_SUM->Params->Items[4]->AsString  = SCOM_YEAR->Text;
       IN_SUM->ExecSQL();
       IN_SUM->Close();
       ID_LIST->MoveBy(1);
      }
      SHOW_ALL->Close();
      SHOW_ALL->ExecSQL();
      SHOW_ALL->Open();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::BitBtn17Click(TObject *Sender)
{
        SUM_ALL_BK->Close();
        SUM_ALL_EMP->Close();
        SUM_ALL_BK->ExecSQL();
        SUM_ALL_BK->Open();
        SUM_ALL_EMP->ExecSQL();
        SUM_ALL_EMP->Open();
}
//---------------------------------------------------------------------------

