//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "POP_DELETE.h"
#include "Main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TDELETE_FORM *DELETE_FORM;
//---------------------------------------------------------------------------
__fastcall TDELETE_FORM::TDELETE_FORM(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TDELETE_FORM::BitBtn1Click(TObject *Sender)
{
   DELETEQuery_EMP->Close();
   // INSERT VALUE
   DELETEQuery_EMP->Params->Items[0]->AsString = DELETE_EMP_ID->Text;
   DELETEQuery_EMP->ExecSQL();
   DELETEQuery_EMP->Close();
   DELETE_FORM->Close();
 // Update Screen for refresh data new entry
   MainForm->EMPQuery->Close();
   MainForm->EMPQuery->SQL->Clear();
   MainForm->EMPQuery->SQL->Add("SELECT * FROM EMPLOYEE ");
   MainForm->EMPQuery->ExecSQL();
   MainForm->EMPQuery->Open();
}
//---------------------------------------------------------------------------
void __fastcall TDELETE_FORM::BitBtn2Click(TObject *Sender)
{
     DELETE_FORM->Close();
}
//---------------------------------------------------------------------------
