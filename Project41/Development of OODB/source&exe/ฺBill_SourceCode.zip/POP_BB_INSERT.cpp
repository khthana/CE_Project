//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "POP_BB_INSERT.h"
#include "Main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TBACK_BILL *BACK_BILL;
//---------------------------------------------------------------------------
__fastcall TBACK_BILL::TBACK_BILL(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TBACK_BILL::BitBtn1Click(TObject *Sender)
{
   BBILLQuery->Close();
   // INSERT VALUE
   BBILLQuery->Params->Items[0]->AsInteger =  atoi(ENTRY_CONFIG->Text.c_str());
   UP_ENTRYQuery->Close();
   UP_ENTRYQuery->Params->Items[0]->AsInteger = (1+atoi(ENTRY_CONFIG->Text.c_str()));
   UP_ENTRYQuery->Params->Items[1]->AsInteger = atoi(ENTRY_CONFIG->Text.c_str());
   UP_ENTRYQuery->ExecSQL();
   UP_ENTRYQuery->Close();
   MainForm->CONFIGURE_TABLE->Active = false;
   MainForm->CONFIGURE_TABLE->Active = true;
   BBILLQuery->Params->Items[1]->AsString  = ID_TO_IN->Text;
   BBILLQuery->Params->Items[2]->AsString  = GOODSBILL->Text;
   BBILLQuery->Params->Items[3]->AsFloat   = atof(TOTALBILL->Text.c_str());
   BBILLQuery->Params->Items[4]->AsString  = BACK_B->Text;
   BBILLQuery->Params->Items[5]->AsString  = DAYBILL->Text;
   BBILLQuery->Params->Items[6]->AsInteger = MONTHBILL->ItemIndex+1;
   BBILLQuery->Params->Items[7]->AsString  = YEARBILL->Text;
   BBILLQuery->ExecSQL();
   BBILLQuery->Close();
   BACK_BILL->Close();
 // Update Screen for refresh data new entry*/
   MainForm->BILL_BAQuery->SQL->Clear();
   MainForm->BILL_BAQuery->SQL->Add("SELECT *");
   MainForm->BILL_BAQuery->SQL->Add("FROM BILLING Billing");
   MainForm->BILL_BAQuery->SQL->Add("WHERE ID = :ID_ AND MONTH = :MONTH_ AND YEAR = :YEAR_ AND BACK = '�׹'");
   MainForm->BILL_BAQuery->Params->Items[0]->AsString   = ID_TO_IN->Text;
   MainForm->BILL_BAQuery->Params->Items[1]->AsInteger  = MONTHBILL->ItemIndex+1;
   MainForm->BILL_BAQuery->Params->Items[2]->AsString   = YEARBILL->Text;
   MainForm->BILL_BAQuery->ExecSQL();
   MainForm->BILL_BAQuery->Active = true;
}
//---------------------------------------------------------------------------

void __fastcall TBACK_BILL::BitBtn2Click(TObject *Sender)
{
     BACK_BILL->Close();
}
//---------------------------------------------------------------------------



