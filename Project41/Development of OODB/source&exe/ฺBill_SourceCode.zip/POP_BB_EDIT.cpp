//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "POP_BB_EDIT.h"
#include "Main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TEDIT_BABILL *EDIT_BABILL;
//---------------------------------------------------------------------------
__fastcall TEDIT_BABILL::TEDIT_BABILL(TComponent* Owner)
    : TForm(Owner)
{
    DAY_ED->Text    =   DAY_b->Text;
    YEAR_ED->Text   =   YEAR_b->Text;
    GOODS_ED->Text  =   GOODS_b->Text;
    TOTAL_ED->Text  =   TOTAL_b->Text;

}
//---------------------------------------------------------------------------
void __fastcall TEDIT_BABILL::BitBtn1Click(TObject *Sender)
{
   ED_BBQuery->Close();
   // INSERT VALUE
   ED_BBQuery->Params->Items[0]->AsString  = GOODS_ED->Text;
   ED_BBQuery->Params->Items[1]->AsString  = TOTAL_ED->Text;
   ED_BBQuery->Params->Items[2]->AsString  = DAY_ED->Text;
   ED_BBQuery->Params->Items[3]->AsString  = YEAR_ED->Text;
   ED_BBQuery->Params->Items[4]->AsInteger = atoi(DATA_ENTRY->Text.c_str());
   ED_BBQuery->ExecSQL();
   ED_BBQuery->Close();
   //Update Screen
   EDIT_BABILL->Close();
   MainForm->BILL_BAQuery->SQL->Clear();
   MainForm->BILL_BAQuery->SQL->Add("SELECT *");
   MainForm->BILL_BAQuery->SQL->Add("FROM BILLING Billing");
   MainForm->BILL_BAQuery->SQL->Add("WHERE ID = :ID_ AND MONTH = :MONTH_ AND YEAR = :YEAR_ AND BACK = '�׹'");
   MainForm->BILL_BAQuery->Params->Items[0]->AsString   = MainForm->ID_BACK->Text;
   MainForm->BILL_BAQuery->Params->Items[1]->AsInteger  = MainForm->MONTH_BACK->ItemIndex+1;
   MainForm->BILL_BAQuery->Params->Items[2]->AsString   = MainForm->YEAR_BACK->Text;
   MainForm->BILL_BAQuery->ExecSQL();
   MainForm->BILL_BAQuery->Active = true;
}
//---------------------------------------------------------------------------
void __fastcall TEDIT_BABILL::BitBtn2Click(TObject *Sender)
{
    EDIT_BABILL->Close();
}
//---------------------------------------------------------------------------
