//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "POP_DEL_ALL.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TPOP_DEL_CFG *POP_DEL_CFG;
//---------------------------------------------------------------------------
__fastcall TPOP_DEL_CFG::TPOP_DEL_CFG(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TPOP_DEL_CFG::POP_DELClick(TObject *Sender)
{
        DEL_ALL->Close();
        DEL_ALL->ExecSQL();
        DEL_ALL->Close();
        DEL_ENTRY->Close();
        DEL_ENTRY->ExecSQL();
        DEL_ENTRY->Close();
        DEL_ALL->SQL->Clear();
        DEL_ALL->SQL->Add("DELETE FROM BILLING");
        DEL_ALL->ExecSQL();
        DEL_ALL->Close();
        POP_DEL_CFG->Close();

}
//---------------------------------------------------------------------------

void __fastcall TPOP_DEL_CFG::BitBtn2Click(TObject *Sender)
{
      POP_DEL_CFG->Close();
}
//---------------------------------------------------------------------------
