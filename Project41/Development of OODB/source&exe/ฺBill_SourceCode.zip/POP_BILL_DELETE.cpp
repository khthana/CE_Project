//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "POP_BILL_DELETE.h"
#include "Main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TBILL_DELETE *BILL_DELETE;
//---------------------------------------------------------------------------
__fastcall TBILL_DELETE::TBILL_DELETE(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TBILL_DELETE::BitBtn1Click(TObject *Sender)
{
   DELETE_BILLQuery->Close();
   // INSERT VALUE
   DELETE_BILLQuery->Params->Items[0]->AsInteger =  atoi(DELETE_ENTRY_BILL->Text.c_str());
   DELETE_BILLQuery->ExecSQL();
   DELETE_BILLQuery->Close();
   BILL_DELETE->Close();
 // Update Screen for refresh data new entry*/
   MainForm->BILL_SEQuery->SQL->Clear();
   MainForm->BILL_SEQuery->SQL->Add("SELECT *");
   MainForm->BILL_SEQuery->SQL->Add("FROM BILLING Billing");
   MainForm->BILL_SEQuery->SQL->Add("WHERE ID = :ID_ AND MONTH = :MONTH_ AND YEAR = :YEAR_ AND BACK = '��'");
   MainForm->BILL_SEQuery->Params->Items[0]->AsString   = MainForm->ID_SEND->Text;
   MainForm->BILL_SEQuery->Params->Items[1]->AsInteger  = MainForm->MONTH_SEND->ItemIndex+1;
   MainForm->BILL_SEQuery->Params->Items[2]->AsString   = MainForm->YEAR_SEND->Text;
   MainForm->BILL_SEQuery->ExecSQL();
   MainForm->BILL_SEQuery->Active = true;
}
//---------------------------------------------------------------------------
void __fastcall TBILL_DELETE::BitBtn2Click(TObject *Sender)
{
   BILL_DELETE->Close();
}
//---------------------------------------------------------------------------
