//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "POP_BILL_INSERT.h"
#include "Main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TIN_BILL *IN_BILL;
//---------------------------------------------------------------------------
__fastcall TIN_BILL::TIN_BILL(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TIN_BILL::BitBtn1Click(TObject *Sender)
{
   IN_BILLQuery->Close();
   // INSERT VALUE
   IN_BILLQuery->Params->Items[0]->AsInteger =  atoi(ENTRY_CONFIG->Text.c_str());
   UP_ENTRYQuery->Close();
   UP_ENTRYQuery->Params->Items[0]->AsInteger = (1+atoi(ENTRY_CONFIG->Text.c_str()));
   UP_ENTRYQuery->Params->Items[1]->AsInteger = atoi(ENTRY_CONFIG->Text.c_str());
   UP_ENTRYQuery->ExecSQL();
   UP_ENTRYQuery->Close();
   MainForm->CONFIGURE_TABLE->Active = false;
   MainForm->CONFIGURE_TABLE->Active = true;
   IN_BILLQuery->Params->Items[1]->AsString  = ID_TO_IN->Text;
   IN_BILLQuery->Params->Items[2]->AsString  = GOODSBILL->Text;
   IN_BILLQuery->Params->Items[3]->AsFloat   = atof(TOTALBILL->Text.c_str());
   IN_BILLQuery->Params->Items[4]->AsString  = BACK_B->Text;
   IN_BILLQuery->Params->Items[5]->AsString  = DAYBILL->Text;
   IN_BILLQuery->Params->Items[6]->AsInteger = MONTHBILL->ItemIndex+1;
   IN_BILLQuery->Params->Items[7]->AsString  = YEARBILL->Text;
   IN_BILLQuery->ExecSQL();
   IN_BILLQuery->Close();
   IN_BILL->Close();
 // Update Screen for refresh data new entry*/
   MainForm->BILL_SEQuery->SQL->Clear();
   MainForm->BILL_SEQuery->SQL->Add("SELECT *");
   MainForm->BILL_SEQuery->SQL->Add("FROM BILLING Billing");
   MainForm->BILL_SEQuery->SQL->Add("WHERE ID = :ID_ AND MONTH = :MONTH_ AND YEAR = :YEAR_ AND BACK = '��' ");
   MainForm->BILL_SEQuery->Params->Items[0]->AsString   = MainForm->ID_SEND->Text;
   MainForm->BILL_SEQuery->Params->Items[1]->AsInteger  = MainForm->MONTH_SEND->ItemIndex+1;
   MainForm->BILL_SEQuery->Params->Items[2]->AsString   = MainForm->YEAR_SEND->Text;
   MainForm->BILL_SEQuery->ExecSQL();
   MainForm->BILL_SEQuery->Active = true;
}
//---------------------------------------------------------------------------

void __fastcall TIN_BILL::BitBtn2Click(TObject *Sender)
{
     IN_BILL->Close();
}
//---------------------------------------------------------------------------



