//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "POP_GOODS_IN.h"
#include "Main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TINSERT_GOODS *INSERT_GOODS;
//---------------------------------------------------------------------------
__fastcall TINSERT_GOODS::TINSERT_GOODS(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TINSERT_GOODS::BitBtn1Click(TObject *Sender)
{
   INQuery->Close();
   // INSERT VALUE
   INQuery->Params->Items[0]->AsString = GOODS_IN->Text;
   INQuery->Params->Items[1]->AsString = GOODS_INFO->Text;
   INQuery->Params->Items[2]->AsFloat = atof(GOODS_PRICE->Text.c_str());
   INQuery->ExecSQL();
   INQuery->Close();
   INSERT_GOODS->Close();
 // Update Screen for refresh data new entry
   MainForm->G_DATAQuery->Close();
   MainForm->G_DATAQuery->SQL->Clear();
   MainForm->G_DATAQuery->SQL->Add("SELECT * FROM GOODS_INFO ");
   MainForm->G_DATAQuery->ExecSQL();
   MainForm->G_DATAQuery->Open();
   MainForm->DataSource4->DataSet = MainForm->G_DATAQuery;
   MainForm->DBGrid3->DataSource = MainForm->DataSource4;
 }
//---------------------------------------------------------------------------
void __fastcall TINSERT_GOODS::BitBtn2Click(TObject *Sender)
{
         INSERT_GOODS->Close();
}
//---------------------------------------------------------------------------

