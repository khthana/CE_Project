//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "POP_GOODS_EDIT.h"
#include "Main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TEDIT_GOODS_FORM *EDIT_GOODS_FORM;
//---------------------------------------------------------------------------
__fastcall TEDIT_GOODS_FORM::TEDIT_GOODS_FORM(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TEDIT_GOODS_FORM::BitBtn2Click(TObject *Sender)
{
         EDIT_GOODS_FORM -> Close();
}
//---------------------------------------------------------------------------
void __fastcall TEDIT_GOODS_FORM::BitBtn1Click(TObject *Sender)
{
   EDIT_GQuery->Close();
   // INSERT VALUE
   EDIT_GQuery->Params->Items[0]->AsString = EDIT_GOODS_GOODS->Text;
   EDIT_GQuery->Params->Items[1]->AsString = EDIT_GOODS_INFO->Text;
   EDIT_GQuery->Params->Items[2]->AsFloat  = atof(EDIT_GOODS_PRICE->Text.c_str());
   EDIT_GQuery->Params->Items[3]->AsString = TEMP_EDIT_GOODS_GOODS->Text;
   EDIT_GQuery->ExecSQL();
   EDIT_GQuery->Close();
   EDIT_GOODS_FORM->Close();
 // Update Screen for refresh data new entry
   MainForm->G_DATAQuery->Close();
   MainForm->G_DATAQuery->SQL->Clear();
   MainForm->G_DATAQuery->SQL->Add("SELECT * FROM GOODS_INFO ");
   MainForm->G_DATAQuery->ExecSQL();
   MainForm->G_DATAQuery->Open();
   MainForm->DataSource4->DataSet = MainForm->G_DATAQuery;
   MainForm->DBGrid3->DataSource = MainForm->DataSource4;
}
//---------------------------------------------------------------------------
