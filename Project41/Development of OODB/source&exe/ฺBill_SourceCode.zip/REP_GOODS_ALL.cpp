//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "REP_GOODS_ALL.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TREPORT_GOODS *REPORT_GOODS;
//---------------------------------------------------------------------------
__fastcall TREPORT_GOODS::TREPORT_GOODS(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
