//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "REP_EMP_ALL.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TREPORT_ALL *REPORT_ALL;
//---------------------------------------------------------------------------
__fastcall TREPORT_ALL::TREPORT_ALL(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
