//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "POP_GOODS_DELETE.h"
#include "Main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TDELETE_GOODS_FORM *DELETE_GOODS_FORM;
//---------------------------------------------------------------------------
__fastcall TDELETE_GOODS_FORM::TDELETE_GOODS_FORM(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TDELETE_GOODS_FORM::BitBtn1Click(TObject *Sender)
{
   DEQuery->Close();
   // INSERT VALUE
   DEQuery->Params->Items[0]->AsString = GOODS_DE->Text;
   DEQuery->ExecSQL();
   DEQuery->Close();
   DELETE_GOODS_FORM->Close();
 // Update Screen for refresh data new entry
   MainForm->G_DATAQuery->Close();
   MainForm->G_DATAQuery->SQL->Clear();
   MainForm->G_DATAQuery->SQL->Add("SELECT * FROM GOODS_INFO ");
   MainForm->G_DATAQuery->ExecSQL();
   MainForm->G_DATAQuery->Open();
   MainForm->DataSource4->DataSet = MainForm->G_DATAQuery;
   MainForm->DBGrid3->DataSource = MainForm->DataSource4;
}
//---------------------------------------------------------------------------
void __fastcall TDELETE_GOODS_FORM::BitBtn2Click(TObject *Sender)
{
     DELETE_GOODS_FORM->Close();
}
//---------------------------------------------------------------------------
