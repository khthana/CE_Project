//---------------------------------------------------------------------------
#include <vcl.h>
#include <stdlib.h>
#pragma hdrstop

#include "Sort_Result.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button1Click(TObject *Sender)
{     char str[5];
      int x,y;
     // for (int i = 0; i < Table1->IndexFieldCount; i++)
      x = 5; 
      Edit1->Text = itoa(x,str,10);

}
//---------------------------------------------------------------------------

