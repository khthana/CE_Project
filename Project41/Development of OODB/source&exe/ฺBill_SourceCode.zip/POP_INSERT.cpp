//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "POP_INSERT.h"
#include "Main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TINSERT_FORM *INSERT_FORM;
//---------------------------------------------------------------------------
__fastcall TINSERT_FORM::TINSERT_FORM(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TINSERT_FORM::INSERT_EMP_OKClick(TObject *Sender)
{
   INSERTQuery_EMP->Close();
   // INSERT VALUE
   INSERTQuery_EMP->Params->Items[0]->AsString = INSERT_EMP_ID->Text;
   INSERTQuery_EMP->Params->Items[1]->AsString = INSERT_EMP_NAME->Text;
   INSERTQuery_EMP->Params->Items[2]->AsString = INSERT_EMP_LASTNAME->Text;
   INSERTQuery_EMP->Params->Items[3]->AsString = INSERT_EMP_TELEPHONE->Text;
   INSERTQuery_EMP->Params->Items[4]->AsString = INSERT_EMP_INFO->Text;
   INSERTQuery_EMP->ExecSQL();
   INSERTQuery_EMP->Close();
   INSERT_FORM->Close();
 // Update Screen for refresh data new entry
   MainForm->EMPQuery->Close();
   MainForm->EMPQuery->SQL->Clear();
   MainForm->EMPQuery->SQL->Add("SELECT * FROM EMPLOYEE ");
   MainForm->EMPQuery->ExecSQL();
   MainForm->EMPQuery->Open();
}
//---------------------------------------------------------------------------
void __fastcall TINSERT_FORM::INSERT_EMP_CANCELClick(TObject *Sender)
{
        INSERT_FORM->Close();
}
//---------------------------------------------------------------------------
