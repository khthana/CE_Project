//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "POP_EDIT_EMP.h"
#include "Main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TEDIT_FORM *EDIT_FORM;
//---------------------------------------------------------------------------
__fastcall TEDIT_FORM::TEDIT_FORM(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TEDIT_FORM::BitBtn1Click(TObject *Sender)
{
   EDITQuery_EMP->Close();
   // INSERT VALUE
   EDITQuery_EMP->Params->Items[0]->AsString = EDIT_EMP_ID->Text;
   EDITQuery_EMP->Params->Items[1]->AsString = EDIT_EMP_FIRSTNAME->Text;
   EDITQuery_EMP->Params->Items[2]->AsString = EDIT_EMP_LASTNAME->Text;
   EDITQuery_EMP->Params->Items[3]->AsString = EDIT_EMP_TELEPHONE->Text;
   EDITQuery_EMP->Params->Items[4]->AsString = EDIT_EMP_INFO->Text;
   EDITQuery_EMP->Params->Items[5]->AsString = TEMP_EDIT_ID_EMP->Text;
   EDITQuery_EMP->ExecSQL();
   EDITQuery_EMP->Close();
   EDIT_FORM->Close();
 // Update Screen for refresh data new entry
   MainForm->EMPQuery->Close();
   MainForm->EMPQuery->SQL->Clear();
   MainForm->EMPQuery->SQL->Add("SELECT * FROM EMPLOYEE ");
   MainForm->EMPQuery->ExecSQL();
   MainForm->EMPQuery->Open();
}
//---------------------------------------------------------------------------
void __fastcall TEDIT_FORM::BitBtn2Click(TObject *Sender)
{
     EDIT_FORM->Close();     
}
//---------------------------------------------------------------------------

