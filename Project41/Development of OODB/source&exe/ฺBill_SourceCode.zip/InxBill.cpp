//---------------------------------------------------------------------------
#include <vcl.h>
#include <stdlib.h>
#pragma hdrstop

#include "InxBill.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn1Click(TObject *Sender)
{     int se,bk;

        COUNTSE->Text = '7';
        COUNTBK->Text = '3';
        se = atoi(COUNTSE->Text.c_str());
        bk = atoi(COUNTBK->Text.c_str());

        while (se > 0){
           //---------this Condition DO Until bk =0
           if (bk > 0){
             INXBILL_Q->Close();
          //--------------------------For Send Bill
             INXBILL_Q->Params->Items[0]->AsString = DAY1->Text;
             INXBILL_Q->Params->Items[1]->AsString = MONTH1->Text;
             INXBILL_Q->Params->Items[2]->AsString = YEAR1->Text;
             INXBILL_Q->Params->Items[3]->AsString = BACK1->Text;
             INXBILL_Q->Params->Items[4]->AsString = GOODS1->Text;
             INXBILL_Q->Params->Items[5]->AsString = TOTAL1->Text;
         //--------------------------For back Bill
             INXBILL_Q->Params->Items[6]->AsString = DAY2->Text;
             INXBILL_Q->Params->Items[7]->AsString = MONTH2->Text;
             INXBILL_Q->Params->Items[8]->AsString = YEAR2->Text;
             INXBILL_Q->Params->Items[9]->AsString = BACK2->Text;
             INXBILL_Q->Params->Items[10]->AsString = GOODS2->Text;
             INXBILL_Q->Params->Items[11]->AsString = TOTAL2->Text;
        //---------------------------------------
             INXBILL_Q->ExecSQL();
             INXBILL_Q->Close();
           se--;
           bk--;
           TabSE->MoveBy(1);
           TabBK->MoveBy(1);
           }
           else
           if (bk < 0){
              if (se < 1){
              //--------------Keep data to temp
                 TDAY->Text   =  DAY1->Text;
                 TMONTH->Text =  MONTH1->Text;
                 TYEAR->Text  =  YEAR1->Text;
                 TBACK->Text  =  BACK1->Text;
                 TGOODS->Text =  GOODS1->Text;
                 TTOTAL->Text =  TOTAL1->Text;
                 TabSE->MoveBy(1);
                 se--;
              //--------------Read next row
                 DAY2->Text   =  DAY1->Text;
                 MONTH2->Text =  MONTH1->Text;
                 YEAR2->Text  =  YEAR1->Text;
                 BACK2->Text  =  BACK1->Text;
                 GOODS2->Text =  GOODS1->Text;
                 TOTAL2->Text =  TOTAL1->Text;
              //--------------Take back data from temp
                 DAY1->Text   =  TDAY->Text;
                 MONTH1->Text =  TMONTH->Text;
                 YEAR1->Text  =  TYEAR->Text;
                 BACK1->Text  =  TBACK->Text;
                 GOODS1->Text =  TGOODS->Text;
                 TOTAL1->Text =  TTOTAL->Text;
                 INXBILL_Q->Close();
              //--------------------------For Send Bill
                 INXBILL_Q->Params->Items[0]->AsString = DAY1->Text;
                 INXBILL_Q->Params->Items[1]->AsString = MONTH1->Text;
                 INXBILL_Q->Params->Items[2]->AsString = YEAR1->Text;
                 INXBILL_Q->Params->Items[3]->AsString = BACK1->Text;
                 INXBILL_Q->Params->Items[4]->AsString = GOODS1->Text;
                 INXBILL_Q->Params->Items[5]->AsString = TOTAL1->Text;
              //--------------------------For back Bill
                 INXBILL_Q->Params->Items[6]->AsString = DAY2->Text;
                 INXBILL_Q->Params->Items[7]->AsString = MONTH2->Text;
                 INXBILL_Q->Params->Items[8]->AsString = YEAR2->Text;
                 INXBILL_Q->Params->Items[9]->AsString = BACK2->Text;
                 INXBILL_Q->Params->Items[10]->AsString = GOODS2->Text;
                 INXBILL_Q->Params->Items[11]->AsString = TOTAL2->Text;
              //---------------------------------------
                 INXBILL_Q->ExecSQL();
                 INXBILL_Q->Close();
              }else
              if (se <=1){
                 DAY2->Text   =  ' ';
                 MONTH2->Text =  ' ';
                 YEAR2->Text  =  ' ';
                 BACK2->Text  =  ' ';
                 GOODS2->Text =  ' ';
                 TOTAL2->Text =  ' ';
                 INXBILL_Q->Close();
              //--------------------------For Send Bill
                 INXBILL_Q->Params->Items[0]->AsString = DAY1->Text;
                 INXBILL_Q->Params->Items[1]->AsString = MONTH1->Text;
                 INXBILL_Q->Params->Items[2]->AsString = YEAR1->Text;
                 INXBILL_Q->Params->Items[3]->AsString = BACK1->Text;
                 INXBILL_Q->Params->Items[4]->AsString = GOODS1->Text;
                 INXBILL_Q->Params->Items[5]->AsString = TOTAL1->Text;
              //--------------------------For back Bill
                 INXBILL_Q->Params->Items[6]->AsString = DAY2->Text;
                 INXBILL_Q->Params->Items[7]->AsString = MONTH2->Text;
                 INXBILL_Q->Params->Items[8]->AsString = YEAR2->Text;
                 INXBILL_Q->Params->Items[9]->AsString = BACK2->Text;
                 INXBILL_Q->Params->Items[10]->AsString = GOODS2->Text;
                 INXBILL_Q->Params->Items[11]->AsString = TOTAL2->Text;
              //---------------------------------------
                 INXBILL_Q->ExecSQL();
                 INXBILL_Q->Close();
              }
           }// end of else (if bk = 0)
  }// end of while
}//end Button Click
//---------------------------------------------------------------------------
