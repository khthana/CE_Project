#!/usr/bin/perl
use Msql;

#-----------------  recieve from CGI and split them in pairs -----------------

read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
@pairs = split(/&/, $buffer);
$size = @pairs;

foreach $pair (@pairs) {
   ($name, $values) = split(/=/, $pair);

   # Un-Webify plus signs and %-encoding
   $values =~ tr/+/ /;
   $values =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

   $value{$name} = $values;
}
# --------------------------------------------------------------------------------------------------

$name = $value{name};
$email = $value{email};
$comment = $value{comment};

open(INPUT,"./../../htdocs/thaiweb/guestbk.html");
@inputfile = <INPUT>;
close(INPUT);

open(INPUT, ">./../../htdocs/thaiweb/guestbk.html");
foreach $temp (@inputfile)
	{if ($temp =~ /<!last>/)
		{
print INPUT<<EOF;
<div align="left">
<table border="0" cellpadding="0" cellspacing="0" width="95%">
  <tr>
    <td width="20">&nbsp;<img src="images/face3.GIF" alt="face3.GIF (1255 bytes)" WIDTH="30"
    HEIGHT="24"><br>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Name : $name<br>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Email : <a href="mailto:$email"> $email</a><br> 
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Comment : $comment <br>
    <hr align="right" width="95%">
    </td>
  </tr>
</table>
</div>
<!last>
EOF
		}
	 else
		{
		 print INPUT $temp;
		}
	}
print "Content-Type: text\/html\n\n";
print "<html>";
print '<head>';
print '<META HTTP-EQUIV="REFRESH" CONTENT="2; URL= ../../thaiweb/guestbk.html">';
print '</head>';
print '<body bgcolor="#89C1FA" text="#6E6E6E" >';  
print "<br> <h2>Thank you <\/h2>";
print "<\/body>";
print "<\/html>";
close(INPUT);
