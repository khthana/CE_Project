#! /usr/bin/perl
use Msql;

$dbh = Msql->connect;		#--- connect database
#$db = "TS_CK8";
$db = "dataweb";
$super="";
$tsuper="";
$dbh->selectdb($db);
	&makehp("art");		#--- make homepage for each main catagory
	$super="";		#--- it run recursive to sub category
	$tsuper="";
	&makehp("business");
	$tsuper="";		#-- reset title for each page
	$super="";
	&makehp("computer");
	$tsuper="";
	$super="";
	&makehp("education");
	$super="";
	$tsuper="";
	&makehp("entertainment");
	$super="";
	$tsuper="";
	&makehp("government");
	$super="";
	$tsuper="";
	&makehp("health");
	$super="";
	$tsuper="";
	&makehp("news");
	$super="";
	$tsuper="";
	&makehp("recreation");
	$super="";
	$tsuper="";
	&makehp("regional");
	$super="";
	$tsuper="";
	&makehp("society");
	$super="";
	$tsuper="";

system('chmod 666 ./../../htdocs/thaiweb/category/*.html');
			#-- chmod all html for write next time -------

sub makehp{

local($sql,@sub,$tmp,@rsub,$co,$num,@row,$nub,$input,$count,@name,$cname,$ctname);
	$input = $_[0];
			#--- get data from input cat name -----------
	$sql = "select C_NAME,CT_NAME from T_ALLCAT where CAT='$input' ";
	$sth = $dbh->query($sql);
	@name = $sth->fetchrow;
	$cname = $name[0]; 
	$ctname = $name[1];
			#-- make homepage for input cat name --------
	open(WEBPAGE,">./../../htdocs/thaiweb/category/$input.html");
	$sql = "select SUBCAT from T_CATLINK where CAT = '$input'";
	$sth = $dbh->query($sql);
	@sub = $sth->fetchcol(0);
	if (@sub){	#-- get sub cat of current cat
		foreach $tmp (@sub){
			$sql = "select NUM_SITE from T_ALLCAT where CAT = '$tmp'";
			$sth = $dbh->query($sql);
			$num = $sth->fetchrow;
		#-- check NUMSITE of each cat for select cat to built
			if ($num != 0){
					push(@rsub,$tmp);
				      }
			}
		$nub = @rsub; 	#@rsub is selected sub to write
		$tmp = $nub - ($nub % 2);
		$nub = $tmp / 2;
		#-- write English homepage for current cat
	print WEBPAGE "<html>\n";
	print WEBPAGE "<body bgcolor=\"\#89C1FA\"  text = \"\#6E6E6E\" alink=\"#000080\" link = \"\#FF00FF\" vlink = \"white\">\n";

		print WEBPAGE '<table border="0" cellpadding="0" cellspacing="0" width="95%">';
                print WEBPAGE '<tr>';
    		print WEBPAGE '<td width="100%"></td>';
		print WEBPAGE "<td width=\"19\"><a href=\"t$input.html\" target=\"bottom2\"><img src=\"..\/images\/THAIOFF.gif\" alt=\"THAI.gif (912 bytes)\" border=\"0\" width=\"17\" height=\"18\"><\/a><\/td>";
    		print WEBPAGE '<td width="19"><img src="../images/ENGON.gif" alt="ENGLISH.gif (909 bytes)" border="0" WIDTH="19" HEIGHT="20"></td>';
  		print WEBPAGE '</tr>';
  		print WEBPAGE '<tr>';
    		print WEBPAGE '<td width="100%" height="50"></td>';
    		print WEBPAGE '<td width="19"></td>';
    		print WEBPAGE '<td width="19"></td>';
  		print WEBPAGE '</tr>';
		print WEBPAGE '</table>';

	print WEBPAGE "<center>\n";
	print WEBPAGE "<font face=\"Cordia New\" size=\"5\">$super<\/font>\n";
	print WEBPAGE "<font color=\"\#6E6E6E\" face=\"Cordia New\" size=\"5\">$cname<\/font><br><br>\n";
	print WEBPAGE "<\/center>\n";
	print WEBPAGE "<center>\n";
	print WEBPAGE "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"80%\">\n";
	print WEBPAGE "  <tr>\n";
	print WEBPAGE "    <td width=\"50%\">\n";
	print WEBPAGE "	<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\n";
		$count = 0;
		# ---------------- write link to sub cat in homepage ---
		foreach $tmp (@rsub){
			$count += 1;
			if ($count == $nub+1)
				{print WEBPAGE "    	<\/table>\n";
				 print WEBPAGE "    <\/td>\n";
				 print WEBPAGE "    <td width=\"50%\">\n";
				 print WEBPAGE "	<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\n";
				}
			$sql = "select C_NAME,NUM_SITE from T_ALLCAT where CAT = '$tmp'";
			$sth = $dbh->query($sql);
			@row = $sth->fetchrow;
			print WEBPAGE "<tr>\n"; 
			print WEBPAGE "		<td align = \"center\">\n";
			print WEBPAGE "		<A href = \"./$tmp.html\" target=\"bottom2\"> $row[0] <\/A> ($row[1]) \n";
			print WEBPAGE "		<\/td>\n";
			print WEBPAGE "<\/tr>\n";
			}
		
		print WEBPAGE "    	<\/table>\n";
		print WEBPAGE "    <\/td>\n";
		print WEBPAGE "  <\/tr>\n";
		
		print WEBPAGE "<\/table>\n";
		print WEBPAGE "<\/center>\n";
		$super = "$super$cname:";
		&mk_hpsite($input);
		print WEBPAGE "<\/body>\n";
		print WEBPAGE "<\/html>\n";

	close(WEBPAGE);
			# ---- call recursive to all sub in @rsub
	foreach $tmp (@rsub)
		{&makehp($tmp);
		}
		
	}
	else {
		#---- incase it has'n sub write site in cat in homepage
open(WEBPAGE,">./../../htdocs/thaiweb/category/$input.html");
		print WEBPAGE "<html>\n";
         	print WEBPAGE "<body bgcolor=\"\#89C1FA\"  text = \"\#6E6E6E\" alink=\"#000080\" link = \"\#FF00FF\" vlink = \"white\">\n";
		#print WEBPAGE "<br>\n";

		print WEBPAGE '<table border="0" cellpadding="0" cellspacing="0" width="95%">';
                print WEBPAGE '<tr>';
    		print WEBPAGE '<td width="100%"></td>';
		print WEBPAGE "<td width=\"19\"><a href=\"t$input.html\" target=\"bottom2\"><img src=\"..\/images\/THAIOFF.gif\" alt=\"THAI.gif (912 bytes)\" border=\"0\" width=\"17\" height=\"18\"><\/a><\/td>";
    		print WEBPAGE '<td width="19"><img src="../images/ENGON.gif" alt="ENGLISH.gif (909 bytes)" border="0" WIDTH="19" HEIGHT="20"></td>';
  		print WEBPAGE '</tr>';
  		print WEBPAGE '<tr>';
    		print WEBPAGE '<td width="100%" height="50"></td>';
    		print WEBPAGE '<td width="19"></td>';
    		print WEBPAGE '<td width="19"></td>';
  		print WEBPAGE '</tr>';
		print WEBPAGE '</table>';


		print WEBPAGE "<center>\n";
		print WEBPAGE "<font face=\"Cordia New\" size=\"5\">$super<\/font>\n";
		print WEBPAGE "<font color=\"yellow\" face=\"Cordia New\" size=\"5\">$cname<\/font>\n";
		print WEBPAGE "<\/center>\n";

		&mk_hpsite($input);
		print WEBPAGE "<\/body>\n";
		print WEBPAGE "<\/html>\n";
		close(WEBPAGE);
#		$super="";
	}
#---------------------- make homepage current cat in thai version  -----------
	
	open(WEBPAGE,">./../../htdocs/thaiweb/category/t$input.html");
	if (@sub){

		print WEBPAGE "<html>\n";
         	print WEBPAGE "<body bgcolor=\"\#89C1FA\"  text = \"\#6E6E6E\" alink=\"#000080\" link = \"\#FF00FF\" vlink = \"white\">\n";

		print WEBPAGE '<table border="0" cellpadding="0" cellspacing="0" width="95%">';
                print WEBPAGE '<tr>';
    		print WEBPAGE '<td width="100%"></td>';
    		print WEBPAGE '<td width="19"><img src="../images/THAION.gif" alt="THAIOFF.gif (909 bytes)" border="0" WIDTH="19" HEIGHT="20"></td>';
		print WEBPAGE "<td width=\"19\"><a href=\"$input.html\" target=\"bottom2\"><img src=\"..\/images\/ENGOFF.gif\" alt=\"ENGON.gif (912 bytes)\" border=\"0\" width=\"17\" height=\"18\"><\/a><\/td>";
  		print WEBPAGE '</tr>';
  		print WEBPAGE '<tr>';
    		print WEBPAGE '<td width="100%" height="50"></td>';
    		print WEBPAGE '<td width="19"></td>';
    		print WEBPAGE '<td width="19"></td>';
  		print WEBPAGE '</tr>';
		print WEBPAGE '</table>';

		print WEBPAGE "<center>\n";
		print WEBPAGE "<font face=\"angsanaUPC\" size=\"5\">$tsuper<\/font>\n";
		print WEBPAGE "<font face=\"angsanaUPC\" size=\"5\">$ctname<\/font><br><br>\n";
		print WEBPAGE "<\/center>\n";
		print WEBPAGE "<center>\n";
		print WEBPAGE "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"80%\">\n";
		print WEBPAGE "  <tr>\n";
		print WEBPAGE "    <td width=\"50%\">\n";
		print WEBPAGE "	<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\n";
		$count = 0;
		foreach $tmp (@rsub){
			$count += 1;
			if ($count == $nub+1)
				{print WEBPAGE "    	<\/table>\n";
				 print WEBPAGE "    <\/td>\n";
				 print WEBPAGE "    <td width=\"50%\">\n";
				 print WEBPAGE "	<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\n";
				}
			$sql = "select CT_NAME,NUM_SITE from T_ALLCAT where CAT = '$tmp'";
			$sth = $dbh->query($sql);
			@row = $sth->fetchrow;
			print WEBPAGE "<tr>\n"; 
			print WEBPAGE "		<td align = \"center\">\n";
			print WEBPAGE "		<A href = \"./t$tmp.html\" target=\"bottom2\"> $row[0] <\/A> ($row[1]) \n";
			print WEBPAGE "		<\/td>\n";
			print WEBPAGE "<\/tr>\n";
		}
		
		print WEBPAGE "    	<\/table>\n";
		print WEBPAGE "    <\/td>\n";
		print WEBPAGE "  <\/tr>\n";
		
		print WEBPAGE "<\/table>\n";
		print WEBPAGE "<\/center>\n";
		$tsuper = "$tsuper$ctname:";
		&mk_hpsite;
		print WEBPAGE "<\/body>\n";
		print WEBPAGE "<\/html>\n";
	close(WEBPAGE);
	foreach $tmp (@rsub)
		{&makehp($tmp);
		}
		
	}
	else {

open(WEBPAGE,">./../../htdocs/thaiweb/category/t$input.html");
		print WEBPAGE "<html>\n";
        	print WEBPAGE "<body bgcolor=\"\#89C1FA\"  text = \"\#6E6E6E\" alink=\"#000080\" link = \"\#FF00FF\" vlink = \"white\">\n";

		print WEBPAGE '<table border="0" cellpadding="0" cellspacing="0" width="95%">';
                print WEBPAGE '<tr>';
    		print WEBPAGE '<td width="100%"></td>';
    		print WEBPAGE '<td width="19"><img src="../images/THAION.gif" alt="THAIOFF.gif (909 bytes)" border="0" WIDTH="19" HEIGHT="20"></td>';
		print WEBPAGE "<td width=\"19\"><a href=\"$input.html\" target=\"bottom2\"><img src=\"..\/images\/ENGOFF.gif\" alt=\"ENGON.gif (912 bytes)\" border=\"0\" width=\"17\" height=\"18\"><\/a><\/td>";
  		print WEBPAGE '</tr>';
  		print WEBPAGE '<tr>';
    		print WEBPAGE '<td width="100%" height="50"></td>';
    		print WEBPAGE '<td width="19"></td>';
    		print WEBPAGE '<td width="19"></td>';
  		print WEBPAGE '</tr>';
		print WEBPAGE '</table>';


		print WEBPAGE "<center>\n";
		print WEBPAGE "<font face=\"angsanaUPC\" size=\"5\">$tsuper<\/font>\n";
		print WEBPAGE "<font color=\"yellow\" face=\"angsanaUPC\" size=\"5\">$ctname<\/font>\n";
		print WEBPAGE "<\/center>\n";
		&mk_hpsite_t;
		print WEBPAGE "<\/body>\n";
		print WEBPAGE "<\/html>\n";
		close(WEBPAGE);
#		$tsuper = "";
	}
}
#---------------------------------- fn make each homepage link
sub mk_hpsite{		# get data of each site to built link to site
	local($sql,$sth,@allsite,$tmp,@site,$name);
	$sql = "select SITE_NO from T_CAT_SITE where CAT = '$input'";
	$sth = $dbh->query($sql);
	@allsite = $sth->fetchcol(0);
	print @allsite;
	if (@allsite) {
		print WEBPAGE "<ul>\n";
		foreach $tmp (@allsite){
			$sql = "select ENAME,TNAME,SITE_URL,EDESCRIP from T_SITE where SITE_NO = $tmp";
			$sth = $dbh->query($sql);
			@site = $sth->fetchrow;
			chop($site[0]);
			if($site[0] eq '-'){$name = $site[1];}
			else{$name = $site[0];}
print WEBPAGE<<EOF;
<li><a href = "$site[2]" target="_blank"> $name </a> <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$site[3]<br>
EOF
	  			}
			}
		print WEBPAGE "<\/ul>\n";
}
#------------------------------------------------------------------
sub mk_hpsite_t{	#-- built site in thai version
	local($sql,$sth,@allsite,$tmp,@site,$name);
	$sql = "select SITE_NO from T_CAT_SITE where CAT = '$input'";
	$sth = $dbh->query($sql);
	@allsite = $sth->fetchcol(0);
	print @allsite;
	if (@allsite) {
		print WEBPAGE "<ul>\n";
		foreach $tmp (@allsite){
			$sql = "select ENAME,TNAME,SITE_URL,TDESCRIP,SITE_NO from T_SITE where SITE_NO = $tmp";
			$sth = $dbh->query($sql);
			@site = $sth->fetchrow;
			if ($site[1] eq '-'){$name = $site[0];}
			else {$name = $site[1];}

print WEBPAGE<<EOF;
<li><a href = "$site[2]" target="_blank"> $name </a> <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$site[3]<br>
EOF
	  			}
			}
		print WEBPAGE "<\/ul>\n";
}


	



