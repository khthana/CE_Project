#! /usr/bin/perl
use Msql;

open(CATLIST,'catlist.txt');	 #-- open file which contain catagory data
$dbh = Msql->connect;		 #-- connect database
#$db = "TS_CK8";
$db = "dataweb";
$dbh -> selectdb($db);
$tmp = <CATLIST>;

until ($tmp eq '')		 #-- loop for insert cat data to database
	{if ($tmp =~ /\|/)	 #-- seperate from <cat|cname*ctname>
		{$cat = $`;
		 $tail = $';
		 if ($tail =~ /\*/)
		 	{$cname = $`;
		  	 $ctname = $';
			 chop($ctname);
		  	 print("$cat----$ctname \n");
				#-- insert data to database -------
		  	 $sql = "insert into T_ALLCAT values ('$cat','$cname','$ctname',0)";
 	           	 $sth = $dbh->query($sql)||print("$cat error/n");
			 }
		}
	 $tmp = <CATLIST>;
	}	
