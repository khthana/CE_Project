#! /usr/bin/perl

read (STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
@pairs = split(/&/, $buffer);
$size = @pairs;

foreach $pair (@pairs) {
   ($name, $values) = split(/=/, $pair);

   # Un-Webify plus signs and %-encoding
   $values =~ tr/+/ /;
   $values =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

   $value{$name} = $values;
}


if ($value{password} eq 'pednoi283' || $value{submit}  eq 'addtoDB'||
$value{submit} eq 'next' || $value{submit} eq 'delete'|| 
$value{submit} eq 'updateHP' )
	{if ($value{action} eq 'admin addURL')
		{&adminAddURL;}

	 elsif ($value{submit} eq 'updateHP' )#update from checklist(p_check)
		{&updateNext;} 		    #has &next

	 elsif ($value{action} eq 'updateHP' ) #update from admin.html
		{&update;} 		     #not has &next	
	 
	 elsif ($value{submit} eq 'next')
		{&next;}
	 elsif ($value{submit} eq 'delete')
		{&delete;}
	 elsif ($value{submit} eq 'addtoDB')
		{&addtoDB;}
	 else	# ($value{action} eq 'Checklist')
		{&checklist;}

	}
else	
		{print "Content-Type: text\/html\n\n";
		 print "<html>\n";

		print "<TITLE>Workshop DHTML Area Redirect Page<\/TITLE>\n";
		print "<META HTTP-EQUIV=\"REFRESH\" CONTENT=\"3;URL=..\/..\/thaiweb\/admin.html\">\n";
		print "<META NAME=\"ROBOTS\" CONTENT=\"NOINDEX\">\n";
		print "<\/HEAD>\n";

		 print '<body bgcolor="#89C1FA" text = "#6E6E6E">';
		 print " <h2>Ha Ha! you are not admin .<\/h2><br>
		         Blareeeeee!!.\n";
		 print "<center><hr width=\"90%\"><\/center>";
		 print "<\/body>";
		 print "<\/html>";
		}
sub checklist{
	open(INPUT,'addurl.txt');
	@input = <INPUT>;
	close(INPUT);
	$i = 0;
	
     if (@input <= 3)
	{print "Content-Type: text\/html\n\n";
	 print "<html>\n";
	 print "<HEAD>\n";

	print "<TITLE>Workshop DHTML Area Redirect Page<\/TITLE>\n";
	print "<META HTTP-EQUIV=\"REFRESH\" CONTENT=\"3;URL=..\/..\/thaiweb\/admin.html\">\n";
	print "<META NAME=\"ROBOTS\" CONTENT=\"NOINDEX\">\n";
	print "<\/HEAD>\n";

	 print '<body bgcolor="#89C1FA" text = "#6E6E6E">';
	 print "\n<h2>Non site in addurl.txt<\/h2><br>\n";
	 print "<center><hr width=\"90%\"><\/center>";
	 print "<\/body>";
	 print "<\/html>";
	}
     else{
	open (INPUT,">addurl.txt");
	until ($input[$i] =~ /<!next>/)		#pass and write until <!next>
		{print INPUT $input[$i++];}
	unless ($input[$i+1] =~ /<no>/)		#if it is EOF
		{$input[$i] = "\n";
		 print INPUT $input[$i];
		 $i = 0;
		 close(INPUT);			#reset file pointer
		 open(INPUT,'>addurl.txt');
		 $input[$i] = "<!next>\n";	#set new next
		}
	print INPUT $input[$i++];		#<!next>
	print INPUT $input[$i++];		#<no>
	print INPUT $input[$i++];		#<name>
	$name = $input[$i];
	chop($name);
	($ename,$tname) = split(/\*/,$name);
	print INPUT $input[$i++];		#name
	print INPUT $input[$i++];		#<url>
	$url = $input[$i];
	chop($url);
	print INPUT $input[$i++];		#url
	print INPUT $input[$i++];		#<type>
	$c=0;
	until ($input[$i] =~ /<keyword>/)
		{
		 $type = $input[$i];
		 chop($type);
		 ($main[$c],$sub[$c])=split(/ /,$type);
		 if ($sub[$c] eq '') {$sub[$c] = 'etc.';}
		 $c++;
		 print INPUT $input[$i++];	# type
		}
	print INPUT $input[$i++];		#<keyword>
	$keyword = $input[$i];
	chop($keyword);
	print INPUT $input[$i++];		#keyword
	
	print INPUT $input[$i++];		#<tdescrip>
	$tdescrip = $input[$i];		
	chop($tdescrip); 
	print INPUT $input[$i++];		# tdescrip
	
	print INPUT $input[$i++];		#<edescrip>
	$edescrip = $input[$i];
	chop($edescrip);
	print INPUT $input[$i++];		# edescrip

	print INPUT $input[$i++];		#<end>

	until ($input[$i] eq '')		#--- until end of file
		{print INPUT $input[$i++];}

	close(INPUT);

	open(DRAFT,'p_check.html');
	@content = <DRAFT>;

	$co = 0;
	foreach $temp (@content)
		{if ($temp =~ /<!tname>/)
			{print "<input type=\"text\" name=\"tname\" size=\"30\"  maxlength=\"60\" value=\"$tname\">";
			}
		 elsif ($temp =~ /<!ename>/)
			{print "<input type=\"text\" name=\"ename\" size=\"30\" maxlength=\"40\" tabindex=\"2\" value=\"$ename\">";
			}
		 elsif ($temp =~/<!url>/)
			{print "<input type=\"text\" name=\"url\" size=\"30\" maxlength=\"80\"value=\"$url\" tabindex=\"3\">";
			}
		elsif ($temp =~/<!link>/)
			{print "<a href=\"$url\" target=\"_blank\">view WEB<\/a>";
			}
		 elsif ($temp =~/<!keyword>/)
			{print "<input type=\"text\" name=\"keyword\" size=\"30\" tabindex=\"4\" value=\"$keyword\">";
			}
		 elsif ($temp =~/<!tdescrip>/)
			{print "<textarea rows=\"3\" name=\"tdescrip\" cols=\"30\" tabindex=\"5\">$tdescrip<\/textarea>";
			}
		 elsif ($temp =~/<!edescrip>/)
			{print "<textarea rows=\"3\" name=\"edescrip\" cols=\"30\"tabindex=\"6\">$edescrip<\/textarea>";
			}
 #-- art
		 elsif (($temp =~/<!art>/) &&  ($main[$co] eq 'art'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'art';
			}
		 elsif (($mode eq 'art') && ($main[$co] eq 'art') && ($temp =~ /<option/) && ($temp =~/$sub[$co]/))
			{
				
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 selected value $sen2";
			 $co++;
			}

#-- business
		elsif (($temp =~/<!business>/) && ($main[$co] eq 'business'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'business';
			}
		 elsif (($mode eq 'business') && ($main[$co] eq 'business') && ($temp =~ /<option/) && 
			($temp =~ /$sub[$co]/))
			{
			 ($sen1,$sen2) = split (/value/,$temp);
			  print "$sen1 selected value $sen2";
			  $co++;
			}

#-- computer
		elsif (($temp =~/<!computer>/) && ($main[$co] eq 'computer'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'computer';
			}
		 elsif (($mode eq 'computer') && ($main[$co] eq 'computer') && ($temp =~ /<option/) && ($temp =~ /$sub[$co]/))
			{
			 ($sen1,$sen2) = split (/value/,$temp);
			  print "$sen1 selected value $sen2";
			  $co++;
			}

#-- education
		elsif (($temp =~/<!education>/) && ($main[$co] eq 'education'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'education';
			}
		 elsif (($mode eq 'education') && ($main[$co] eq 'education') && ($temp =~ /<option/) && ($temp =~ /$sub[$co]/))
			{
			 ($sen1,$sen2) = split (/value/,$temp);
			  print "$sen1 selected value $sen2";
			  $co++;
			}

#-- entertainment
		elsif (($temp =~/<!entertainment>/) && ($main[$co] eq 'entertainment'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'entertainment';
			}
		 elsif (($mode eq 'entertainment') && ($main[$co] eq 'entertainment') && ($temp =~ /<option/) && ($temp =~ /$sub[$co]/))
			{
			 ($sen1,$sen2) = split (/value/,$temp);
			  print "$sen1 selected value $sen2";
			  $co++;
			}

#-- government		
		elsif (($temp =~/<!government>/) && ($main[$co] eq 'government'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'government';
			}
		 elsif (($mode eq 'government') && ($main[$co] eq 'government') && ($temp =~ /<option/) && ($temp =~ /$sub[$co]/))
			{
			 ($sen1,$sen2) = split (/value/,$temp);
			  print "$sen1 selected value $sen2";
			  $co++;
			}

#-- health
		elsif (($temp =~/<!health>/) && ($main[$co] eq 'health'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'health';
			}
		 elsif (($mode eq 'health') && ($main[$co] eq 'health') && ($temp =~ /<option/) && ($temp =~ /$sub[$co]/))
			{
			 ($sen1,$sen2) = split (/value/,$temp);
			  print "$sen1 selected value $sen2";
			  $co++;
			}

#-- news
		elsif (($temp =~/<!news>/) && ($main[$co] eq 'news'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'news';
			}
		 elsif (($mode eq 'news') && ($main[$co] eq 'news') && ($temp =~ /<option/) && ($temp =~ /$sub[$co]/))
			{
			 ($sen1,$sen2) = split (/value/,$temp);
			  print "$sen1 selected value $sen2";
			  $co++;
			}

#-- recreation
		elsif (($temp =~/<!recreation>/) && ($main[$co] eq 'recreation'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'recreation';
			}
		 elsif (($mode eq 'recreation') && ($main[$co] eq 'recreation') && ($temp =~ /<option/) && ($temp =~ /$sub[$co]/))
			{
			 ($sen1,$sen2) = split (/value/,$temp);
			  print "$sen1 selected value $sen2";
			  $co++;
			}

#-- regional
		elsif (($temp =~/<!regional>/) && ($main[$co] eq 'regional'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'regional';
			}
		 elsif (($mode eq 'regional') && ($main[$co] eq 'regional') && ($temp =~ /<option/) && ($temp =~ /$sub[$co]/))
			{
			 ($sen1,$sen2) = split (/value/,$temp);
			  print "$sen1 selected value $sen2";
			  $co++;
			}

#--society
		elsif (($temp =~/<!society>/) && ($main[$co] eq 'society'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'society';
			}
		 elsif (($mode eq 'society') && ($main[$co] eq 'society') && ($temp =~ /<option/) && ($temp =~ /$sub[$co]/))
			{
			 ($sen1,$sen2) = split (/value/,$temp);
			  print "$sen1 selected value $sen2";
			  $co++;
			}

		else	{	
		  	print $temp;
			}
		}
		
	close(DRAFT);
	@sub = @clear;
	@main = @clear;
	$c = 0;
   }
}

sub adminAddURL{
	open(DRAFT,'p_adminAddURL.html');
	@content = <DRAFT>;
	foreach $temp (@content)
		{
		  print $temp;
		}
}

#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

sub addtoDB{

open(RESULT,'>addtoDB.txt'); 

$pass = 1;	#$pass = 1 is data completed can add it to addurl.txt

#-------------------------------- convert keyword case

$_ = $value{keyword};		#-- change upper case to lower case
tr/A-Z/a-z/;
$value{keyword} = $_;

$_ = $value{tdescrip};		#-- ged rid of ENTER ,if user include in
tr/\x0D\x0A/ /;			#massage
$value{tdescrip} = $_;

$_ = $value{edescrip};		#-- same above
tr/\x0D\x0A/ /;
$value{edescrip} = $_;

if ($value{ename} eq '')	#-- check they are not empty
	{&fnerror('no_ename');
	}
if ($value{tname} eq '')
	{&fnerror('no_tname');
	}
if ($value{url} eq 'http://')
	{&fnerror('no_url');
	}
if ($value{tdescrip} eq '')
	{&fnerror('no_tdes');
	}
if ($value{edescrip} eq '')
	{&fnerror('no_des');
	}
if ($value{keyword}  eq '')
	{&fnerror('no_key');
	}
#------------- change mark between keywork from , to |
	{if($value{keyword} =~ /,/)
		{$value{keyword} =~ tr/,/|/;
		} 
	}


$num = 0;			#-- num=>number of type which each site be
				#in

if ($value{art} eq 'ON')	#-- If has it value,It is been add in
	{$main[$num] = 'art';
	  if ($value{subart} eq 'etc.')	#-- if site not in any subgroup
   		{$sub[$num] = '';}
	  else {$sub[$num] = $value{subart};}
	  $num++;		#-- increase number of type
 	}         
if ($value{business} eq 'ON')
	{$main[$num] = 'business';
	  if ($value{subbus} eq 'etc.')
   		{$sub[$num] = '';}
	  else {$sub[$num] = $value{subbus};}
     	  $num++;
      	}

if ($value{computer} eq 'ON')
	{$main[$num] = 'computer';
	  if ($value{subcom} eq 'etc.')
   		{$sub[$num] = '';}
	  else {$sub[$num] = $value{subcom};}
	  $num++; 
              	}

if ($value{education} eq 'ON')
	{$main[$num] = 'education';
	  if ($value{subedu} eq 'etc.')
   		{$sub[$num] = '';}
	  else {$sub[$num] = $value{subedu};}
	  $num++;
               	}

if ($value{entertainment} eq 'ON')
	{$main[$num] = 'entertainment';
	  if ($value{subent} eq 'etc.')
   		{$sub[$num] = '';}
	  else {$sub[$num] = $value{subent};}
	  $num++;          
     	}

if ($value{government} eq 'ON')
	{$main[$num] = 'government';
	  if ($value{subgov} eq 'etc.')
   		{$sub[$num] = '';}
	  else {$sub[$num] = $value{subgov};}
       	  $num++;       	
	}

if ($value{health} eq 'ON')
	{$main[$num] = 'health';
	  if ($value{subhealth} eq 'etc.')
   		{$sub[$num] = '';}
	  else {$sub[$num] = $value{subhealth};}
	  $num++;
               	}

if ($value{news} eq 'ON')
	{$main[$num] = 'news';
	  if ($value{subnews} eq 'etc.')
   		{$sub[$num] = '';}
	  else {$sub[$num] = $value{subnews};}
	  $num++;
               	}

if ($value{recreation} eq 'ON')
	{$main[$num] = 'recreation';
	  if ($value{subrec} eq 'etc.')
   		{$sub[$num] = '';}
	  else {$sub[$num] = $value{subrec};}
	  $num++;
               	}

if ($value{regional} eq 'ON')
	{$main[$num] = 'regional';
	  if ($value{subreg} eq 'etc.')
   		{$sub[$num] = '';}
	  else {$sub[$num] = $value{subreg};}
	  $num++;
               	}

if ($value{society} eq 'ON')
	{$main[$num] = 'society';
	  if ($value{subsoc} eq 'etc.')
   		{$sub[$num] = '';}
	  else {$sub[$num] = $value{subsoc};}
	  $num++;
               	}

if ($num == 0)			#-- check if site has no type
	{&fnerror('no_type');
	}
			#-- if site is all correct program will write
			# to addurl.txt in input format
if ($pass == 1)  	
	{print RESULT "<no>1\n";
	 print RESULT "<name>\n$value{ename}*$value{tname}\n";
	 print RESULT "<url>\n$value{url}\n";
	 print RESULT "<type>\n";
	 for ($i=0; $i < $num; $i++)
		{
		 print RESULT "$main[$i] $sub[$i]\n";
		}
	 print RESULT "<keyword>\n$value{keyword}\n";
	 print RESULT "<tdescrip>\n$value{tdescrip}\n";
	 print RESULT "<edescrip>\n$value{edescrip}\n";
	 print RESULT "<end>\n\n";

	
	}
 else   		#-- if it not correct program tell error to user
	{print "Content-Type: text\/html\n\n";
	 print "<html>\n";

	print "<TITLE>Workshop DHTML Area Redirect Page<\/TITLE>\n";
#	print "<META HTTP-EQUIV=\"REFRESH\" CONTENT=\"3;URL=..\/..\/thaiweb\/admin.html\">\n";
#	print "<META NAME=\"ROBOTS\" CONTENT=\"NOINDEX\">\n";
	print "<\/HEAD>\n";

	 print '<body bgcolor="#89C1FA" text="#6E6E6E">\n';
	 print "<h2>Input Data Error.</h2>\n";
	 foreach $temp (@temp) {
		 print "$temp\n";
                 }

         print "<br>\n";
	 print "<center><hr width=\"90%\"><\/center>";
	 print "<\/body>";
	 print "<\/html>";
        }
close(RESULT);

if (system('perl checkcgi.pl >out.txt 2>error2.txt'))
	{
	 syserror('mun run mai dai');
	}
@sub = @clear;
@main = @clear;
$num = 0;
&delete;
}

#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

#----------------------------------------   next
sub next{
	open(INPUT,'addurl.txt');
	@input = <INPUT>;
	close(INPUT);
	$i = 0;
	
     if (@input <= 3)
	{print "Content-Type: text\/html\n\n";
	 print "<html>\n";
	 print "<HEAD>\n";

	print "<TITLE>Workshop DHTML Area Redirect Page<\/TITLE>\n";
	print "<META HTTP-EQUIV=\"REFRESH\" CONTENT=\"3;URL=..\/..\/thaiweb\/admin.html\">\n";
	print "<META NAME=\"ROBOTS\" CONTENT=\"NOINDEX\">\n";
	print "<\/HEAD>\n";

	 print '<body bgcolor="#89C1FA" text = "#6E6E6E">';
	 print "\n<h2>Non site in addurl.txt<\/h2><br>\n";
	 print "<center><hr width=\"90%\"><\/center>";
	 print "<\/body>";
	 print "<\/html>";
	}
     else{
	open (INPUT,">addurl.txt");
	until ($input[$i] =~ /<!next>/)
		{print INPUT $input[$i++];}

	unless ($input[$i+1] =~ /<no>/)		#if it is EOF
		{$input[$i] = "\n";
		 print INPUT $input[$i];
		 $i = 0;
		 close(INPUT);			#reset file pointer
		 open(INPUT,'>addurl.txt');
		 $input[$i] = "<!next>\n";	#set new next
		}

	$input[$i] = "\n";		#clear next --------------------
	print INPUT $input[$i++];		#blank line
	until ($input[$i] =~ /<end>/)
		{print INPUT $input[$i++];}
	print INPUT $input[$i++];	#print <end> of previous site
	$input[$i] = "<!next>\n";	#set  next --------------------


	unless ($input[$i+1] =~ /<no>/)		#if it is EOF
	{$input[$i] = "\n";
	 print INPUT $input[$i];
	 $i = 0;
	 close(INPUT);			#reset file pointer
	 open(INPUT,'>addurl.txt');
	 $input[$i] = "<!next>\n";	#set new next
	}

	print INPUT $input[$i++];	#print <!next>
 
	print INPUT $input[$i++];		#<no>
	print INPUT $input[$i++];		#<name>
	$name = $input[$i];			
	chop($name);
	($ename,$tname) = split(/\*/,$name);
	print INPUT $input[$i++];		#name
	print INPUT $input[$i++];		#<url>
	$url = $input[$i];
	chop($url);
	print INPUT $input[$i++];		#url
	print INPUT $input[$i++];		#<type>
	$c=0;
	until ($input[$i] =~ /<keyword>/)
		{
		 $type = $input[$i];
		 chop($type);
		 ($main[$c],$sub[$c])=split(/ /,$type);
		 if ($sub[$c] eq '') {$sub[$c] = 'etc.';}
		 $c++;
		 print INPUT $input[$i++];	# type
		}
	print INPUT $input[$i++];		#<keyword>
	$keyword = $input[$i];
	chop($keyword);
	print INPUT $input[$i++];		#keyword
	
	print INPUT $input[$i++];		#<tdescrip>
	$tdescrip = $input[$i];		
	chop($tdescrip); 
	print INPUT $input[$i++];		# tdescrip
	
	print INPUT $input[$i++];		#<edescrip>
	$edescrip = $input[$i];
	chop($edescrip);
	print INPUT $input[$i++];		# edescrip

	print INPUT $input[$i++];		#<end>

	until ($input[$i] eq '')		#--- until end of file
		{print INPUT $input[$i++];}

	close(INPUT);

	open(DRAFT,'p_check.html');
	@content = <DRAFT>;

	$co = 0;
	foreach $temp (@content)
		{if ($temp =~ /<!tname>/)
			{print "<input type=\"text\" name=\"tname\" size=\"30\"  maxlength=\"60\" value=\"$tname\">";
			}
		 elsif ($temp =~ /<!ename>/)
			{print "<input type=\"text\" name=\"ename\" size=\"30\" maxlength=\"40\" tabindex=\"2\" value=\"$ename\">";
			}
		 elsif ($temp =~/<!url>/)
			{print "<input type=\"text\" name=\"url\" size=\"30\" maxlength=\"80\"value=\"$url\" tabindex=\"3\">";
			}
		elsif ($temp =~/<!link>/)
			{print "<a href=\"$url\" target=\"_blank\">view WEB<\/a>";
			}
		 elsif ($temp =~/<!keyword>/)
			{print "<input type=\"text\" name=\"keyword\" size=\"30\" tabindex=\"4\" value=\"$keyword\">";
			}
		 elsif ($temp =~/<!tdescrip>/)
			{print "<textarea rows=\"3\" name=\"tdescrip\" cols=\"30\" tabindex=\"5\">$tdescrip<\/textarea>";
			}
		 elsif ($temp =~/<!edescrip>/)
			{print "<textarea rows=\"3\" name=\"edescrip\" cols=\"30\"tabindex=\"6\">$edescrip<\/textarea>";
			}
 #-- art
		 elsif (($temp =~/<!art>/) &&  ($main[$co] eq 'art'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'art';
			}
		 elsif (($mode eq 'art') && ($main[$co] eq 'art') && ($temp =~ /<option/) && ($temp =~/$sub[$co]/))
			{
				
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 selected value $sen2";
			 $co++;
			}

#-- business
		elsif (($temp =~/<!business>/) && ($main[$co] eq 'business'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'business';
			}
		 elsif (($mode eq 'business') && ($main[$co] eq 'business') && ($temp =~ /<option/) && 
			($temp =~ /$sub[$co]/))
			{
			 ($sen1,$sen2) = split (/value/,$temp);
			  print "$sen1 selected value $sen2";
			  $co++;
			}

#-- computer
		elsif (($temp =~/<!computer>/) && ($main[$co] eq 'computer'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'computer';
			}
		 elsif (($mode eq 'computer') && ($main[$co] eq 'computer') && ($temp =~ /<option/) && ($temp =~ /$sub[$co]/))
			{
			 ($sen1,$sen2) = split (/value/,$temp);
			  print "$sen1 selected value $sen2";
			  $co++;
			}

#-- education
		elsif (($temp =~/<!education>/) && ($main[$co] eq 'education'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'education';
			}
		 elsif (($mode eq 'education') && ($main[$co] eq 'education') && ($temp =~ /<option/) && ($temp =~ /$sub[$co]/))
			{
			 ($sen1,$sen2) = split (/value/,$temp);
			  print "$sen1 selected value $sen2";
			  $co++;
			}

#-- entertainment
		elsif (($temp =~/<!entertainment>/) && ($main[$co] eq 'entertainment'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'entertainment';
			}
		 elsif (($mode eq 'entertainment') && ($main[$co] eq 'entertainment') && ($temp =~ /<option/) && ($temp =~ /$sub[$co]/))
			{
			 ($sen1,$sen2) = split (/value/,$temp);
			  print "$sen1 selected value $sen2";
			  $co++;
			}

#-- government		
		elsif (($temp =~/<!government>/) && ($main[$co] eq 'government'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'government';
			}
		 elsif (($mode eq 'government') && ($main[$co] eq 'government') && ($temp =~ /<option/) && ($temp =~ /$sub[$co]/))
			{
			 ($sen1,$sen2) = split (/value/,$temp);
			  print "$sen1 selected value $sen2";
			  $co++;
			}

#-- health
		elsif (($temp =~/<!health>/) && ($main[$co] eq 'health'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'health';
			}
		 elsif (($mode eq 'health') && ($main[$co] eq 'health') && ($temp =~ /<option/) && ($temp =~ /$sub[$co]/))
			{
			 ($sen1,$sen2) = split (/value/,$temp);
			  print "$sen1 selected value $sen2";
			  $co++;
			}

#-- news
		elsif (($temp =~/<!news>/) && ($main[$co] eq 'news'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'news';
			}
		 elsif (($mode eq 'news') && ($main[$co] eq 'news') && ($temp =~ /<option/) && ($temp =~ /$sub[$co]/))
			{
			 ($sen1,$sen2) = split (/value/,$temp);
			  print "$sen1 selected value $sen2";
			  $co++;
			}

#-- recreation
		elsif (($temp =~/<!recreation>/) && ($main[$co] eq 'recreation'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'recreation';
			}
		 elsif (($mode eq 'recreation') && ($main[$co] eq 'recreation') && ($temp =~ /<option/) && ($temp =~ /$sub[$co]/))
			{
			 ($sen1,$sen2) = split (/value/,$temp);
			  print "$sen1 selected value $sen2";
			  $co++;
			}

#-- regional
		elsif (($temp =~/<!regional>/) && ($main[$co] eq 'regional'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'regional';
			}
		 elsif (($mode eq 'regional') && ($main[$co] eq 'regional') && ($temp =~ /<option/) && ($temp =~ /$sub[$co]/))
			{
			 ($sen1,$sen2) = split (/value/,$temp);
			  print "$sen1 selected value $sen2";
			  $co++;
			}

#--society
		elsif (($temp =~/<!society>/) && ($main[$co] eq 'society'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'society';
			}
		 elsif (($mode eq 'society') && ($main[$co] eq 'society') && ($temp =~ /<option/) && ($temp =~ /$sub[$co]/))
			{
			 ($sen1,$sen2) = split (/value/,$temp);
			  print "$sen1 selected value $sen2";
			  $co++;
			}

		else	{	
		  	print $temp;
			}
		}
		
	close(DRAFT);
	@sub = @clear;
	@main = @clear;
	$c = 0;

   }

}

#DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD
sub delete{
	open(INPUT,'addurl.txt');
	@input = <INPUT>;
	close(INPUT);
	$i = 0;
	
     if (@input <= 3)
	{print "Content-Type: text\/html\n\n";
	 print "<html>\n";
	 print "<HEAD>\n";

	print "<TITLE>Workshop DHTML Area Redirect Page<\/TITLE>\n";
	print "<META HTTP-EQUIV=\"REFRESH\" CONTENT=\"3;URL=..\/..\/thaiweb\/admin.html\">\n";
	print "<META NAME=\"ROBOTS\" CONTENT=\"NOINDEX\">\n";
	print "<\/HEAD>\n";

	 print '<body bgcolor="#89C1FA" text = "#6E6E6E">';
	 print "\n<h2>Non site in addurl.txt<\/h2><br>\n";
	 print "<center><hr width=\"90%\"><\/center>";
	 print "<\/body>";
	 print "<\/html>";
	}
     else{
	open (INPUT,">addurl.txt");
	until ($input[$i] =~ /<!next>/)
		{print INPUT $input[$i++];}

	unless ($input[$i+1] =~ /<no>/)		#if it is EOF
		{$input[$i] = "\n";
		 print INPUT $input[$i];
		 $i = 0;
		 close(INPUT);			#reset file pointer
		 open(INPUT,'>addurl.txt');
		 $input[$i] = "<!next>\n";	#set new next
		}
	$n = $i;
	$input[$i++] = '#';		#clear next --------------------
	until ($input[$i] =~ /<end>/)	#pass previous site
		{$input[$i++]='#';}
	$input[$i++]='#';		#pass <end> of previous site
	
	foreach $input_item (@input)
	{unless ($input_item =~ /\#/)
		{push(@pass,$input_item);}
	}
	@input = @pass;
	@pass = @clear;
	$i = $n;
	$input[$i] = "<!next>\n";	#set  next --------------------


	unless ($input[$i+1] =~ /<no>/)		#if it is EOF
	{$input[$i] = "\n";
	 print INPUT $input[$i];
	 $i = 0;
	 close(INPUT);			#reset file pointer
	 open(INPUT,'>addurl.txt');
	 $input[$i] = "<!next>\n";	#set new next
	 unless ($input[$i+1] =~ /<no>/)
		{print INPUT $input[$i];
		 close(INPUT);
		print "Content-Type: text\/html\n\n";
	 	print "<html>\n";
	 	print "<HEAD>\n";

		print "<TITLE>Workshop DHTML Area Redirect Page<\/TITLE>\n";
		print "<META HTTP-EQUIV=\"REFRESH\" CONTENT=\"3;URL=..\/..\/thaiweb\/admin.html\">\n";
		print "<META NAME=\"ROBOTS\" CONTENT=\"NOINDEX\">\n";
		print "<\/HEAD>\n";

		print '<body bgcolor="#89C1FA" text = "#6E6E6E">';
		print "\n<h2>Non site in addurl.txt<\/h2><br>\n";
	 	print "<center><hr width=\"90%\"><\/center>";
	 	print "<\/body>";
	 	print "<\/html>";
		exit;
		}	
	}

	print INPUT $input[$i++];	#print <!next>
 
	print INPUT $input[$i++];		#<no>
	print INPUT $input[$i++];		#<name>
	$name = $input[$i];			
	chop($name);
	($ename,$tname) = split(/\*/,$name);
	print INPUT $input[$i++];		#name
	print INPUT $input[$i++];		#<url>
	$url = $input[$i];
	chop($url);
	print INPUT $input[$i++];		#url
	print INPUT $input[$i++];		#<type>
	$c=0;
	until ($input[$i] =~ /<keyword>/)
		{
		 $type = $input[$i];
		 chop($type);
		 ($main[$c],$sub[$c])=split(/ /,$type);
		 if ($sub[$c] eq '') {$sub[$c] = 'etc.';}
		 $c++;
		 print INPUT $input[$i++];	# type
		}
	print INPUT $input[$i++];		#<keyword>
	$keyword = $input[$i];
	chop($keyword);
	print INPUT $input[$i++];		#keyword
	
	print INPUT $input[$i++];		#<tdescrip>
	$tdescrip = $input[$i];		
	chop($tdescrip); 
	print INPUT $input[$i++];		# tdescrip
	
	print INPUT $input[$i++];		#<edescrip>
	$edescrip = $input[$i];
	chop($edescrip);
	print INPUT $input[$i++];		# edescrip

	print INPUT $input[$i++];		#<end>

	until ($input[$i] eq '')		#--- until end of file
		{print INPUT $input[$i++];}

	close(INPUT);

	open(DRAFT,'p_check.html');
	@content = <DRAFT>;

	$co = 0;
	foreach $temp (@content)
		{if ($temp =~ /<!tname>/)
			{print "<input type=\"text\" name=\"tname\" size=\"30\"  maxlength=\"60\" value=\"$tname\">";
			}
		 elsif ($temp =~ /<!ename>/)
			{print "<input type=\"text\" name=\"ename\" size=\"30\" maxlength=\"40\" tabindex=\"2\" value=\"$ename\">";
			}
		 elsif ($temp =~/<!url>/)
			{print "<input type=\"text\" name=\"url\" size=\"30\" maxlength=\"80\"value=\"$url\" tabindex=\"3\">";
			}
		elsif ($temp =~/<!link>/)
			{print "<a href=\"$url\" target=\"_blank\">view WEB<\/a>";
			}
		 elsif ($temp =~/<!keyword>/)
			{print "<input type=\"text\" name=\"keyword\" size=\"30\" tabindex=\"4\" value=\"$keyword\">";
			}
		 elsif ($temp =~/<!tdescrip>/)
			{print "<textarea rows=\"3\" name=\"tdescrip\" cols=\"30\" tabindex=\"5\">$tdescrip<\/textarea>";
			}
		 elsif ($temp =~/<!edescrip>/)
			{print "<textarea rows=\"3\" name=\"edescrip\" cols=\"30\"tabindex=\"6\">$edescrip<\/textarea>";
			}
 #-- art
		 elsif (($temp =~/<!art>/) &&  ($main[$co] eq 'art'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'art';
			}
		 elsif (($mode eq 'art') && ($main[$co] eq 'art') && ($temp =~ /<option/) && ($temp =~/$sub[$co]/))
			{
				
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 selected value $sen2";
			 $co++;
			}

#-- business
		elsif (($temp =~/<!business>/) && ($main[$co] eq 'business'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'business';
			}
		 elsif (($mode eq 'business') && ($main[$co] eq 'business') && ($temp =~ /<option/) && 
			($temp =~ /$sub[$co]/))
			{
			 ($sen1,$sen2) = split (/value/,$temp);
			  print "$sen1 selected value $sen2";
			  $co++;
			}

#-- computer
		elsif (($temp =~/<!computer>/) && ($main[$co] eq 'computer'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'computer';
			}
		 elsif (($mode eq 'computer') && ($main[$co] eq 'computer') && ($temp =~ /<option/) && ($temp =~ /$sub[$co]/))
			{
			 ($sen1,$sen2) = split (/value/,$temp);
			  print "$sen1 selected value $sen2";
			  $co++;
			}

#-- education
		elsif (($temp =~/<!education>/) && ($main[$co] eq 'education'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'education';
			}
		 elsif (($mode eq 'education') && ($main[$co] eq 'education') && ($temp =~ /<option/) && ($temp =~ /$sub[$co]/))
			{
			 ($sen1,$sen2) = split (/value/,$temp);
			  print "$sen1 selected value $sen2";
			  $co++;
			}

#-- entertainment
		elsif (($temp =~/<!entertainment>/) && ($main[$co] eq 'entertainment'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'entertainment';
			}
		 elsif (($mode eq 'entertainment') && ($main[$co] eq 'entertainment') && ($temp =~ /<option/) && ($temp =~ /$sub[$co]/))
			{
			 ($sen1,$sen2) = split (/value/,$temp);
			  print "$sen1 selected value $sen2";
			  $co++;
			}

#-- government		
		elsif (($temp =~/<!government>/) && ($main[$co] eq 'government'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'government';
			}
		 elsif (($mode eq 'government') && ($main[$co] eq 'government') && ($temp =~ /<option/) && ($temp =~ /$sub[$co]/))
			{
			 ($sen1,$sen2) = split (/value/,$temp);
			  print "$sen1 selected value $sen2";
			  $co++;
			}

#-- health
		elsif (($temp =~/<!health>/) && ($main[$co] eq 'health'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'health';
			}
		 elsif (($mode eq 'health') && ($main[$co] eq 'health') && ($temp =~ /<option/) && ($temp =~ /$sub[$co]/))
			{
			 ($sen1,$sen2) = split (/value/,$temp);
			  print "$sen1 selected value $sen2";
			  $co++;
			}

#-- news
		elsif (($temp =~/<!news>/) && ($main[$co] eq 'news'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'news';
			}
		 elsif (($mode eq 'news') && ($main[$co] eq 'news') && ($temp =~ /<option/) && ($temp =~ /$sub[$co]/))
			{
			 ($sen1,$sen2) = split (/value/,$temp);
			  print "$sen1 selected value $sen2";
			  $co++;
			}

#-- recreation
		elsif (($temp =~/<!recreation>/) && ($main[$co] eq 'recreation'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'recreation';
			}
		 elsif (($mode eq 'recreation') && ($main[$co] eq 'recreation') && ($temp =~ /<option/) && ($temp =~ /$sub[$co]/))
			{
			 ($sen1,$sen2) = split (/value/,$temp);
			  print "$sen1 selected value $sen2";
			  $co++;
			}

#-- regional
		elsif (($temp =~/<!regional>/) && ($main[$co] eq 'regional'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'regional';
			}
		 elsif (($mode eq 'regional') && ($main[$co] eq 'regional') && ($temp =~ /<option/) && ($temp =~ /$sub[$co]/))
			{
			 ($sen1,$sen2) = split (/value/,$temp);
			  print "$sen1 selected value $sen2";
			  $co++;
			}

#--society
		elsif (($temp =~/<!society>/) && ($main[$co] eq 'society'))
			{ 
			 ($sen1,$sen2) = split (/value/,$temp);
			 print "$sen1 checked value $sen2";
			 $mode = 'society';
			}
		 elsif (($mode eq 'society') && ($main[$co] eq 'society') && ($temp =~ /<option/) && ($temp =~ /$sub[$co]/))
			{
			 ($sen1,$sen2) = split (/value/,$temp);
			  print "$sen1 selected value $sen2";
			  $co++;
			}

		else	{	
		  	print $temp;
			}
		}
		
	close(DRAFT);
	@sub = @clear;
	@main = @clear;
	$c = 0;

   }

}
#DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
#-----------------------------------------------------------------------------
sub fnerror {		#-- each case of error they push message in @temp
	if ($_[0] eq 'no_ename')
		{push(@temp,"$url not have English name <br>");
		 $pass = 0;
		}

	if ($_[0] eq 'no_tname')
		{push(@temp,"$url not have Thai name <br>");
		 $pass = 0;
		}

	if ($_[0] eq 'no_url')
		{push(@temp,"$url not have URL <br>");
		 $pass = 0;
		}
	if ($_[0] eq 'no_type')
		{push(@temp,"$url not have category <br>");
		 $pass = 0;
		}

	if ($_[0] eq 'no_tdes')
		{push(@temp,"$url not have Thai description <br>");
		 $pass = 0;
		}

	if ($_[0] eq 'no_edes')
		{push(@temp,"$url not have English description <br>");
		 $pass = 0;
		}

	if ($_[0] eq 'no_key')
		{push(@temp,"$url not have Keyword <br>");
		 $pass = 0;
		}
}

#@@@@@@@@@@@@@@@@@@@@@@@@@@
sub updateNext{
	&next;
	$message = 'Update complete';
	if (system('perl makecatcgi.pl >out.txt 2>error2.txt'))
		{$message = 'Update error';
		}
	print "Content-Type: text\/html\n\n";
		 print "<html>\n";
		 print "<head>\n";
		 print '<META HTTP-EQUIV="REFRESH" CONTENT="2;
URL=../../thaiweb/admin.html">';
		 print "<\/head>\n";
		 print '<body bgcolor="#89C1FA" text="#6E6E6E">';
		 print "\n<h2>$message<\/h2>\n";
		 print "<center><hr width=\"90%\"><\/center>";
		 print "<\/body>";
		 print "<\/html>";

}

sub update{
	$message = 'Update complete';
	if (system('perl makecatcgi.pl >out.txt 2>error2.txt'))
		{$message = 'Update error';
		}
	print "Content-Type: text\/html\n\n";
		 print "<html>\n";
		 print "<head>\n";
		 print '<META HTTP-EQUIV="REFRESH" CONTENT="2; URL= ../../thaiweb/admin.html">';
		 print "<\/head>\n";
		 print '<body bgcolor="#89C1FA" text="#6E6E6E">';	 
		 print "\n<h2>$message\n<\/h2>\n";
		 print "<center>\n<hr width=\"90%\">\n<\/center>\n";
		 print "<\/body>\n";
		 print "<\/html>";

}

sub syserror{
	print "Content-Type: text\/html\n\n";
		 print "<html>\n";
		print "<TITLE>Workshop DHTML Area Redirect Page<\/TITLE>\n";
		print "<META HTTP-EQUIV=\"REFRESH\" CONTENT=\"3;URL=..\/..\/thaiweb\/admin.html\">\n";
		print "<META NAME=\"ROBOTS\" CONTENT=\"NOINDEX\">\n";
		print "<\/HEAD>\n";
		 print "<body>\n";
		 print " <h2>$_[0].\n";
		 print "<center><hr width=\"90%\"><\/center>";
		 print "<\/body>";
		 print "<\/html>";

}

