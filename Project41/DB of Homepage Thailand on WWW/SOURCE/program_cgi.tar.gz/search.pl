#!/usr/bin/perl
use Msql;

$dbh = Msql->connect; 
$dbh -> selectdb('dataweb');

#-----------------  recieve from CGI and split them in pairs -----------------

#read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
$buffer = $ENV{'QUERY_STRING'};
@pairs = split(/&/, $buffer);
$size = @pairs;

foreach $pair (@pairs) {
   ($name, $values) = split(/=/, $pair);

   # Un-Webify plus signs and %-encoding
   $values =~ tr/+/ /;
   $values =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

   $value{$name} = $values;
}
# --------------------------------------------------------------------------------------------------

$key = $value{word};		#-- give values to variables
$option = $value{option};

$_ = $key;			#-- change upper case to lower case
tr/A-Z/a-z/;
$key = $_;

if ($key eq '')			#-- check if keyword empty
	{&fn_error('Please enter keyword');
	 exit;
	}
($head,@tail) = split(/\s+/,$key);	#-- split keyword
if (@tail == '')		#-- if it has one key search only head
	{
	 if ($option eq 'sub')	#-- if option is sub
		{
		 @site = &fn_searchsub($head);
		}
	 else			
		{
		 @site = &fn_search($head);
		}
	}
else 				#-- if it has many keys
	{
	 if ($option eq 'and')  #-- 'and' case
		{@site = &fn_searchand;
		}
	elsif ($option eq 'or') #-- 'or' case
		{@site = &fn_searchor;
		}
	elsif ($option eq 'phrase') #-- 'phrase' case
		{@site = &fn_search($key);
		}
	}
	print "site is :";
	foreach $tmp (@site)
		{print "$tmp " ;
		}
	print "\n";
	if ($value{language} eq 'english')
		{&makehpsite(@site);}
	else	{&makehpsitet(@site);}
# -------------------------------------------------------------
sub fn_error{		 #if error program tell to user
	local($output);
	$output = $_[0];


print "Content-Type: text\/html\n\n";
print "<html>\n";
print '<body bgcolor="#89C1FA" text="#6E6E6E">';
print "\n<b><font size=3 >$output</font></b><br>\n";
print "<center><hr width=\"90%\"><\/center>";
print "<\/body>";
print "<\/html>";
	

}
# --------------------------------------------------------------------------------------------------

sub fn_search		#-- serch site from keyword and return site no
	{local(@result,$sql,$sth,$word);
	$word = $_[0];
	if ($word =~ /[^a-z0-9 \']/)
		{$sql = "select SITE_NO from T_TKEY where KEYWORD = '$word' ";
		 $sth = $dbh->query($sql);
		 @result = $sth ->fetchcol(0);
		 if (0==@result)       #?????????????????
		 	{
			 $sql = "select ENG from T_DIC where THAI = '$word'";
			 $sth = $dbh->query($sql);
			 @eng = $sth ->fetchcol(0);
			 if (@eng != 0)
				{
				 foreach $engWord(@eng)
				 {
		  		  $sql = "select SITE_NO from T_EKEY where KEYWORD = '$engWord' ";
		 		  $sth = $dbh->query($sql);
		 		  @resultEng = $sth ->fetchcol(0);
	      		          foreach $resultEngWord(@resultEng)
				  {
					 push(@result,$resultEngWord);
				  }
				 }
				}
						 
			}
		}
	else
		{$sql = "select SITE_NO from T_EKEY where KEYWORD = '$word' ";
		 $sth = $dbh->query($sql);
		 @result = $sth ->fetchcol(0);
		}
	 @result;
	}

sub fn_searchsub  	#-- function for search sub
	{local(@result,@buffer,@clear,$sql,$sth,$word,$i,$tmp);
	 $word = $_[0];
	 if ($word =~ /[^a-z0-9 \']/)
		{$sql = "select SITE_NO from T_TKEY where KEYWORD like '%$word%' ";
		 $sth = $dbh->query($sql);
		 @result = $sth->fetchcol(0);
		 if (@result == 0)
			{$sql = "select ENG from T_DIC where THAI = '$word'"; 
			 $sth = $dbh->query($sql);
			 @eng = $sth->fetchcol(0);
			 if (@eng != 0)
				{foreach $engword(@eng)
					{$sql = "select SITE_NO from T_EKEY where KEYWORD like '%$engword%'";
					 $sth = $dbh->query($sql);
					 @resulteng = $sth->fetchcol(0);
					 foreach $resultengword(@resulteng)
						{push(@result,$resultengword);
						}
					}
				}	
			}
		}
	 else
		{$sql = "select SITE_NO from T_EKEY where KEYWORD like '%$word%'";
		 $sth = $dbh->query($sql);
		 @result = $sth->fetchcol(0);
		}
	 @buffer = @result;
	 @result = @clear;
	 foreach $word(@buffer)
		{$i = 0;
		 foreach $tmp(@result)
			{if ($word == $tmp)
				{$i++;
				}
			}
		 if ($i == 0) 
			{push(@result,$word);
			}
		}
	 @result;
	}


# --------------------------------------------------------------------------------------------------

sub fn_searchand	#-- use function search in and option by intersect
			# each result
	{local(@temp,@result,@new,@clear,$word,$buffer,$i);
	 @result = &fn_search($head);
	 foreach $word (@tail)
		{@new = &fn_search($word);
		 @temp = @result;
		 @result = @clear;
		 foreach $buffer(@temp)
			{$i =0;
			 until (($buffer == $new[$i]) || ($new[$i]  eq ''))
				{$i++;
				}
		 	if ($new[$i] ne '') 
				{push(@result,$buffer);
				}
			}
		}
	 @result;
	}


sub fn_searchor		#-- use search function in or option by include
			#include different result togeter 
	{local(@result,@buffer,@clear,$word,$i,$tmp);
	 @result = &fn_search($head);
	 foreach $word (@tail)
		{@new = &fn_search($word);
		 @result = (@result,@new);
		}
	 @buffer = @result;
	 @result = @clear;
	 foreach $word(@buffer)
			{$i =0;
			 foreach $tmp (@result)
				{if ($word == $tmp)
					{$i++;
					}
				}
		 	if ($i == 0) 
				{push(@result,$word);
				}
			}
	 @result;
	}
	 
	 
# ---------------------------------------------------------
sub makehpsite		#-- return last result to user in homepage format
        {local(@site,@row,$tmp,$sql,$sth,$name,$dash,$key2);
	 @site = @_;
	 $tmp = @site;
	 $key2 = $key;
	 $key2 =~ tr/ /+/;
   	# $key2 =~ s/pack("C", hex($1))/%([a-fA-F0-9][a-fA-F0-9])/eg;

 	 print "Content-Type: text\/html\n\n";
	 print "<html>\n";
	 print "<body bgcolor = \"\#\89C1FA\" text=\"\#6E6E6E\" vlink=\"\#FFFFFF\" link =\"\#FF00FF\" alink=\"\#000080\">\n";
		
		print  '<table border="0" cellpadding="0" cellspacing="0" width="95%">';
                print  '<tr>';
    		print  '<td width="100%"></td>';
		print  "<td width=\"19\"><a href=\"search.pl?language=thai\&word=$key2\&option=$option\" target=\"bottom2\"><img src=\"..\/..\/thaiweb\/images\/THAIOFF.gif\" alt=\"THAI.gif (912 bytes)\" border=\"0\" width=\"17\" height=\"18\"><\/a><\/td>";
    		print  '<td width="19"><img src="../../thaiweb/images/ENGON.gif" alt="ENGLISH.gif (909 bytes)" border="0" WIDTH="19" HEIGHT="20"></td>';
  		print  '</tr>';
  		print  '<tr>';
    		print  '<td width="100%" height="50"></td>';
    		print  '<td width="19"></td>';
    		print  '<td width="19"></td>';
  		print  '</tr>';
		print  '</table>';

	 print "Found  $tmp sites <br>\n";
	 foreach $tmp(@site)
	 	{$sql = "select ENAME,TNAME,SITE_URL,EDESCRIP from T_SITE where SITE_NO = $tmp ";
		 $sth = $dbh ->query($sql);
		 @row = $sth ->fetchrow;
		 chop($row[0]);
		 if ($row[0] eq '-'){$name = $row[1];}
		 else {$name = $row[0];}
print <<EOF;
<br>
<li><a href = \"$row[2]\" target=\"window$tmp\">$name<\/a><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$row[3]<br>\n
EOF
		} 
	 print "<\/body>\n";
	 print "<\/html>\n";

}
#-----------------------------------------------------------------------
# ---------------------------------------------------------
sub makehpsitet		#-- return last result to user in homepage format
        {local(@site,@row,$tmp,$sql,$sth,$name,$key2);
	 @site = @_;
	 $tmp = @site;
	 $key2 = $key;
	 $key2 =~ tr/ /+/;
   	 #$key2 =~ s/pack("C", hex($1))/%([a-fA-F0-9][a-fA-F0-9])/eg;
	 print "Content-Type: text\/html\n\n";
	 print "<html>\n";
	 print "<body bgcolor = \"\#\89C1FA\" text=\"\#6E6E6E\" vlink=\"\#FFFFFF\" link =\"\#FF00FF\" alink=\"\#000080\">\n";
	 
		print '<table border="0" cellpadding="0" cellspacing="0" width="95%">';
                print '<tr>';
    		print '<td width="100%"></td>';	
    		print '<td width="19"><img src="../../thaiweb/images/THAION.gif" alt="thai.gif (909 bytes)" border="0" WIDTH="19" HEIGHT="20"></td>';
		print "<td width=\"19\"><a href=\"search.pl?language=english\&word=$key2\&option=$option\" target=\"bottom2\"><img src=\"..\/..\/thaiweb\/images\/ENGOFF.gif\" alt=\"English.gif (912 bytes)\" border=\"0\" width=\"17\" height=\"18\"><\/a><\/td>"; 
 		print '</tr>';
  		print '<tr>';
    		print '<td width="100%" height="50"></td>';
    		print '<td width="19"></td>';
    		print '<td width="19"></td>';
  		print '</tr>';
		print '</table>';

	 print "Found $tmp sites <br>\n";
	 foreach $tmp(@site)
	 	{$sql = "select ENAME,TNAME,SITE_URL,TDESCRIP from T_SITE where SITE_NO = $tmp ";
		 $sth = $dbh ->query($sql);
		 @row = $sth ->fetchrow;
		 if ($row[1] eq '-') {$name = $row[0];}
		 else {$name = $row[1];}
print <<EOF;
<br>
<li><a href = \"$row[2]\" target=\"window$tmp\">$name<\/a><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$row[3]<br>\n
EOF
		} 
	 print "<\/body>\n";
	 print "<\/html>\n";

}
#-----------------------------------------------------------------------

