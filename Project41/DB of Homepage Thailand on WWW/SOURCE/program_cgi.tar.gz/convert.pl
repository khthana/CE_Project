#! /usr/bin/perl
use Msql;

open(RESULT,'result.txt');
$dbh = Msql->connect || &dberror('connect');
$dbh -> selectdb('dataweb') || &dberror('selectdb');
$sql = 'select SITE_NO from T_SITE';
#$dbh -> selectdb('TS_CK8') || &dberror('selectdb');
#$sql = 'select SITE_NO from T_SITE ';
$sth = $dbh->query($sql) || &dberror('select site_no');
@temp = $sth ->fetchcol(0);
#print("@temp\n");

$max = 0;
foreach $tmp(@temp)
	{if ($max < $tmp)
		{$max = $tmp;
		}
	}
#print("$max\n");

$tmp = <RESULT>;
if ($max != 0)
	{$check = 1;
	 while ($check)
		{if ($tmp =~ /<no>/)
			{$no = $';
			 if ($no == $max)
				{$check = 0;
				}
			}
 		$tmp = <RESULT>;
		}
		#print ("$tmp\n $no\n");
	}
until (($tmp =~/<no>/) || ($tmp eq ''))
	{$tmp = <RESULT>;
	}
#print ("$tmp\n");
 
while ($tmp ne '')
	{$tmp =~/<no>/;
	 $no = $';
	 chop($no);

	 $tmp = <RESULT>;
	 $ename = <RESULT>;
	 $ename = $dbh->quote($ename)||&dberror("$no quote");
#	 chop($ename);  #no chop because quote make it automatically
	 
	 $tmp = <RESULT>;
	 $tname = <RESULT>;
	 chop($tname);
	 
	 $tmp = <RESULT>;
	 $url = <RESULT>;
	 chop($url);

#        print ("$no\n $ename\n $tname\n $url\n");

	 $tmp = <RESULT>;
	 $tmp = <RESULT>;
	 until ($tmp =~/<keyword>/)
		{chop($tmp);
		 &addcat($tmp);
		 $tmp = <RESULT>;
		}
	 
	 $tmp = <RESULT>;
	 chop($tmp);
	 &addkey($tmp);
	 
	 $tmp = <RESULT>;
	 $tdes = <RESULT>;
	 chop($tdes);

	 $tmp = <RESULT>;
	 $edes = <RESULT>;
	 $edes = $dbh->quote($edes)||&dberror("$no quote edes");
#	 chop($edes);

	 $sql = "insert into T_SITE values($no,'$tname',$ename,'$url','$tdes',$edes,0,'exist')";
#    $ename and $edes not have '  ' because use quote--------
	 $sth = $dbh->query($sql) || &dberror("$no insert T_SITE");

	 until (($tmp eq '') || ($tmp =~/<no>/))
	 	{$tmp = <RESULT>;
		}
	}

close<RESULT>;

#----------------------------------------------------------------------------
sub dberror  {
	local($msg);
	$msg = $dbh->errmsg;
	print("$_[0] error : $msg\n");
}

sub addkey   {
	local($tmp);
	$tmp = $_[0];
	@buffer = split(/\|/,$tmp);
	foreach $tmp (@buffer)
	    {if ($tmp =~ /[^a-z0-9 ]/)
		{$sql = "insert into T_TKEY values ('$tmp',$no)";
		}
	     else 
		{$sql = "insert into T_EKEY values ('$tmp',$no)";
		}
	    $sth = $dbh->query($sql) || &dberror('insert keyword');
	    }	    
}

sub  addcat  {
	local($sql,$tmp,$fr3,$add,@listtype,@tmp2,$tmp3);
	$add = '';
	@listtype = split(/ /,$_[0]);
	foreach $tmp (@listtype)
		{$tmp = $add.$tmp; 
		 $tmp3 = $tmp;
		 $sql = "select NUM_SITE from T_ALLCAT where CAT = '$tmp'";
		 $sth = $dbh->query($sql) || &dberror(" $no $tmp addcat");
		 @tmp2 = $sth->fetchcol(0);
		 @tmp2[0] +=1;
	 	 $sql = "update T_ALLCAT set NUM_SITE = @tmp2[0] where CAT = '$tmp'";
		 $sth = $dbh->query($sql) || &dberror("$tmp update cat");
		 $_[0] =~ /.../;
		 $fr3 = $&;
		 $add = $add.$fr3.'_';
		}
	$sql = "insert into T_CAT_SITE values ('$tmp3',$no)";
	$sth = $dbh->query($sql) || &dberror("$tmp3 T_CAT_SITE insert");
}
