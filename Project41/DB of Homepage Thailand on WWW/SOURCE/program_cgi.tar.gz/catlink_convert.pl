#! /usr/bin/perl
use Msql;

open(CATLINK,'catlist.txt');	#open file which contain link-catagory data
$dbh = Msql->connect;		#connect database
#$db = "TS_CK8";
$db = "dataweb";
$dbh -> selectdb($db);

$tmp = <CATLINK>;
until ($tmp eq '')		#insert data until reach EOF
	{if ($tmp =~ /<main>/)  #search for main catagory
		{$catmain = $';
		 chop($catmain); #get main catagory
		 until ($tmp =~ /<end>/) #loop to add maincat & each subcat
			{if ($tmp =~/\|/)
				{$catsub = $`;
				 $sql = "insert into T_CATLINK values ('$catmain', '$catsub')";
				 $sth = $dbh->query($sql);	
				 print "main = $catmain -- sub = $catsub\n";
				}
			 $tmp = <CATLINK>;
			}
		}
	 $tmp = <CATLINK>;
	}
