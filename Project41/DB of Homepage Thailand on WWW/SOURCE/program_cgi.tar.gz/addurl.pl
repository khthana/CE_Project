#!/usr/bin/perl

use Msql;
$dbh = Msql ->connect;
                        #test ------------------------------
$db = 'dataweb';
$dbh ->selectdb($db);

read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});	#---get cgi
@pairs = split(/&/, $buffer);
$size = @pairs;

foreach $pair (@pairs) {			#--match name&value
   ($name, $values) = split(/=/, $pair);

   # Un-Webify plus signs and %-encoding
   $values =~ tr/+/ /;
   $values =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

   $value{$name} = $values;
}
open(RESULT,">>addurl.txt");		#--addurl.txt is file to keep
					#  info from addurl.html 's cgi 

$pass = 1;	#$pass = 1 is data completed can add it to addurl.txt

#-------------------------------- convert keyword case

$_ = $value{keyword};		#-- change upper case to lower case
tr/A-Z/a-z/;
$value{keyword} = $_;

$_ = $value{tdescrip};		#-- ged rid of ENTER ,if user include in
tr/\x0D\x0A/ /;			#massage
$value{tdescrip} = $_;

$_ = $value{edescrip};		#-- same above
tr/\x0D\x0A/ /;
$value{edescrip} = $_;

if (($value{ename} eq '')&&($value{tname} eq ''))	#-- check they are not empty
	{&fnerror('no_name');
	}
if ($value{url} eq 'http://')
	{&fnerror('no_url');
	}

$sql = "select SITE_URL from T_SITE where SITE_URL = '$value{url}'";
$sth = $dbh->query($sql) || &fnerror('query error');
@temp = $sth ->fetchcol(0);

if ($temp[0] ne '')
	{&fnerror('repeat url');
	}
if ($value{tdescrip} eq '')
	{&fnerror('no_tdes');
	}
if ($value{edescrip} eq '')
	{&fnerror('no_des');
	}
if ($value{keyword}  eq '')
	{&fnerror('no_key');
	}
#------------- change mark between keywork from , to |
	{if($value{keyword} =~ /,/)
		{$value{keyword} =~ tr/,/|/;
		} 
	}


$num = 0;			#-- num=>number of type which each site be
				#in

if ($value{art} eq 'ON')	#-- If has it value,It is been add in
	{$main[$num] = 'art';
	  if ($value{subart} eq 'etc.')	#-- if site not in any subgroup
   		{$sub[$num] = '';}
	  else {$sub[$num] = $value{subart};}
	  $num++;		#-- increase number of type
 	}         
if ($value{business} eq 'ON')
	{$main[$num] = 'business';
	  if ($value{subbus} eq 'etc.')
   		{$sub[$num] = '';}
	  else {$sub[$num] = $value{subbus};}
     	  $num++;
      	}

if ($value{computer} eq 'ON')
	{$main[$num] = 'computer';
	  if ($value{subcom} eq 'etc.')
   		{$sub[$num] = '';}
	  else {$sub[$num] = $value{subcom};}
	  $num++; 
              	}

if ($value{education} eq 'ON')
	{$main[$num] = 'education';
	  if ($value{subedu} eq 'etc.')
   		{$sub[$num] = '';}
	  else {$sub[$num] = $value{subedu};}
	  $num++;
               	}

if ($value{entertainment} eq 'ON')
	{$main[$num] = 'entertainment';
	  if ($value{subent} eq 'etc.')
   		{$sub[$num] = '';}
	  else {$sub[$num] = $value{subent};}
	  $num++;          
     	}

if ($value{government} eq 'ON')
	{$main[$num] = 'government';
	  if ($value{subgov} eq 'etc.')
   		{$sub[$num] = '';}
	  else {$sub[$num] = $value{subgov};}
       	  $num++;       	
	}

if ($value{health} eq 'ON')
	{$main[$num] = 'health';
	  if ($value{subhealth} eq 'etc.')
   		{$sub[$num] = '';}
	  else {$sub[$num] = $value{subhealth};}
	  $num++;
               	}

if ($value{news} eq 'ON')
	{$main[$num] = 'news';
	  if ($value{subnews} eq 'etc.')
   		{$sub[$num] = '';}
	  else {$sub[$num] = $value{subnews};}
	  $num++;
               	}

if ($value{recreation} eq 'ON')
	{$main[$num] = 'recreation';
	  if ($value{subrec} eq 'etc.')
   		{$sub[$num] = '';}
	  else {$sub[$num] = $value{subrec};}
	  $num++;
               	}

if ($value{regional} eq 'ON')
	{$main[$num] = 'regional';
	  if ($value{subreg} eq 'etc.')
   		{$sub[$num] = '';}
	  else {$sub[$num] = $value{subreg};}
	  $num++;
               	}

if ($value{society} eq 'ON')
	{$main[$num] = 'society';
	  if ($value{subsoc} eq 'etc.')
   		{$sub[$num] = '';}
	  else {$sub[$num] = $value{subsoc};}
	  $num++;
               	}

if ($num == 0)			#-- check if site has no type
	{&fnerror('no_type');
	}
			#-- if site is all correct program will write
			# to addurl.txt in input format
if ($pass == 1)  	
	{print RESULT "<no>1\n";
	 print RESULT "<name>\n$value{ename}*$value{tname}\n";
	 print RESULT "<url>\n$value{url}\n";
	 print RESULT "<type>\n";
	 for ($i=0; $i < $num; $i++)
		{
		 print RESULT "$main[$i] $sub[$i]\n";
		}
	 print RESULT "<keyword>\n$value{keyword}\n";
	 print RESULT "<tdescrip>\n$value{tdescrip}\n";
	 print RESULT "<edescrip>\n$value{edescrip}\n";
	 print RESULT "<end>\n\n";

	 print "Content-Type: text\/html\n\n";
	 print "<html>\n";

	print "<TITLE>Workshop DHTML Area Redirect Page<\/TITLE>\n";
	print "<META HTTP-EQUIV=\"REFRESH\" CONTENT=\"3;URL=..\/..\/thaiweb\/addurl.html\" target = \"_self\">\n";
	print "<META NAME=\"ROBOTS\" CONTENT=\"NOINDEX\">\n";
	print "<\/HEAD>\n";

	 print '<body bgcolor="#89C1FA" text="#6E6E6E">';
	 print "\n<h2>Data transfer complete .</h2><br>
	         See your link in our homepage next week .
	         Thank you.\n";

	 print "<center><hr width=\"90%\"><\/center>";
	 print "<\/body>";
	 print "<\/html>";
	}
 else   		#-- if it not correct program tell error to user
	{print "Content-Type: text\/html\n\n";
	 print "<html>\n";


	print "<TITLE>Workshop DHTML Area Redirect Page<\/TITLE>\n";
#	print "<META HTTP-EQUIV=\"REFRESH\" CONTENT=\"3;URL=..\/..\/thaiweb\/addurl.html\" target = \"_self\">\n";
	print "<META NAME=\"ROBOTS\" CONTENT=\"NOINDEX\">\n";
	print "<\/HEAD>\n";

	 print "<body text=\"\#6E6E6E\" bgcolor =\"\#89C1FA\">\n";
	 print "<h2>Input Data Error.</h2>\n";
	 foreach $temp (@temp) {
		 print "$temp\n";
                 }

         print "<br>\n";
	 print "<center><hr width=\"90%\"><\/center>";
	 print "<\/body>";
	 print "<\/html>";
        }

close(RESULT);
#-----------------------------------------------------------------------------
sub fnerror {		#-- each case of error they push message in @temp
	if ($_[0] eq 'no_name')
		{push(@temp,"Not have Site name <br>");
		 push(@temp,"You should have Thai name or English name<br>");
		 $pass = 0;
		}

	if ($_[0] eq 'no_url')
		{push(@temp,"Not have URL <br>");
		 $pass = 0;
		}
	if ($_[0] eq 'no_type')
		{push(@temp,"Not have category <br>");
		 $pass = 0;
		}

	if ($_[0] eq 'no_tdes')
		{push(@temp,"Not have Thai description <br>");
		 $pass = 0;
		}

	if ($_[0] eq 'no_edes')
		{push(@temp,"Not have English description <br>");
		 $pass = 0;
		}

	if ($_[0] eq 'no_key')
		{push(@temp,"Not have Keyword <br>");
		 $pass = 0;
		}

	if ($_[0] eq 'query error')
		{push(@temp,"Query ERROR <br>");
		 $pass = 0;
		}

	if ($_[0] eq 'repeat url')
		{push(@temp,"Repeat URL <br>");
		 $pass = 0;
		}

}

sub   copyfile{
	open(OLD,$_[0]) || print "open old file error\n";
	open(NEW,">$_[1]") || print "open new file error\n";
	local(@buffer);
	@buffer = <OLD>;
	print NEW @buffer;
	close(OLD);
	close(NEW);
}
