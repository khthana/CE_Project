#! /usr/bin/perl
use Msql;

$dbh = Msql->connect;
$dbh->selectdb('dataweb');

open(DIC,"dic.txt");
@buffer=<DIC>;
foreach $line(@buffer)
	{
	 chop($line);
	 ($thai,$tail) = split(/\|/,$line);
	 @eng = split(/&/,$tail);
	 foreach $word(@eng)
		{
		 $sql = "insert into T_DIC values ('$thai','$word')";
		 $sth = $dbh->query($sql);
		}
	}

