#! /usr/bin/perl

use Msql;
$dbh = Msql ->connect;
			#test ------------------------------
$db = 'dataweb';
$dbh ->selectdb($db);
$dberror = $dbh ->errmsg;
if ($dberror)
	{print "error: $dberror";
	}

print "Enter input file name : ";       #accept filename whice be checked
#$fname = <STDIN>;
#chop($fname);

$fname = $ARGV[0];
#$fname = "webmod.txt";
#$fname = "test.txt";
#$fname = "test_t.txt";
open(TEST,'>test.txt');
print TEST "stomashace\n";
close(TEST);
unless (-r $fname)			#check input file is readable
	{print "$fname:Error no file name or can't read.\n";
	}	 

&copyfile('result.txt','result.bak');
open(INPUT,$fname);
open(ERROR,">error.txt");		#open error file to write


if (-r "result.txt")
	{open(RESULT,'result.txt');
	 $count = 1;
	 while($temp = <RESULT>)
		{if ($temp =~ /<no>/)
			{$count++;
			}
		}
	 $st_no = $count;
	}
else
	{$st_no = 1;
	}
print "start site is $st_no\n";
close (RESULT);
open (RESULT,'>>result.txt');
#test-----------------------------

#unless (-w "result.txt")		#check result file
#	{print "result.txt:Error no file name or can't write.\n";
#	}
#
#open(RESULT,">>result.txt");
					#get data from database to @url_in	
#test
			#test ------------------------------------
open(TMP,'result.txt');
$temp = <TMP>;
while ($temp ne '') 
	{if ($temp =~ /<url>/)
		{$temp = <TMP>;
		 chop($temp);
		 push(@url_in,$temp);
                 }
	 $temp =<TMP>;
	}
close(TMP);


open(CATWORD,'catword.txt');		#creat @main for ckeck type
$temp = <CATWORD>;
$count = 0;
until ($temp =~ /<sub>/)
	{$temp = <CATWORD>;
	 chop($temp);
	 unless ($temp =~ /<sub>/)
		{$main[$count++] = $temp;
		}
	}
$count = 0;				#creat @sub for check type
while ($temp ne '')
	{$temp = <CATWORD>;
	 if ($temp =~ /\w/)
		{chop($temp);
		 $sub[$count++] = $temp;
		}
	}
close(CATWORD);

#---------------------------- begin check ---------------------

ALL:{	#start loop
					#test it should continue or finish
$no = <INPUT>;
until ($no =~ /<no>/)
	{if ($no eq '')			#it 's END of input file
		{last ALL;
		}
	$no = <INPUT>;
	}
					#test site no.
$no =~ /<no>/;
$no = $';
chop($no);
if ($no =~ /\D/ )
	{&fnerror('no');
	}
					#test name.
$temp = <INPUT>;
$name = <INPUT>;
chop($name);
unless ($name =~ /<url>/)		#---is it exist?
	{if ($name =~ /\*/)
		{$ename = $`;
		 if ($ename eq '')	#---Has it ename?
			{$ename = '-';
			}
	 	 $tname = $';
		}
	else
		{$ename = $name;	#---Has it tname?
		 $tname = '-';
		}
	}
else
	{&fnerror('noname'); 
	}
$count = &nub($ename);			#---check size of ename
if ($count > 40)
	{&fnerror('esize');
	}

$count = &nub($tname);			#---check size of tname
if ($count > 60)
	{&fnerror('tsize');
	}

$temp = <INPUT>;			#test url
$url = <INPUT>;
if ($url =~ /<type>/)			#---Has it url?
	{&fnerror('nourl');
	}

chop($url);
$count = &nub($url);			#---check url size
if ($count > 80)
	{&fnerror('usize');
	}

$repeat = 0;				#---check repeation of url
foreach $ulist (@url_in)
	{if ($url eq $ulist)
		{$repeat = 1;
		}
	}
if ($repeat == 1)
	{&fnerror('repurl');
	}

$temp = <INPUT>; 			#check type
$type = <INPUT>;
if ($type =~/<keyword>/)		#---Has it type?
	{&fnerror('notype');
	}
$count = 0;
until ($type =~/<keyword>/)		#---check correctness
	{chop($type);
	 ($head,@tail) = split(/ /,$type);
	 $repeat = 0;
	 foreach $temp (@main)		#------first cat
		{if ($temp eq $head)			
			{$repeat = 1;
			}
		}
	 if ($repeat == 0)
		{&fnerror('missmain',$head)
		}
	 $chkerr = 0; 
	 foreach $tail_temp (@tail)	#------anather cat
		{$repeat = 0;
		 foreach $temp (@sub)
			{if ($tail_temp eq $temp)
			 	{$repeat = 1;
				}
			}
		 if ($repeat == 0)
		 	{$chkerr++ ;
			}
	 	}
	if ($chkerr == 1)
		{&fnerror('misssub')
		}
	 $alltype[$count++] = "$type\n";
	 $type = <INPUT>;
	}

$key = <INPUT>;					#check keyword
if ($key =~/<tdescrip>/)
	{&fnerror('nokey');
	}
chop($key);
@tail = split(/\|/,$key);			#check size of each keyword
foreach $temp (@tail)
	 {if (&nub($temp) > 20)
		{&fnerror('ksize');	
		}
	}

$temp = <INPUT>;				#check thai descrip
$tdes = <INPUT>;
if ($tdes =~ /<edescrip>/)
	{&fnerror('notdes');
	}
chop($tdes);
if (&nub($tdes) > 255)				#---check it 's size
	{&fnerror('tdsize');
	}

$temp = <INPUT>;				#check english descrip
$edes = <INPUT>;
if ($edes =~ /<end>/)
	{&fnerror('noedes')
	}

chop($edes);
if (&nub($edes) > 255)				#---check it 's size
	{&fnerror('edsize');
	}

print RESULT "<no>";
print RESULT "$st_no\n";
$st_no++;
print RESULT "<ename>\n$ename\n<tname>\n$tname\n";
print RESULT "<url>\n$url\n";
print RESULT "<type>\n";
foreach $temp (@alltype)
	{print RESULT $temp;
	}
print RESULT "<keyword>\n$key\n";
print RESULT "<tdescrip>\n$tdes\n";
print RESULT "<edescrip>\n$edes\n";
print RESULT "<end>\n\n";
push(@url_in,$url);
redo ALL;				#--goto check next site

}	#end of loop ALL

close(RESULT);				#close all file
close(ERROR);
close(INPUT);
system('convert.pl');
#------------------------------------ end check ----------------------
#function error	#report error and goto next site
sub   fnerror {
					#each case for each error
	if ($_[0] eq 'no')
		{print ERROR "$no : not have no. \n";
		 print "$no : not have no. \n";
		 redo ALL;
		}
	elsif ($_[0] eq 'noname')
		{print ERROR "$no : not have name. \n";
		 print "$no : not have name. \n";
		 redo ALL;
		}
	elsif ($_[0] eq 'esize')
		{print ERROR "$no : ename exceed size. \n";
		 print "$no : ename exceed size. \n";
		 redo ALL;
		}
	elsif ($_[0] eq 'tsize')
		{print ERROR "$no : tname exceed size. \n";
		 print "$no : tname exceed size. \n";
		 redo ALL;
		}
	elsif ($_[0] eq 'nourl')
		{print ERROR "$no  : no have url. \n";
		 print "$no : no have url.\n";
		 redo ALL;
		}
	elsif ($_[0] eq 'usize')
		{print ERROR "$no : url exceed size. \n";
		 print "$no : url exceed size. \n";
		 redo ALL;
		}
	elsif ($_[0] eq 'edsize')
		{print ERROR "$no : edescrip exceed size. \n";
		 print "$no : edescrip exceed size. \n";
		 redo ALL;
		}
	elsif ($_[0] eq 'tdsize')
		{print ERROR "$no : tdescrip exceed size. \n";
		 print "$no : tdescrip exceed size. \n";
		 redo ALL;
		}
	elsif ($_[0] eq 'repurl')
		{print ERROR "$no : url is repeat. \n";
		 print "$no : url is repeat. \n";
		 redo ALL;
		}
	elsif ($_[0] eq 'notype')
		{print ERROR "$no : not have type. \n";
		 print "$no : not have type. \n";
		 redo ALL;
		}
	elsif ($_[0] eq 'missmain')
		{print ERROR "$no : main $_[1] is incorrect. \n";
		 print "$no : main $_[1] is incorrect. \n";
		 redo ALL;
		}
	elsif ($_[0] eq 'misssub')
		{print ERROR "$no : sub is incorrect.\n";
		 print "$no : sub is incorrect. \n";
		 redo ALL;
		}
	elsif ($_[0] eq 'nokey')
		{print ERROR "$no : not have keyword. \n";
		 print "$no : not have keyword. \n";
		 redo ALL;
		}
	elsif ($_[0] eq 'ksize')
		{print ERROR "$no : keyword exceed size. \n";
		 print "$no : keyword exceed size. \n";
		 redo ALL;
		}
	elsif ($_[0] eq 'notdes')
		{print ERROR "$no : not have tdescrip. \n";
		 print "$no : not have tdescrip. \n";
		 redo ALL;
		}
	elsif ($_[0] eq 'noedes')
		{print ERROR "$no : not have edescrip. \n";
		 print "$no : not have edescrip. \n";
		 redo ALL;
		}
}

sub   nub {				#function check char size
	$tmp = $_[0];
	local($co);
	$co = 0;
	while ($tmp ne '')
		{$co++;
		 chop($tmp);
		}
	$co;
}

sub   copyfile {
	open (OLD,$_[0]) || print "open old file error\n";
	open (NEW,">$_[1]") || print "new old file error\n";
	local(@buffer);
	@buffer = <OLD>;
	print NEW @buffer;
	close (NEW);
	close (OLD);
}

