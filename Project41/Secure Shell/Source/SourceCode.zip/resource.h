//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SecureShell.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_SOCKETS_INIT_FAILED         104
#define IDR_MAINFRAME                   128
#define IDR_SECURETYPE                  129
#define IDD_LOGIN_DLG                   130
#define IDC_HOST                        1000
#define IDC_PORT                        1001
#define IDC_COMBO_HOST                  1005
#define IDC_EDIT_PORT                   1006
#define IDC_PASSWD                      1007
#define IDC_USER                        1008
#define IDC_EDIT_USER                   1009
#define IDC_EDIT_PASSWD                 1010
#define IDC_CONNECT                     1011
#define ID_CONNECT_LOGIN                32771
#define ID_CONNECT_DISCONNECT           32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
