#!/usr/bin/perl

print " :) Monitoring run OK. (: \n";

#init variable
open(PACKET,"/project/tcpdump-3.4a6/tcpdump -tt -S -n 'tcp && ! port 3128'|");
my($day,$mon) = (localtime())[3..4];
$_ = localtime();
my($year) = (split(/\s+/,$_))[4];
$myday = ($day."-".$mon."-".$year);

while (<PACKET>)  
{      #$pack = $_;
       $temp = s/:|>/ /g;  # cut ':' and '>' discard
       ($time,$src_port,$dst_port,$flag,
       $seq1,$seq2,$ack,$ack_num) =split(/\s+/,$_);
       
       #state1  --SYN-->    
       if (($flag eq 'S')and($ack ne 'ack')) 
       {  
           $index_of_key = $src_port."-".$dst_port;
           {   $database{$index_of_key} = 
               {       "server"=>$dst_port,
                       "client"=>$src_port,
                       "state"=>"Open1",
                       "start_t"=>$time,
                       "end_t"=>0,
                       "seq_no"=>$seq1,
                       "ack_no"=>0 
                };
           }; 

       };  

       #state2   <--SYN,ACK--- respond host
       if (($flag eq 'S')and($ack eq 'ack')) 
       {  
           $index_of_key = $dst_port."-".$src_port; 
           if(exists($database{$index_of_key}))     
           {  
               $con = $database{$index_of_key};
               $seq_number = %{$con}->{"seq_no"};    
               if ($seq_number+1 eq $ack_num ) 
               {  %{$con}->{"seq_no"} = $seq2;
                  %{$con}->{"state"} = "Open2";
                  %{$con}->{"ack_no"} = $ack_num;
               };
           };
       };
       #state3  ---ACK-->  respond host
       if (($flag eq '.')and($seq1 eq 'ack'))
       {   $index_of_key = $src_port."-".$dst_port; 
           if(exists($database{$index_of_key}))
           {     
               $con = $database{$index_of_key};
               $seq_number = %{$con}->{"seq_no"};
               if ($seq_number+1 eq $seq2 )
               {  %{$con}->{"state"} = "Open3";
                  %{$con}->{"end_t"} = $time;
               }
            }
       }
       #state4 <---- F / FP ----> 
       if (($flag eq 'F') or ($flag eq 'FP'))
       {   # Server send F Close 
           $index_of_key = $src_port."-".$dst_port;
           if(exists($database{$index_of_key}))
           {   $con = $database{$index_of_key};
               $close = %{$con}->{"state"};
               if ($close eq 'Open3' )
               {  #print("Client send F req s=Open3\n"); 
                  %{$con}->{"state"} = "Client_close";
                  %{$con}->{"end_t"} = $time;
               }
               if ($close eq 'Server_close' )
               {  #print("Client send F res s=Client_close\n");
                  %{$con}->{"end_t"} = $time;
                  %{$con}->{"state"} = "Close";
                  send_data();
                  delete($database{$index_of_key});
               }
           }
           # Server Side            
           $index_of_key = $dst_port."-".$src_port;
           if(exists($database{$index_of_key}))
           {   $con = $database{$index_of_key};
               $close = %{$con}->{"state"}; 
               if ($close eq 'Open3')
               {  #print("Server send F req s=Open3\n");
                  %{$con}->{"state"} = "Server_close";
                  %{$con}->{"end_t"} = $time;
               }
               if ($close eq 'Client_close')
               {  #print("Server send F res s=Client_close\n");
                  %{$con}->{"end_t"} = $time;
                  %{$con}->{"state"} = "Close";
                  send_data();
                  delete($database{$index_of_key});
               }
            }
       }    

       # RST state  <-- RST---> respond host  delete all direction      
       if ($flag eq 'R')
       {  $index_of_key = $src_port."-".$dst_port;
          if(exists($database{$index_of_key}))
          {   $con = $database{$index_of_key}; 
              $state_reset = %{$con}->{"state"};
              if ($state_reset eq 'Open1')
              {  delete($database{$index_of_key});
              }
              if ($state_reset eq 'Open2')
              {  delete($database{$index_of_key});
              }
              if ($state_reset eq 'Open3')
              {   %{$con}->{"end_t"} = $time;
                  %{$con}->{"state"} = "RC_Open";
                  send_data($_);
                  delete($database{$index_of_key});
              }
              if ($state_reset eq 'Server_close')
              {  %{$con}->{"end_t"} = $time;
                 %{$con}->{"state"} = "RC_SClose";
                 send_data($_);
                 delete($database{$index_of_key});
              }
              if ($state_reset eq 'Client_close')
              {  %{$con}->{"end_t"} = $time;
                 %{$con}->{"state"} = "RC_CClose";
                 send_data();
                 delete($database{$index_of_key});
              }
           }
           else
           { $index_of_key = $dst_port."-".$src_port;
             if (exists($database{$index_of_key}))              
             {   $con = $database{$index_of_key};
                 $state_reset = %{$con}->{"state"};
                 if ($state_reset eq 'Open1')
                 {  delete($database{$index_of_key});
                 }
                 if ($state_reset eq 'Open2')
                 {  delete($database{$index_of_key});
                 };
                 if ($state_reset eq 'Open3')
                 {  %{$con}->{"end_t"} = $time;
                    %{$con}->{"state"} = "RS_Open";  
                    send_data($_);
                    delete($database{$index_of_key});
                 }
                 if ($state_reset eq 'Server_close')
                 {  %{$con}->{"end_t"} = $time;
                    %{$con}->{"state"} = "RS_SClose"; 
                    send_data($_);  
                    delete($database{$index_of_key});
                 }
                 if ($state_reset eq 'Client_close')
                 {  %{$con}->{"end_t"} = $time;
                    %{$con}->{"state"} = "RS_CClose";
                    send_data($_); 
                    delete($database{$index_of_key});
                 }   
             }
           }
       }
}
close(PACKET);
#-----------------------------------------------------
sub send_data 
{     
      check_day();  
      open(FILE,">>/project/data/closed.dat");
      print FILE (%{$con}->{"server"});print FILE (" ");
      print FILE (%{$con}->{"client"});print FILE (" ");
      print FILE (%{$con}->{"state"});print FILE (" ");
      print FILE (%{$con}->{"start_t"});print FILE (" ");
      print FILE (%{$con}->{"end_t"});print FILE ("\n");
      close(FILE);
}
sub check_day
{
my($day,$mon) = (localtime())[3..4];
$_ = localtime();
my($year) = (split(/\s+/,$_))[4];
my($newday) = ($day."-".$mon."-".$year);
if ($myday ne $newday) 
{   rename("/project/data/closed.dat","/project/data/closed".$myday);
    $myday = $newday;
}
}
