#!/usr/bin/perl

print " :) Full Scan Port Detector run OK. (: \n";

#init variable
$port_Max = 7;
$allow_Time = 7; #sec
$check_point = 20;
$check = 0;
while (<STDIN>)  # input from pipe of tcpdump -tt -S -n 'tcp' |
{      $temp = s/:|>/ /g;  # cut ':' and '>' discard
       #print "$_"; 
       ($time,$src,$dst,$flag,
       $seq1,$seq2,$ack,$ack_num) =split(/\s+/,$_);

       $_ = $src;   # cut out port 
       ($aaa,$bbb,$ccc,$ddd,$port) = split(/\./,$_);
       $src = $aaa."\.".$bbb."\.".$ccc."\.".$ddd;

       $_ = $dst;   # cut out port
       ($aaa,$bbb,$ccc,$ddd,$port) = split(/\./,$_);
       $dst = $aaa."\.".$bbb."\.".$ccc."\.".$ddd;


       $key = $src."-".$dst; 
      
       #state1  --SYN-->    
       if (($flag eq S)and($ack ne ack)and($port <= 1024)) 
       {  
          $check++;
          if (exists($database{$key})) {
              %{$database{$key}}->{$port} = $time;
          }
          else {
              $database{$key} = {
                        $port => $time
              };
          };
       };
       if ($check == $check_point) {
          check_scan_port();
          $check = 0; 
       };
};
#-------------------------------------------------------------------------
sub check_scan_port{
    while (($key,$value)=each(%database))
    {
         @list = values(%{$value});
         $total_port = scalar(@list);
         sort(@list);
         $min = shift(@list);
         $max = pop(@list);

         if ($total_port > $port_Max)
         {
            $_ = $key;
            ($attack_host,$victim_host) = split(/-/,$_);  
            if (($max-$min) < $allow_Time)
            {
               $time_now = localtime();
               open(FILE,">>/project/data/attack.dat");
               print FILE ("$time_now");           
               print FILE ("~Scan Port");
               print FILE ("~$attack_host:$victim_host:Real Time\n");
               close(FILE);
            } else {
               $time_now = localtime(); 
               open(FILE,">>/project/data/attack.dat");
               print FILE ("$time_now");  
               print FILE ("~Scan Port");
               print FILE ("~$attack_host:$victim_host:Collecton\n");
               close(FILE);
            }
            delete($database{$key});
         }  
   }
}
# last modify 14/2/1999
# check port to less than 1024
