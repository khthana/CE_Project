#!/usr/bin/perl

print " :) Syn Flooding Detecter run OK. (: \n";

#init variable
$max_SYN = 100; #maximum syn flag for that allow by server (100)
$backlog = 15; #backlog queue
while (<STDIN>)  # input from pipe of tcpdump -tt -S -n 'tcp' |
{      $temp = s/:|>/ /g;  # cut ':' and '>' discard
       #print "$_"; 
       ($time,$src,$dst,$flag,
       $seq1,$seq2,$ack,$ack_num) =split(/\s+/,$_);

       #state1  --SYN-->    
       if (($flag eq S)and($ack ne ack)) {  
          $_ = $src;   # cut out port
          ($aaa,$bbb,$ccc,$ddd,$port) = split(/\./,$_);
          $src = $aaa."\.".$bbb."\.".$ccc."\.".$ddd; 
          $_ = $dst;   # cut out port
          ($aaa,$bbb,$ccc,$ddd,$port) = split(/\./,$_);
          $dst = $aaa."\.".$bbb."\.".$ccc."\.".$ddd;
 
          $server_key = $dst;  
          if (exists($database{$server_key})) {
              $key = $database{$server_key};
              if (exists($key{$port})) {
                  %{$key{$port}}->{"syn"}++;
                  if (%{$key{$port}}->{"syn"} >= $max_SYN) 
                  {
		#($sec,$min,$hour,$mday,$mon,$year)=(localtime())[0..5];
                     $time_now = localtime();
                     open(FILE,">>/project/data/attack.dat");
          #print FILE ($sec.":".$min.":".$hour.":".$mday.":".$mon.":".$year);
                     print FILE ("$time_now");
                     print FILE ("~TCP SYN Flooding");
                     print FILE ("~$server_key".":".$port.":Max SYN\n"); 
                     close(FILE);
                     delete($key{$port});
                  };
              }
              else {
                  %{$key{$port}}->{"syn"} = 1;
                  %{$key{$port}}->{"syn_ack"} = 0;
              };
          }
          else {
             $database{$server_key} = {
                  $port => {"syn" => 1,
                            "syn_ack" => 0
                           }           
             };  
          };
       };
       #state2 <--- SYN,ACK 
       if (($flag eq S)and($ack eq ack)) {  
          $_ = $dst;   # cut out port
          ($aaa,$bbb,$ccc,$ddd,$port) = split(/\./,$_);
          $dst = $aaa."\.".$bbb."\.".$ccc."\.".$ddd; 
          $_ = $src;   # cut out port
          ($aaa,$bbb,$ccc,$ddd,$port) = split(/\./,$_);
          $src = $aaa."\.".$bbb."\.".$ccc."\.".$ddd;
 
          $server_key = $src;  
          if (exists($database{$server_key})) {
              $key = $database{$server_key};
              if (exists($key{$port})) {
                  if (%{$key{$port}}->{"syn"} > 0) {
                     --(%{$key{$port}}->{"syn"});
                  };
                  ++(%{$key{$port}}->{"syn_ack"});
                  if ((%{$key{$port}}->{"syn_ack"} > $backlog) and 
                     (%{$key{$port}}->{"syn"} > 1)) {
		#($sec,$min,$hour,$mday,$mon,$year)=(localtime())[0..5];
                     $time_now = localtime();
                     open(FILE,">>/project/data/attack.dat");
        # print FILE ($sec.":".$min.":".$hour.":".$mday.":".$mon.":".$year);
                     print FILE ("$time_now");
                     print FILE ("~TCP SYN Flooding");
          print FILE ("~$server_key".":".$port.":Backlog-Queue Full\n"); 
                     close(FILE);
                     delete($key{$port});
                  };
              }
              else {
                  %{$key{$port}}->{"syn"} = 0;
                  %{$key{$port}}->{"syn_ack"} = 1;
              };
          }
          else {
             $database{$server_key} = {
                  $port => {"syn" => 0,
                            "syn_ack" => 1
                           }           
             };  
          };
       };
       #state3 ACK
       if (($flag eq ".")and($seq1 ne ack)) {  
          $_ = $src;   # cut out port
          ($aaa,$bbb,$ccc,$ddd,$port) = split(/\./,$_);
          $src = $aaa."\.".$bbb."\.".$ccc."\.".$ddd; 
          $_ = $dst;   # cut out port
          ($aaa,$bbb,$ccc,$ddd,$port) = split(/\./,$_);
          $dst = $aaa."\.".$bbb."\.".$ccc."\.".$ddd;
 
          $server_key = $dst;  
          if (exists($database{$server_key})) {
              $key = $database{$server_key};
              if (exists($key{$port})) {
                  if ((%{$key{$port}}->{"syn"} == 0) and 
                      (%{$key{$port}}->{"syn_ack"} == 1)) {
                      delete($key{$port});
                  };
                  if ((%{$key{$port}}->{"syn"} >= 1) and
                      (%{$key{$port}}->{"syn_ack"} == 1)) {
                      --(%{$key{$port}}->{"syn_ack"});
                  };
                  if (%{$key{$port}}->{"syn_ack"} > 1) {
                      --(%{$key{$port}}->{"syn_ack"});
                  };
              };
          };
       };
       # state x RST
       if (($flag eq R)and($ack ne ack)) {  
          $_ = $dst;   # cut out port
          ($aaa,$bbb,$ccc,$ddd,$port) = split(/\./,$_);
          $src = $aaa."\.".$bbb."\.".$ccc."\.".$ddd; 
          $_ = $src;   # cut out port
          ($aaa,$bbb,$ccc,$ddd,$port) = split(/\./,$_);
          $dst = $aaa."\.".$bbb."\.".$ccc."\.".$ddd;
 
          $server_key = $src;  
          if (exists($database{$server_key})) {
              $key = $database{$server_key};
              if (exists($key{$port})) {
                  if ((%{$key{$port}}->{"syn"} == 1) and 
                      (%{$key{$port}}->{"syn_ack"} == 0)){
                      delete($key{$port}); 
                  };
                  if ((%{$key{$port}}->{"syn"} > 1) and
                      (%{$key{$port}}->{"syn_ack"} == 0)){
                      --(%{$key{$port}}->{"syn"});
                  };
                  if ((%{$key{$port}}->{"syn"} == 0) and
                      (%{$key{$port}}->{"syn_ack"} == 1)){
                      delete($key{$port});
                  };
                  if ((%{$key{$port}}->{"syn"} >= 1) and
                      (%{$key{$port}}->{"syn_ack"} == 1)){
                      --(%{$key{$port}}->{"syn_ack"});
                  };
                  if (%{$key{$port}}->{"syn_ack"} > 1) {
                      --(%{$key{$port}}->{"syn_ack"});
                  };
              };
          };
       };
};
