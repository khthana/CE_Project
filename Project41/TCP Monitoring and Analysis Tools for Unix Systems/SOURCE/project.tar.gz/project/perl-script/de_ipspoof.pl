#!/usr/bin/perl 

print " :) IP Spoof Detector run OK. (: \n";

open(FILE_MEM,"</project/data/ether-ip.dat");
while (<FILE_MEM>)
{   ($ip_addr,$mac_addr) = split(/\s+/,$_);
     $key = $mac_addr;
     $database{$key} = 
     { "ip_addr" => $ip_addr
     } 
}
close(FILE_MEM);   

while (<STDIN>)  # input from pipe of tcpdump -e -tt -n 'tcp' |
{      
       #print "$_"; 
       ($time,$src_mac,$dst_mac,$type,
       $len,$src_ip,$dir,$dst_ip) =split(/\s+/,$_);

       $_ = $src_ip;   # cut out port 
       ($aaa,$bbb,$ccc,$ddd,$port) = split(/\./,$_);
       $src_ip = $aaa."\.".$bbb."\.".$ccc."\.".$ddd;

       $_ = $dst_ip;   # cut out port
       ($aaa,$bbb,$ccc,$ddd,$port) = split(/\./,$_);
       $dst_ip = $aaa."\.".$bbb."\.".$ccc."\.".$ddd;
    
       #print("     time = $time\n");
       #print("src mac = $src_mac  src ip = $src_ip \n");
       #print("dst mac = $dst_mac  dst ip = $dst_ip\n");      

       if(exists($database{$src_mac}))
       {
         if($src_ip eq %{$database{$src_mac}}->{"ip_addr"})
         {  #print("ok\n");
         }
         else 
         { 
           #($sec,$min,$hour,$mday,$mon,$year)=(localtime())[0..5];
           $time_now = localtime();   
           $correct_ip = %{$database{$src_mac}}->{"ip_addr"};
           $src_mac =~ tr/:/-/; 
           open(FILE,">>/project/data/attack.dat");
          #print FILE ($sec.":".$min.":".$hour.":".$mday.":".$mon.":".$year);
           print FILE ("$time_now");
           print FILE ("~TCP IP-Spoofing");
           print FILE ("~$correct_ip:$src_ip:$src_mac\n");
           close(FILE);
           #print("!not ok\n");
         }
       } 
       else
       {  #print("not exists\n");
       } 
}
