                           READ ME FIRST 
                               FOR 
                INFORMIX CLIENT PRODUCTS VERSION 2.02 
                 FOR MICROSOFT WINDOWS ENVIRONMENTS 
                         DATE: 5/28/1998


OVERVIEW

This file provides important information that arrived too late to include
in the "Informix Client Products Installation Guide for Microsoft Windows
Environments."

This information includes the following:

-  Notes on new installation program version-checking behavior

-  Notes on installing a Microsoft ODBC Driver Manager for INFORMIX-CLI


NEW INSTALLATION PROGRAM VERSION-CHECKING BEHAVIOR

In Informix Client Products Version 2.02, Setup avoids copying files over 
newer versions of the files that are already on your computer. Setup 
compares file versions using either the file system's file date or, for 
.exe and .dll files, a version number stored within the file. It installs 
only files that are newer than existing files. In previous versions some
files were checked by date, while others were overwritten without any 
version checking. 


INSTALLING A MICROSOFT ODBC DRIVER MANAGER

This section contains information about the compatibility of Microsoft 
Driver Manager versions and the ODBC drivers included with this Informix 
sofware release.

This Informix software release includes two 32-bit ODBC drivers:

-  INFORMIX-CLI Version 2.80.0006 complies with ODBC 2.5 and supports 
   extended data types provided by Informix Dynamic Server with Universal
   Data Option. With this ODBC driver, you can use Microsoft Driver Manager
   Version 2.5 or higher.

-  INTERSOLV DataDirect ODBC Driver Version 3.10 complies with ODBC 3.0. 
   You must use Microsoft Driver Manager Version 3.0 or 3.5 with this ODBC driver.

Determining the Driver Manager Version Installed on Your Computer

If ODBC is already installed on your computer, you can determine which version 
of the Microsoft ODBC Driver Manager you have by following the instructions 
in this section.

NOTE: Windows NT 4.0 Service Pack 3 installs ODBC Driver Manager Version 3.0.

1.  Double-click the ODBC icon in the Control Panel. If your Driver Manager 
    is 3.0 or higher, you will see an About tab. Otherwise, go to step 2.
    Click the About tab to see the Driver Manager version.

2.  If there is no About tab, you have a version of Driver Manager lower 
    than version 3.0. In this case, use Windows Explorer to locate the driver 
    file in your Windows SYSTEM directory:

    -  If you have Windows NT, go to the SYSTEM32 subdirectory of your Windows 
       installation directory.

    -  If you have Windows 95, go to the SYSTEM subdirectory of your Windows 
       installation directory.

4.  Select the odbc32.dll file.

5.  Choose File-> Properties.

6.  Click the Version tab to see the Driver Manager version.

Installing an ODBC Driver Manager

Informix Client SDK Version 2.02 includes Microsoft Driver Manager version
3.5. To install Driver Manager from Setup, choose Custom on the Installation
Options dialog box, and then check ODBC DM 3.5 on the Select Installation 
Components dialog box. 

You can also download Driver Manager from the Microsoft web site at
http://www.microsoft.com.
======================================================================
