function [count_char_out]=show_div1(picture_in,pict_div,max_div,count_char_in)
count_char_out_again_2 = 0;
count_char_out = 0;
count_char = count_char_in;  
picture = double(picture_in);
size_picture = size(picture);
wd_size_pict = size_picture(1,2);
hd_size_pict = size_picture(1,1);
map = [0 0 0;1 1 1];
start = 1;
for i = 1:max_div+1
   pict_tmp = ones(hd_size_pict,pict_div(1,start+1)-pict_div(1,start)+2);
   jj = 1;
   for j = pict_div(1,i)+1:pict_div(1,i+1)
      jj = jj+1;
      for k = 1:hd_size_pict
         pict_tmp(k,jj) = picture_in(k,j);
      end
   end
   start = start+1;
   pict_tmp = double(pict_tmp);
   picture_size = size(pict_tmp);
   wd = picture_size(1,2);
   hd = picture_size(1,1);
   pict_tmp1 = ones((hd-2),(wd-2));
   for i = 1:(hd-2)
      for j = 1:(wd-2)
           pict_tmp1(i,j)=pict_tmp((i+1),(j+1));
      end
   end
   if ((any(all(pict_tmp1)')==1)|(any(all(pict_tmp1'))==1))
      [count_char_out_again_2] = again_1(pict_tmp,map,count_char);
      count_char = count_char_out_again_2; 
   else 
      count_char = count_char+1;    
      directory = strcat(pwd,'\');
      name_pic = strcat('Char_',num2str(count_char),'.bmp');
      full_name = strcat(directory,name_pic);
      imwrite(uint8(pict_tmp),map,full_name,'bmp');
   end 
 end
 count_char_out = count_char;
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
 