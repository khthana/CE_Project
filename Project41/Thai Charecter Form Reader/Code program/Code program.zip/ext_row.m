function [row_data]=extract_row(x,info);
row_1=rownon_0(x);
b=1;
temp=row_1(1,1);
if temp~=0 
   for a=2:info.Height 
      if (row_1(a,1)==not(temp))
         y(b)=a;
         temp=row_1(a,1);
         b=b+1;
      end
   end
end
if temp==0
   y(1)=1;
   b=2;
   for a=2:info.Height 
      if (row_1(a,1)==not(temp))
         y(b)=a;
         temp=row_1(a,1);
         b=b+1;
      end
   end
end
row_data=y';

