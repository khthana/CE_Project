% main aaa
more off;
echo off;
clc;
count_char_out = 0;
count_char = 0;
cout_out = 0;
nn = 0;
mm = 0;
pwd_image_file = strcat(pwd,'\block.bmp');
  info = imfinfo(pwd_image_file);
  [x,map]=imread(pwd_image_file);
  [row_data_1] = ext_row(x,info);
  size_row_data = size(row_data_1);
  row_data_max  = size_row_data(1,1);
  picture_max1  = row_data_max/2;
  start_1 = 1;
  map = [0 0 0;1 1 1];
  for d=1:picture_max1
     picture=ones(info.Height,info.Width);
     for a=row_data_1(start_1):((row_data_1(start_1+1))-1)
           for b=1:info.Width
              picture(a,b)=x(a,b);
           end
     end
     start_1 = start_1+2;
     picture=uint8(picture);
     image(picture);
     colormap(map);
     choice = questdlg('�ӡ�úѹ�֡����ٻ�Ҿ�������      ',' Image Processing ','Yes','No','No');
     switch choice,
        case 'Yes',
           show=strcat('Save As Line Picture_',num2str(d));
           [save_image_file,save_pwd]=uiputfile('*.bmp',show);
           if (save_image_file~=0)
              save_pwd_image_file = strcat(save_pwd,save_image_file);
              imwrite(picture,map,save_pwd_image_file,'bmp');
           end
      end
  ch1 = questdlg('�ӡ�õѴ�¡����ѡ��    ',' Image Processing','Yes','No','Exit','Exit');  
  switch ch1,
     case 'Yes',
     xx = picture;
     [col_data] = ext_col(xx,info);
     [row_data_2] = ext_row(xx,info);
     size_pict_height = row_data_2(2)-(row_data_2(1)-1);
     size_col_data = size(col_data);
     col_data_max  = size_col_data(1,2);
     picture_max2   = col_data_max/2;
     start_2 = 1;
     for d=1:picture_max2
        size_pict_width = col_data(start_2+1)-col_data(start_2);
        picture=ones(size_pict_height,size_pict_width);
        cc=1;
        for k=(col_data(start_2)-1):(col_data(start_2+1))
           rr=0;
             for l=(row_data_2(1)-1):row_data_2(2)
               rr=rr+1;
               picture(rr,cc)=x(l,k);
             end
             cc=cc+1;    
        end
        start_2 = start_2+2;
        picture=uint8(picture);
        image(picture);
        colormap(map);
             picture = double(picture);
             picture_size = size(picture);
             wd = picture_size(1,2);
             hd = picture_size(1,1);
             picture_temp = ones((hd-2),(wd-2));
             for i = 1:(hd-2)
                for j = 1:(wd-2)
                   picture_temp(i,j)=picture((i+1),(j+1));
                end
             end
             if ((any(all(picture_temp)')==1)|(any(all(picture_temp'))==1))
              ch_ext_again = questdlg('�Ҿ����ѧ�ա�����������Ӣͧ����ѡ������ �ӡ���¡����ѡ���ա���� ?    ',' Image Processing','Yes','No','Yes');  
             switch ch_ext_again,
             case 'Yes',
                  [count_char_out] = again_2(picture,map,count_char);
                  count_char = count_char_out;
              end
           else 
             [mm,nn]= div_sp2(picture);
             if (nn~=0)
                errordlg('�Ҿ����ѧ�ա�����������Ӣͧ����ѡ������ �ӡ���¡����ѡ���ա���� ?    ',' Image Processing ');
                waitforbuttonpress;
                [cout_out]=showdiv2(picture,mm,nn,count_char);
                count_char =cout_out;
             else
                 errordlg(' �Ҿ����繵���ѡ������������������ö�¡�͡���ա����     ',' Image Processing ');   
                 waitforbuttonpress;
                 count_char = count_char+1;
                 choice = questdlg('�ӡ�úѹ�֡����ٻ�Ҿ�������      ',' Image Processing ','Yes','No','No');
                 switch choice,
                 case 'Yes',
                    show=strcat('Save As Charactor Picture_',num2str(d));
                    [save_image_file,save_pwd]=uiputfile('*.bmp',show);
                     if (save_image_file~=0)
                        save_pwd_image_file = strcat(save_pwd,save_image_file);
                        imwrite(picture,map,save_pwd_image_file,'bmp');
                     end
                 end
             end
           end 
      end
  case 'Exit'
     return;
  end   
  errordlg('  �ӡ�û����żŷ���÷Ѵ����    ',' Image Processing');
  waitforbuttonpress;
  end

   