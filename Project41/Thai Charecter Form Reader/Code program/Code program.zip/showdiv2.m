function [count_char_out]=showdiv2(picture_in,pict_div,max_div,count_char_in)
count_char_out = 0;
count_chat_out1 = 0;
count_char = count_char_in;
picture = double(picture_in);
size_picture = size(picture);
wd_size_pict = size_picture(1,2);
hd_size_pict = size_picture(1,1);
map = [0 0 0;1 1 1];
start = 1;

for i = 1:max_div+1
   pict_tmp = ones(hd_size_pict,pict_div(1,start+1)-pict_div(1,start)+2);
   jj = 1;
   for j = pict_div(1,i)+1:pict_div(1,i+1)
      jj = jj+1;
      for k = 1:hd_size_pict
         pict_tmp(k,jj) = picture_in(k,j);         
      end
   end
   start = start+1;   
   image(uint8(pict_tmp));
   colormap(map);   
             pict_tmp = double(pict_tmp);
             picture_size = size(pict_tmp);
             wd = picture_size(1,2);
             hd = picture_size(1,1);
             pict_tmp1 = ones((hd-2),(wd-2));
             for i = 1:(hd-2)
                for j = 1:(wd-2)
                   pict_tmp1(i,j)=pict_tmp((i+1),(j+1));
                end
             end
         
         if ((any(all(pict_tmp1)')==1)|(any(all(pict_tmp1'))==1))
              ch_ext_again = questdlg('�Ҿ����ѧ�ա�����������Ӣͧ����ѡ������ �ӡ���¡����ѡ���ա���� ?    ',' Image Processing','Yes','No','Yes');    
             switch ch_ext_again,
             case 'Yes',
                [count_char_out1] = again_2(pict_tmp,map,count_char);
                count_char = count_char_out1;                  
             end
          else 
              errordlg('  �Ҿ����繵���ѡ������������������ö�¡�͡���ա����     ',' Image Processing ');   
              waitforbuttonpress;
              count_char = count_char+1;              
         choice = questdlg('�ӡ�úѹ�֡����ٻ�Ҿ�������      ',' Image Processing ','Yes','No','No');

         switch choice,
         case 'Yes',
                [save_image_file,save_pwd]=uiputfile('*.bmp','  Save As Charactor  ??? ');
                if (save_image_file~=0)
                   save_pwd_image_file = strcat(save_pwd,save_image_file);
                   imwrite(pict_tmp,map,save_pwd_image_file,'bmp');
                end
         end                                                       
     end 
 end
   
 count_char_out=count_char;
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
 