function [pict_div,max_div] = div_sp1(picture)
picture = double(picture);
size_picture = size(picture);
wd_size_pict = size_picture(1,2);
hd_size_pict = size_picture(1,1);
pict_div = 0;
max_div = 0;
status = 0;
kk = 0;
pos = zeros(hd_size_pict,1);
count_pict = zeros(1,wd_size_pict);
count_pict(1,1) = 1;
for i = 3:(wd_size_pict-1)
   for j = 2:hd_size_pict
      if (picture(j,i)==0)
         if (picture(j-1,i-1)==0)
            status = 1;
         elseif (picture(j,i-1)==0)
            status = 1;
         elseif (picture(j+1,i-1)==0)
            status = 1;
         else
            status = 0;
         end
         pos(j,1) = status;
       else 
         status = 0;
         pos(j,1) = status;
      end
   end
   if (any(pos)==0)
      kk = kk + 1;
      count_pict(1,kk+1) = i-1;
   end
end
count_pict(1,kk+2)= wd_size_pict-1;
max_div = kk;
pict_div = count_pict;















