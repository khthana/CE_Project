% Main  process1 ;  

clear;
more off;
echo off;
clc;
count_char_a = 0;
count_char = 0;
aaaa = 0;
mm = 0;
nn = 0;

[image_file,pwd]=uigetfile('Image File;*.bmp;*.jpg;*.pcx;*.tif;*.hdf;*.xwd','Open Image File');

if ((image_file==0)&(pwd==0)) 
   warndlg(' ¡��ԡ������͡��� ��ŧ ',' Image Processing ');
   waitforbuttonpress;
   return;
end

pwd_image_file = strcat(pwd,image_file);
info = imfinfo(pwd_image_file);
[x,map]=imread(pwd_image_file);
image(x);
colormap(map);
[row_data_1]=ext_row(x,info);
size_row_data = size(row_data_1);
row_data_max  = size_row_data(1,1);
picture_max1   = row_data_max/2;
start_1 = 1;
map = [0 0 0;1 1 1];
  
for d=1:picture_max1
     picture=ones(info.Height,info.Width);
     for a=row_data_1(start_1):((row_data_1(start_1+1))-1)
           for b=1:info.Width
               picture(a,b)=x(a,b);
           end
     end
     start_1 = start_1+2;
     picture=uint8(picture);
     xx = picture;
     [col_data] = ext_col(xx,info);
     [row_data_2] = ext_row(xx,info);
     size_pict_height = row_data_2(2)-(row_data_2(1)-1);
     size_col_data = size(col_data);
     col_data_max  = size_col_data(1,2);
     picture_max2   = col_data_max/2;
     start = 1;
     for d=1:picture_max2
        size_pict_width = col_data(start+1)-col_data(start);
        picture=ones(size_pict_height,size_pict_width);
        cc=1;
        for k=(col_data(start)-1):(col_data(start+1))
           rr=0;
             for l=(row_data_2(1)-1):row_data_2(2)
               rr=rr+1;
               picture(rr,cc)=x(l,k);
             end
             cc=cc+1;    
        end
        start = start+2;
        picture=uint8(picture);
        picture = double(picture);
        picture_size = size(picture);
        wd = picture_size(1,2);
        hd = picture_size(1,1);
        picture_temp = ones((hd-2),(wd-2));
        for i = 1:(hd-2)
            for j = 1:(wd-2)
                picture_temp(i,j)=picture((i+1),(j+1));
            end
        end
        if ((any(all(picture_temp)')==1)|(any(all(picture_temp'))==1))
            [count_char_a] = again_1(picture,map,count_char);
            count_char = count_char_a;
         else
            [mm,nn]= div_sp1(picture);
            if (nn~=0)
                   [aaaa]=showdiv1(picture,mm,nn,count_char);
                   count_char=aaaa;
            else
                    count_char = count_char+1;
                    directory = strcat(pwd,'\');
                    name_pic = strcat('Char_',num2str(count_char),'.bmp');
                    full_name = strcat(directory,name_pic);
                    imwrite(uint8(picture),map,full_name,'bmp');
             end
         end 
      end
  end
  errordlg(' ���ͺ��è��ӤӡѺ�ҹ�����ŷ���������¡�����¡����� ',' Image Processing ');
  waitforbuttonpress;
for pp = 1:count_char
   pwd_seg = pwd;
   name_seg = strcat(pwd_seg,'Char_',num2str(pp),'.bmp');
   [zz,map]=imread(name_seg,'bmp');
   eval(['Seg_'num2str(pp) '=zz']);
end
delete Char*.bmp
load angsana;
load cordial;
Zero_tag = '0';
seg_max = count_char;  
max_type_char = 2;   
  for i = 1:seg_max
     a =strcat('Seg_',num2str(i));
     found = 0;
     for k = 1:max_type_char
        if (k==1) 
           type = 'A_';  max_char_of_type = 140;  
        else  
           type = 'C_';  max_char_of_type = 140;  
        end
        for j = 1:max_char_of_type
           aa=strcat(type,num2str(j));
           b = eval(a); 
           b = double(b);
           bb = eval(aa);
           bb = double(bb);
           if size(b)==size(bb)
              if (double(b)==double(bb))
                 eval(['S_'num2str(i) ' = strcat(type,num2str(j))']);
  	 found=1;
                 break;
              end
           end
         end
     end
      if (found==0)           
        eval(['S_'num2str(i) ' = Zero_tag']);
	   end
  end
     
     % calculator %
  if ((size(eval(S_1))==size(A_140))|(size(eval(S_1))==size(C_140)))
        
     if all(((S_1=='A_140')|(S_1=='C_140'))')&all(((S_2=='A_49')|(S_2=='C_49'))')&all(((S_3=='A_46')|(S_3=='C_46'))')&all(((S_4=='A_50')|(S_4=='C_50'))')&all(((S_5=='A_3')|(S_5=='C_3'))')&all(((S_6=='A_33')|(S_6=='C_33'))')&all(((S_7=='A_41')|(S_7=='C_41'))')&all(((S_8=='A_5')|(S_8=='C_5'))')&all(((S_9=='A_3')|(S_9=='C_3'))')&all(((S_10=='A_18')|(S_10=='C_18'))')&all(((S_11=='A_50')|(S_11=='C_50'))')&all(((S_12=='A_34')|(S_12=='C_34'))')&all(((S_13=='A_2')|(S_13=='C_2'))')
        dos('calc.exe');    
     end
     
     % Paint Brush
  elseif ((size(eval(S_1))==size(A_35))|(size(eval(S_1))==size(C_35)))
     
     if all(((S_1=='A_35')|(S_1=='C_35'))')&all(((S_2=='A_45')|(S_2=='C_45'))')&all(((S_3=='A_18')|(S_3=='C_18'))')&all(((S_4=='A_33')|(S_4=='C_33'))')&all(((S_5=='A_25')|(S_5=='C_25'))')&all(((S_6=='A_61')|(S_6=='C_61'))')
        dos('pbrush.exe');
     end
     
     % Cdplayer
  elseif ((size(eval(S_1))==size(A_47))|(size(eval(S_2))==size(C_47)))
     
     if all(((S_2=='A_47')|(S_2=='C_47'))')&all(((S_3=='A_9')|(S_3=='C_9'))')&all(((S_4=='A_18')|(S_4=='C_18'))')&all(((S_5=='A_50')|(S_5=='C_50'))')&all(((S_6=='A_28')|(S_6=='C_28'))')&all(((S_7=='A_34')|(S_7=='C_34'))')&all(((S_8=='A_5')|(S_8=='C_5'))')
        dos('cdplayer.exe');    
     end
     
     % Document Wordpad
  elseif ((size(eval(S_1))==size(A_50))|(size(eval(S_1))==size(C_50)))
     
     if all(((S_1=='A_50')|(S_1=='C_50'))')&all(((S_2=='A_41')|(S_2=='C_41'))')&all(((S_3=='A_1')|(S_3=='C_1'))')&all(((S_4=='A_38')|(S_4=='C_38'))')&all(((S_5=='A_45')|(S_5=='C_45'))')&all(((S_6=='A_33')|(S_6=='C_33'))')
        dos('write.exe');
     end
     
     %  Media Player
  elseif ((size(eval(S_1))==size(A_43))|(size(eval(S_1))==size(C_43)))
     
     if all(((S_1=='A_43')|(S_1=='C_43'))')&all(((S_2=='A_18')|(S_2=='C_18'))')&all(((S_3=='A_39')|(S_3=='C_39'))')&all(((S_4=='A_23')|(S_4=='C_23'))')&all(((S_5=='A_5')|(S_5=='C_5'))')&all(((S_6=='A_61')|(S_6=='C_61'))')
        dos('mplayer.exe');
     end

  else
     
     warndlg(' �������ö Match �Ѻ������� Database ��',' Image Processing ');
     waitforbuttonpress;
     
   end
  
   [xx,mapxx]=imread('logo.bmp');
   image(xx);
   colormap(mapxx);  
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
