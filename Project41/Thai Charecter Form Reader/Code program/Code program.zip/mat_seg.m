

load angsana;
load cordial;

   
seg_max = count_char;  
max_type_char = 2;   
max_char_of_type = 140;  
  
  for i = 1:seg_max
     
     a =strcat('Seg_',num2str(i));
%     seg_match = strcat('Seg_match_',num2str(i));
     for k = 1:max_type_char
        if (k==1) 
           type = 'A_'; 
        else  
           type = 'C_'; max_char_of_type = 139;
        end
   
        for j = 1:max_char_of_type
           aa=strcat(type,num2str(j));
           b = eval(a); 
           b = double(b);
           bb = eval(aa);
           bb = double(bb);
           if size(b)==size(bb)
              
              if (double(b)==double(bb))
                 eval (['S_'num2str(i) '= strcat(type,num2str(j))']);
                
              end
               
           end
         end
     end
  end