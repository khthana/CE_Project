% main process3 
clear;
more off;
echo off;
clc;
[image_file,pwd]=uigetfile('Image File;*.bmp;*.jpg;*.pcx;*.tif;*.hdf;*.xwd','Open Image File');
if ((image_file==0)&(pwd==0)) 
   warndlg(' ¡��ԡ������͡��� ��ŧ    ',' Image Processing ');
   waitforbuttonpress;
   return;
end
pwd_image_file = strcat(pwd,image_file);
info = imfinfo(pwd_image_file);
[x,map]=imread(pwd_image_file);
image(x);
colormap(map);
errordlg('�Ҿ������鹩�Ѻ �ӡ���¡�������ͧ����� ',' Image Processing ');
waitforbuttonpress;
[row_data_1]=ext_row(x,info);
size_row_data = size(row_data_1);
row_data_max  = size_row_data(1,1);
picture_max_1   = row_data_max/2;
height = row_data_1(2)-row_data_1(1)+1;
width  = info.Width;
picture = ones(height,width);
start_1 = 1;
ii = 1;
jj = 1;
map = [0 0 0;1 1 1];
x1=x;
x2=x;
x3=x;
x4=x;
x5=x;
x6=x;
x7=x;
x8=x;
x9=x;

for i = row_data_1(1)-1:row_data_1(2)
   jj = 1;
   for j = 1:width
      picture(ii,jj) = x(i,j);
      jj = jj+1;
   end
   ii = ii+1;
end
map = [0 0 0;1 1 1];
xx = picture;
size_xx = size(xx);
load ext_form;
form1 = double(form1);
form2 = double(form2);
size_form1 = size(form1);
size_form2 = size(form2);

if (size_xx==size_form1)
   if (xx==form1)
      errordlg(' �ٻẺ������� �Ӣ�����¹�礢ͧ��Ҥ�� �����żŵ��� ',' Image Processing ');
      waitforbuttonpress;
      pos_x = [706,1102,592,1102,548,1102,80,1015,188,1102,608,1102,453,908];
      pos_y = [113,206,213,272,279,338,349,405,412,471,487,537,615,773];
      errordlg('  �ʴ��ѹ���ͧ����� �ѧ�ٻ���� ',' Image Processing ');
      waitforbuttonpress;
      [block1]=gen_pic(x1,pos_x(1,1),pos_x(1,2),pos_y(1,1),pos_y(1,2));
      image(uint8(block1));
      colormap(map);
     choice = questdlg('�ӡ�úѹ�֡����ٻ�Ҿ�������   ',' Image Processing ','Yes','No','No');
     switch choice,
        case 'Yes',
           show=strcat('Save As Line Picture_',num2str(d));
           [save_image_file,save_pwd]=uiputfile('*.bmp',show);
           if (save_image_file~=0)
              save_pwd_image_file = strcat(save_pwd,save_image_file);
              imwrite(block1,map,save_pwd_image_file,'bmp');
           end
      end
      ch = questdlg(' �ӡ�õѴ�¡����ѡ�� ',' Image Processing ','Yes','No','Exit','Yes');
      switch ch,
      case 'Yes'
         save_im = strcat(pwd,'\block.bmp');
         imwrite(uint8(block1),map,save_im,'bmp');
         aaa;
         delete block.bmp
      case 'Exit'
         [xx,mapxx]=imread('logo.bmp');
         image(xx);
         colormap(mapxx);  
         return;
      end
      errordlg('  �ʴ��ҢҸ�Ҥ�âͧ����� �ѧ�ٻ����  ',' Image Processing ');
      waitforbuttonpress;
      [block2]=gen_pic(x2,pos_x(1,3),pos_x(1,4),pos_y(1,3),pos_y(1,4));
      image(uint8(block2));
      colormap(map);
     choice = questdlg('�ӡ�úѹ�֡����ٻ�Ҿ�������   ',' Image Processing ','Yes','No','No');
     switch choice,
        case 'Yes',
           show=strcat('Save As Line Picture_',num2str(d));
           [save_image_file,save_pwd]=uiputfile('*.bmp',show);
           if (save_image_file~=0)
              save_pwd_image_file = strcat(save_pwd,save_image_file);
              imwrite(block2,map,save_pwd_image_file,'bmp');
           end
      end
      ch = questdlg(' �ӡ�õѴ�¡����ѡ�� ',' Image Processing ','Yes','No','Exit','Yes');
      switch ch,
      case 'Yes'
         save_im = strcat(pwd,'\block.bmp');
         imwrite(uint8(block2),map,save_im,'bmp');
         aaa;
         delete block.bmp
      case 'Exit'
         [xx,mapxx]=imread('logo.bmp');
         image(xx);
         colormap(mapxx);  
         return;
      end
      errordlg('  �ʴ��ӹǹ�Թ�繵���Ţ �ѧ�ٻ����  ',' Image Processing ');
      waitforbuttonpress;
      [block3]=gen_pic(x3,pos_x(1,5),pos_x(1,6),pos_y(1,5),pos_y(1,6));
      image(uint8(block3));
      colormap(map);
     choice = questdlg('�ӡ�úѹ�֡����ٻ�Ҿ�������   ',' Image Processing ','Yes','No','No');
     switch choice,
        case 'Yes',
           show=strcat('Save As Line Picture_',num2str(d));
           [save_image_file,save_pwd]=uiputfile('*.bmp',show);
           if (save_image_file~=0)
              save_pwd_image_file = strcat(save_pwd,save_image_file);
              imwrite(block3,map,save_pwd_image_file,'bmp');
           end
      end
      ch = questdlg(' �ӡ�õѴ�¡����ѡ�� ',' Image Processing ','Yes','No','Exit','Yes');      
      switch ch,
      case 'Yes'
         save_im = strcat(pwd,'\block.bmp');
         imwrite(uint8(block3),map,save_im,'bmp');
         aaa;
         delete block.bmp
      case 'Exit'
         [xx,mapxx]=imread('logo.bmp');
         image(xx);
         colormap(mapxx);           
         return;
      end
      errordlg('  �ʴ��ӹǹ�Թ�繵���ѡ�� �ѧ�ٻ����  ',' Image Processing ');
      waitforbuttonpress;
      [block4]=gen_pic(x4,pos_x(1,7),pos_x(1,8),pos_y(1,7),pos_y(1,8));
      image(uint8(block4));
      colormap(map);
     choice = questdlg('�ӡ�úѹ�֡����ٻ�Ҿ�������   ',' Image Processing ','Yes','No','No');
     switch choice,
        case 'Yes',
           show=strcat('Save As Line Picture_',num2str(d));
           [save_image_file,save_pwd]=uiputfile('*.bmp',show);
           if (save_image_file~=0)
              save_pwd_image_file = strcat(save_pwd,save_image_file);
              imwrite(block4,map,save_pwd_image_file,'bmp');
           end
      end
      ch = questdlg(' �ӡ�õѴ�¡����ѡ�� ',' Image Processing ','Yes','No','Exit','Yes');      
      switch ch,
      case 'Yes'
         save_im = strcat(pwd,'\block.bmp');
         imwrite(uint8(block4),map,save_im,'bmp');
         aaa;
         delete block.bmp
      case 'Exit'
         [xx,mapxx]=imread('logo.bmp');
         image(xx);
         colormap(mapxx);  
         return;
      end
      errordlg('  �ʴ���è������Ѻ... �ѧ�ٻ����  ',' Image Processing ');
      waitforbuttonpress;
      [block5]=gen_pic(x5,pos_x(1,9),pos_x(1,10),pos_y(1,9),pos_y(1,10));
      image(uint8(block5));
      colormap(map);
     choice = questdlg('�ӡ�úѹ�֡����ٻ�Ҿ�������   ',' Image Processing ','Yes','No','No');
     switch choice,
        case 'Yes',
           show=strcat('Save As Line Picture_',num2str(d));
           [save_image_file,save_pwd]=uiputfile('*.bmp',show);
           if (save_image_file~=0)
              save_pwd_image_file = strcat(save_pwd,save_image_file);
              imwrite(block5,map,save_pwd_image_file,'bmp');
           end
      end
      ch = questdlg(' �ӡ�õѴ�¡����ѡ�� ',' Image Processing ','Yes','No','Exit','Yes');      
      switch ch,
      case 'Yes'
         save_im = strcat(pwd,'\block.bmp');
         imwrite(uint8(block5),map,save_im,'bmp');
         aaa;
         delete block.bmp
      case 'Exit'
         [xx,mapxx]=imread('logo.bmp');
         image(xx);
         colormap(mapxx);  
         return;
      end
      errordlg('��Ǩ�ͺ������Թʴ������ ',' Image Processing');
      waitforbuttonpress;
      [box1] = gen_pic(x8,319,347,510,536);
      [box2] = gen_pic(x9,443,468,510,537);
      check_box1 = all(all(double(box1))');
      check_box2 = all(all(double(box2))');
      if (check_box1==0)
         questdlg('���ͺ�Թʴ��� ',' Image Processing ','OK','OK');
      elseif (check_box2==0)
         questdlg('���ͺ���Ţ���.. �ѧ�ٻ���� ',' Image Processing ','OK','OK');
         [block6]=gen_pic(x6,pos_x(1,11),pos_x(1,12),pos_y(1,11),pos_y(1,12));
         image(uint8(block6));
         colormap(map);
        choice = questdlg('�ӡ�úѹ�֡����ٻ�Ҿ�������   ',' Image Processing ','Yes','No','No');
        switch choice,
        case 'Yes',
           show=strcat('Save As Line Picture_',num2str(d));
           [save_image_file,save_pwd]=uiputfile('*.bmp',show);
           if (save_image_file~=0)
              save_pwd_image_file = strcat(save_pwd,save_image_file);
              imwrite(block6,map,save_pwd_image_file,'bmp');
           end
        end

         ch = questdlg(' �ӡ�õѴ�¡����ѡ�� ',' Image Processing ','Yes','No','Exit','Yes');        
         switch ch,
         case 'Yes'
            save_im = strcat(pwd,'\block.bmp');
            imwrite(uint8(block6),map,save_im,'bmp');
            aaa;
            delete block.bmp
         case 'Exit'
            [xx,mapxx]=imread('logo.bmp');
            image(xx);
            colormap(mapxx);  
            return;
         end
      end
      errordlg('  �ʴ����ŧ����...���� �ѧ�ٻ����  ',' Image Processing ');
      waitforbuttonpress;
      [block7]=gen_pic(x7,pos_x(1,13),pos_x(1,14),pos_y(1,13),pos_y(1,14));
      image(uint8(block7));
      colormap(map);
      choice = questdlg('�ӡ�úѹ�֡����ٻ�Ҿ�������   ',' Image Processing ','Yes','No','No');
      switch choice,
      case 'Yes',
           show=strcat('Save As Line Picture_',num2str(d));
           [save_image_file,save_pwd]=uiputfile('*.bmp',show);
           if (save_image_file~=0)
              save_pwd_image_file = strcat(save_pwd,save_image_file);
              imwrite(block7,map,save_pwd_image_file,'bmp');
           end
      end
      ch = questdlg(' �ӡ�õѴ�¡����ѡ�� ',' Image Processing ','Yes','No','Exit','Yes');  
      switch ch,
      case 'Yes'
         save_im = strcat(pwd,'\block.bmp');
         imwrite(uint8(block7),map,save_im,'bmp');
         aaa;
         delete block.bmp
      case 'Exit'
         [xx,mapxx]=imread('logo.bmp');
         image(xx);
         colormap(mapxx);  
         return;
         
      end
   end
elseif (size_xx==size_form2)
   if (xx==form2)
      errordlg(' �ٻẺ������� �Ӣͫ����礢ͧ��ѭ �����żŵ��� ',' Image Processing ');
      waitforbuttonpress;
   end
else 
   errordlg (' �������ö�ҿ������� match �ѹ�� ',' Image Processing ');
   waitforbuttonpress;
end
questdlg('  ����ش��û����ż�㹿������� ',' Image Processing ','OK','OK');
[xx,mapxx]=imread('logo.bmp');
image(xx);
colormap(mapxx);  

