function [count_char_out] =again_1(picture_in,map,count_char_in);
count_char_1 = 0;
mm = 0;
nn = 0;
bbbb = 0;
picture=0;   
map = [0 0 0;1 1 1];
count_char = count_char_in;
count_char_out=0;   
picture_size1 = size(picture_in);
Height1 = picture_size1(1,1);
Width1  = picture_size1(1,2);
row_1=rownon_0(picture_in);
b=1;
temp=row_1(1,1);
if temp~=0 
   for a=2:Height1 
      if (row_1(a,1)==not(temp))
         y(b)=a;
         temp=row_1(a,1);
         b=b+1;
      end
   end
end
if temp==0
   y(1)=1;
   b=2;
   for a=2:Height1 
      if (row_1(a,1)==not(temp))
         y(b)=a;
         temp=row_1(a,1);
         b=b+1;
      end
   end
end
row_data=y';
row_data_1 = row_data;
size_row_data = size(row_data_1);
row_data_max  = size_row_data(1,1);
picture_max1   = row_data_max/2;
start_1 = 1;
for d=1:picture_max1
     picture=ones(Height1,Width1);
     for a=row_data_1(start_1):((row_data_1(start_1+1))-1)
           for b=1:Width1
               picture(a,b)=picture_in(a,b);
           end
     end
     start_1 = start_1+2;
     picture=uint8(picture);
     xx = picture;
     col_1=colnon_0(xx);
     picture_size2 = size(xx);
     Height2 = picture_size2(1,1);
     Width2  = picture_size2(1,2);
     b=1;
        temp=col_1(1,1);
        if temp~=0 
           for a=2:Width2
              if (col_1(1,a)==not(temp))
                 w(b)=a;
                 temp=col_1(1,a);
                 b=b+1;
               end
            end
        end
        if temp==0
           w(1)=1;
           b = 2;
           for a=2:Width2 
              if (col_1(1,a)==not(temp))
                 w(b)=a;
                 temp=col_1(1,a);
                 b=b+1;
              end
           end
        end
        col_data1 = w;
        col_data = col_data1;
        picture_size2 = size(xx);
        Height2 = picture_size2(1,1);
        Width2  = picture_size2(1,2);
        row_1 = rownon_0(picture);
        b=1;
        temp=row_1(1,1);
        if temp~=0 
           for a=2:Height2 
              if (row_1(a,1)==not(temp))
                 y(b)=a;
                 temp=row_1(a,1);
                 b=b+1;
              end
           end
        end
        if temp==0
           y(1)=1;
           b=2;
           for a=2:Height2 
              if (row_1(a,1)==not(temp))
                 y(b)=a;
                 temp=row_1(a,1);
                 b=b+1;
              end
           end
        end
        row_data=y';
        [row_data_2] = row_data;
        size_pict_height = row_data_2(2)-(row_data_2(1)-1);
        size_col_data = size(col_data);
        col_data_max  = size_col_data(1,2);
        picture_max2   = col_data_max/2;
        start = 1;
        for d=1:picture_max2
           size_pict_width = col_data(start+1)-col_data(start);
           picture=ones(size_pict_height,size_pict_width);
           cc=1;
           for k=(col_data(start)-1):(col_data(start+1))
              rr=0;
              for l=(row_data_2(1)-1):row_data_2(2)
                 rr=rr+1;
                 picture(rr,cc)=picture_in(l,k);
              end
              cc=cc+1;    
           end
           start = start+2;
           picture = uint8(picture);
           picture = double(picture);
           picture_size = size(picture);
           wd = picture_size(1,2);
           hd = picture_size(1,1);
           picture_temp = ones((hd-2),(wd-2));
             for i = 1:(hd-2)
                for j = 1:(wd-2)
                   picture_temp(i,j)=picture((i+1),(j+1));
                end
             end
             if ((any(all(picture_temp)')==1)|(any(all(picture_temp'))==1))
                  [count_char_1] = again_1(picture,map,count_char);
                  count_char = count_char_1;
             else 
                  [mm,nn]= div_sp1(picture);
                  if (nn~=0)
                     [bbbb]=showdiv1(picture,mm,nn,count_char);
                     count_char = bbbb;
                  else
                     count_char = count_char+1;
                     directory = strcat(pwd,'\');;
                     name_pic = strcat('Char_',num2str(count_char),'.bmp');
                     full_name = strcat(directory,name_pic);
                     imwrite(uint8(picture),map,full_name,'bmp');
                  end
           end    
        end
     end   
     count_char_out = count_char;
  
 