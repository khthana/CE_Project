function [col_data]=extract_col(x,info);
col_1=colnon_0(x);
b=1;
temp=col_1(1,1);
if temp~=0 
   for a=2:info.Width 
      if (col_1(1,a)==not(temp))
         w(b)=a;
         temp=col_1(1,a);
         b=b+1;
      end
   end
end
if temp==0
   w(1)=1;
   b = 2;
   for a=2:info.Width 
      if (col_1(1,a)==not(temp))
         w(b)=a;
         temp=col_1(1,a);
         b=b+1;
      end
   end
 end
 col_data=w;

