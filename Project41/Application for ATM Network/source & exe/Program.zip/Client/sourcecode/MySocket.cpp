// MySocket.cpp: implementation of the MySocket class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "MySocket.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


MySocket::MySocket()
{

}

MySocket::MySocket(int Addr,int Sock,int Protocol,int maxsendbuf,int maxreceivebuf,CListBox * Log)
//:CWinThread()
{
	AddressFamily=Addr;
	SocketType=Sock;
	ProtocolType=Protocol;
	Terminated=false;
	EventLog=Log;
	SizeofSendBuffer=maxsendbuf*1024;
	SizeofReceiveBuffer=maxreceivebuf*1024;
	ReceiveBuffer.len=SizeofReceiveBuffer;
	ReceiveBuffer.buf=new char[SizeofReceiveBuffer];
	SendBuffer.len=SizeofSendBuffer;
	SendBuffer.buf=new char[SizeofSendBuffer];

	//CreateThread(CREATE_SUSPENDED,0,NULL);

}

MySocket::~MySocket()
{

}

void MySocket::PutEventMessage(char* Message)
{
	EventLog->AddString(Message);
}
//create socket
bool MySocket::CreateSocket()
{
	char temp[256];
	char error[256];
    s=WSASocket(AddressFamily,SocketType,ProtocolType,NULL,0,0);
    if (s==INVALID_SOCKET)
    {
		strcpy(temp,"Could not create socket");
		_itoa(WSAGetLastError(),error,10);
         PutEventMessage(strcat(temp,error));
		 return false;
    }
    else
    {
        PutEventMessage("Socket Create OK");
		return true;
    }

}
//close socket
bool MySocket::CloseSocket()
{
	char temp[256];
	char error[256];
	if (closesocket(s)==SOCKET_ERROR)
	{
		strcpy(temp,"Could not create socket");
		_itoa(WSAGetLastError(),error,10);
		PutEventMessage(strcat(temp,error));
		return false;
	}
	else
	{
		PutEventMessage("Close socket OK");
		return true;
	}

}

//set sendbuffer 
void MySocket::SetSendBuffer(char* sendbuf,int length)
{
	memset(SendBuffer.buf,0,SendBuffer.len);
	memmove(SendBuffer.buf,header,10);
	memmove(SendBuffer.buf+10,sendbuf,length);
}

//get only data from receive buffer
void MySocket::GetReceiveBuffer(char* temp)
{
	char* temp1=ReceiveBuffer.buf+=sizeof(char)*10;
	memmove(temp,temp1,ReceiveBuffer.len-10);
}

//get only header from receive buffer
char* MySocket::GetHeader()
{
	memcpy(header,ReceiveBuffer.buf,sizeof(char)*10);
	header[10]='\0';
	return header;
}

//put header to header variable
bool MySocket::PutHeader(char* headertosend)
{
	memmove(header,headertosend,sizeof(char)*11);
	return true;
}

//send data in send buffer with socket
int MySocket::SendData()
{
    char temp[256];
	char error[256];
    nReturn=WSASend(s,(LPWSABUF)&SendBuffer,1,(LPDWORD)&ByteSend,0,NULL,NULL);
    if (nReturn!=0)
 	{
		strcpy(temp,"WSASend() error");
		_itoa(WSAGetLastError(),error,10);
        PutEventMessage(strcat(temp,error));
        CloseSocket();
	}
	return ByteSend;
}

// receive data and put into receive buffer
int MySocket::ReceiveData()
{
    char temp[256];
	char error[256];
    DWORD flags=0;
    nReturn=WSARecv(s,(LPWSABUF)&ReceiveBuffer,1,(LPDWORD)&ByteReceive,&flags,NULL,NULL);
    if (nReturn==SOCKET_ERROR)
    {
		strcpy(temp,"WSAReceive() error");
		_itoa(WSAGetLastError(),error,10);
        PutEventMessage(strcat(temp,error));
        CloseSocket();
    }
    return ByteReceive;
}


DWORD MySocket::GetSizeofSendBuffer()
{
	return SizeofSendBuffer;
}

DWORD MySocket::GetSizeofReceiveBuffer()
{
	return SizeofReceiveBuffer;
}

DWORD MySocket::GetByteSend()
{
	return ByteSend;
}

DWORD MySocket::GetByteReceive()
{
	return ByteReceive;
}
