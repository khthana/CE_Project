#if !defined(AFX_PLAYDLG_H__434263E5_E39E_11D2_BC27_0020480E452C__INCLUDED_)
#define AFX_PLAYDLG_H__434263E5_E39E_11D2_BC27_0020480E452C__INCLUDED_

#include <Streams.h>
#include <asyncio.h>
#include <asyncrdr.h>
#include "PlayStream.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PlayDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPlayDlg dialog

class CPlayDlg : public CDialog
{
// Construction
public:
	void GetSocket(ATMClientSocket* sock);
	CWinThread *SliderThread;
	LONGLONG GetPosition(void);
	void SetBufferSize(DWORD bufferSize,DWORD fileSize);
	CPlayStream *ps;
	BOOL PutBuffer(PBYTE buff);
	CPlayDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CPlayDlg)
	enum { IDD = IDD_DIALOGPLAYER };
	CButton	m_buttonStop;
	CButton	m_buttonRewind;
	CButton	m_buttonPlay;
	CButton	m_buttonPause;
	CButton	m_buttonFullscreen;
	CButton	m_buttonForward;
	CButton	m_buttonEnd;
	CSliderCtrl	m_slider;
	CEdit	m_editFrameStart;
	CStatic	m_display;
	CButton	m_buttonBegin;
	long	m_frame;
	long	m_frameEnd;
	int		m_slidervalue;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPlayDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	ATMClientSocket* ATMClient;
	PBYTE m_buffer; 
	DWORD m_bufferSize;    // size of buffer
    DWORD m_fileSize;

	// Generated message map functions
	//{{AFX_MSG(CPlayDlg)
	afx_msg void OnDestroy();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	virtual BOOL OnInitDialog();
	afx_msg void OnBegin();
	afx_msg void OnEnd();
	afx_msg void OnForward();
	afx_msg void OnFullscreen();
	afx_msg void OnPause();
	afx_msg void OnPlay();
	afx_msg void OnRewind();
	afx_msg void OnStop();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PLAYDLG_H__434263E5_E39E_11D2_BC27_0020480E452C__INCLUDED_)
