#if !defined(AFX_FILENAMESELECT_H__BBF14D73_DDAF_11D2_8821_0020480E452C__INCLUDED_)
#define AFX_FILENAMESELECT_H__BBF14D73_DDAF_11D2_8821_0020480E452C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FileNameSelect.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// FileNameSelect dialog

class FileNameSelect : public CDialog
{
// Construction
public:
	bool GetFTPorStream();
	CString GetFilename();
	FileNameSelect(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(FileNameSelect)
	enum { IDD = IDD_LISTFILE };
	CListBox	m_listfilename;
	CString	m_filename;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(FileNameSelect)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	bool FTPorStream;

	// Generated message map functions
	//{{AFX_MSG(FileNameSelect)
	afx_msg void OnFtpfile();
	afx_msg void OnGetstream();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILENAMESELECT_H__BBF14D73_DDAF_11D2_8821_0020480E452C__INCLUDED_)
