// projectClientView.cpp : implementation of the CProjectClientView class
//

#include "stdafx.h"
#include "projectClient.h"

#include "projectClientDoc.h"
#include "projectClientView.h"
#include "FileNameSelect.h"
#include "FTPFile.h"
#include "PlayDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CProjectClientView

IMPLEMENT_DYNCREATE(CProjectClientView, CFormView)

BEGIN_MESSAGE_MAP(CProjectClientView, CFormView)
	//{{AFX_MSG_MAP(CProjectClientView)
	ON_BN_CLICKED(IDC_CONNECT, OnConnect)
	ON_BN_CLICKED(IDC_CBR, OnCbr)
	ON_BN_CLICKED(IDC_VBR, OnVbr)
	ON_BN_CLICKED(IDC_UBR, OnUbr)
	ON_BN_CLICKED(IDC_DISCONNECT, OnDisconnect)
	ON_BN_CLICKED(IDC_RQSERVICE, OnRqservice)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
//global function,variable
///////////////////////////////////////////////////////////////////////////
FileNameSelect selectfile;
CWinThread* MyThread;
extern CString FileName[20];
///////////////////////////////////////////////////////////////////////////
//thread that manage send and receive data with server
UINT SendReceiveThread(LPVOID sock)
{
	int SizeSend;
	int nResult;
	int SizeReceive;
	int TransferRate;
	CStdioFile ListFile;
	CFile FTPFile;
	FTPFILE* FTPDialog;
	CPlayDlg* StreamDialog;
	long StreamPointer;
	DWORD count=0;
	DWORD StartTime=0;
	DWORD EndTime=0;
	DWORD Lastpackage=0;
	DWORD ListFileLength=0;
	ATMClientSocket* ATMClient=(ATMClientSocket*)sock;
	SizeSend=ATMClient->GetSizeofSendBuffer();
	CString temp;
	char* StreamPointerString=new char[50];
	char* tempreceive=new char[ATMClient->GetSizeofReceiveBuffer()];
	char* StreamBuf;
	SizeReceive=ATMClient->GetSizeofReceiveBuffer();
	while (true)
	{
		ATMClient->ReceiveData();
//receive list file
///////////////////////////////////////////////////////////////////////////
		//size of list file
		if (strcmp(ATMClient->GetHeader(),"SSIZELISTF")==0)
		{
			ListFile.Open("listfile.txt",CFile::modeCreate|CFile::modeReadWrite,NULL);
			memset(tempreceive,0,ATMClient->GetSizeofReceiveBuffer());
			ATMClient->GetReceiveBuffer(tempreceive);
			ListFileLength=atoi(tempreceive);
			count=ListFileLength / (ATMClient->GetSizeofReceiveBuffer());
			Lastpackage=ListFileLength % (ATMClient->GetSizeofReceiveBuffer());
			ATMClient->PutHeader("RDLISTFILE");
			ATMClient->SetSendBuffer("test",sizeof("test"));
			ATMClient->SendData();
		}
		else
		//list file
		if (strcmp(ATMClient->GetHeader(),"SSENDLISTF")==0)
		{
			if (count>0)
			{
				memset(tempreceive,0,ATMClient->GetSizeofReceiveBuffer());
				ATMClient->GetReceiveBuffer(tempreceive);
				ListFile.WriteHuge((char far*) tempreceive,ATMClient->GetSizeofReceiveBuffer()-10);
				count--;
				for(UINT i=0;i<count;i++)
				{
					ATMClient->ReceiveData();
					memset(tempreceive,0,ATMClient->GetSizeofReceiveBuffer());
					ATMClient->GetReceiveBuffer(tempreceive);
					ListFile.WriteHuge((char far*)tempreceive,ATMClient->GetSizeofReceiveBuffer()-10);
				}			
				if (Lastpackage>0)
				{
					ATMClient->ReceiveData();
					memset(tempreceive,0,ATMClient->GetSizeofReceiveBuffer());
					ATMClient->GetReceiveBuffer(tempreceive);
					ListFile.WriteHuge((char far*)tempreceive,Lastpackage);
					ATMClient->PutEventMessage("Acception List File OK");
					ListFile.SeekToBegin();
					while (!feof(ListFile.m_pStream))
					{
						temp.Empty();
						ListFile.ReadString(temp);
						temp+='\0';
						selectfile.m_listfilename.AddString(temp);
					}
					ListFile.Close();
				}
			}
			else
			if (Lastpackage>0)
			{
				memset(tempreceive,0,ATMClient->GetSizeofReceiveBuffer());
				ATMClient->GetReceiveBuffer(tempreceive);
				ListFile.WriteHuge((char far*)tempreceive,Lastpackage);
				ATMClient->PutEventMessage("Acception List File OK");
				ListFile.SeekToBegin();
				while (!feof(ListFile.m_pStream))
				{
					temp.Empty();
					ListFile.ReadString(temp);
					temp+='\0';
					selectfile.m_listfilename.AddString(temp);
				}
				ListFile.Close();
			}

		}
		else
//FTP file
///////////////////////////////////////////////////////////////////////////
		// size of FTP file
		if (strcmp(ATMClient->GetHeader(),"SIZEFTPFIL")==0)
		{
			FTPFile.Open(selectfile.GetFilename().operator LPCTSTR(),CFile::modeCreate|CFile::modeReadWrite,NULL);
			memset(tempreceive,0,ATMClient->GetSizeofReceiveBuffer());
			FTPDialog=new FTPFILE();
			FTPDialog->Create(IDD_FTPFILE,NULL);
			ATMClient->GetReceiveBuffer(tempreceive);
			ListFileLength=atoi(tempreceive);
			count=ListFileLength / (ATMClient->GetSizeofReceiveBuffer());
			FTPDialog->m_ftpprogress.SetRange(0,count+1);
			FTPDialog->m_ftpprogress.SetPos(0);
			FTPDialog->m_ftpprogress.SetStep(1);
			Lastpackage=ListFileLength % (ATMClient->GetSizeofReceiveBuffer());
			ATMClient->PutHeader("RDFTPFILE#");
			ATMClient->SetSendBuffer("test",sizeof("test"));
			ATMClient->SendData();
		}
		else
		//FTP file
		if (strcmp(ATMClient->GetHeader(),"SENDFTPFIL")==0)
		{
			if (count>0)
			{
				StartTime=GetCurrentTime();
				memset(tempreceive,0,ATMClient->GetSizeofReceiveBuffer());
				ATMClient->GetReceiveBuffer(tempreceive);
				FTPFile.WriteHuge((char far*) tempreceive,ATMClient->GetSizeofReceiveBuffer()-10);
				FTPDialog->m_ftpprogress.StepIt();
				count--;
				for(UINT i=0;i<count;i++)
				{
					ATMClient->ReceiveData();
					memset(tempreceive,0,ATMClient->GetSizeofReceiveBuffer());
					ATMClient->GetReceiveBuffer(tempreceive);
					FTPFile.WriteHuge((char far*)tempreceive,ATMClient->GetSizeofReceiveBuffer()-10);
					FTPDialog->m_ftpprogress.StepIt();
				}			
				if (Lastpackage>0)
				{
					ATMClient->ReceiveData();
					memset(tempreceive,0,ATMClient->GetSizeofReceiveBuffer());
					ATMClient->GetReceiveBuffer(tempreceive);
					FTPFile.WriteHuge((char far*)tempreceive,Lastpackage);
					EndTime=GetCurrentTime();
					ATMClient->PutEventMessage("Acception FTP File OK");
					if ((EndTime-StartTime)>0)
					{
						TransferRate=(ListFileLength*8)/((EndTime-StartTime));
						memset(tempreceive,0,ATMClient->GetSizeofReceiveBuffer());
 						_itoa(TransferRate,tempreceive,10);
						strcat(tempreceive," bits per millisecond");
						MessageBox(NULL,tempreceive,"Transfer Rate value",MB_OK);
					}
					FTPDialog->EndDialog(nResult);
					delete FTPDialog;
					FTPFile.Close();
				}
			}
			else
			if (Lastpackage>0)
			{
				memset(tempreceive,0,ATMClient->GetSizeofReceiveBuffer());
				ATMClient->GetReceiveBuffer(tempreceive);
				FTPFile.WriteHuge((char far*)tempreceive,Lastpackage);
				FTPDialog->m_ftpprogress.StepIt();
				ATMClient->PutEventMessage("Acception FTP File OK");
				FTPDialog->EndDialog(nResult);
				delete FTPDialog;
				FTPFile.Close();
			}
		}
		else
//Stream
///////////////////////////////////////////////////////////////////////////
		//size of video stream file and start video window to send and receive
		//video stream file
		if (strcmp(ATMClient->GetHeader(),"SIZESTREAM")==0)
		{
			StreamBuf= new char[ATMClient->GetSizeofReceiveBuffer()-10];
			memset(StreamBuf,0,ATMClient->GetSizeofReceiveBuffer()-10);
			memset(tempreceive,0,ATMClient->GetSizeofReceiveBuffer());
			ATMClient->GetReceiveBuffer(tempreceive);
			ListFileLength=atoi(tempreceive);
			StreamDialog=new CPlayDlg();
			StreamDialog->GetSocket(ATMClient);
			//buffer must be dec with 10(size of header)
			StreamDialog->SetBufferSize(ATMClient->GetSizeofReceiveBuffer()-10,ListFileLength);
			ATMClient->PutHeader("RDSTREAMFI");
			StreamPointer=0;
			ATMClient->SetSendBuffer("0",sizeof("0"));
			ATMClient->SendData();
			ATMClient->ReceiveData();
			ATMClient->GetReceiveBuffer(StreamBuf);
			StreamDialog->PutBuffer((unsigned char*)StreamBuf);
			StreamDialog->DoModal();
		}
	}
}

/////////////////////////////////////////////////////////////////////////////
// CProjectClientView construction/destruction

CProjectClientView::CProjectClientView()
	: CFormView(CProjectClientView::IDD)
{
	//{{AFX_DATA_INIT(CProjectClientView)
	m_atmhostname = _T("cloak");
	m_mbs = _T("");
	m_pcr = _T("50000");
	m_receivebuffer = _T("40");
	m_scr = _T("");
	m_sel = _T("19");
	m_vci = _T("");
	m_vpi = _T("");
	m_sendbuffer = _T("40");
	QoSCheck=0;
	//}}AFX_DATA_INIT
	// TODO: add construction code here

}

CProjectClientView::~CProjectClientView()
{
}

void CProjectClientView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CProjectClientView)
	DDX_Control(pDX, IDC_EVENTLOG, m_eventlog);
	DDX_Text(pDX, IDC_ATMHOSTNAME, m_atmhostname);
	DDX_Text(pDX, IDC_MBS, m_mbs);
	DDX_Text(pDX, IDC_PCR, m_pcr);
	DDX_Text(pDX, IDC_RECEIVEBUFFER, m_receivebuffer);
	DDX_Text(pDX, IDC_SCR, m_scr);
	DDX_Text(pDX, IDC_SEL, m_sel);
	DDX_Text(pDX, IDC_VCI, m_vci);
	DDX_Text(pDX, IDC_VPI, m_vpi);
	DDX_Text(pDX, IDC_SENDBUFFER, m_sendbuffer);
	//}}AFX_DATA_MAP
}

BOOL CProjectClientView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFormView::PreCreateWindow(cs);
}

void CProjectClientView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();
    WSADATA wsadata;
    int nRet;
    nRet = WSAStartup(MAKEWORD(2,0),&wsadata);
    if (nRet)
    {
        m_eventlog.AddString("Initial winsock error");
		return;
    }
    else
    if (MAKEWORD(2,0)!=wsadata.wVersion)
    {
        m_eventlog.AddString("Version Error");
        WSACleanup();
		return;
    }
    else
    {
        m_eventlog.AddString("Winsock2 start successful");
	}

}

/////////////////////////////////////////////////////////////////////////////
// CProjectClientView diagnostics

#ifdef _DEBUG
void CProjectClientView::AssertValid() const
{
	CFormView::AssertValid();
}

void CProjectClientView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CProjectClientDoc* CProjectClientView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CProjectClientDoc)));
	return (CProjectClientDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CProjectClientView message handlers

void CProjectClientView::OnConnect() 
{
		UpdateData(true);
	    LPQOS tempQOS;
		tempQOS=new QOS();
        AAL_PARAMETERS_IE AAL_IE;
        ATM_TRAFFIC_DESCRIPTOR_IE TD_IE;
        ATM_BROADBAND_BEARER_CAPABILITY_IE BBC_IE;
        ATM_QOS_CLASS_IE qos_IE;
        Q2931_IE* ie_ptr;
        int size=0;
		//UBR
//-------------------------------------------------------------------------------
        if (QoSCheck==2)
        {
            ATMClient=new ATMClientSocket(AF_ATM,
										  SOCK_RAW,
                                          ATMPROTO_AAL5,
                                          (UCHAR)atoi(m_sel),
										  (DWORD)atoi(m_sendbuffer),
										  (DWORD)atoi(m_receivebuffer),
										  NULL,
                                          &m_eventlog);
            ATMClient->CreateSocket();
          //set saATMServer
			sockaddr_atm tempsaATM;
			tempsaATM.satm_family=AF_ATM;
			memmove(tempsaATM.satm_number.Addr,ATMClient->GetATMAddress(m_atmhostname),sizeof(UCHAR)*20);
			tempsaATM.satm_number.AddressType=ATM_NSAP;
			tempsaATM.satm_number.NumofDigits=ATM_ADDR_SIZE;
			tempsaATM.satm_number.Addr[19]=(UCHAR)atoi(m_sel);
			tempsaATM.satm_blli.Layer2Protocol=SAP_FIELD_ABSENT;
			tempsaATM.satm_blli.Layer3Protocol=SAP_FIELD_ABSENT;
			tempsaATM.satm_bhli.HighLayerInfoType=SAP_FIELD_ABSENT;
			//set sockaddr_atm
			ATMClient->ATMSetsaATM(tempsaATM);
            ATMClient->ATMConnect();
			ATM_CONNECTION_ID tempconid;
			tempconid=ATMClient->GetATMConnectionID();
			char temp[20];
			_itoa(tempconid.VCI,temp,10);
			m_vci=temp;
			_itoa(tempconid.VPI,temp,10);
			m_vpi=temp;
			UpdateData(false);
        }
        else
//CBR
//-------------------------------------------------------------------------------
	    if (QoSCheck==0)
        {
        //setting ATM parameter
        //aal information element
            AAL_IE.AALType=AALTYPE_5;
            AAL_IE.AALSpecificParameters.AAL5Parameters.ForwardMaxCPCSSDUSize
            =1516;
            AAL_IE.AALSpecificParameters.AAL5Parameters.BackwardMaxCPCSSDUSize
            =1516;
            AAL_IE.AALSpecificParameters.AAL5Parameters.Mode=AAL5_MODE_MESSAGE;
            AAL_IE.AALSpecificParameters.AAL5Parameters.SSCSType=AAL5_SSCS_NULL;
    	    size = sizeof(Q2931_IE_TYPE) + sizeof(ULONG)
                    + sizeof(AAL_PARAMETERS_IE);
        //traffic descriptor information element
            TD_IE.Forward.PeakCellRate_CLP0=SAP_FIELD_ABSENT;
            TD_IE.Forward.PeakCellRate_CLP01=(ULONG)atoi(m_pcr);
            TD_IE.Forward.SustainableCellRate_CLP0=SAP_FIELD_ABSENT;
        	TD_IE.Forward.SustainableCellRate_CLP01 = SAP_FIELD_ABSENT;
        	TD_IE.Forward.MaxBurstSize_CLP0 = SAP_FIELD_ABSENT;
        	TD_IE.Forward.MaxBurstSize_CLP01 = SAP_FIELD_ABSENT;
        	TD_IE.Forward.Tagging = SAP_FIELD_ABSENT;

        	TD_IE.Backward.PeakCellRate_CLP0 = SAP_FIELD_ABSENT;
        	TD_IE.Backward.PeakCellRate_CLP01 = (ULONG)atoi(m_pcr);
        	TD_IE.Backward.SustainableCellRate_CLP0 = SAP_FIELD_ABSENT;
        	TD_IE.Backward.SustainableCellRate_CLP01 = SAP_FIELD_ABSENT;
           	TD_IE.Backward.MaxBurstSize_CLP0 = SAP_FIELD_ABSENT;
        	TD_IE.Backward.MaxBurstSize_CLP01 = SAP_FIELD_ABSENT;
	        TD_IE.Backward.Tagging = SAP_FIELD_ABSENT;

            TD_IE.BestEffort=false;
        	size += sizeof(Q2931_IE_TYPE) + sizeof(ULONG)
                    + sizeof(ATM_TRAFFIC_DESCRIPTOR_IE);
		//Broadband bearer capability information element
            BBC_IE.BearerClass=BCOB_A;
            BBC_IE.TrafficType=TT_CBR;
            BBC_IE.TimingRequirements = TR_END_TO_END;
        	BBC_IE.ClippingSusceptability = CLIP_NOT;
        	BBC_IE.UserPlaneConnectionConfig = UP_P2P;
        	size += sizeof(Q2931_IE_TYPE) + sizeof(ULONG)
                    + sizeof(ATM_BROADBAND_BEARER_CAPABILITY_IE);
	    //qos service parameter information element
            qos_IE.QOSClassForward=QOS_CLASS0;
            qos_IE.QOSClassBackward=QOS_CLASS0;
        	size += sizeof(Q2931_IE_TYPE) + sizeof(ULONG) + sizeof(ATM_QOS_CLASS_IE);
            tempQOS->ProviderSpecific.len=size;
            tempQOS->ProviderSpecific.buf=new char[size];
            memset(tempQOS->ProviderSpecific.buf,0,size);
//        fill information element to providerSpecific field
            ie_ptr=(Q2931_IE *)tempQOS->ProviderSpecific.buf;
		//fill aal information element
            ie_ptr->IEType=IE_AALParameters;
            ie_ptr->IELength=sizeof(Q2931_IE_TYPE) + sizeof(ULONG)
                             + sizeof(AAL_PARAMETERS_IE);
            memmove(ie_ptr->IE,&AAL_IE,sizeof(AAL_PARAMETERS_IE));
            ie_ptr=(Q2931_IE*)((char*)ie_ptr+ie_ptr->IELength);
		//fill td information element
            ie_ptr->IEType=IE_TrafficDescriptor;;
            ie_ptr->IELength=sizeof(Q2931_IE_TYPE) + sizeof(ULONG)
                             + sizeof(ATM_TRAFFIC_DESCRIPTOR_IE);
            memmove(ie_ptr->IE,&TD_IE,sizeof(ATM_TRAFFIC_DESCRIPTOR_IE));
            ie_ptr=(Q2931_IE*)((char*)ie_ptr+ie_ptr->IELength);
        //fill bbc information element
            ie_ptr->IEType=IE_BroadbandBearerCapability;;
            ie_ptr->IELength=sizeof(Q2931_IE_TYPE) + sizeof(ULONG)
                             + sizeof(ATM_BROADBAND_BEARER_CAPABILITY_IE);
            memmove(ie_ptr->IE,&BBC_IE,sizeof(ATM_BROADBAND_BEARER_CAPABILITY_IE));
            ie_ptr=(Q2931_IE*)((char*)ie_ptr+ie_ptr->IELength);
	    //fill qos information element
            ie_ptr->IEType=IE_QOSClass;
            ie_ptr->IELength=sizeof(Q2931_IE_TYPE) + sizeof(ULONG)
                             + sizeof(ATM_QOS_CLASS_IE);
            memmove(ie_ptr->IE,&qos_IE,sizeof(ATM_QOS_CLASS_IE));
			//set no use parameter
        	tempQOS->SendingFlowspec.TokenRate = -1;
        	tempQOS->SendingFlowspec.TokenBucketSize = -1;
        	tempQOS->SendingFlowspec.PeakBandwidth = -1;
        	tempQOS->SendingFlowspec.Latency = -1;
        	tempQOS->SendingFlowspec.DelayVariation = -1;
        	tempQOS->SendingFlowspec.LevelOfGuarantee = BestEffortService ;
        	tempQOS->SendingFlowspec.CostOfCall = 0;

        	tempQOS->ReceivingFlowspec.TokenRate = -1;
        	tempQOS->ReceivingFlowspec.TokenBucketSize = -1;
        	tempQOS->ReceivingFlowspec.PeakBandwidth = -1;
        	tempQOS->ReceivingFlowspec.Latency = -1;
        	tempQOS->ReceivingFlowspec.DelayVariation = -1;
        	tempQOS->ReceivingFlowspec.LevelOfGuarantee = BestEffortService ;
        	tempQOS->ReceivingFlowspec.CostOfCall = 0;

            //create ATM client socket
            ATMClient=new ATMClientSocket(AF_ATM,
                                       SOCK_RAW,
                                       ATMPROTO_AAL5,
									   (UCHAR)atoi(m_sel),
									   (DWORD)atoi(m_sendbuffer),
								 	  (DWORD)atoi(m_receivebuffer),
 									   tempQOS,
                                       &m_eventlog);
            ATMClient->CreateSocket();
          //set saATMServer
			sockaddr_atm tempsaATM;
			tempsaATM.satm_family=AF_ATM;
			memmove(tempsaATM.satm_number.Addr,ATMClient->GetATMAddress(m_atmhostname),sizeof(UCHAR)*20);
			tempsaATM.satm_number.AddressType=ATM_NSAP;
			tempsaATM.satm_number.NumofDigits=ATM_ADDR_SIZE;
			tempsaATM.satm_number.Addr[19]=(UCHAR)atoi(m_sel);
			tempsaATM.satm_blli.Layer2Protocol=SAP_FIELD_ABSENT;
			tempsaATM.satm_blli.Layer3Protocol=SAP_FIELD_ABSENT;
			tempsaATM.satm_bhli.HighLayerInfoType=SAP_FIELD_ABSENT;
			//set sockaddr_atm
			ATMClient->ATMSetsaATM(tempsaATM);
			// connect to server
            ATMClient->ATMConnect();
			//find VPI and VCI
			ATM_CONNECTION_ID tempconid;
			tempconid=ATMClient->GetATMConnectionID();
			char temp[20];
			_itoa(tempconid.VCI,temp,10);
			m_vci=temp;
			_itoa(tempconid.VPI,temp,10);
			m_vpi=temp;
			UpdateData(false);
        }
        else
//VBR
//-------------------------------------------------------------------------------
        if (QoSCheck==1)
        {
        //aal information element
            AAL_IE.AALType=AALTYPE_5;
            AAL_IE.AALSpecificParameters.AAL5Parameters.ForwardMaxCPCSSDUSize
            =1516;
            AAL_IE.AALSpecificParameters.AAL5Parameters.BackwardMaxCPCSSDUSize
            =1516;
            AAL_IE.AALSpecificParameters.AAL5Parameters.Mode=AAL5_MODE_MESSAGE;
            AAL_IE.AALSpecificParameters.AAL5Parameters.SSCSType=AAL5_SSCS_NULL;
    	    size = sizeof(Q2931_IE_TYPE) + sizeof(ULONG)
                    + sizeof(AAL_PARAMETERS_IE);
        //traffic descriptor information element
            TD_IE.Forward.PeakCellRate_CLP0=SAP_FIELD_ABSENT;
            TD_IE.Forward.PeakCellRate_CLP01=(ULONG)atoi(m_pcr);
            TD_IE.Forward.SustainableCellRate_CLP0=SAP_FIELD_ABSENT;
        	TD_IE.Forward.SustainableCellRate_CLP01 =(ULONG)atoi(m_scr);
        	TD_IE.Forward.MaxBurstSize_CLP0 = SAP_FIELD_ABSENT;
        	TD_IE.Forward.MaxBurstSize_CLP01 = (ULONG)atoi(m_mbs);
        	TD_IE.Forward.Tagging = SAP_FIELD_ABSENT;

        	TD_IE.Backward.PeakCellRate_CLP0 = SAP_FIELD_ABSENT;
        	TD_IE.Backward.PeakCellRate_CLP01 = (ULONG)atoi(m_pcr);
        	TD_IE.Backward.SustainableCellRate_CLP0 = SAP_FIELD_ABSENT;
        	TD_IE.Backward.SustainableCellRate_CLP01 =(ULONG)atoi(m_scr);
           	TD_IE.Backward.MaxBurstSize_CLP0 = SAP_FIELD_ABSENT;
        	TD_IE.Backward.MaxBurstSize_CLP01 =(ULONG)atoi(m_mbs);
	        TD_IE.Backward.Tagging = SAP_FIELD_ABSENT;

            TD_IE.BestEffort=false;
        	size += sizeof(Q2931_IE_TYPE) + sizeof(ULONG)
                    + sizeof(ATM_TRAFFIC_DESCRIPTOR_IE);
	    //Broadband bearer capability information element
            BBC_IE.BearerClass=BCOB_C;
            BBC_IE.TrafficType=TT_VBR;
            BBC_IE.TimingRequirements = TR_END_TO_END;
        	BBC_IE.ClippingSusceptability = CLIP_NOT;
        	BBC_IE.UserPlaneConnectionConfig = UP_P2P;
        	size += sizeof(Q2931_IE_TYPE) + sizeof(ULONG)
                    + sizeof(ATM_BROADBAND_BEARER_CAPABILITY_IE);
         //qos service parameter information element
            qos_IE.QOSClassForward=QOS_CLASS1;
            qos_IE.QOSClassBackward=QOS_CLASS1;
        	size += sizeof(Q2931_IE_TYPE) + sizeof(ULONG) + sizeof(ATM_QOS_CLASS_IE);
            tempQOS->ProviderSpecific.buf=(char*)malloc(size);
            tempQOS->ProviderSpecific.len=size;
            memset(tempQOS->ProviderSpecific.buf,0,size);
//        fill ie to providerSpecific field
            ie_ptr=(Q2931_IE *)tempQOS->ProviderSpecific.buf;
		//fill aal information element
            ie_ptr->IEType=IE_AALParameters;
            ie_ptr->IELength=sizeof(Q2931_IE_TYPE) + sizeof(ULONG)
                             + sizeof(AAL_PARAMETERS_IE);
            memmove(ie_ptr->IE,&AAL_IE,sizeof(AAL_PARAMETERS_IE));
            ie_ptr=(Q2931_IE*)((char*)ie_ptr+ie_ptr->IELength);
		//fill td information element
            ie_ptr->IEType=IE_TrafficDescriptor;;
            ie_ptr->IELength=sizeof(Q2931_IE_TYPE) + sizeof(ULONG)
                             + sizeof(ATM_TRAFFIC_DESCRIPTOR_IE);
            memmove(ie_ptr->IE,&TD_IE,sizeof(ATM_TRAFFIC_DESCRIPTOR_IE));
            ie_ptr=(Q2931_IE*)((char*)ie_ptr+ie_ptr->IELength);
         //fill bbc information element
            ie_ptr->IEType=IE_BroadbandBearerCapability;;
            ie_ptr->IELength=sizeof(Q2931_IE_TYPE) + sizeof(ULONG)
                             + sizeof(ATM_BROADBAND_BEARER_CAPABILITY_IE);
            memmove(ie_ptr->IE,&BBC_IE,sizeof(ATM_BROADBAND_BEARER_CAPABILITY_IE));
            ie_ptr=(Q2931_IE*)((char*)ie_ptr+ie_ptr->IELength);
		//fill qos information element
            ie_ptr->IEType=IE_QOSClass;
            ie_ptr->IELength=sizeof(Q2931_IE_TYPE) + sizeof(ULONG)
                             + sizeof(ATM_QOS_CLASS_IE);
            memmove(ie_ptr->IE,&qos_IE,sizeof(ATM_QOS_CLASS_IE));
			//set no use parameter
        	tempQOS->SendingFlowspec.TokenRate = -1;
        	tempQOS->SendingFlowspec.TokenBucketSize = -1;
        	tempQOS->SendingFlowspec.PeakBandwidth = -1;
        	tempQOS->SendingFlowspec.Latency = -1;
        	tempQOS->SendingFlowspec.DelayVariation = -1;
        	tempQOS->SendingFlowspec.LevelOfGuarantee = BestEffortService ;
        	tempQOS->SendingFlowspec.CostOfCall = 0;


        	tempQOS->ReceivingFlowspec.TokenRate = -1;
        	tempQOS->ReceivingFlowspec.TokenBucketSize = -1;
        	tempQOS->ReceivingFlowspec.PeakBandwidth = -1;
        	tempQOS->ReceivingFlowspec.Latency = -1;
        	tempQOS->ReceivingFlowspec.DelayVariation = -1;
        	tempQOS->ReceivingFlowspec.LevelOfGuarantee = BestEffortService ;
        	tempQOS->ReceivingFlowspec.CostOfCall = 0;

            //create ATM client socket
            ATMClient=new ATMClientSocket(AF_ATM,
                                       SOCK_RAW,
                                       ATMPROTO_AAL5,
                                       (UCHAR)atoi(m_sel),
									  (DWORD)atoi(m_sendbuffer),
									  (DWORD)atoi(m_receivebuffer),
                                       tempQOS,
                                       &m_eventlog);
            ATMClient->CreateSocket();
          //set saATMServer
			sockaddr_atm tempsaATM;
			tempsaATM.satm_family=AF_ATM;
			memmove(tempsaATM.satm_number.Addr,ATMClient->GetATMAddress(m_atmhostname),sizeof(UCHAR)*20);
			tempsaATM.satm_number.AddressType=ATM_NSAP;
			tempsaATM.satm_number.NumofDigits=ATM_ADDR_SIZE;
			tempsaATM.satm_number.Addr[19]=(UCHAR)atoi(m_sel);
			tempsaATM.satm_blli.Layer2Protocol=SAP_FIELD_ABSENT;
			tempsaATM.satm_blli.Layer3Protocol=SAP_FIELD_ABSENT;
			tempsaATM.satm_bhli.HighLayerInfoType=SAP_FIELD_ABSENT;
			//set sockaddr_atm
			ATMClient->ATMSetsaATM(tempsaATM);
			//connect to server
            ATMClient->ATMConnect();
			//find VPI and VCI
			ATM_CONNECTION_ID tempconid;
			tempconid=ATMClient->GetATMConnectionID();
			char temp[20];
			_itoa(tempconid.VCI,temp,10);
			m_vci=temp;
			_itoa(tempconid.VPI,temp,10);
			m_vpi=temp;
			UpdateData(false);
		}
		//create thread that use to send and receive data with server
	MyThread=AfxBeginThread(SendReceiveThread,ATMClient,THREAD_PRIORITY_NORMAL,0,CREATE_SUSPENDED,NULL);
	MyThread->m_bAutoDelete=false;
	MyThread->ResumeThread();
	// TODO: Add your control notification handler code here
	
}
//choose CBR
void CProjectClientView::OnCbr() 
{
	QoSCheck=0;
	// TODO: Add your control notification handler code here
}
//choose VBR
void CProjectClientView::OnVbr() 
{
	QoSCheck=1;
	// TODO: Add your control notification handler code here
}
//choose UBR
void CProjectClientView::OnUbr() 
{
	QoSCheck=2;
	// TODO: Add your control notification handler code here
}

//Send Disconnect Message to server and terminate thread
void CProjectClientView::OnDisconnect() 
{
	DWORD dwExit;
	int nRet;
	nRet=TerminateThread(MyThread->m_hThread,dwExit);
	if (nRet!=0)
	{
		delete MyThread;
		ATMClient->PutHeader("DISCONNECT");
		ATMClient->SetSendBuffer("test",sizeof("test"));
		ATMClient->SendData();
		ATMClient->CloseSocket();
		delete ATMClient;
	}
	else
	{
		dwExit=GetLastError();
	}
	// TODO: Add your control notification handler code here
}

//request service from server
void CProjectClientView::OnRqservice() 
{
	char* temp=new char[ATMClient->GetSizeofSendBuffer()];
	ATMClient->PutHeader("RQLISTFILE");
	memset(temp,0,sizeof(temp));
    ATMClient->SetSendBuffer("test",sizeof("test"));
	ATMClient->SendData();
	//create dialog for receive filename
 	if (selectfile.DoModal()==IDOK)
	{
		//FTP
		if (selectfile.GetFTPorStream()==true)
		{
			ATMClient->PutHeader("RQFTPFILE#");
			memset(temp,0,sizeof(temp));
			ATMClient->SetSendBuffer((char*)selectfile.GetFilename().operator LPCTSTR(),sizeof(char)*selectfile.GetFilename().GetLength());
			ATMClient->SendData();
		}
		//stream
		else
		{	
			ATMClient->PutHeader("RQSTREAMFI");
			memset(temp,0,sizeof(temp));
			ATMClient->SetSendBuffer((char*)selectfile.GetFilename().operator LPCTSTR(),sizeof(char)*selectfile.GetFilename().GetLength());
			ATMClient->SendData();
		}

	}
	// TODO: Add your control notification handler code here
}
