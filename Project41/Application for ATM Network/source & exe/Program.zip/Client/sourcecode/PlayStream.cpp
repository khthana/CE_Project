// PlayStream.cpp: implementation of the CPlayStream class.
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"
//#include "AppPlayer.h"
#include "PlayStream.h"
#include "projectClient.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define WM_GRAPHNOTIFY WM_USER+13

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

//Constructor for CPlayStream Class
CPlayStream::CPlayStream(PBYTE buffer,DWORD bufferSize,DWORD fileSize,HWND hwnd,ATMClientSocket* sock)
{
	m_hWnd = hwnd;
	p_ms   = NULL;
	ATMClient=sock;
	if (buffer ==NULL)
	{
		MessageBox(NULL,"Buffer not allocated!","ERROR MESSAGE!",MB_OK);
	}
	else
	{
		m_buffer = buffer;
		m_bufferSize = bufferSize;
	};
	
	DWORD KBPerSec = INFINITE;
    CMediaType mt;
    //----- Assign Mutimedia type -----//
	mt.majortype = MEDIATYPE_Stream;
    mt.subtype = MEDIASUBTYPE_MPEG1VideoCD;
    
	ULARGE_INTEGER Size;
    Size.QuadPart = fileSize;

    HRESULT hr = S_OK;
    CoInitialize(NULL);
	
    //---- Create Stream for Source filter(CMemReader) ----//
    p_ms = new CMemStream(m_buffer, (LONGLONG)Size.QuadPart,m_bufferSize,ATMClient,KBPerSec);
	p_mr = new CMemReader(p_ms, &mt, &hr);
	if (FAILED(hr) || p_mr == NULL) {
        delete p_mr;
        MessageBox(NULL,"Could not create CMemReader!","ERROR MESSAGE!",MB_OK);
        CoUninitialize();
    }
    p_mr->AddRef();
	p_fg=NULL;
	p_mp=NULL;
	p_mc=NULL;
	p_me=NULL;
	p_vw=NULL;
	p_mp=NULL;
	if (!CreateFilter(&p_fg,p_mr)){
		  MessageBox(NULL,"Could not create Filter Graph Interface!","ERROR MESSAGE!",MB_OK);
    };
}

////////////////////////////////////////////////////////////////////////////////////////////////////

//Destructor for CPlayStream Class
CPlayStream::~CPlayStream()
{
	p_fg->Release();
	p_gb->Release();
	p_mc->Release();
	p_me->Release();
	p_mp->Release();
	p_mr->Release();
	p_mseek->Release();
	delete p_ms;
	p_vw->Release();
}


////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////


//Main method of CPlayStream class for creating all interface to play video file 
BOOL CPlayStream::CreateFilter(IFilterGraph **pp_fg,CMemReader *p_r)
{	
	//---- Create instance for IFilterGreaph ----//
	HRESULT hr;
	hr = CoCreateInstance(CLSID_FilterGraph,NULL,CLSCTX_INPROC,IID_IFilterGraph,(void**)pp_fg);
    if (FAILED(hr)) {
        MessageBox(NULL,"Could not create filter!","ERROR MESSAGE!",MB_OK);
		return (false);
    }
	
	if (FAILED(hr)) {
		MessageBox(NULL,"Could not add filter!","ERROR MESSAGE!",MB_OK);
		return (false);
    }
	//----  Query for IGraphBuilder Interface ----//
	p_gb =NULL;
	hr = (*pp_fg)->QueryInterface(IID_IGraphBuilder,(void**)&p_gb);
	if (FAILED(hr)) {
		MessageBox(NULL,"Could not add Filter Graph Manager!","ERROR MESSAGE!",MB_OK);
		return (false);
    }
	p_gb->AddFilter(p_r,NULL);

	//----- Query for IMediaControl Interface -----
	hr = p_gb->QueryInterface(IID_IMediaControl,(void**)&p_mc);
    if (FAILED(hr)) {
		MessageBox(NULL,"Could not query IMediaControl Interface!","ERROR MESSAGE!",MB_OK);
		return (false);
    };
	
	//----- Query for IMediaEvent Interface -----
	hr = p_gb->QueryInterface(IID_IMediaEvent,(void**)&p_me);
    if (FAILED(hr)) {
		MessageBox(NULL,"Could not query IMediaEventEx Interface!","ERROR MESSAGE!",MB_OK);
		return (false);
    };
	//----- Query for IVideoWindow Interface
	hr = p_gb->QueryInterface(IID_IVideoWindow, (void **)&p_vw);
    if (FAILED(hr)) {
		MessageBox(NULL,"Could not query IVideoWindow Interface!","ERROR MESSAGE!",MB_OK);
		return (false);
    };
	p_me->SetNotifyWindow((OAHWND)m_hWnd,WM_GRAPHNOTIFY,0);

	//----- Render and waiting for Run() from IMediaControl Interface ---------------
	hr = p_gb->Render(p_r->GetPin(0));
	if (FAILED(hr)) {
		MessageBox(NULL,"Could not render!","ERROR MESSAGE!",MB_OK);
		//p_gb->Release(); 
		return (false);
    };
	
	
	//----- Query for IMediaPosition Interface
	hr = p_gb->QueryInterface(IID_IMediaPosition, (void **)&p_mp);
    if (FAILED(hr)) {
		MessageBox(NULL,"Could not query IMediaPosition Interface!","ERROR MESSAGE!",MB_OK);
		return (false);
    };

	
	//----- Query for IMediaSeeking Interface
	hr = p_gb->QueryInterface(IID_IMediaSeeking, (void **)&p_mseek);
    hr = p_mseek->SetTimeFormat(&TIME_FORMAT_FRAME);
	if (FAILED(hr)) {
		MessageBox(NULL,"Could not query IMediaSeeking Interface!","ERROR MESSAGE!",MB_OK);
		return (false);
    };
	hr = p_mseek->GetDuration(&m_frameRange);


	RECT r;
	p_vw->put_Owner((OAHWND)m_hWnd);
	p_vw->put_WindowStyle(WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS);
	GetClientRect(m_hWnd,&r);
	p_vw->SetWindowPosition(r.left,r.top,r.right,r.bottom);

	hr = p_vw->put_MessageDrain((OAHWND)m_hWnd);

    if (FAILED(hr)) {
		MessageBox(NULL,"Could not put messageDrain!","ERROR MESSAGE!",MB_OK);
		return (false);
    };
	hr = p_me->GetEventHandle((OAEVENT*)&m_hGraphNotifyEvent);

	return (true);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//Play video 
BOOL CPlayStream::Play()
{	
	HRESULT hr=S_OK;
	hr = p_mc->Run();

	if (FAILED(hr)) {
		MessageBox(NULL,"Could not play!","ERROR MESSAGE!",MB_OK); 
		return (false);
    }
	return(true);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//Pause video
BOOL CPlayStream::Pause()
{
	
	HRESULT hr = p_mc->Pause();
	if (FAILED(hr)) {
		MessageBox(NULL,"Could not pause!","ERROR MESSAGE!",MB_OK); 
		return (false);
    }
	return(true);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//Stop video
BOOL CPlayStream::Stop()
{
	HRESULT hr = p_mc->Stop();
	LONGLONG pos = 0L;
	hr = p_mseek->SetPositions(&pos,AM_SEEKING_AbsolutePositioning,&m_frameRange,AM_SEEKING_AbsolutePositioning);
	if (FAILED(hr)) {
		MessageBox(NULL,"Could not stop!","ERROR MESSAGE!",MB_OK); 
		return (false);
    }
	return(true);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


//Set position of video file for playing
BOOL CPlayStream::SetPosition(LONGLONG pos)
{
	HRESULT hr=S_OK;
	//----- Returned length of the media stream to range ----
	hr = p_mseek->SetPositions(&pos,AM_SEEKING_AbsolutePositioning,&m_frameRange,AM_SEEKING_AbsolutePositioning);
    if (FAILED(hr)) {
		MessageBox(NULL,"Could not set position of media stream!","ERROR MESSAGE!",MB_OK);
		return (0);
    };
	return(true);
}


//Get range of video file
LONGLONG CPlayStream::GetRange()
{
	LONGLONG range=0;
	HRESULT hr=S_OK;
	//----- Returned length of the media stream to range ----
	hr = p_mseek->GetDuration(&range);
    if (FAILED(hr)) {
		MessageBox(NULL,"Could not get duration of media stream!","ERROR MESSAGE!",MB_OK);
		return (0);
    };
	return(range);
}


//Rewind video 30 frame
BOOL CPlayStream::Rewind()
{
	HRESULT hr ;
	LONGLONG pos = 0L;
	hr = p_mseek->GetCurrentPosition(&pos);
	
	//rewind 30 frame
	pos = pos-30;
	hr = p_mseek->SetPositions(&pos,AM_SEEKING_AbsolutePositioning,&m_frameRange,AM_SEEKING_AbsolutePositioning);
	if (FAILED(hr)) {
		MessageBox(NULL,"Could not Rewind!","ERROR MESSAGE!",MB_OK); 
		return (false);
    }
	return(true);
}

//Forward video 30 frame
BOOL CPlayStream::Forward()
{
	HRESULT hr ; 
	LONGLONG pos = 0L;
	hr = p_mseek->GetCurrentPosition(&pos);
	
	//forward 30 frame
	pos = pos+30;
	hr = p_mseek->SetPositions(&pos,AM_SEEKING_AbsolutePositioning,&m_frameRange,AM_SEEKING_AbsolutePositioning);
	if (FAILED(hr)) {
		MessageBox(NULL,"Could not Forward!","ERROR MESSAGE!",MB_OK); 
		return (false);
    }
	return(true);
}

//Rewind video to first position of video file
BOOL CPlayStream::ToBegin()
{
	HRESULT hr;
	LONGLONG pos = 0L;
	hr = p_mseek->SetPositions(&pos,AM_SEEKING_AbsolutePositioning,&m_frameRange,AM_SEEKING_AbsolutePositioning);
	if (FAILED(hr)) {
		MessageBox(NULL,"Could not go to Begin!","ERROR MESSAGE!",MB_OK); 
		return (false);
    }
	return(true);
}

//Forward video to last position of video file
BOOL CPlayStream::ToEnd()
{
	HRESULT hr = p_mc->Pause();
	hr = p_mseek->SetPositions(&m_frameRange,AM_SEEKING_AbsolutePositioning,&m_frameRange,AM_SEEKING_AbsolutePositioning);
	if (FAILED(hr)) {
		MessageBox(NULL,"Could not go to End!","ERROR MESSAGE!",MB_OK); 
		return (false);
    }
	return(true);
}

//Display video in fullscreen mode
BOOL CPlayStream::FullScreen(long out)
{
	p_vw->put_FullScreenMode(out);
	return(true);
}


//Get current frame of video file
LONGLONG CPlayStream::GetCurrentFrame()
{
	HRESULT hr ;
	LONGLONG pos = 0L;
	hr = p_mseek->GetCurrentPosition(&pos);
	if (FAILED(hr)) {
		MessageBox(NULL,"Could not get current Frame!","ERROR MESSAGE!",MB_OK); 
		return 0;
    }
	return pos;
}
