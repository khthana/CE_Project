// lientSocket.h: interface for the ClientSocket class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LIENTSOCKET_H__3B510283_D7D7_11D2_BBF3_0020182A2CC3__INCLUDED_)
#define AFX_LIENTSOCKET_H__3B510283_D7D7_11D2_BBF3_0020182A2CC3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "MySocket.h"

class ClientSocket : public MySocket  
{
protected:
	LPQOS SocketQOS; // Quality of Service Parameter
	char* ServerName;
public:
	ClientSocket();
	ClientSocket(int Addr,int Sock,int Protocol,int maxsendbuf,int maxreceivebuf,CListBox* Log);
	virtual ~ClientSocket();

};

#endif // !defined(AFX_LIENTSOCKET_H__3B510283_D7D7_11D2_BBF3_0020182A2CC3__INCLUDED_)
