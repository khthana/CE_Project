// ATMClientSocket.cpp: implementation of the ATMClientSocket class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ATMClientSocket.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

ATMClientSocket::ATMClientSocket()
{

}
ATMClientSocket::ATMClientSocket(int Addr,int Sock,int Protocol,UCHAR sel,int maxsendbuf,int maxreceivebuf,LPQOS qos,CListBox* Log)
:ClientSocket(Addr,Sock,Protocol,maxsendbuf,maxreceivebuf,Log)
{
	ATMSEL=sel;
	if (qos!=NULL)
	{
		SocketQOS=qos;
	}
	else
	{
		SocketQOS=NULL;
	}

}

ATMClientSocket::~ATMClientSocket()
{

}
//connect to server
bool ATMClientSocket::ATMConnect()
{
	char temp[256];
	char error[256];
	nReturn=WSAConnect(s,(struct sockaddr FAR*)&saATM,
		        sizeof(sockaddr_atm),NULL,NULL,SocketQOS,NULL);
    if (nReturn==SOCKET_ERROR)
    {
		strcpy(temp,"ATM WSACONNECT ERROR");
		_itoa(WSAGetLastError(),error,10);
		PutEventMessage(strcat(temp,error));
        return false;
    }
    else
	{
		PutEventMessage("ATM Connect OK");
        return true;
	}
}

//get ATM address of ATM server by use ATMHOST file to map from
//HOST NAME to ATM address
unsigned char* ATMClientSocket::GetATMAddress(CString h)
{
  int i,j,j0,j1;
  j=0;j1=0;i=0;
  int filelength;
  char *some;
  char hostadd[40];
  memset(hostadd,' ',40); 
  char *buffer;
  char *host;
  int hostlen=0;
  h = h+" ";
  host = (char*)h.operator LPCTSTR();
  CFile file("atmhost",CFile::modeRead);
  file.SeekToBegin();
  filelength = file.GetLength();
  buffer = new char[filelength+1];
  file.Read(buffer,filelength);
  file.Close();
  //file.ReadString(buffer,filelength);
  buffer=strlwr(buffer) ;
  host=strlwr(host);
  some=strstr(buffer,host);
  if (some==NULL)
  {  
	 return('\0');
  };
  for (i=0;some[i]!=' ';i++)
  {
    if (some[i]!=' ')
        hostlen=hostlen+1;
  };
  for (i=0;i<hostlen;i++)
    if (some[i]!=host[i]) return('\0');
  for (i=hostlen, j=0;some[i]!='\r';i++)
    {
      // fill address to hostadd.c_str()
      if ( (some[i]!=' ')&&(some[i]!='.'))
           {
            hostadd[j]=some[i];
             j++;
           }
    } ;
  hostadd[40]='\0';
  unsigned char* add=(unsigned char*)malloc(20);
  int x;
  for(x=0;x<20;x++)
  add[x]=' ';
  int k;
  int n;
  for (n=0,k=0;n<40;n=n+2,k++)
  {
    if (hostadd[n] >= 97 )
    { j0 = hostadd[n]-87; }
   else if (hostadd[n] >=48)
    { j0= hostadd[n]-48;};
   if (hostadd[n+1] >= 97 )
    { j1 = hostadd[n+1]-87;}
   else if (hostadd[n+1] >=48 )
    { j1= hostadd[n+1]-48;};
     j =(j0*16)+j1;
     add[k]=(char)j;
  };
   add[20]=NULL;
  return(add);
}

//set saATM variable
void ATMClientSocket::ATMSetsaATM(sockaddr_atm saServer)
{
	memmove(&saATM,&saServer,sizeof(sockaddr_atm));
}

//get VPI and VIC of connection
ATM_CONNECTION_ID ATMClientSocket::GetATMConnectionID()
{
	char temp[256];
	char error[256];
	DWORD deviceID=0, bytes;
	ATM_CONNECTION_ID ATMConnectionID;
	if (WSAIoctl(s,SIO_GET_ATM_CONNECTION_ID,(LPVOID)&deviceID,sizeof(DWORD),
	(LPVOID)&ATMConnectionID,sizeof(ATM_CONNECTION_ID),&bytes,NULL,NULL) == SOCKET_ERROR)
	{
		strcpy(temp,"ATM Server Find VPI,VCI Error");
		_itoa(WSAGetLastError(),error,10);
	    PutEventMessage(strcat(temp,error));
	}
	else
	{
	   	PutEventMessage("ATM Server FindConnectionID() OK");		
	}
    return ATMConnectionID;
}
