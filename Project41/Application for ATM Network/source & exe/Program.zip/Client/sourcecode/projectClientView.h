// projectClientView.h : interface of the CProjectClientView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROJECTCLIENTVIEW_H__89312E62_DC9C_11D2_881B_0020480E452C__INCLUDED_)
#define AFX_PROJECTCLIENTVIEW_H__89312E62_DC9C_11D2_881B_0020480E452C__INCLUDED_
#include "ATMClientSocket.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CProjectClientView : public CFormView
{
protected: // create from serialization only
	CProjectClientView();
	DECLARE_DYNCREATE(CProjectClientView)

public:
	//{{AFX_DATA(CProjectClientView)
	enum { IDD = IDD_PROJECTCLIENT_FORM };
	CListBox	m_eventlog;
	CString	m_atmhostname;
	CString	m_mbs;
	CString	m_pcr;
	CString	m_receivebuffer;
	CString	m_scr;
	CString	m_sel;
	CString	m_vci;
	CString	m_vpi;
	CString	m_sendbuffer;
	//}}AFX_DATA

// Attributes
public:
	CProjectClientDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CProjectClientView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CProjectClientView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	ATMClientSocket* ATMClient;
	int QoSCheck;

// Generated message map functions
protected:
	//{{AFX_MSG(CProjectClientView)
	afx_msg void OnConnect();
	afx_msg void OnCbr();
	afx_msg void OnVbr();
	afx_msg void OnUbr();
	afx_msg void OnDisconnect();
	afx_msg void OnRqservice();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in projectClientView.cpp
inline CProjectClientDoc* CProjectClientView::GetDocument()
   { return (CProjectClientDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROJECTCLIENTVIEW_H__89312E62_DC9C_11D2_881B_0020480E452C__INCLUDED_)
