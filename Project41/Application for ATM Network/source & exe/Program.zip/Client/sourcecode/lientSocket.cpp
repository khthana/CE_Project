// lientSocket.cpp: implementation of the ClientSocket class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "lientSocket.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

ClientSocket::ClientSocket()
{

}

ClientSocket::ClientSocket(int Addr,int Sock,int Protocol,int maxsendbuf,int maxreceivebuf,CListBox* Log)
:MySocket(Addr,Sock,Protocol,maxsendbuf,maxreceivebuf,Log)
{

}


ClientSocket::~ClientSocket()
{

}

