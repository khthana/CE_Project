// FTPFILE.cpp : implementation file
//

#include "stdafx.h"
#include "projectClient.h"
#include "FTPFILE.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// FTPFILE dialog


FTPFILE::FTPFILE(CWnd* pParent /*=NULL*/)
	: CDialog(FTPFILE::IDD, pParent)
{
	//{{AFX_DATA_INIT(FTPFILE)
	//m_ftpfilename = _T("");
	//m_transferrate = _T("");
	//}}AFX_DATA_INIT
}


void FTPFILE::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(FTPFILE)
	DDX_Control(pDX, IDC_PROGRESS1, m_ftpprogress);
//	DDX_Text(pDX, IDC_FTPFILENAME, m_ftpfilename);
//	DDX_Text(pDX, IDC_TRANSFERRATE, m_transferrate);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(FTPFILE, CDialog)
	//{{AFX_MSG_MAP(FTPFILE)
	ON_BN_CLICKED(IDC_OK, OnOk)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// FTPFILE message handlers

BOOL FTPFILE::OnInitDialog() 
{
	CDialog::OnInitDialog();
	UpdateData(true);
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void FTPFILE::OnOk() 
{
//	CloseFlag=true;
	// TODO: Add your control notification handler code here
}

//DEL void FTPFILE::SetCloseFlag(bool flag)
//DEL {
//DEL 	CloseFlag=flag;
//DEL }

//DEL bool FTPFILE::GetCloseFlag()
//DEL {
//DEL 	return CloseFlag;
//DEL }
