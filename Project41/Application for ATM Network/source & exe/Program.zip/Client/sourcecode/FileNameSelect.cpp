// FileNameSelect.cpp : implementation file
//

#include "stdafx.h"
#include "projectClient.h"
#include "FileNameSelect.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// FileNameSelect dialog


FileNameSelect::FileNameSelect(CWnd* pParent /*=NULL*/)
	: CDialog(FileNameSelect::IDD, pParent)
{
	//{{AFX_DATA_INIT(FileNameSelect)
	m_filename = _T("");
	//}}AFX_DATA_INIT
}


void FileNameSelect::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(FileNameSelect)
	DDX_Control(pDX, IDC_LISTFILENAME, m_listfilename);
	DDX_Text(pDX, IDC_FILENAME, m_filename);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(FileNameSelect, CDialog)
	//{{AFX_MSG_MAP(FileNameSelect)
	ON_BN_CLICKED(IDC_FTPFILE, OnFtpfile)
	ON_BN_CLICKED(IDC_GETSTREAM, OnGetstream)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// FileNameSelect message handlers

//choose FTP file
void FileNameSelect::OnFtpfile() 
{
	UpdateData(true);
	if (strcmp(m_filename.operator LPCTSTR(),"")!=0)
	{
		FTPorStream=true;
		CDialog::OnOK();
	}
	// TODO: Add your control notification handler code here
	
}

//choose Getstream
void FileNameSelect::OnGetstream()
{
	UpdateData(true);
	if (strcmp(m_filename.operator LPCTSTR(),"")!=0)
	{
		FTPorStream=false;
		CDialog::OnOK();
	}
	// TODO: Add your control notification handler code here
}

CString FileNameSelect::GetFilename()
{
	return m_filename;
}

bool FileNameSelect::GetFTPorStream()
{
	return FTPorStream;
}

//cancel to request service
void FileNameSelect::OnCancel() 
{
	// TODO: Add extra cleanup here
	CDialog::OnCancel();
}
