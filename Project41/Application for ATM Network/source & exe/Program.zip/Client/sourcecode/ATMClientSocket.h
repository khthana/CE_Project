// ATMClientSocket.h: interface for the ATMClientSocket class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ATMCLIENTSOCKET_H__3B510286_D7D7_11D2_BBF3_0020182A2CC3__INCLUDED_)
#define AFX_ATMCLIENTSOCKET_H__3B510286_D7D7_11D2_BBF3_0020182A2CC3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "lientSocket.h"

class ATMClientSocket : public ClientSocket  
{
protected:
	sockaddr_atm saATM;
	UCHAR ATMSEL;
public:
	ATM_CONNECTION_ID GetATMConnectionID();
	ATMClientSocket();
	ATMClientSocket(int Addr,int Sock,int Protocol,UCHAR sel,int maxsendbuf,int maxreceivebuf,LPQOS qos,CListBox* Log);
	virtual ~ATMClientSocket();
	bool ATMConnect();
    unsigned char* GetATMAddress(CString host);
	void ATMSetsaATM(sockaddr_atm saServer);

};

#endif // !defined(AFX_ATMCLIENTSOCKET_H__3B510286_D7D7_11D2_BBF3_0020182A2CC3__INCLUDED_)
