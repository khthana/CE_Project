//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by projectClient.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_PROJECTCLIENT_FORM          101
#define IDR_MAINFRAME                   128
#define IDR_PROJECTYPE                  129
#define IDD_LISTFILE                    130
#define IDD_FTPFILE                     131
#define IDD_DIALOGPLAYER                133
#define IDI_ICONPLAY                    134
#define IDI_ICONBEGIN                   135
#define IDI_ICONEND                     136
#define IDI_ICONFORWARD                 137
#define IDI_ICONSTOP                    139
#define IDI_ICONPAUSE                   140
#define IDI_ICONFULLSCREEN              141
#define IDI_ICONREWIND                  142
#define IDC_RQSERVICE                   1000
#define IDPLAY                          1000
#define IDC_LISTFILENAME                1001
#define IDSTOP                          1001
#define IDC_FILENAME                    1002
#define IDPAUSE                         1002
#define IDC_GETSTREAM                   1003
#define IDBEGIN                         1003
#define IDC_FTPFILE                     1004
#define IDC_PROGRESS1                   1004
#define IDREWIND                        1004
#define IDC_FTPFILENAME                 1005
#define IDC_DISPLAY                     1005
#define IDEND                           1006
#define IDC_TRANSFERRATE                1006
#define IDC_EVENTLOG                    1007
#define IDC_SLIDER                      1007
#define IDC_OK                          1007
#define IDC_FRAME                       1008
#define IDC_FRAMEEND                    1009
#define IDFORWARD                       1010
#define IDFULLSCREEN                    1011
#define IDC_CONNECT                     1012
#define IDC_DISCONNECT                  1013
#define IDC_ATMHOST                     1014
#define IDC_CBR                         1015
#define IDC_VBR                         1016
#define IDC_UBR                         1017
#define IDC_PCR                         1018
#define IDC_SCR                         1019
#define IDC_MBS                         1020
#define IDC_ATMHOSTNAME                 1021
#define IDC_SEL                         1022
#define IDC_VPI                         1023
#define IDC_VCI                         1024
#define IDC_SENDBUFFER                  1025
#define IDC_RECEIVEBUFFER               1026

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        143
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
