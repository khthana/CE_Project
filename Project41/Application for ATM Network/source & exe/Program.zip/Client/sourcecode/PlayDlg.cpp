// PlayDlg.cpp : implementation file
//

#include "stdafx.h"
#include "projectClient.h"
#include "PlayDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

typedef struct SLIDER
{
	CPlayStream *pss;
	CSliderCtrl *sl;
	CEdit       *ed;
}slider;

UINT HScrollSliderThread( LPVOID slider);    


/////////////////////////////////////////////////////////////////////////////
// CPlayDlg dialog


CPlayDlg::CPlayDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPlayDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPlayDlg)
	m_frame = 0;
	m_frameEnd = 0;
	m_slidervalue = 0;
	//}}AFX_DATA_INIT
	ps=NULL;
}


void CPlayDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPlayDlg)
	DDX_Control(pDX, IDSTOP, m_buttonStop);
	DDX_Control(pDX, IDREWIND, m_buttonRewind);
	DDX_Control(pDX, IDPLAY, m_buttonPlay);
	DDX_Control(pDX, IDPAUSE, m_buttonPause);
	DDX_Control(pDX, IDFULLSCREEN, m_buttonFullscreen);
	DDX_Control(pDX, IDFORWARD, m_buttonForward);
	DDX_Control(pDX, IDEND, m_buttonEnd);
	DDX_Control(pDX, IDC_SLIDER, m_slider);
	DDX_Control(pDX, IDC_FRAME, m_editFrameStart);
	DDX_Control(pDX, IDC_DISPLAY, m_display);
	DDX_Control(pDX, IDBEGIN, m_buttonBegin);
	DDX_Text(pDX, IDC_FRAME, m_frame);
	DDX_Text(pDX, IDC_FRAMEEND, m_frameEnd);
	DDX_Slider(pDX, IDC_SLIDER, m_slidervalue);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPlayDlg, CDialog)
	//{{AFX_MSG_MAP(CPlayDlg)
	ON_WM_DESTROY()
	ON_WM_HSCROLL()
	ON_BN_CLICKED(IDBEGIN, OnBegin)
	ON_BN_CLICKED(IDEND, OnEnd)
	ON_BN_CLICKED(IDFORWARD, OnForward)
	ON_BN_CLICKED(IDFULLSCREEN, OnFullscreen)
	ON_BN_CLICKED(IDPAUSE, OnPause)
	ON_BN_CLICKED(IDPLAY, OnPlay)
	ON_BN_CLICKED(IDREWIND, OnRewind)
	ON_BN_CLICKED(IDSTOP, OnStop)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPlayDlg message handlers

void CPlayDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	if (ps != NULL)
	{
	    ps->Stop();
		ps->~CPlayStream();
		DWORD exit=0;
	}
}

void CPlayDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	if (ps!= NULL){

		UpdateData(TRUE);
		m_frame=m_slidervalue;
		UpdateData(FALSE);
		ps->SetPosition((LONGLONG)m_frame);
	};
	
	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}

BOOL CPlayDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	m_buttonPlay.SetIcon(AfxGetApp()->LoadIcon(IDI_ICONPLAY));
	m_buttonStop.SetIcon(AfxGetApp()->LoadIcon(IDI_ICONSTOP));
	m_buttonPause.SetIcon(AfxGetApp()->LoadIcon(IDI_ICONPAUSE));
	m_buttonForward.SetIcon(AfxGetApp()->LoadIcon(IDI_ICONFORWARD));
	m_buttonEnd.SetIcon(AfxGetApp()->LoadIcon(IDI_ICONEND));
	m_buttonBegin.SetIcon(AfxGetApp()->LoadIcon(IDI_ICONBEGIN));
	m_buttonRewind.SetIcon(AfxGetApp()->LoadIcon(IDI_ICONREWIND));
	m_buttonFullscreen.SetIcon(AfxGetApp()->LoadIcon(IDI_ICONFULLSCREEN));
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPlayDlg::OnBegin() 
{
	ps->ToBegin();
	
}

void CPlayDlg::OnEnd() 
{
	ps->ToEnd();
	
}

void CPlayDlg::OnForward() 
{
	ps->Forward();
	
}

void CPlayDlg::OnFullscreen() 
{
	ps->FullScreen(OATRUE);
	
}

void CPlayDlg::OnPause() 
{
	if (ps!=NULL){
		ps->Pause();
	}
}

void CPlayDlg::OnPlay() 
{
	if (ps==NULL) {
		ps = new CPlayStream(m_buffer,m_bufferSize,m_fileSize,m_display.m_hWnd,ATMClient);
		m_slider.SetRange(1,(int)ps->GetRange());
		m_frame = 0;
		m_frameEnd = (LONG)ps->GetRange();	
		UpdateData(FALSE);	
		struct SLIDER *slider;
		slider = new SLIDER;
		slider->pss = ps;
		slider->sl = &m_slider;
		slider->ed = &m_editFrameStart;
		ps->Play();
	}
	else {
		ps->Play();
	};
	
}

void CPlayDlg::OnRewind() 
{
	ps->Rewind();
	
}

void CPlayDlg::OnStop() 
{
	if (ps!=NULL){
		ps->Stop();
	}
}

LONGLONG CPlayDlg::GetPosition()
{
	if (ps == NULL) {
		return 0 ;
	}
	else if (ps != NULL){
	
		LONGLONG position;
		position = ps->p_ms->GetPosition();
		return position;
	};
	return 0;
}


UINT HScrollSliderThread( LPVOID sl) 
{    
	SLIDER *slider = (SLIDER*)sl;
	CSliderCtrl *sll = (CSliderCtrl*)slider->sl;
	CPlayStream *pll = (CPlayStream*)slider->pss;
	CEdit *ed = (CEdit*)slider->ed;
	while (1){

		LONGLONG position;
		position = pll->GetCurrentFrame();
		sll->SetPos((int)position);
		char test[20];
		_i64toa((__int64)position,test,10);
		ed->SetSel(0,-1,TRUE);
		ed->ReplaceSel(test,TRUE);
		Sleep(100);
	};
}

void CPlayDlg::SetBufferSize(DWORD buffersize,DWORD filesize)
{
	m_bufferSize = buffersize;
	m_fileSize = filesize;
}

BOOL CPlayDlg::PutBuffer(PBYTE buff)
{
	if (buff ==NULL)
	{
		MessageBox("Buffer not allocated!","ERROR MESSAGE!",MB_OK);
		return(false);
	}
	else if (ps == NULL)
	{		
		m_buffer = buff;
		return(true);
	};
	return(true);

}

void CPlayDlg::GetSocket(ATMClientSocket *sock)
{
	ATMClient=sock;
}
