// PlayStream.h: interface for the CPlayStream class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PLAYSTREAM_H__867A9AD4_DB91_11D2_BC54_000000000000__INCLUDED_)
#define AFX_PLAYSTREAM_H__867A9AD4_DB91_11D2_BC54_000000000000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <streams.h>
#include <asyncio.h>
#include <asyncrdr.h>
#include "ATMClientSocket.h"
// MPEG1 : 6.98 Kbytes/Frame; 1.74 Mb/s;
/////////////////////////////////////////////////////////////////////////////////////

class CMemStream : public CAsyncStream
{
public:
	//Constructor for CMemStream Class
    CMemStream(LPBYTE pbData, 
			   LONGLONG llLength, 
			   LONGLONG bufferLength,
			   ATMClientSocket* sock,
			   DWORD dwKBPerSec = INFINITE
			   )
			   :m_pbData(pbData),
		        m_llLength(llLength),
				m_llPosition(0),
				m_dwKBPerSec(dwKBPerSec)
    {
		m_dwTimeStart = timeGetTime();
		m_bufferLength=bufferLength;
		m_pbDataBuffer = new BYTE[(int)m_bufferLength];
		m_pbDataBuffer = new BYTE[(int)m_bufferLength];
		m_ready = true;
		ATMClient=sock;

    }
    
	//Method for set position of video file
	HRESULT SetPointer(LONGLONG llPos)
    { 
		if (llPos < 0 || llPos > m_llLength) {
            return S_FALSE;
        } else {
            m_llPosition = llPos;
            return S_OK;
        }
    }

	//Method for reading buffer to display video
    HRESULT Read(PBYTE pbBuffer,
                 DWORD dwBytesToRead,
                 BOOL bAlign,
                 LPDWORD pdwBytesRead)
	{
		m_byteToRead = 0;
		DWORD StreamPointer;
		char* temp=new char[(DWORD)m_bufferLength];
		CAutoLock lck(&m_csLock);
		
		DWORD dwReadLength;
		LONGLONG offset;
		offset = m_llPosition % m_bufferLength;
		DWORD readLength1,readLength2;
		if ((offset + dwBytesToRead > m_bufferLength)&&(m_llPosition + dwBytesToRead < m_llLength)){
			
			m_byteToRead = dwBytesToRead;
			CAutoLock lock(&m_readLock);

			readLength1 = (DWORD)(m_bufferLength-offset);
		 	readLength2 = (DWORD)(dwBytesToRead - readLength1);
				
			CopyMemory((PVOID)pbBuffer, (PVOID)(m_pbData + offset),
                      readLength1);

			ATMClient->PutHeader("RDSTREAMFI");
			StreamPointer=(DWORD) m_llPosition+readLength1;
			_itoa((int)StreamPointer,temp,10);
			ATMClient->SetSendBuffer(temp,(int)m_bufferLength);//sizeof(temp));
			ATMClient->SendData();
			ATMClient->ReceiveData();
			if (strcmp(ATMClient->GetHeader(),"SENDSTREAM")==0)
			{
				ATMClient->GetReceiveBuffer(temp);
				m_pbDataBuffer=(PBYTE)temp;
			}
			else
			{
				MessageBox(NULL,"error stream header","error",MB_OK);
			}
			
			m_pbData = m_pbDataBuffer;
			offset=0;
			CopyMemory((PVOID)(pbBuffer+readLength1), (PVOID)(m_pbData+offset),
                      readLength2);
			dwReadLength = readLength1+readLength2;
			m_llPosition += dwReadLength;
			*pdwBytesRead = dwReadLength;
		}

		else {

			 dwReadLength = dwBytesToRead;
			 CopyMemory((PVOID)pbBuffer, (PVOID)(m_pbData + offset),
                      dwReadLength);
		     m_llPosition += dwReadLength;
			 *pdwBytesRead = dwReadLength;
		};
		m_ready = true;
        return S_OK;
    }

	//Method for returning remain size of video file
    LONGLONG Size(LONGLONG *pSizeAvailable)
    {
		LONGLONG llCurrentAvailable =
            Int32x32To64((timeGetTime() - m_dwTimeStart),m_dwKBPerSec);
        *pSizeAvailable =  min(m_llLength, llCurrentAvailable);
		return m_llLength;
    }
    DWORD Alignment()
    {
		return 1;
    }
    void Lock()
    {
		m_csLock.Lock();
    }
    void Unlock()
    {
		m_csLock.Unlock();
    }
	

	LONGLONG CMemStream::GetPosition()
	{
		return(m_llPosition);
	}

private:
    CCritSec       m_csLock;
	CCritSec       m_readLock;
    PBYTE          m_pbData;			//ready data for reading
	PBYTE          m_pbDataBuffer;		//data buffer
    LONGLONG       m_llLength;			//length of media file
    LONGLONG       m_llPosition;
	BOOL           m_ready;             //check for write buffer;
	DWORD          m_byteToRead;
    DWORD          m_dwKBPerSec;
    DWORD          m_dwTimeStart;
	LONGLONG       m_bufferLength;		//length of buffer
	ATMClientSocket* ATMClient;
};


//////////////////////////////////////////////////////////////////////////////

class CMemReader : public CAsyncReader
{
public:

 
    STDMETHODIMP Register()
    {
        return S_OK;
    }
    STDMETHODIMP Unregister()
    {
        return S_OK;
    }
    CMemReader(CMemStream *pStream, CMediaType *pmt, HRESULT *phr) :
        CAsyncReader(NAME("Mem Reader"), NULL, pStream, phr)
    {
        m_mt = *pmt;
    }

};


////////////////////////////////////////////////////////////////////////////////

class CPlayStream  
{
public:
	LONGLONG GetCurrentFrame();
	BOOL FullScreen(long out);
	BOOL ToEnd();
	BOOL ToBegin();
	BOOL Forward();
	BOOL Rewind();
	LONGLONG GetRange();  // get range of media stream;
	BOOL SetPosition(LONGLONG pos);
	BOOL Stop();
	BOOL Pause();
	BOOL Play();
	BOOL CreateFilter(IFilterGraph **pp_fg,CMemReader *p_r);
	CPlayStream(PBYTE buffer,DWORD bufferSize,DWORD fileSize,HWND hwnd,ATMClientSocket* sock);
	virtual ~CPlayStream();
	CMemStream *p_ms;
private:	
    LONG eventCode,param1,param2;
	HANDLE m_hGraphNotifyEvent;
	PBYTE m_buffer;
	DWORD m_bufferSize;
	DWORD m_fileSize;
	LONGLONG m_frameRange;
    HWND m_hWnd;
	IFilterGraph *p_fg;
	IMediaControl *p_mc;
    IMediaEventEx *p_me;
    IVideoWindow *p_vw;
	IMediaPosition *p_mp;
	IGraphBuilder *p_gb;
	IMediaSeeking *p_mseek;
	CMemReader *p_mr;
protected:
	ATMClientSocket* ATMClient;
};


//////////////////////////////////////////////////////////////////////////////////

#endif // !defined(AFX_PLAYSTREAM_H__867A9AD4_DB91_11D2_BC54_000000000000__INCLUDED_)
