#if !defined(AFX_FTPFILE_H__A2851DF3_E36A_11D2_BC25_0020480E452C__INCLUDED_)
#define AFX_FTPFILE_H__A2851DF3_E36A_11D2_BC25_0020480E452C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FTPFILE.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// FTPFILE dialog

class FTPFILE : public CDialog
{
// Construction
public:
	FTPFILE(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(FTPFILE)
	enum { IDD = IDD_FTPFILE };
	CProgressCtrl	m_ftpprogress;
	CString	m_ftpfilename;
	CString	m_transferrate;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(FTPFILE)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
//	bool CloseFlag;

	// Generated message map functions
	//{{AFX_MSG(FTPFILE)
	virtual BOOL OnInitDialog();
	afx_msg void OnOk();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FTPFILE_H__A2851DF3_E36A_11D2_BC25_0020480E452C__INCLUDED_)
