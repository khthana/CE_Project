#include <winsock2.h>
#include <ws2atm.h>
// MySocket.h: interface for the MySocket class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYSOCKET_H__3B51027C_D7D7_11D2_BBF3_0020182A2CC3__INCLUDED_)
#define AFX_MYSOCKET_H__3B51027C_D7D7_11D2_BBF3_0020182A2CC3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class MySocket // :public CWinThread
{
protected:
	DWORD SizeofReceiveBuffer;
	DWORD SizeofSendBuffer;
	DWORD ByteReceive;
	DWORD ByteSend;
	SOCKET s;
	WSABUF ReceiveBuffer;
	WSABUF SendBuffer;
	int nReturn;
	int AddressFamily;
	int SocketType;
	int ProtocolType;
	CListBox* EventLog;
	bool Terminated;
    WSAEVENT SocketEvent;
	char header[11];

public:
	DWORD GetByteReceive();
	DWORD GetByteSend();
	MySocket();
	MySocket(int Addr,int Sock,int Protocol,int maxsendbuf,int maxreceivebuf,CListBox* EventLog);
	virtual ~MySocket();
	bool CreateSocket();
	bool CloseSocket();
	int SendData();
	int ReceiveData();
	void SetSocket(SOCKET s1){s=s1;};
	bool GetTerminated(){return Terminated;};
	void PutEventMessage(char* Message);
	bool PutHeader(char* header);
	char* GetHeader();
	void GetReceiveBuffer(char* temp);
	void SetSendBuffer(char* sendbuf,int length);
	DWORD GetSizeofReceiveBuffer();
	DWORD GetSizeofSendBuffer();
};

#endif // !defined(AFX_MYSOCKET_H__3B51027C_D7D7_11D2_BBF3_0020182A2CC3__INCLUDED_)
