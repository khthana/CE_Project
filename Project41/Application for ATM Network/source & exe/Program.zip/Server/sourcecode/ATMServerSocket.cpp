// ATMServerSocket.cpp: implementation of the ATMServerSocket class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ATMServerSocket.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

ATMServerSocket::ATMServerSocket()
{

}
ATMServerSocket::ATMServerSocket(int Addr,int Sock,int Protocol,int listen,int max,UCHAR sel,int maxsendbuf,int maxreceivebuf,CListBox * Log)
:ServerSocket(Addr,Sock,Protocol,listen,max,maxsendbuf,maxreceivebuf,Log)
{
	ATMSEL=sel;
	int i=0;
	while (i<MaximumConnection)
	{
		ATMClient[i]= NULL;
		i++;
	}
}


ATMServerSocket::~ATMServerSocket()
{

}

//bind socket
bool ATMServerSocket::ATMBind()
{
	char temp[256];
	char error[256];
	nReturn=bind(s,(const struct sockaddr FAR *)&saATM,sizeof(struct sockaddr_atm));
    if (nReturn==SOCKET_ERROR)
    {
		strcpy(temp,"ATM Server bind() error");
		_itoa(WSAGetLastError(),error,10);
        PutEventMessage(strcat(temp,error));
        return false;
    }
    else
    {
        PutEventMessage("ATM Server's socket bind() ok");
        return true;
    }
}
//listen socket
bool ATMServerSocket::ATMListen()
{
	char temp[256];
	char error[256];
    nReturn=listen(s,ListenQueue);
    if (nReturn==SOCKET_ERROR)
    {
		strcpy(temp,"ATM Server's socket listen() error");
		_itoa(WSAGetLastError(),error,10);
       PutEventMessage(strcat(temp,error));
       return false;
    }
    else
    {
        PutEventMessage("ATM Server's socket listen() ok");
        return true;
    }

}

//set saATM variable
void ATMServerSocket::ATMSetsaATM(sockaddr_atm saServer)
{
	saATM=saServer;
}

//find ATM address 
ATM_ADDRESS ATMServerSocket::ATMFindAddress()
{
	char temp[256];
	char error[256];
	DWORD deviceID=0, bytes;
	memset((void *)&saATM,0,sizeof(struct sockaddr_atm));
	if (WSAIoctl(s,SIO_GET_ATM_ADDRESS,(LPVOID)&deviceID,sizeof(DWORD),
	(LPVOID)&saATM.satm_number,sizeof(ATM_ADDRESS),&bytes,NULL,NULL) == SOCKET_ERROR)
	{
		strcpy(temp,"ATM Server Find Address Error");
		_itoa(WSAGetLastError(),error,10);
	    PutEventMessage(strcat(temp,error));
	}
	else
	{
	   	PutEventMessage("ATM Server FindAddress() OK");		
	}
    return saATM.satm_number;
}

//accept client 
SOCKET ATMServerSocket::ATMAccept()
{
	SOCKET temp;
	int	len=sizeof(sockaddr_atm);
	temp=WSAAccept(s,(struct sockaddr FAR *)&saATM,&len,NULL,0);
	if (temp==INVALID_SOCKET)
	{
		PutEventMessage("WSAAccept () error");
		return 0;
	}
	else
	{
		return temp;
	}
}

//create socket that use in thread that manage client connection
void ATMServerSocket::ATMCreateClientThread(int i,int family,int sock,int protocol,int maxsendbuf,int maxreceivebuf,CListBox* log)
{
	ATMClient[i]=new MySocket(family,sock,protocol,maxsendbuf,maxreceivebuf,log);
}

//delete Mysocket object that use in thread
void ATMServerSocket::ATMDeleteClientThread(int i)
{
	delete ATMClient[i];
}

MySocket* ATMServerSocket::ATMGetClientThread(int i)
{
	return ATMClient[i];
}

//get VPI and VCI that use in connection
ATM_CONNECTION_ID ATMServerSocket::GetATMConnectionID(SOCKET sock)
{
	char temp[256];
	char error[256];
	DWORD deviceID=0, bytes;
	ATM_CONNECTION_ID ATMConnectionID;
	if (WSAIoctl(sock,SIO_GET_ATM_CONNECTION_ID,(LPVOID)&deviceID,sizeof(DWORD),
	(LPVOID)&ATMConnectionID,sizeof(ATM_CONNECTION_ID),&bytes,NULL,NULL) == SOCKET_ERROR)
	{
		strcpy(temp,"ATM Server Find VPI,VCI Error");
		_itoa(WSAGetLastError(),error,10);
	    PutEventMessage(strcat(temp,error));
	}
	else
	{
	   	PutEventMessage("ATM Server FindConnectionID() OK");		
	}
    return ATMConnectionID;
}
