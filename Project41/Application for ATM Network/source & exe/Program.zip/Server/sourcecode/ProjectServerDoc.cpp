// ProjectServerDoc.cpp : implementation of the CProjectServerDoc class
//

#include "stdafx.h"
#include "ProjectServer.h"

#include "ProjectServerDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CProjectServerDoc

IMPLEMENT_DYNCREATE(CProjectServerDoc, CDocument)

BEGIN_MESSAGE_MAP(CProjectServerDoc, CDocument)
	//{{AFX_MSG_MAP(CProjectServerDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CProjectServerDoc construction/destruction

CProjectServerDoc::CProjectServerDoc()
{
	// TODO: add one-time construction code here

}

CProjectServerDoc::~CProjectServerDoc()
{
}

BOOL CProjectServerDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CProjectServerDoc serialization

void CProjectServerDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CProjectServerDoc diagnostics

#ifdef _DEBUG
void CProjectServerDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CProjectServerDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CProjectServerDoc commands
