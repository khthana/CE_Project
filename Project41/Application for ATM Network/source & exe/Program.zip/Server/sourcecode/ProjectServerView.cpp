// ProjectServerView.cpp : implementation of the CProjectServerView class
//

#include "stdafx.h"
#include "ProjectServer.h"

#include "ProjectServerDoc.h"
#include "ProjectServerView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//global variable
CEdit* SendStat;
CEdit* ReceiveStat;
CEdit* NumberClient;
DWORD SendCount=0;
DWORD ReceiveCount=0;

int ClientCount;   //count for number of client
CRITICAL_SECTION CriticalSectionHandle; //lock update
const headersize=10;

//// update send stat
void AddSendStat(DWORD add)
{
	char temp[20];
	EnterCriticalSection(&CriticalSectionHandle);
	SendCount+=add;
	SendStat->SetSel(0,-1,true);
	SendStat->ReplaceSel(_itoa(SendCount/1024,temp,10));
	LeaveCriticalSection(&CriticalSectionHandle);
}

// update receive stat
void AddReceiveStat(DWORD add)
{
	char temp[20];
	EnterCriticalSection(&CriticalSectionHandle);
	ReceiveCount+=add;
	ReceiveStat->SetSel(0,-1,true);
	ReceiveStat->ReplaceSel(_itoa(ReceiveCount/1024,temp,10));
	LeaveCriticalSection(&CriticalSectionHandle);
}

//update client count
void UpdateClientCount()
{
	char temp[5];
	EnterCriticalSection(&CriticalSectionHandle);
	NumberClient->SetSel(0,-1,true);
	NumberClient->ReplaceSel(_itoa(ClientCount,temp,10));
	LeaveCriticalSection(&CriticalSectionHandle);
}
//initial ClientCount
void InitialClientCount()
{
	InitializeCriticalSection(&CriticalSectionHandle);
	ClientCount=0;
}
//increase ClientCount
void IncClientCount()
{
	EnterCriticalSection(&CriticalSectionHandle);
	ClientCount++;
	LeaveCriticalSection(&CriticalSectionHandle);
}
//decrease ClientCount
void DecClientCount()
{
	EnterCriticalSection(&CriticalSectionHandle);
	if (ClientCount>0)
	{
		ClientCount--;
	}
	LeaveCriticalSection(&CriticalSectionHandle);
}

//Server send and receive data with client
UINT ClientThread(LPVOID ClientParam)
{
	MySocket* ATMClientThread=(MySocket*)ClientParam;
	CFile ListFile;
	CFile FTPFile;
	CFile StreamFile;
	long StreamPointer;
	DWORD count=0;
	DWORD ListFileLength;
	char* temp=new char[ATMClientThread->GetSizeofSendBuffer()];
	while (true)
	{
		ATMClientThread->ReceiveData();		
//		AddReceiveStat(ATMClientThread->GetByteReceive());
		if (strcmp(ATMClientThread->GetHeader(),"DISCONNECT")==0)
		{
			ATMClientThread->PutEventMessage("Client Close Connection");
			DecClientCount();
			UpdateClientCount();
			break;
		}
		else
//list filecommand
///////////////////////////////////////////////////////////////
		//client request list file
		if (strcmp(ATMClientThread->GetHeader(),"RQLISTFILE")==0)
		{
			ListFile.Open("mpeg.txt",CFile::modeRead|CFile::shareDenyNone,NULL);
			ListFileLength=ListFile.GetLength();
			ATMClientThread->PutHeader("SSIZELISTF");
			memset(temp,0,ATMClientThread->GetSizeofSendBuffer());
			_itoa(ListFileLength,temp,10);
		    ATMClientThread->SetSendBuffer(temp,ATMClientThread->GetSizeofSendBuffer());
			ATMClientThread->SendData();
//			AddSendStat(ATMClientThread->GetByteSend());
		}
		else
		//client ready to receive list file
		if (strcmp(ATMClientThread->GetHeader(),"RDLISTFILE")==0)
		{
			if ((ListFileLength % ATMClientThread->GetSizeofSendBuffer())>0)
			{
				count = ListFileLength / ATMClientThread->GetSizeofSendBuffer()+1;
			}
			else
			{
				count = ListFileLength / ATMClientThread->GetSizeofSendBuffer();
			}
			while (count>0)
			{
				ATMClientThread->PutHeader("SSENDLISTF");
				memset(temp,0,ATMClientThread->GetSizeofSendBuffer());
				ATMClientThread->SetSendBuffer(temp,ListFile.ReadHuge((char far*)temp,ATMClientThread->GetSizeofSendBuffer()-headersize));
				ATMClientThread->SendData();
//				AddSendStat(ATMClientThread->GetByteSend());
				count--;
			}
			ListFile.Close();
		}
		else
//FTP service
////////////////////////////////////////////////////////////////////////////
	    //client request FTP file
		if (strcmp(ATMClientThread->GetHeader(),"RQFTPFILE#")==0)
		{
			ATMClientThread->PutHeader("SIZEFTPFIL");
			memset(temp,0,ATMClientThread->GetSizeofSendBuffer());
			ATMClientThread->GetReceiveBuffer(temp);
			FTPFile.Open(temp,CFile::modeRead|CFile::shareDenyNone,NULL);
			ListFileLength=FTPFile.GetLength();
			memset(temp,0,ATMClientThread->GetSizeofSendBuffer());
			_itoa(ListFileLength,temp,10);
		    ATMClientThread->SetSendBuffer(temp,ATMClientThread->GetSizeofSendBuffer());
			ATMClientThread->SendData();
//			AddSendStat(ATMClientThread->GetByteSend());
		}
		else
		//client ready to receive FTP file
		if (strcmp(ATMClientThread->GetHeader(),"RDFTPFILE#")==0)
		{
			if ((ListFileLength % ATMClientThread->GetSizeofSendBuffer())>0)
			{
				count = ListFileLength / ATMClientThread->GetSizeofSendBuffer()+1;
			}
			else
			{
				count = ListFileLength / ATMClientThread->GetSizeofSendBuffer();
			}
			while (count>0)
			{
				ATMClientThread->PutHeader("SENDFTPFIL");
				memset(temp,0,ATMClientThread->GetSizeofSendBuffer());
				ATMClientThread->SetSendBuffer(temp,FTPFile.ReadHuge((char far*)temp,ATMClientThread->GetSizeofSendBuffer()-headersize));
				ATMClientThread->SendData();
//				AddSendStat(ATMClientThread->GetByteSend());
				count--;
			}
			FTPFile.Close();
		}
		else
//stream service
///////////////////////////////////////////////////////////////////////////////////
		//client request video stream file
		if (strcmp(ATMClientThread->GetHeader(),"RQSTREAMFI")==0)
		{
			memset(temp,0,ATMClientThread->GetSizeofSendBuffer());
			ATMClientThread->GetReceiveBuffer(temp);
			StreamFile.Open(temp,CFile::modeRead|CFile::shareDenyNone,NULL);
			ListFileLength=StreamFile.GetLength();
			ATMClientThread->PutHeader("SIZESTREAM");
			memset(temp,0,ATMClientThread->GetSizeofSendBuffer());
			_itoa(ListFileLength,temp,10);
   		    ATMClientThread->SetSendBuffer(temp,ATMClientThread->GetSizeofSendBuffer());
			ATMClientThread->SendData();
//			AddSendStat(ATMClientThread->GetByteSend());
		}
		else
		//client ready to receive video stream file
		if (strcmp(ATMClientThread->GetHeader(),"RDSTREAMFI")==0)
		{
			memset(temp,0,ATMClientThread->GetSizeofSendBuffer());
			ATMClientThread->GetReceiveBuffer(temp);
			StreamPointer=atoi(temp);
			ATMClientThread->PutHeader("SENDSTREAM");
			memset(temp,0,ATMClientThread->GetSizeofSendBuffer());
			StreamFile.Seek(StreamPointer,CFile::begin);
			ATMClientThread->SetSendBuffer(temp,StreamFile.ReadHuge((char far*)temp,ATMClientThread->GetSizeofSendBuffer()-headersize));
			ATMClientThread->SendData();
//			AddSendStat(ATMClientThread->GetByteSend());
		}
	}
	return 1;
}

// Server Accept Function
UINT AcceptThread(LPVOID Serverparam)
{
	ATMServerSocket* ATMServer;
	SOCKET tempsock;
	DWORD lpcode;
	CWinThread* Client[16];
	char vci[10];
	char vpi[10];
	char temp[256];
	ATM_CONNECTION_ID tempconid;
	int i=0;
	while (i<16)
	{
		Client[i]=NULL;
		i++;
	}
	ServerData* ATMServerData;
	ATMServerData=(ServerData*)Serverparam;
	//create server object
	ATMServer =new ATMServerSocket(AF_ATM,
								   SOCK_RAW,
								   ATMPROTO_AAL5,
							   	   atoi(ATMServerData->listenqueue),
								   atoi(ATMServerData->max),
								   (UCHAR)atoi(ATMServerData->sel),
								   atoi(ATMServerData->sizesend),
								   atoi(ATMServerData->sizereceive),
								   ATMServerData->eventlog);
    if (ATMServer->CreateSocket()==false)
	{
		delete ATMServer;
		WSACleanup();
		return 0;
	}
	else
	{
		//set saATMServer
		sockaddr_atm tempsaATM;
		tempsaATM.satm_family=AF_ATM;
		//get ATM address from WSAioctl
		tempsaATM.satm_number=ATMServer->ATMFindAddress();
		tempsaATM.satm_number.AddressType=ATM_NSAP;
		tempsaATM.satm_number.NumofDigits=ATM_ADDR_SIZE;
		tempsaATM.satm_number.Addr[19]=(UCHAR)atoi(ATMServerData->sel);
		tempsaATM.satm_blli.Layer2Protocol=SAP_FIELD_ABSENT;
		tempsaATM.satm_blli.Layer3Protocol=SAP_FIELD_ABSENT;
		tempsaATM.satm_bhli.HighLayerInfoType=SAP_FIELD_ABSENT;
		//set sockaddr_atm
		ATMServer->ATMSetsaATM(tempsaATM);
		//bind socket
		if (ATMServer->ATMBind()==false)
		{
			ATMServer->CloseSocket();
			delete ATMServer;
		    WSACleanup();
			return 0;
		}
		else
		{
			//listen socket
			if (ATMServer->ATMListen()==false)
			{
				ATMServer->CloseSocket();
				delete ATMServer;
			    WSACleanup();
				return 0;
			}
			else
			{
				ATMServer->PutEventMessage("ATM Server is Started");
			    int nLen=sizeof(sockaddr_atm);
				InitialClientCount();
				while (1)
				{
					if (ClientCount<ATMServer->GetMaximumConnection())
					{
						i=0;
						while (i<ATMServer->GetMaximumConnection())
						{
							//never use
							if (Client[i]==NULL)
							{
							 	ATMServer->ATMCreateClientThread(i,AF_ATM,SOCK_RAW,ATMPROTO_AAL5,atoi(ATMServerData->sizesend),atoi(ATMServerData->sizereceive),ATMServerData->eventlog);
								//accept socket
								tempsock=ATMServer->ATMAccept();
								IncClientCount();
								UpdateClientCount();
								tempconid=ATMServer->GetATMConnectionID(tempsock);
								_itoa(tempconid.VCI,vci,10);
								_itoa(tempconid.VPI,vpi,10);
								memset(temp,0,sizeof(char)*20);
								strcat(temp,"Acception client connection");
								strcat(temp,"VPI :");
								strcat(temp,vpi);
								strcat(temp,"VCI :");
								strcat(temp,vci);
								ATMServer->PutEventMessage(temp);
								ATMServer->ATMGetClientThread(i)->SetSocket(tempsock);
								Client[i]=AfxBeginThread(ClientThread,ATMServer->ATMGetClientThread(i),THREAD_PRIORITY_NORMAL,0,CREATE_SUSPENDED,NULL);
								Client[i]->m_bAutoDelete=false;
								Client[i]->ResumeThread();
								break;
							}
							else
							{
								//ever use but disconnect
								if (GetExitCodeThread(Client[i]->m_hThread,&lpcode)!=0)
								{
									if (lpcode!=STILL_ACTIVE)
									{
										ATMServer->ATMGetClientThread(i)->CloseSocket();
										ATMServer->ATMDeleteClientThread(i);
										ATMServer->ATMCreateClientThread(i,AF_ATM,SOCK_RAW,ATMPROTO_AAL5,atoi(ATMServerData->sizesend),atoi(ATMServerData->sizereceive),ATMServerData->eventlog);
										//accept socket
										tempsock=ATMServer->ATMAccept();
										IncClientCount();
										UpdateClientCount();
										tempconid=ATMServer->GetATMConnectionID(tempsock);
										_itoa(tempconid.VCI,vci,10);
										_itoa(tempconid.VPI,vpi,10);
										memset(temp,0,sizeof(char)*20);
										strcat(temp,"Acception client connection");
										strcat(temp,"VPI :");
										strcat(temp,vpi);
										strcat(temp,"VCI :");
										strcat(temp,vci);
										ATMServer->PutEventMessage(temp);
										ATMServer->ATMGetClientThread(i)->SetSocket(tempsock);
										Client[i]=AfxBeginThread(ClientThread,ATMServer->ATMGetClientThread(i),THREAD_PRIORITY_NORMAL,0,CREATE_SUSPENDED,NULL);
										Client[i]->m_bAutoDelete=false;
										Client[i]->ResumeThread();
										break;
									}
									else
									{
										i++;
										continue;
									}
								}
								else
								{
									ATMServer->PutEventMessage("GetExitCodeThread() error()");
									return 0;
								}
							}
						}
					}
				}
			}

		}
	}   
}
/////////////////////////////////////////////////////////////////////////////
// CProjectServerView

IMPLEMENT_DYNCREATE(CProjectServerView, CFormView)

BEGIN_MESSAGE_MAP(CProjectServerView, CFormView)
	//{{AFX_MSG_MAP(CProjectServerView)
	ON_BN_CLICKED(IDC_START, OnStart)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CProjectServerView construction/destruction

CProjectServerView::CProjectServerView()
	: CFormView(CProjectServerView::IDD)
{
	//{{AFX_DATA_INIT(CProjectServerView)
	m_sel = _T("19");
	m_listenqueue = _T("5");
	m_max = _T("5");
	m_numclient = _T("0");
	m_sizesend = _T("40");
	m_sizereceive = _T("40");
	m_receivestat2 = _T("");
	m_sendstat2 = _T("");
	//}}AFX_DATA_INIT
	// TODO: add construction code here

}

CProjectServerView::~CProjectServerView()
{
}

void CProjectServerView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CProjectServerView)
	DDX_Control(pDX, IDC_SENDSTAT2, m_sendstat);
	DDX_Control(pDX, IDC_RECEIVESTAT2, m_receivestat);
	DDX_Control(pDX, IDC_NUMCLIENT, m_numclientcontrol);
	DDX_Control(pDX, IDC_EVENTLOG, m_eventlog);
	DDX_Text(pDX, IDC_ATMSEL, m_sel);
	DDX_Text(pDX, IDC_LISTENQUEUE, m_listenqueue);
	DDX_Text(pDX, IDC_MAXCON, m_max);
	DDX_Text(pDX, IDC_NUMCLIENT, m_numclient);
	DDX_Text(pDX, IDC_SIZEOFSENDBUFFER, m_sizesend);
	DDX_Text(pDX, IDC_SIZEOFRECEIVEBUFFER, m_sizereceive);
	DDX_Text(pDX, IDC_RECEIVESTAT2, m_receivestat2);
	DDX_Text(pDX, IDC_SENDSTAT2, m_sendstat2);
	//}}AFX_DATA_MAP
}

BOOL CProjectServerView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFormView::PreCreateWindow(cs);
}

void CProjectServerView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();
	//start winsock 2.0 
    WSADATA wsadata;
    int nRet;
    nRet = WSAStartup(MAKEWORD(2,0),&wsadata);
    if (nRet)
    {
        m_eventlog.AddString("Initial winsock error");
		return;
    }
    else
    if (MAKEWORD(2,0)!=wsadata.wVersion)
    {
        m_eventlog.AddString("Version Error");
        WSACleanup();
		return;
    }
    else
    {
        m_eventlog.AddString("Winsock2 start successful");
		NumberClient=&m_numclientcontrol;
		SendStat=&m_sendstat;
		ReceiveStat=&m_receivestat;
	}
}

/////////////////////////////////////////////////////////////////////////////
// CProjectServerView diagnostics

#ifdef _DEBUG
void CProjectServerView::AssertValid() const
{
	CFormView::AssertValid();
}

void CProjectServerView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CProjectServerDoc* CProjectServerView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CProjectServerDoc)));
	return (CProjectServerDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CProjectServerView message handlers


void CProjectServerView::OnStart() 
{
		UpdateData(true);
		ATMServerData.sel=m_sel;
		ATMServerData.max=m_max;
		ATMServerData.listenqueue=m_listenqueue;
		ATMServerData.numclient=m_numclient;
		ATMServerData.receivestat=m_receivestat2;
		ATMServerData.sendstat=m_sendstat2;
		ATMServerData.eventlog=&m_eventlog;
		ATMServerData.sizereceive=m_sizereceive;
		ATMServerData.sizesend=m_sizesend;
		// start accepting thread
		AfxBeginThread(AcceptThread,&ATMServerData,THREAD_PRIORITY_NORMAL,0,0,NULL);
	
	// TODO: Add your control notification handler code here

}
