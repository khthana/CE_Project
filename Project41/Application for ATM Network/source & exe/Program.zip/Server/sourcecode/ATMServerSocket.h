// ATMServerSocket.h: interface for the ATMServerSocket class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ATMSERVERSOCKET_H__3B510284_D7D7_11D2_BBF3_0020182A2CC3__INCLUDED_)
#define AFX_ATMSERVERSOCKET_H__3B510284_D7D7_11D2_BBF3_0020182A2CC3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ServerSocket1.h"

class ATMServerSocket : public ServerSocket  
{
protected:
	sockaddr_atm saATM;
	UCHAR ATMSEL;
	MySocket* ATMClient[16];
public:
	ATM_CONNECTION_ID GetATMConnectionID(SOCKET sock);
	ATMServerSocket();
	ATMServerSocket(int Addr,int Socket,int Protocol,int listen,int max,UCHAR sel,int maxsendbuf,int maxreceivebuf,CListBox* Log);
	virtual ~ATMServerSocket();
	bool ATMBind();
	bool ATMListen();
	SOCKET ATMAccept();
	ATM_ADDRESS ATMFindAddress();
	void ATMSetsaATM(sockaddr_atm saServer);
	void ATMCreateClientThread(int i,int family,int sock, int protocol,int maxsendbuf,int maxreceivebuf,CListBox* log);
	void ATMDeleteClientThread(int i);
	MySocket* ATMGetClientThread(int i);
};

#endif // !defined(AFX_ATMSERVERSOCKET_H__3B510284_D7D7_11D2_BBF3_0020182A2CC3__INCLUDED_)
