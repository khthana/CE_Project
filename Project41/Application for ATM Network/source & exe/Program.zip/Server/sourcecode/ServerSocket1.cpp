// ServerSocket1.cpp: implementation of the ServerSocket class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ServerSocket1.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

ServerSocket::ServerSocket()
{
}

ServerSocket::ServerSocket(int Addr,int Sock,int Protocol,int listen,int max,int maxsendbuf,int maxreceivebuf,CListBox * Log)
:MySocket(Addr,Sock,Protocol,maxsendbuf,maxreceivebuf,Log)
{
	//seting ListenQueue and MaximumConnection variable
	ListenQueue=listen;
	if (max<=16)
	{
		MaximumConnection=max;
	}
	else
	{
		MaximumConnection=16;
	}
}

ServerSocket::~ServerSocket()
{
}
