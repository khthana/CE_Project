// ProjectServerView.h : interface of the CProjectServerView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROJECTSERVERVIEW_H__89312E4F_DC9C_11D2_881B_0020480E452C__INCLUDED_)
#define AFX_PROJECTSERVERVIEW_H__89312E4F_DC9C_11D2_881B_0020480E452C__INCLUDED_
#include "ATMServerSocket.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

typedef struct serverdata
{
	CString sel; 
	CString listenqueue;
	CString max;
	CString numclient;
	CString	receivestat;
	CString	sendstat;
	CString	sizereceive;
	CString	sizesend;
	CListBox* eventlog;
} ServerData;

class CProjectServerView : public CFormView
{
protected: // create from serialization only
	CProjectServerView();
	DECLARE_DYNCREATE(CProjectServerView)

public:
	//{{AFX_DATA(CProjectServerView)
	enum { IDD = IDD_PROJECTSERVER_FORM };
	CEdit	m_sendstat;
	CEdit	m_receivestat;
	CEdit	m_numclientcontrol;
	CListBox	m_eventlog;
	CString	m_sel;
	CString	m_listenqueue;
	CString	m_max;
	CString	m_numclient;
	CString	m_sizesend;
	CString	m_sizereceive;
	CString	m_receivestat2;
	CString	m_sendstat2;
	//}}AFX_DATA

// Attributes
public:
	CProjectServerDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CProjectServerView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CProjectServerView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	ServerData ATMServerData;	
//	ATMServerSocket* ATMServer;
// Generated message map functions
protected:
	//{{AFX_MSG(CProjectServerView)
	afx_msg void OnStart();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in ProjectServerView.cpp
inline CProjectServerDoc* CProjectServerView::GetDocument()
   { return (CProjectServerDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROJECTSERVERVIEW_H__89312E4F_DC9C_11D2_881B_0020480E452C__INCLUDED_)
