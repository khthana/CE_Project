// ServerSocket1.h: interface for the ServerSocket class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SERVERSOCKET1_H__3B510280_D7D7_11D2_BBF3_0020182A2CC3__INCLUDED_)
#define AFX_SERVERSOCKET1_H__3B510280_D7D7_11D2_BBF3_0020182A2CC3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "MySocket.h"

class ServerSocket : public MySocket  
{
protected:
	int MaximumConnection;    
	int ListenQueue;
public:
	ServerSocket();
	ServerSocket(int Addr,int Sock,int Protocol,int listen,int max,int maxsendbuf,int maxreceivebuf,CListBox* Log);
	virtual ~ServerSocket();
	int GetMaximumConnection(){return MaximumConnection;};
};

#endif // !defined(AFX_SERVERSOCKET1_H__3B510280_D7D7_11D2_BBF3_0020182A2CC3__INCLUDED_)
