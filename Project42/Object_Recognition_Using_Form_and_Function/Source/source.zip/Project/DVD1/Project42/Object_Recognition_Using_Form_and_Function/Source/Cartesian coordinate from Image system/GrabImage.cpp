/*
 * Copyright (c) 1998 Point Grey Research, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Point
 * Grey Research, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with PGR.
 * 
 * PGR MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. PGR SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */

/*
 * Example 4:
 *
 * Takes input from the frame grabber and performs subpixel
 * interpolation to create a 16-bit disparity image, which is saved.
 * The disparity data is then converted to 3-dimensional X/Y/Z
 * coordinates which is written to a file. 
 */

#include <stdio.h>
#include "triclops.h"
#include "grab.h"
#include <math.h>
#include <stdlib.h>
#include <malloc.h>

int
main( int argc, char **argv )
{
    TriclopsContext     context;
    TriclopsImage/*16*/     depthImage16;
    TriclopsImage       refImage,leftImage,rightImage,topImage;
	TriclopsInput       inputData;
    GrabInfo            grabInfo;
	int                 i, j,t,LeftTh,N;
	float               x, y, z;
    FILE *              pointFile;
	FILE *				EpointFile;
	int                 pixelinc,Threshold;
	int					th,a,FitThreshold=0,*MaskSize;
	float				Hb,Hw,*Pt,*Histogram,*F,p,*Baseline;
	int					errorofLeftTh=0,errorofRightTh=50;
	int					errorofTopTh=50;

///////////////////// Initial Triclops//////////////////
    // get the camera module configuration
    triclopsGetDefaultContextFromFile( &context, "config" );
    // open the grabber
    grabInfoInitialize( &grabInfo );
    grabOpen( &grabInfo, gcMETEOR_RGB, 0 );
    // grab an image
    grabTriclopsInput( &grabInfo, &inputData );
    // set to 120x160 output images
    triclopsSetResolution( context, 120, 160 );
	// set Validation
 	triclopsSetTextureValidation(context,1);
	triclopsSetUniquenessValidation(context,1);
	triclopsSetUniquenessValidationThreshold(context,0.5);
	triclopsSetTextureValidationThreshold(context,0.0);
	triclopsSetTextureValidationMapping( context, 0 );
    triclopsSetUniquenessValidationMapping( context, 0 );	
    // set disparity value
    triclopsSetDisparity( context,0,60);
    triclopsSetDisparityMapping( context,0,60);
	triclopsSetStereoMask(context,60);
    // preprocessing the images
    triclopsPreprocess( context, &inputData );
    // stereo processing
    triclopsStereo( context );

    triclopsGetImage( context, TriImg_RECTIFIED, TriCam_L_TOP, &topImage );
//////Write Top/////// 
	FILE* 	ImageFile;

	ImageFile = fopen("TopImage.pgm","w+");
	fprintf( ImageFile,"P5 ");
	fprintf( ImageFile,"160 120 ");
	fprintf( ImageFile,"255 ");
		  
	for (i=0;i<topImage.nrows;i++)
		for (j=0;j<topImage.ncols;j++)
		{
			fprintf( ImageFile,"%c",topImage.data[i*topImage.rowinc+j]);
	
		}
	fclose(ImageFile);
///////End///////
	triclopsGetImage( context, TriImg_RECTIFIED, TriCam_L_LEFT, &refImage );
//////Write Left/////// 
	ImageFile = fopen("RefleftImage.pgm","w+");
	fprintf( ImageFile,"P5 ");
	fprintf( ImageFile,"160 120 ");
	fprintf( ImageFile,"255 ");
		  
	for (i=0;i<refImage.nrows;i++)
		for (j=0;j<refImage.ncols;j++)
		{
			fprintf( ImageFile,"%c",refImage.data[i*refImage.rowinc+j]);
	
		}
	fclose(ImageFile);
///////End///////
	triclopsGetImage( context, TriImg_RECTIFIED, TriCam_L_RIGHT, &rightImage );
//////Write Right/////// 
	ImageFile = fopen("RightImage.pgm","w+");
	fprintf( ImageFile,"P5 ");
	fprintf( ImageFile,"160 120 ");
	fprintf( ImageFile,"255 ");
		  
	for (i=0;i<rightImage.nrows;i++)
		for (j=0;j<rightImage.ncols;j++)
		{
			fprintf( ImageFile,"%c",rightImage.data[i*rightImage.rowinc+j]);
	
		}
	fclose(ImageFile);
///////End///////

///////////////////find threshold reference refImage//////////////
	Pt = (float *)malloc(sizeof(float)*256);
	Histogram = (float *)malloc(sizeof(float)*256);  
	F = (float *)malloc(sizeof(float)*256);  
/*				initial histogram		*/
	for (i=0;i<256;i++)
	{
		Histogram[i]=0.0;
	}
	//printf("%i",refImage.nrows);
	for (i=0; i<refImage.nrows; i++)
	  for (j=0; j<refImage.ncols; j++)
	    Histogram[refImage.data[(i*refImage.rowinc)+j]] += 1.0;

	N=240*320;
	
	for (i=0; i<256; i++)
	  Histogram[i] /= (float)N;
/*			compute factor Pt     */	
	Pt[0] = Histogram[0];
	for (i=1; i<256; i++)
	  Pt[i] = Pt[i-1] + Histogram[i];
/* Calculate the function to be maximized at all levels */
	t = 0;
	for (i=0; i<256; i++)
	{
	  Hb = Hw = 0.0;
	  for (j=0; j<256; j++)
	  {
		
	    if (j<=i)
		{	
			p=Pt[i];
			if (Histogram[j] > 0.0 && p>0.0)
			Hb += -(Histogram[j]/p * (float)log((double)(Histogram[j])/p));
			else
			Hb += 0.0;

		}
	    else 
		{
			p=1.0-Pt[i];
			if (Histogram[j] > 0.0 && p>0.0)
			Hb += -(Histogram[j]/p * (float)log((double)(Histogram[j])/p));
			else
			Hb += 0.0;

		}
	  F[i] = Hb+Hw;
	  if (i>0 && F[i] > F[t]) t = i;
	  }
	}
	t=t-errorofLeftTh;
	LeftTh=t;
	fprintf (stderr, "ThresholdLeft is %d\n", t);
	free(Histogram); free(Pt); free(F);
//////Write LeftInterest/////// 
	for (i=0; i<refImage.nrows; i++)
		for (j=0; j<refImage.ncols; j++)
			if (refImage.data[i*refImage.rowinc+j]>LeftTh)
			{
				refImage.data[i*refImage.rowinc+j]=255;	
			}
			else
			{
				refImage.data[i*refImage.rowinc+j]=0;
			}

	ImageFile = fopen("InterestedLeftImage.pgm","w+");
	fprintf( ImageFile,"P5 ");
	fprintf( ImageFile,"160 120 ");
	fprintf( ImageFile,"255 ");
		  
	for (i=0;i<refImage.nrows;i++)
		for (j=0;j<refImage.ncols;j++)
		{
			fprintf( ImageFile,"%c",refImage.data[i*refImage.rowinc+j]);
	
		}
	fclose(ImageFile);
///////End///////
//////////////////end find threshold//////////////

///////////Segment on RightImage///////////
	////FindTH/////
	int RightTh;

	Pt = (float *)malloc(sizeof(float)*256);
	Histogram = (float *)malloc(sizeof(float)*256);  
	F = (float *)malloc(sizeof(float)*256);  
/*				initial histogram		*/
	for (i=0;i<256;i++)
	{
		Histogram[i]=0.0;
	}
	//printf("%i",refImage.nrows);
	for (i=0; i<rightImage.nrows; i++)
	  for (j=0; j<rightImage.ncols; j++)
	    Histogram[rightImage.data[(i*rightImage.rowinc)+j]] += 1.0;

	N=240*320;
	
	for (i=0; i<256; i++)
	  Histogram[i] /= (float)N;
/*			compute factor Pt     */	
	Pt[0] = Histogram[0];
	for (i=1; i<256; i++)
	  Pt[i] = Pt[i-1] + Histogram[i];
/* Calculate the function to be maximized at all levels */
	t = 0;
	for (i=0; i<256; i++)
	{
	  Hb = Hw = 0.0;
	  for (j=0; j<256; j++)
	  {
		
	    if (j<=i)
		{	
			p=Pt[i];
			if (Histogram[j] > 0.0 && p>0.0)
			Hb += -(Histogram[j]/p * (float)log((double)(Histogram[j])/p));
			else
			Hb += 0.0;

		}
	    else 
		{
			p=1.0-Pt[i];
			if (Histogram[j] > 0.0 && p>0.0)
			Hb += -(Histogram[j]/p * (float)log((double)(Histogram[j])/p));
			else
			Hb += 0.0;

		}
	  F[i] = Hb+Hw;
	  if (i>0 && F[i] > F[t]) t = i;
	  }
	}
	t=t-errorofRightTh;
	RightTh=t;
	fprintf (stderr, "ThresholdRight is %d\n",RightTh);
	free(Histogram); free(Pt); free(F);
//////Write RightInterest/////// 
	for (i=0; i<rightImage.nrows; i++)
		for (j=0; j<rightImage.ncols; j++)
			if (rightImage.data[i*rightImage.rowinc+j]>RightTh)
			{
				rightImage.data[i*rightImage.rowinc+j]=255;	
			}
			else
			{
				rightImage.data[i*rightImage.rowinc+j]=0;
			}

	ImageFile = fopen("InterestedRightImage.pgm","w+");
	fprintf( ImageFile,"P5 ");
	fprintf( ImageFile,"160 120 ");
	fprintf( ImageFile,"255 ");
		  
	for (i=0;i<rightImage.nrows;i++)
		for (j=0;j<rightImage.ncols;j++)
		{
			fprintf( ImageFile,"%c",rightImage.data[i*rightImage.rowinc+j]);
	
		}
	fclose(ImageFile);
///////End///////
///////////Segment on TopImage///////////
	////FindTH/////
	int TopTh;

	Pt = (float *)malloc(sizeof(float)*256);
	Histogram = (float *)malloc(sizeof(float)*256);  
	F = (float *)malloc(sizeof(float)*256);  
/*				initial histogram		*/
	for (i=0;i<256;i++)
	{
		Histogram[i]=0.0;
	}
	//printf("%i",refImage.nrows);
	for (i=0; i<topImage.nrows; i++)
	  for (j=0; j<topImage.ncols; j++)
	    Histogram[topImage.data[(i*topImage.rowinc)+j]] += 1.0;

	N=240*320;
	
	for (i=0; i<256; i++)
	  Histogram[i] /= (float)N;
/*			compute factor Pt     */	
	Pt[0] = Histogram[0];
	for (i=1; i<256; i++)
	  Pt[i] = Pt[i-1] + Histogram[i];
/* Calculate the function to be maximized at all levels */
	t = 0;
	for (i=0; i<256; i++)
	{
	  Hb = Hw = 0.0;
	  for (j=0; j<256; j++)
	  {
		
	    if (j<=i)
		{	
			p=Pt[i];
			if (Histogram[j] > 0.0 && p>0.0)
			Hb += -(Histogram[j]/p * (float)log((double)(Histogram[j])/p));
			else
			Hb += 0.0;

		}
	    else 
		{
			p=1.0-Pt[i];
			if (Histogram[j] > 0.0 && p>0.0)
			Hb += -(Histogram[j]/p * (float)log((double)(Histogram[j])/p));
			else
			Hb += 0.0;

		}
	  F[i] = Hb+Hw;
	  if (i>0 && F[i] > F[t]) t = i;
	  }
	}
	t=t-errorofTopTh;
	TopTh=t;
	fprintf (stderr, "ThresholdTop is %d\n",RightTh);
	free(Histogram); free(Pt); free(F);
//////Write RightInterest/////// 
	for (i=0; i<topImage.nrows; i++)
		for (j=0; j<topImage.ncols; j++)
			if (topImage.data[i*topImage.rowinc+j]>TopTh)
			{
				topImage.data[i*topImage.rowinc+j]=255;	
			}
			else
			{
				topImage.data[i*topImage.rowinc+j]=0;
			}

	ImageFile = fopen("InterestedTopImage.pgm","w+");
	fprintf( ImageFile,"P5 ");
	fprintf( ImageFile,"160 120 ");
	fprintf( ImageFile,"255 ");
		  
	for (i=0;i<topImage.nrows;i++)
		for (j=0;j<topImage.ncols;j++)
		{
			fprintf( ImageFile,"%c",topImage.data[i*topImage.rowinc+j]);
	
		}
	fclose(ImageFile);
///////End///////

////////////////Find Match Beteween LR Image/////////
	//Define Parameter
	int sumDiff,sumMinDiff,rowMxM,colMxM,DiffThMin=0,offsetMarkSize=5;
	int ri,rj,subj;
	FILE *	checkFile;
	FILE *  c1;
	FILE *	XFile;
	FILE *	YFile;
	FILE *	ZFile;
	float	orderofPower;

    pointFile = fopen("points.txt", "w+" );
	XFile = fopen("Xpoints.txt", "w+" );
	YFile = fopen("Ypoints.txt", "w+" );
	ZFile = fopen("Zpoints.txt", "w+" );
	
	checkFile = fopen("rowtest.txt", "w+" );
	c1	= fopen("c1test.txt","w+");

	for (i=0; i<refImage.nrows; i++)
	  for (j=48; j<refImage.ncols; j++)//Filter Range of Right see
	  {
		  if (refImage.data[i*refImage.rowinc+j]<LeftTh)
		  {
			sumMinDiff=/*10000000*/0;			
			fprintf( checkFile, "rowL=%i,colL=%i\n",i,j);
			for (subj=0; subj<100; subj++)
			{
				sumDiff=0;			
		        //fprintf( c1,"rowR=%i,colR=%i\n",i,subj);
				for (ri=-offsetMarkSize;ri<=offsetMarkSize;ri++)
				{
					if (((i+ri)>=0)&&((i+ri)<refImage.nrows))
					{
						for (rj=-offsetMarkSize;rj<=offsetMarkSize;rj++)
						{							
							if ((((j+rj)>=0)&&((j+rj)<refImage.ncols))&&
								(((subj+rj)>=0)&&((subj+rj)<rightImage.ncols)))
							{
							//	sumDiff = sumDiff+abs(refImage.data[((i+ri)*refImage.rowinc)+(j+rj)]-rightImage.data[((i+ri)*rightImage.rowinc)+(subj+rj)]);
							//	fprintf( pointFile, "rowR=%i,colR=%i,MarkR=%i,MarkC=%i,Sum=%i",i,subj,(i+ri),(subj+rj),sumDiff);
							//	fprintf(pointFile,"VarLeft=%i,VarRight=%i\n",refImage.data[((i+ri)*refImage.rowinc)+(j+rj)],rightImage.data[((i+ri)*rightImage.rowinc)+(subj+rj)]);
								if (abs(refImage.data[((i+ri)*refImage.rowinc)+(j+rj)]-rightImage.data[((i+ri)*rightImage.rowinc)+(subj+rj)])==DiffThMin)
								{
									sumDiff+=1;
								}
							}
							/*else
							{
								sumDiff+=255;
							}*/
						}
					}
					/*else
					{
						sumDiff+=255;
					}*/
				}
			//	fprintf( c1, "rowR=%i\n",i);
				//fprintf( c1,"rowR=%i,colR=%i,sumDiff=%i\n",i,subj,sumDiff);
				if (sumDiff/*<*/>sumMinDiff)
				{
					sumMinDiff=sumDiff;
					rowMxM=i;colMxM=subj;
			//		fprintf( pointFile, "rowR=%i,colR=%i,\n",rowMxM,colMxM);
		  		}
			}
			orderofPower=((abs(j-80)+abs(colMxM-80)-60)/3);
			z=21-orderofPower;
			x=((j-80)*2*z)/(18*15);//col
			y=((60-i)*2*z)/(-22*15);//row
			if (z>0) 
			{
			fprintf( pointFile,"row=%i,col=%i,%f %f %f\n",i,j,x,y,z);
			fprintf( XFile,"%f\n",x);
			fprintf( YFile,"%f\n",y);
			fprintf( ZFile,"%f\n",z);
			}	
            //fprintf( pointFile, "rowL=%i,colL=%i,rowR=%i,colR=%i,MinDiff=%i\n",i,j,rowMxM,colMxM,sumMinDiff);
			//fprintf( c1, "rowL=%i,colL=%i\n",i,j);
		  }
	  }

    EpointFile=fopen("Escapepoint.txt","w+");
    fclose(pointFile );
	fclose(EpointFile);
	fclose(checkFile);
	fclose(XFile);
	fclose(YFile);
	fclose(ZFile);
	
	fclose(c1);
	///////////////end generate X,Y,Z//////////////
	// close the grabber
    grabClose( &grabInfo );
	
    return 0;
}
