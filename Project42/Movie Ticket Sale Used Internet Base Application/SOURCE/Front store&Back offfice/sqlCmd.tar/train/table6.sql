drop table table6;
create table table6(
     --tab6_seq  integer,
     Round    integer
   constraint fk_round references table5 on delete cascade,
     seat     varchar(4),
   constraint table6uniq unique(round,seat),
     state    varchar(5)
   constraint stateValue check (state in (null,'order') ) );
--insert into table6 values(1,'A0',null);
--insert into table6 values(1,'A1',null);
--insert into table6 values(1,'A2',null);
--insert into table6 values(1,'A3',null);
--insert into table6 values(1,'A4',null);
--insert into table6 values(1,'A5',null);
--insert into table6 values(1,'A6',null);
--insert into table6 values(1,'A7',null);
--insert into table6 values(1,'A8',null);
--insert into table6 values(1,'A9',null);
commit work;
