drop view Vtable1;
create view Vtable1
 as select ID_customer,name,surname,password
    from table1 ;
