drop table table5;
create table table5(
         Round    integer primary key,
         screen   smallint,
         day      varchar(12),
         time     varchar(6),
     constraint table5uniq unique(screen,day,time),
         id_movie integer
     constraint fk_idmovie references table4);
--insert into table5 values(1,1,'22/12/99','10:30',1);
--insert into table5 values(2,1,'22/12/99','12:00',1);
--insert into table5 values(3,1,'22/12/99','14:30',1);
--insert into table5 values(4,1,'22/12/99','17:30',1);
--insert into table5 values(5,1,'22/12/99','23:00',1);
commit work;
