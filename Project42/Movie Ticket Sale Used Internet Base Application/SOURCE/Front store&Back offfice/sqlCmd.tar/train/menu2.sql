select t1.name,t1.surname,t4.name,t8.id_screen,t7.type,t8.day,t8.time,t8.id_seat,t8.print
from webapp.table1 t1,webapp.table4 t4
      ,webapp.table7 t7,webapp.table8 t8
where t1.id_customer=t8.id_customer
    and t4.id_movie=t8.id_movie
    and t7.id_screen = t8.id_screen
    and t1.id_customer=1;
