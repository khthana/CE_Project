drop user yord cascade; 
create user yord
identified by yord
default tablespace users
temporary tablespace temp
quota unlimited on users
quota unlimited on temp;



