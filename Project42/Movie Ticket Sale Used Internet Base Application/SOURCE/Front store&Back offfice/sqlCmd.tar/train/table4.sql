drop table table4;
create table table4(
          ID_movie   integer primary key,
          name       varchar(20),
          type       varchar(10),
          arrive     varchar(12),
          leave      varchar(12));
--insert into table4 values(1,'StarWar','Action','12/2/99','19/2/99');
--insert into table4 values(2,'007','Action','23/3/00','23/4/00');
--insert into table4 values(3,'American Pine','Comady','2/3/66','4/3/66');
--insert into table4 values(4,'NangNark','Ghost','12/3/99','22/3/99');
--insert into table4 values(5,'BigDaddy','Comady','23/4/99','2/5/99');
commit;
