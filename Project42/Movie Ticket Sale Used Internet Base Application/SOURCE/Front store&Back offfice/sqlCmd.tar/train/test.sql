drop table test;
create table test(
            ID_customer integer not null, 
            email       varchar(30));
insert into test values(1,'ac.th');
insert into test values(1,'otmail.com');
insert into test values(2,'dmail.com');
insert into test values(3,'futl.ac.th');
commit;
