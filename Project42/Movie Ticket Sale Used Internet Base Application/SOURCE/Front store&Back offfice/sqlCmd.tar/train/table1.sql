create table table1(
          ID_customer integer primary key,
          username    varchar(18), 
  constraint username_uniq unique(username),
          name        varchar(12),
          surname     varchar(12),
          password    varchar(10),
          credit      smallint,
          email       varchar(30) not null,
          phone       varchar(15) not null,
          start_date  date);
--insert into table1 values(1,'yord','yord','timmart','yord',10,'s9014512@kmitl.ac.th','5512360',TO_DATE('13-NOV-1992','DD-MON-YYYY'));
--insert into table1 values(2,'den','den','timmart','den',10,'den@kmitl.ac.th','5456123',TO_DATE('16-JAN-1992','DD-MON-YYYY'));
--insert into table1 values(3,'doy','doy','timmart','doy',10,'doy@abc.com','4561234',TO_DATE('5-DEC-1992','DD-MON-YYYY')); 
--insert into table1 values(4,'fon','fon','timmart','fon',10,'fon@hotmail.com','5456895',TO_DATE('25-FEB-1992','DD-MON-YYYY'));
--insert into table1 values(5,'ting','ting','timmart','ting',10,'ting@yipintsoi.co.th','6548956',TO_DATE('12-OCT-1992','DD-MON-YYYY'));
--insert into table1 values(6,'in','in','timmart','in',10,'in@dentist.com','8987895',TO_DATE('12-OCT-1992','DD-MON-YYYY'));
--insert into table1 values(7,'dba','dba','timmart','dba',0,'dba@benz.com','456125',TO_DATE('11-Jan-2000','DD-MON-YYYY'));
commit comment 'ok Its work now';
