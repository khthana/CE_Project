set transaction

savepoint first;

update table6 
  set state='order' 
  where round=1 and seat='A5';

savepoint secound;

update table6 
  set state='order' 
  where round=1 and seat='A6';
rollback to secound;
commit;
