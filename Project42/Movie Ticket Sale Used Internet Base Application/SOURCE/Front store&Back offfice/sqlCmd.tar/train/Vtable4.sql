drop view Vtable4;
create view Vtable4
 as select ID_movie,name,type
    from table4 ;
