drop table table7;
create table table7(
          ID_screen  smallint primary key,
          amount     smallint,
          type       varchar(8), 
          state      varchar(5)
         constraint stateTherter check (state in ('open','close')));
--insert into table7 values(1,50,'THX');
--insert into table7 values(2,50,'SRD-S');
--insert into table7 values(3,50,'SSRD');
--insert into table7 values(4,50,'THX');
--insert into table7 values(5,50,'THX');
commit;
