/
drop table table3
/
create table table3(
     id_customer integer
     constraint Fkey references table1 on delete cascade , 
     phone       varchar(15) not null,
     constraint uniq unique(id_customer,phone))
/
insert into table3 values(1,'5512360')
/
insert into table3 values(1,'4561235')
/
insert into table3 values(2,'5684213')
/
insert into table3 values(3,'5684213')
/
insert into table3 values(3,'4484615')
/
commit work
/
