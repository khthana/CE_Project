/
drop table table2
/
create table table2(
            ID_customer integer not null 
 constraint fk_id references table1 on delete cascade, 
            email       varchar(30),
 constraint uniq_mail unique(ID_CUSTOMER,EMAIL))
/
insert into table2 values(1,'s9014512@kmitl.ac.th')
/
insert into table2 values(1,'yord@hotmail.com')
/
insert into table2 values(2,'deb@hotmail.com')
/
insert into table2 values(3,'full@kmitl.ac.th')
/
commit 
/
