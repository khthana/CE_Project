/
drop table table8
/
create table table8(
          ID_order    integer primary key,
          ID_customer integer 
      constraint fk_idcustomer references table1,  
          ID_movie    integer 
      constraint fk_movie references table4,  
          ID_screen   smallint 
      constraint fk_screen references table7,  
          day         varchar(12),
          time        varchar(8),
          ID_seat     varchar(8),
          print       varchar(6))
/
commit work
/
