drop user customer;
create user customer
identified by movie;
