drop sequence tab1_seq;
create sequence tab1_seq
start with 1
increment by 1
nomaxvalue
nocycle
cache 20;
commit;
