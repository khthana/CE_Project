grant create session to yord;
grant create table to yord;
grant create view to yord;
grant grant any privilege to yord;
grant unlimited tablespace to yord;
-- revoke create session from yord;



