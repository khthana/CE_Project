declare
    mystate  varchar(7);
begin
    select state into mystate from table6
        where round=1 and seat='A2' 
        for update of state;

    if mystate=null then 
        update table6 SET state ='order' 
            where round = 1 and seat='A2';
    end if;

    commit;
end;
/

