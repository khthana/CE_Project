create table session_control(
          ID_customer integer primary key);
