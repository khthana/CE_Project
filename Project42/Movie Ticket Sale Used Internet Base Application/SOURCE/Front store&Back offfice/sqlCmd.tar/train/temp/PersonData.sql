create table Person(
          ID integer primary key,
          name varchar(10) );
insert into Person values(1,'yord1');
insert into Person values(2,'yord2');
insert into Person values(3,'yord3');
insert into Person values(4,'yord4');
insert into Person values(5,'yord5');
insert into Person values(6,'yord6');
