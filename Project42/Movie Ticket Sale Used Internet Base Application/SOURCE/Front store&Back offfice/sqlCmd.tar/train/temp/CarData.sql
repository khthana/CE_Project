create table CarData(
         ID integer primary key,
         ID_Person integer constraint per_Fk references Person on delete cascade); 
insert into CarData values(1,1);
insert into CarData values(2,2);
insert into CarData values(3,3);
insert into CarData values(4,null);
 
