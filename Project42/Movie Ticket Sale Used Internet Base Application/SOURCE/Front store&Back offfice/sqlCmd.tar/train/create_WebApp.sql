drop user WebApp cascade; 
create user WebApp
identified by web
default tablespace users
temporary tablespace temp
quota unlimited on users
quota unlimited on temp;



