drop sequence order_table8;
create sequence order_table8
start with 1
increment by 1
nomaxvalue
nocycle
cache 10;
commit;
