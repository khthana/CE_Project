drop sequence tab6_seq;
create sequence tab6_seq
start with 1
increment by 1
nomaxvalue
nocycle
cache 10;
commit;
