grant create session to WebApp;
grant create table to WebApp;
grant create view to WebApp;
grant select any table to WebApp;
grant grant any privilege to WebApp;
grant unlimited tablespace to WebApp;
grant create sequence to WebApp;
-- revoke create session from WebApp;



