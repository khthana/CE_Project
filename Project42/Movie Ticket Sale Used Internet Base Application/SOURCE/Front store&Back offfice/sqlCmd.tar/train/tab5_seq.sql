drop sequence tab5_seq;
create sequence tab5_seq
start with 1
increment by 1
nomaxvalue
nocycle
cache 20;
commit;
