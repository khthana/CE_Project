import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class Menu2Seat extends HttpServlet 
{
    public void service(HttpServletRequest _req,HttpServletResponse _res)
        throws IOException, ServletException
    {  
        PrintWriter out = _res.getWriter();  
        String name="",surname="",MovieName="";
        String id_seat="";
        try
        {   
           SQL mysql= new SQL();
           _res.setContentType ("text/html");
           String id_customer=_req.getParameter("id_customer");
           String id_order=_req.getParameter("id_order");
           String id_movie=_req.getParameter("id_movie");
           String round=_req.getParameter("round");
           Connection conn =  mysql.Connect("customer","movie");
         
         login mylogin = new login(conn,mysql,out);
         if (mylogin.active(id_customer))
         {

           ResultSet Rs = mysql.Query(conn,"select name,surname"+
                        " from webapp.table1 where id_customer="+id_customer);
           while(Rs.next())
           {
             name=Rs.getString(1);
             surname=Rs.getString(2);
           }

           Rs = mysql.Query(conn," select seat,state "+
                                  " from webapp.table6 "+
                                  " where round="+round+
                                  " order by seat");
           out.println("<form method=post action=page25.jhtml>");
           out.println("<table cellpadding=8><tr align=right>");
           int countTmp=0;
           while (Rs.next())
           {
               id_seat = Rs.getString(1);
               String state = Rs.getString(2);
               if (state == null) {
                      out.println("<td>"+id_seat+":"+"<input type=checkbox value="+id_seat+" name="+id_seat+"></td>");
                                  }
               else  {
                        out.println("<td>"+id_seat+" :</td>");
                     }
               if (++countTmp==10) 
               {  out.println("</tr><tr align=right>");
                  countTmp=0;
               }
           }
           out.println("</tr></table>");
           out.println("<table align=center bgcolor=#DDA0DD><tr><td><input type=submit value=Submit>");
           out.println("<input type=reset value=Undo></td></tr></table>");
     out.println("<input type=hidden name=id_customer value="+id_customer+">"); 
     out.println("<input type=hidden name=id_movie value="+id_movie+">"); 
     out.println("<input type=hidden name=id_order value="+id_order+">"); 
     out.println("<input type=hidden name=round value="+round+">");
           out.println("</form></center>");

     out.println("<a href=./page21.jhtml?id_customer="+id_customer+
                 ">Back</a>");   

 out.println("<table width=100%><tr bgcolor=#7FFFD4>"+
                       "<td align=left><table><tr><td>"+
                "<form method=post action=http://www.benz/servlet/logout>"+
                  "<input type=hidden name=id_customer value="+id_customer+">"+
                  "<font color=black><input type=submit value=Logout>"+
                  "</font></form></td></tr></table></td><td><table>"+
                  "<tr><td><font color=black>"+
 "Please click Logout if you do not want to change ticket"+
                 "</font></td></tr></table></td></tr></table>");
         }
         else
         {
   out.println("Please verify user,password");
        out.println("<a href=http://www.benz/MovieProject/ByJSSI/page20.html>"+
                   "Goto Verify</a>");

         }
        }
        catch(SQLException e )
        { 
           out.println("Error:" + "<br>");
           out.println(e); 
        }   

     }
} 
