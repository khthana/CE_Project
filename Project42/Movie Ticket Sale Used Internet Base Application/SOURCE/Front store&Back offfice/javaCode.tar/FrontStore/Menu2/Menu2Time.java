import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class Menu2Time extends HttpServlet 
{
    public void service(HttpServletRequest _req,HttpServletResponse _res)
        throws IOException, ServletException
    {  
        PrintWriter out = _res.getWriter();  
        String name="",surname="",MovieName="";
        String id_temp="",day_temp="";
        String id_customer="";
        String id_order="";
        try
        {   
           SQL mysql= new SQL();
           _res.setContentType ("text/html");
            id_customer=_req.getParameter("id_customer");
            id_order=_req.getParameter("id_order");
           String id_movie=_req.getParameter("id_movie");
           Connection conn =  mysql.Connect("customer","movie");

         login mylogin = new login(conn,mysql,out);
         if (mylogin.active(id_customer))
         {

           ResultSet Rs = mysql.Query(conn,"select name,surname"+
                        " from webapp.table1 where id_customer="+id_customer);
           while(Rs.next())
           {
             name=Rs.getString(1);
             surname=Rs.getString(2);
           }
           Rs = mysql.Query(conn," select name from webapp.table4 where "+
                          " id_movie="+id_movie);
           while ( Rs.next())
           { name=Rs.getString(1);}
           out.println("<h2>New Movie :"+name+"</h2><br>");
           out.println("<table width=50% bgcolor=#7FFFD4 align=center><tr align=center><td><font color=black><b>Show Time</b></font></td></tr></table>");
           out.println("<table cellspacing=10 align=center>");
           out.println("<tr align = center>");
           out.println("<th bgcolor=#FFEFD5><font color=black>Screen</font></th>");
           out.println("<th bgcolor=#FFEFD5><font color=black>Day</font></th>");
           out.println("<th bgcolor=#FFEFD5><font color=black>Time</font></th>");
           out.println("<th bgcolor=#FFEFD5><font color=black>Free_Seat</font></th></tr>");
           Rs = mysql.Query(conn," select screen,day,time,round "+
                                  " from webapp.table5 "+
                                  " where id_movie="+id_movie +
                                  " group by screen,day,time,round "+
                                  " order by round");
           while (Rs.next())
           {
               String id_screen = Rs.getString(1);
               String day = Rs.getString(2);
               String time = Rs.getString(3);
               String round = Rs.getString(4);
                        out.println("<tr align=center>");
                        if (id_screen.equals(id_temp))
                           out.println("<td></td>");
                        else   {
                                 out.println("<td>"+id_screen+"</td>");
                                 id_temp = id_screen;
                               }
                        if (day.equals(day_temp))
                           out.println("<td></td>");
                        else   {
                                 out.println("<td>"+day+"</td>");
                                 day_temp = day;
                               }
                        out.println("<td><a href=page24.jhtml?id_order="+id_order+"&id_customer="+id_customer+"&id_movie="+id_movie+"&round="+round+">");
                        out.println(time+"</a></td>");


                ResultSet myRs=mysql.Query(conn,"select count(*) from "+
                               " webapp.table6 where round="+round+
                               " and state='order'");
                int numofOrder =0;
                while (myRs.next())
                {
                    numofOrder= myRs.getInt(1);
                }
                ResultSet myRs1=mysql.Query(conn,"select amount from "+
                                       " webapp.table7 "+
                                       " where id_screen="+id_screen+" ");
                int numofSeat =0;
                while (myRs1.next())
                {
                    numofSeat= myRs1.getInt(1);
                }
                out.println("<td>"+(numofSeat-numofOrder)+"</td></tr>");
           }
           out.println("</table><br>");

           out.println("<a href=./page21.jhtml?id_customer="+id_customer+
                     ">Back</a>");

       out.println("<table width=100%><tr bgcolor=#7FFFD4>"+
                       "<td align=left><table><tr><td>"+
                "<form method=post action=http://www.benz/servlet/logout>"+
                  "<input type=hidden name=id_customer value="+id_customer+">"+
                  "<font color=black><input type=submit value=Logout>"+
                  "</font></form></td></tr></table></td><td><table>"+
                  "<tr><td><font color=black>"+
 "Please click Logout if you do not want to change ticket"+
                 "</font></td></tr></table></td></tr></table>");

         }
         else 
         {
      out.println("Please verify user,password");
        out.println("<a href=http://www.benz/MovieProject/ByJSSI/page20.html>"+
                   "Goto Verify</a>");

         }

        }
        catch(SQLException e )
        { 
           out.println("Error:" + "<br>");
           out.println(e); 
        }   

     }
} 
