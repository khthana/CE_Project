import java.awt.*;
import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class Menu2verify extends HttpServlet 
{
    public void service(HttpServletRequest request,HttpServletResponse response)
        throws IOException, ServletException
    {  
        response.setContentType("text/html");
        PrintWriter out  = response.getWriter();
   out.println("<form method=post action=https://www.benz/page21.jhtml>");
      out.println("<br><center>UserName:<input type=text size=10 name=username>");
      out.println("<br>Password:<input type=password size=10 name=password>");
      out.println("<br><input type=submit value=Ok>");
      out.println("<input type=reset value=Clear></center>");
      out.println("</form>");

      out.println("<hr align=center width=70%>");
      out.println("<a href=./index.html><u>MainMenu</u></a>");

    }
}
