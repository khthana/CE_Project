import java.lang.*;
import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.http.*;
import javax.servlet.*;


public class login
{
   Connection conn=null;
   SQL mysql = null;
   PrintWriter out = null;
   public login(Connection conn,SQL mysql,PrintWriter out)
   {
      this.conn = conn;
      this.mysql = mysql;
      this.out = out;
   }
   public boolean active(String id_customer)
   {
      String id_result="";
      try
      {
          ResultSet Rs=mysql.Query(conn,"select * from webapp.session_control "+
                            " where id_customer="+id_customer);
          while (Rs.next())
          {
             id_result = Rs.getString(1);
          }
          if (id_result.equals(""))
          {
            return false;
          }
          else return true;
      }
      catch(SQLException e){return false;}
   }
   public void login(String id_customer)
   {
      try
      {
         mysql.Update(conn,"insert into webapp.session_control values( "+
                           id_customer+")");
      }
      catch(SQLException e){out.println(e);}
   }
}

