import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class logout extends HttpServlet 
{
    public void service(HttpServletRequest _req,HttpServletResponse _res)
        throws IOException, ServletException
    {  
        PrintWriter out = _res.getWriter();  
        _res.setContentType ("text/html");
        String id_customer = _req.getParameter("id_customer");
        SQL mysql= new SQL();
        try
        {
          Connection conn =  mysql.Connect("customer","movie");
          mysql.Update(conn,"delete webapp.session_control where id_customer= "+
                     id_customer); 
        }
        catch(SQLException e)
        { out.println(e);}

        try{ _res.sendRedirect("http://www.benz/");}
        catch(IOException e)
        { out.println(e);}

    }

} 
