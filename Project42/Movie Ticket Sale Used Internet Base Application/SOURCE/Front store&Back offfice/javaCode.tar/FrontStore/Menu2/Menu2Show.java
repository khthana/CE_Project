import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class Menu2Show extends HttpServlet 
{
    public void service(HttpServletRequest _req,HttpServletResponse _res)
        throws IOException, ServletException
    {  
        PrintWriter out = _res.getWriter();  
           _res.setContentType ("text/html");
        String name="",surname="",MovieName="";
        String id_customer=_req.getParameter("id_customer");
        String nameTmp="",surnameTmp="";
           SQL mysql= new SQL();
           Connection conn =null;

        try
        {   
           conn =  mysql.Connect("customer","movie");
           login mylogin = new login(conn,mysql,out);
           if (mylogin.active(id_customer))
           {

           ResultSet Rs = mysql.Query(conn,"select name,surname"+
                        " from webapp.table1 where id_customer='"+id_customer+"'");
           while(Rs.next())
           {
             name=Rs.getString(1);
             surname=Rs.getString(2);
           }
           out.println("<table width=100% height=15%>"+
                     "<tr bgcolor=#7FFFD4><td><font color=black>"+
                     "<b>Your name:</b> "+name+" "+surname+
                     "</font></td></tr></table>");


           Rs = mysql.Query(conn,"select t8.id_movie,t4.name,"+
                              " t8.id_screen,t7.type,t8.day,t8.time,"+
                              " t8.id_seat,t8.id_order"+
                              " from webapp.table4 t4,"+
                              " webapp.table7 t7,webapp.table8 t8"+
                              " where t4.id_movie=t8.id_movie "+
                              "  and t7.id_screen = t8.id_screen "+
                              " and id_customer="+id_customer+
                              " and t8.print='false'");
           int count=0;
           while (Rs.next())
           {
               String id_movie = Rs.getString(1);
               MovieName = Rs.getString(2);
               int id_screen=Rs.getInt(3);
               String type = Rs.getString(4);
               String day = Rs.getString(5);
               String time = Rs.getString(6);
               String seat = Rs.getString(7);
               int id_order=Rs.getInt(8);
               ResultSet myRs = mysql.Query(conn,"select round from "+
                                 " webapp.table5 where "+
                                 " screen="+id_screen+
                                 " and day='"+day+"'"+
                                 " and time='"+time+"'");
               String roundTmp="";
               while (myRs.next())
               {
                  roundTmp = myRs.getString(1);
               }
             out.println("<table><tr bgcolor=#ADD8E6><td><font color=black><b>Ticket</b>"+(++count)+"</font></td></tr><tr><td><table bgcolor=white border=3"+
                " cellpadding=10><tr><td><b><u><font color=black>Movie Name</font>:</u></b> "+
               "<a href=http://www.benz/MovieProject/ByJSSI/page22.jhtml?id_order="+id_order+"&id_customer="+id_customer+">"+MovieName+"</a>");
              out.println("<br><b><u><font color=black>Date</font></u></b>: "+
               "<a href=http://www.benz/MovieProject/ByJSSI/page23.jhtml?id_order="+id_order+"&id_customer="+id_customer+"&id_movie="+id_movie+">"+day+"</a>");
               out.println("<b><u><font color=black>Time</font></u></b>: "+
               "<a href=http://www.benz/MovieProject/ByJSSI/page23.jhtml?id_order="+id_order+"&id_customer="+id_customer+"&id_movie="+id_movie+">"+time+"</a>");
               out.println("<br><b><u><font color=black>Screen</font></u></b>: "+
               "<a href=http://www.benz/MovieProject/ByJSSI/page23.jhtml?id_order="+id_order+"&id_customer="+id_customer+"&id_movie="+id_movie+">"+id_screen+"("+type+")</a>");
               out.println("<b><u><font color=black>Seat</font></u></b>:  "+
               "<a href=http://www.benz/MovieProject/ByJSSI/page24.jhtml?id_order="+id_order+"&id_customer="+id_customer+"&id_movie="+id_movie+"&round="+roundTmp+">"+seat+"</a></td></tr>");
               out.println("</table></td></tr></table>");
               out.println("<br><br>");
           }
          if (MovieName=="") out.println("You don't have movie list");
          out.println("<table width=100%><tr bgcolor=#7FFFD4>"+
                       "<td align=left><table><tr><td>"+
                  "<form method=post action=http://www.benz/servlet/logout>"+
                  "<input type=hidden name=id_customer value="+id_customer+">"+
                  "<font color=black><input type=submit value=Logout></font></form></td></tr></table></td><td><table><tr><td><font color=black>Please click Logout if you do not want to change ticket</font></td></tr></table></td></tr></table>");
         }
         else 
         {
           out.println("Please verify user,password");
        out.println("<a href=http://www.benz/MovieProject/ByJSSI/page20.html>Goto Verify</a>");
         }

       }
       catch(SQLException e )
       { 
          out.println("Error:" + "<br>");
          out.println(e); 
       }   

     }

} 
