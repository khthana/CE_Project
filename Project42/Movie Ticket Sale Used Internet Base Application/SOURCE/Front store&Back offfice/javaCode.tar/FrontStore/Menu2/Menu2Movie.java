import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class Menu2Movie extends HttpServlet 
{
    public void doGet(HttpServletRequest _req,HttpServletResponse _res)
        throws IOException, ServletException
    {  
        PrintWriter out = _res.getWriter();  
        String name="",surname="",MovieName="";
        dateTime mydateTime = new dateTime();
        String id_customer=_req.getParameter("id_customer");
        try
        {   
           SQL mysql= new SQL();
           _res.setContentType ("text/html");
           Connection conn =  mysql.Connect("customer","movie");

           login mylogin = new login(conn,mysql,out);
           if (mylogin.active(id_customer))
           {

           String id_order=_req.getParameter("id_order");
           ResultSet Rs = mysql.Query(conn,"select name,surname"+
                        " from webapp.table1 where id_customer="+id_customer);
           while(Rs.next())
           {
             name=Rs.getString(1);
             surname=Rs.getString(2);
           }
         out.println("<table width=100% height=15%>"+
                     "<tr bgcolor=#7FFFD4><td><font color=black>"+
                     "<b>The Old Ticket of Mr.</b> "+name+" "+surname+
                     "</font></td></tr></table>");


           Rs = mysql.Query(conn,"select t4.name,"+
                              " t8.id_screen,t7.type,t8.day,t8.time,"+
                              " t8.id_seat "+
                              " from webapp.table4 t4,"+
                              " webapp.table7 t7,webapp.table8 t8"+
                              " where t4.id_movie=t8.id_movie "+
                              "  and t7.id_screen = t8.id_screen "+
                              " and id_order="+id_order);
           while (Rs.next())
           {
               MovieName = Rs.getString(1);
               int id_screen=Rs.getInt(2);
               String type = Rs.getString(3);
               String day = Rs.getString(4);
               String time = Rs.getString(5);
               String seat = Rs.getString(6);
             out.println("<table bgcolor=white border=3"+
               " cellpadding=10><tr><td><font color=black><b><u>Movie Name:</u></b> "+MovieName+"</font>");
              out.println("<br><font color=black><b><u>Date</u></b>: "+day+"</font>");
               out.println("<font color=black><b><u>Time</u></b>: "+time+"</font>");
               out.println("<br><font color=black><b><u>Screen</u></b>: "+id_screen+"("+type+")</font>");
               out.println("<font color=black><b><u>Seat</u></b>:  "+seat+"</font></td></tr>");
               out.println("</table>");
           }
               out.println("<br><hr width=80% align=left><br>");
           out.println("<b>From movie </b>"+MovieName+"<b>, Which one you want to change to?</b><br>"); 
           int count=0;
           out.println("<center><table cellpadding=5>");
           Rs =mysql.Query(conn,"select id_movie,name,type,arrive,leave from webapp.table4");
           while(Rs.next())
           {
               String id_movie = Rs.getString(1);
               String movieName = Rs.getString(2);
               String movieType = Rs.getString(3);
               String arrive = Rs.getString(4);
               String leave = Rs.getString(5);
               int begin = mydateTime.compareTo(arrive); 
               int end = mydateTime.compareTo(leave); 
               if ((!movieName.equals(MovieName))&&(begin<=0)&&(end>=0))
               {
                 out.println("<tr><td>");
                 out.println("<br>"+(++count)+". <u><a href=page23.jhtml?id_order="+id_order+"&id_customer="+id_customer+"&id_movie="+id_movie+">"+movieName+" ("+movieType+")</a></u>");
                 out.println("</td></tr>");
               }
           }
           out.println("</table></center>");

           out.println("<a href=./page21.jhtml?id_customer="+id_customer+">Back</a>");
           out.println("<table width=100%><tr bgcolor=#7FFFD4>"+
                       "<td align=left><table><tr><td>"+
                "<form method=post action=http://www.benz/servlet/logout>"+
                  "<input type=hidden name=id_customer value="+id_customer+">"+
                  "<font color=black><input type=submit value=Logout>"+
                  "</font></form></td></tr></table></td><td><table>"+
                  "<tr><td><font color=black>"+
 "Please click Logout if you do not want to change ticket"+
                 "</font></td></tr></table></td></tr></table>");

         }
         else 
         {
           out.println("Please verify user,password");
        out.println("<a href=http://www.benz/MovieProject/ByJSSI/page20.html>"+
                   "Goto Verify</a>");
         }

        }
        catch(SQLException e )
        { 
           out.println("Error:" + "<br>");
           out.println(e); 
        }   

     }
} 
