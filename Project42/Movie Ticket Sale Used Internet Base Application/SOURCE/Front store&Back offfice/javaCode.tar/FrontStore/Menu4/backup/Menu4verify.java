import java.awt.*;
import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class Menu4verify extends HttpServlet 
{
    String username,passwd,name,surname,email,phone;
    int id_customer,credit;

    public void service(HttpServletRequest request,HttpServletResponse response)
        throws IOException,ServletException
    {  
        response.setContentType("text/html");
        SQL mysql = new SQL();
        PrintWriter out  = response.getWriter();
        username = request.getParameter("username");
        passwd = request.getParameter("password");
        try
        {   
           if (verify.verify(username,passwd))
              {   
               Connection conn = mysql.Connect("customer","movie"); 
               ResultSet Rs = mysql.Query(conn,"select id_customer,name,surname,credit,email,phone from webapp.table1 where username= '"+username+"'");
               while (Rs.next())
               {
                   id_customer = Rs.getInt(1);
                   name = Rs.getString(2);
                   surname = Rs.getString(3);
                   credit = Rs.getInt(4);
                   email=Rs.getString(5);
                   phone=Rs.getString(6);
               }
               out.println("<form method=post action=https://www.benz/page42.jhtml>");
               out.println("<table cellpadding=10>");
               out.println("<input type=hidden name=id_customer value="+id_customer+">");
               out.println("<tr align=left><td><b>NAME : </b></td><td>"+name+"</td>");
               out.println("<td><b>SURNAME : </b></td><td>"+surname+"</td></tr>");
               out.println("<tr align=left><td><b>CREDIT : </b></td><td>"+ credit+"</td>");
               out.println("<td></td><td></td></tr>");
               out.println("<tr><td><b>USERNAME : </b></td><td><input type=text name=username value=\""+username+"\"></td>");
               out.println("<input type=hidden name=Oldusername value=\""+username+"\">");
               out.println("<td><b>PASSWORD : </b></td><td><input type=password name=password1 value="+passwd+"></td></tr>");
               out.println("<tr><td></td><td></td>");
               out.println("<td><b>RE-PASSWORD : </b></td><td><input type=password name=password2 value="+passwd+"></td></tr>");
               out.println("<input type=hidden name=Oldpassword value="+passwd+">");
               out.println("<tr><td><b>EMAIL : </b></td>");
               out.println("<td><input type=text name=email value="+email+"></td>");
               out.println("<input type=hidden name=Oldemail value="+email+">");
               out.println("<td><b>PHONE : </b></td>");
               out.println("<td><input type=text name=phone value="+phone+"></td></tr>");
               out.println("<input type=hidden name=Oldphone value="+phone+">");
               out.println("</table>");
           out.println("<center><input type=submit value=Submit>"); 
           out.println("<input type=reset value=Undo>");
               out.println("</center></form>");
             }
             else 
             { out.println("Menu2 SORRY YOU HAVE NOT PERMISSION<br>");
             }
        }
        catch(SQLException e )
        { 
           out.println("Error:"+e);
        }
 out.println("<hr align=center width=70%>");
      out.println("<a href=http://www.benz/MovieProject/ByJSSI/index.html><u>MainMenu</u></a>"); 
   }
}
