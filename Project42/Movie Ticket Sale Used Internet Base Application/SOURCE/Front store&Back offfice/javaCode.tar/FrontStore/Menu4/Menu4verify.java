import java.awt.*;
import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class Menu4verify extends HttpServlet 
{
    String username,passwd,name,surname,email,phone;
    int id_customer,credit;

    public void service(HttpServletRequest request,HttpServletResponse response)
        throws IOException,ServletException
    {  
        response.setContentType("text/html");
        SQL mysql = new SQL();
        PrintWriter out  = response.getWriter();
        String id_customer = request.getParameter("id_customer");
        try
        {
          Connection conn = mysql.Connect("customer","movie"); 
          login mylogin = new login(conn,mysql,out);
          if (mylogin.active(id_customer))
          {
           try
           {   
               ResultSet Rs = mysql.Query(conn,"select name,surname,credit,email,phone,username,password from webapp.table1 where id_customer= '"+id_customer+"'");
               while (Rs.next())
               {
                   name = Rs.getString(1);
                   surname = Rs.getString(2);
                   credit = Rs.getInt(3);
                   email=Rs.getString(4);
                   phone=Rs.getString(5);
                   username=Rs.getString(6);
                   passwd=Rs.getString(7);
               }
               out.println("<form method=post action=https://www.benz/page42.jhtml>");
               out.println("<table cellpadding=10>");
               out.println("<input type=hidden name=id_customer value="+id_customer+">");
               out.println("<tr align=left><td><b>NAME : </b></td><td>"+name+"</td>");
               out.println("<td><b>SURNAME : </b></td><td>"+surname+"</td></tr>");
               out.println("<tr align=left><td><b>CREDIT : </b></td><td>"+ credit+"</td>");
               out.println("<td></td><td></td></tr>");
               out.println("<tr><td><b>USERNAME : </b></td><td><input type=text name=username value=\""+username+"\"></td>");
               out.println("<input type=hidden name=Oldusername value=\""+username+"\">");
               out.println("<td><b>PASSWORD : </b></td><td><input type=password name=password1 value="+passwd+"></td></tr>");
               out.println("<tr><td></td><td></td>");
               out.println("<td><b>RE-PASSWORD : </b></td><td><input type=password name=password2 value="+passwd+"></td></tr>");
               out.println("<input type=hidden name=Oldpassword value="+passwd+">");
               out.println("<tr><td><b>EMAIL : </b></td>");
               out.println("<td><input type=text name=email value="+email+"></td>");
               out.println("<input type=hidden name=Oldemail value="+email+">");
               out.println("<td><b>PHONE : </b></td>");
               out.println("<td><input type=text name=phone value="+phone+"></td></tr>");
               out.println("<input type=hidden name=Oldphone value="+phone+">");
               out.println("</table>");
           out.println("<center><input type=submit value=Submit>"); 
           out.println("<input type=reset value=Undo>");
               out.println("</center></form>");
           }
           catch(SQLException e )
           { 
              out.println("Error:"+e);
           }
     out.println("<table width=100%><tr bgcolor=#7FFFD4>"+
                       "<td align=left><table><tr><td>"+
                "<form method=post action=http://www.benz/servlet/logout>"+
                  "<input type=hidden name=id_customer value="+id_customer+">"+
                  "<font color=black><input type=submit value=Logout>"+
                  "</font></form></td></tr></table></td><td><table>"+
                  "<tr><td><font color=black>"+
 "Please click Logout if you do not want to cancel ticket"+
                 "</font></td></tr></table></td></tr></table>");

          }
          else
          {
  out.println("Please verify user,password");
        out.println("<a href=http://www.benz/MovieProject/ByJSSI/page40.html>"+
                  "Goto Verify</a>");

          }

      }
      catch(SQLException e)
      {
         out.println(e);
         out.println("<a href=http://www.benz/MovieProject/ByJSSI/>MainMenu</a>");
      }
   }
}
