import java.awt.*;
import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class Menu4Update extends HttpServlet 
{
    String username,passwd1,passwd2,hidePasswd,name,surname,email,phone;
    String Oldusername,Oldpassword,Oldemail,Oldphone,passwdTmp;
    int id_customer,credit;

    public void service(HttpServletRequest request,HttpServletResponse response)
        throws IOException,ServletException
    {  
        response.setContentType("text/html");
        SQL mysql = new SQL();
        PrintWriter out  = response.getWriter();
        id_customer= Integer.parseInt(request.getParameter("id_customer")); 
        username= request.getParameter("username"); 
        Oldusername= request.getParameter("Oldusername"); 
        passwd1= request.getParameter("password1"); 
        passwd2= request.getParameter("password2"); 
        Oldpassword= request.getParameter("Oldpassword"); 
        email=request.getParameter("email");
        Oldemail=request.getParameter("Oldemail");
        phone=request.getParameter("phone");
        Oldphone=request.getParameter("Oldphone");
        try
        {   
               Connection conn = mysql.Connect("customer","movie"); 
               if ( !(Oldusername.equals(username)))
               {
                  mysql.Update(conn,"update webapp.table1 set username='"+
                                 username+"'"+ 
                                 " where id_customer="+id_customer);
                  conn.commit();
               }
               if ( !(Oldpassword.equals(passwd1))&&(passwd1.equals(passwd2)))
               {
               mysql.Update(conn,"update webapp.table1 set"+
                                 " password='"+passwd1+ 
                                 "' where id_customer="+id_customer);
               conn.commit();
               }
               if (!(Oldemail.equals(email))) 
               {
                    mysql.Update(conn,"update webapp.table1 set email='"+
                                       email+"'"+ 
                                      " where id_customer= "+id_customer);
                    conn.commit();
               }
                 if (!(Oldphone.equals(phone))) 
                 {
                    mysql.Update(conn,"update webapp.table1 set phone='"+
                                       phone+"'"+ 
                                      " where id_customer="+id_customer);
                    conn.commit();
                 }
               ResultSet Rs = mysql.Query(conn,"select username,name,surname,password,credit,email,phone from webapp.table1 where id_customer="+id_customer);
               while (Rs.next())
               {
                   username = Rs.getString(1);
                   name = Rs.getString(2);
                   surname = Rs.getString(3);
                   passwdTmp = Rs.getString(4);
                   credit = Rs.getInt(5);
                   email = Rs.getString(6);
                   phone = Rs.getString(7);
               }
               String hidepassword="";
               for(int i=0;i<passwdTmp.length();i++){hidepassword+="*";}
               out.println("<table>");
               out.println("<tr><td>Your name : </td><td>"+name+"</td></tr>");
               out.println("<tr><td>Your surname : </td><td>"+surname+"</td></tr>");
               out.println("<tr><td>Your username : </td><td>"+username+"</td></tr>");
               out.println("<tr><td>Your password : </td><td>"+hidepassword+"</td></tr>");
         if (!passwd1.equals(passwd2)) 
          out.println("<tr><td></td><td>RE-PASSWORD don't match</td></tr>"); 
               out.println("<tr><td>You have credit : </td><td>"+ credit+"</td></tr>");
               out.println("<tr><td>You Email : </td>");
               out.println("<td>"+email+"</td></tr>");
               out.println("<tr><td>You Phone : </td>");
               out.println("<td>"+phone+"</td></tr>");
               out.println("</table>");
          out.println("<a href=./page41.jhtml?id_customer="+id_customer+
                      ">Change any more?</a>");
        }
        catch(SQLException e )
        { 
           out.println("Error:"+e);
        }
  out.println("<table width=100%><tr bgcolor=#7FFFD4>"+
                       "<td align=left><table><tr><td>"+
                "<form method=post action=http://www.benz/servlet/logout>"+
                  "<input type=hidden name=id_customer value="+id_customer+">"+
                  "<font color=black><input type=submit value=Logout>"+
                  "</font></form></td></tr></table></td><td><table>"+
                  "<tr><td><font color=black>"+
 "Please click Logout if you do not want to cancel ticket"+
                 "</font></td></tr></table></td></tr></table>");

   }
}
