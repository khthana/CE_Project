import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class listVerify extends HttpServlet 
{
    public void doPost(HttpServletRequest _req,HttpServletResponse _res)
        throws IOException, ServletException
    {  
        PrintWriter out = _res.getWriter();  
        _res.setContentType ("text/html");
        String username=_req.getParameter("username");
        String password=_req.getParameter("password");

           if (verify.verify(username,password))
           {
             Connection conn=null;
             String id_customer="";
             SQL mysql= new SQL();
             try
             {   
              conn =  mysql.Connect("customer","movie");
              ResultSet Rs = mysql.Query(conn,"select id_customer from webapp.table1 where username='"+username+"'");
               while (Rs.next())
               {
                 id_customer = Rs.getString(1);
               }
             }
             catch(SQLException e )
             { 
              out.println("Error:" + "<br>");
              out.println(e); 
             }

             login mylogin = new login(conn,mysql,out);
             if (mylogin.active(id_customer))
             {
                try
                {
                   _res.sendRedirect("http://www.benz/MovieProject/ByJSSI/loginRepeatList.jhtml?id_customer="+id_customer);
                }
                catch (IOException e)
                {
                   out.println(e);
                } 
             }
             else 
             {
                mylogin.login(id_customer);
                try
                {
                   _res.sendRedirect("http://www.benz/MovieProject/ByJSSI/page51.jhtml?id_customer="+id_customer);
                }
                catch (IOException e)
                {
                   out.println(e);
                } 
             }
          }
          else { 
                 out.println("You don't have permission");}
                 out.println("<a href=http://www.benz/MovieProject/ByJSSI/page40.html>Try Again</a>");

     }
} 
