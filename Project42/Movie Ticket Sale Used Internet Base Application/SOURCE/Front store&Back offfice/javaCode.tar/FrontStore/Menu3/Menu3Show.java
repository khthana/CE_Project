import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class Menu3Show extends HttpServlet 
{
    public void service(HttpServletRequest _req,HttpServletResponse _res)
        throws IOException, ServletException
    {  
        PrintWriter out = _res.getWriter();  
        String name="",surname="",MovieName="";
        SQL mysql= new SQL();
        _res.setContentType ("text/html");
        _res.setIntHeader ("Expires",-1);
        String id_customer=_req.getParameter("id_customer");
        try
        {
           Connection conn =  mysql.Connect("customer","movie");
           login mylogin = new login(conn,mysql,out);
           if (mylogin.active(id_customer))
           {
             try
             {   
              ResultSet Rs = mysql.Query(conn,"select name,surname"+
                           " from webapp.table1 where id_customer='"+id_customer+"'");
              while(Rs.next())
              {
                name=Rs.getString(1);
                surname=Rs.getString(2);
              }
          out.println("<table width=100% height=15%><tr bgcolor=#7FFFCC><td>");
           out.println("<font color=black><b>Your name:</b> "+name+" "+surname);
          out.println(" </font></td></tr></table>");

           Rs = mysql.Query(conn,"select t4.name,"+
                              " t8.id_screen,t7.type,t8.day,t8.time,"+
                              " t8.id_seat,t8.id_order"+
                              " from webapp.table4 t4,"+
                              " webapp.table7 t7,webapp.table8 t8"+
                              " where t4.id_movie=t8.id_movie "+
                              "  and t7.id_screen = t8.id_screen "+
                              " and id_customer="+id_customer+
                              " and t8.print='false'");
           int count=0;
           while (Rs.next())
           { 
               MovieName = Rs.getString(1);
               int id_screen=Rs.getInt(2);
               String type = Rs.getString(3);
               String day = Rs.getString(4);
               String time = Rs.getString(5);
               String seat = Rs.getString(6);
               int id_order=Rs.getInt(7);
              out.println("<table bgcolor=#ADD8E6><tr><td><font color=black><b>Ticket</b>"+(++count)+"</font></td></tr><tr><td><table bgcolor=white border=3 cellpadding=10><tr><td><font color=black><b><u>Movie Name:</u></b> "+MovieName+" </font>");
              out.println("<br><font color=black><b><u>Date</u></b>: "+day+"</font>");
               out.println("<font color=black><b><u>Time</u></b>: "+time+" </font>");
               out.println("<br><font color=black><b><u>Screen</u></b>: "+id_screen+"("+type+")</font>");
               out.println("<font color=black><b><u>Seat</u></b>:  "+seat+"</td></tr></font>");
               out.println("</table></td></tr>");
         out.println("<form method=\"post\" action=\"http://www.benz/MovieProject/ByJSSI/page32.jhtml\">");
         out.println("<input type=hidden value="+id_order+" name=order>");
         out.println("<input type=hidden value="+id_customer+" name=id_customer>");
         out.println("<tr bgcolor=red><td><input type=submit value=cancel></td></tr>");
               out.println("</form></table><br><br>");
           }
           if (MovieName=="") out.println("You don't have movie list");

        }
        catch(SQLException e )
        { 
           out.println("Error:" + "<br>");
           out.println(e); 
        }   
      out.println("<table width=100%><tr bgcolor=#7FFFD4>"+
                       "<td align=left><table><tr><td>"+
                "<form method=post action=http://www.benz/servlet/logout>"+
                  "<input type=hidden name=id_customer value="+id_customer+">"+
                  "<font color=black><input type=submit value=Logout>"+
                  "</font></form></td></tr></table></td><td><table>"+
                  "<tr><td><font color=black>"+
 "Please click Logout if you do not want to cancel ticket"+
                 "</font></td></tr></table></td></tr></table>");

      }
      else 
      {
   out.println("Please verify user,password");
        out.println("<a href=http://www.benz/MovieProject/ByJSSI/page30.html>"+
                  "Goto Verify</a>");
      }

     }
     catch(SQLException e)
     { out.println(e);}
     }
} 
