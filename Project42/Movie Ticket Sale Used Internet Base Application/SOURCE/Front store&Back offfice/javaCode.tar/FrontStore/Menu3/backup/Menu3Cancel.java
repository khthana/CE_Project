import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class Menu3Cancel extends HttpServlet 
{
    public void service(HttpServletRequest _req,HttpServletResponse _res)
        throws IOException, ServletException
    {  
        PrintWriter out = _res.getWriter();  
        int credit=0,id_movie=0,id_screen=0,round=0,id_order=0;
        String day="",time="",seat="",name="",surname="",MovieName="",type="",print="";
        try
        {   
           SQL mysql= new SQL();
           _res.setContentType ("text/html");
           id_order=Integer.parseInt(_req.getParameter("order"));
           String id_customer=_req.getParameter("id_customer");
           Connection conn =  mysql.Connect("customer","movie");
           ResultSet Rs = mysql.Query(conn,"select print from webapp.table8 "+
                                     " where id_order= "+ id_order);
           while (Rs.next())
           {
              print = Rs.getString(1);
           }
         if (!(print.equals("cancel")))
         {
          
           Rs=mysql.Query(conn,"select credit from webapp.table1"+
                                       " where id_customer="+id_customer); 
           while(Rs.next())
           {
               credit = Rs.getInt(1);
           }
           credit++;
           mysql.Update(conn,"update webapp.table1"+
                     " set credit="+credit+" where id_customer="+id_customer);
        
           Rs=mysql.Query(conn,"select id_movie,id_screen,day,time,id_seat from webapp.table8 where id_order="+id_order);
           while(Rs.next())
           {
               id_movie = Rs.getInt(1);
               id_screen = Rs.getInt(2);
               day= Rs.getString(3);
               time= Rs.getString(4);
               seat= Rs.getString(5);
           }
           Rs=mysql.Query(conn,"select round from webapp.table5"+
                               " where id_movie="+id_movie+
                               " and screen="+id_screen+
                               " and day='"+day+"'"+
                               " and time='"+time+"'"); 
           while(Rs.next())
           {
              round = Rs.getInt(1);
           }
           mysql.Update(conn,"update webapp.table6"+
                        " set state=null where seat='"+seat+"'"+
                        " and round="+round);

           mysql.Update(conn,"update webapp.table8"+
                           " set print='cancel' where id_order="+id_order);
           out.println(" Delete your order complete");

           out.println("<a href=./page31.jhtml?id_customer="+id_customer+
                     ">Cancel any more?</a>");

     out.println("<table width=100%><tr bgcolor=#7FFFD4>"+
                       "<td align=left><table><tr><td>"+
                "<form method=post action=http://www.benz/servlet/logout>"+
                  "<input type=hidden name=id_customer value="+id_customer+">"+
                  "<font color=black><input type=submit value=Logout>"+
                  "</font></form></td></tr></table></td><td><table>"+
                  "<tr><td><font color=black>"+
 "Please click Logout if you do not want to cancel ticket"+
                 "</font></td></tr></table></td></tr></table>");

         }
         else {out.println("this order has been canceled");}
        }
        catch(SQLException e )
        { 
           out.println("Error:" + "<br>");
           out.println(e); 
        }   
     }
} 
