import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class loginRepeatCancel extends HttpServlet 
{
    public void service(HttpServletRequest _req,HttpServletResponse _res)
        throws IOException, ServletException
    {  
        PrintWriter out = _res.getWriter();  
        _res.setContentType ("text/html");
        String id_customer = _req.getParameter("id_customer");
       out.println("<form method=post action=http://www.benz/servlet/logout>"+
                  "<input type=hidden name=id_customer value="+id_customer+">"+
                  "<table width=100% bgcolor=#BC8F8F><tr align=left><td>"+
                  "<input type=submit value=Logout>"+
                  "</td></tr></table></form>");

    }

} 
