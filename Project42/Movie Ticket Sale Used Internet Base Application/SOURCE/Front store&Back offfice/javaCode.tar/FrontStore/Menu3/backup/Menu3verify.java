import java.awt.*;
import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class Menu3verify extends HttpServlet 
{
    public void service(HttpServletRequest request,HttpServletResponse response)
        throws IOException, ServletException
    {  
        response.setContentType("text/html");
        PrintWriter out  = response.getWriter();
      out.println("<form method=post action=https://www.benz/page31.jhtml>");

     out.println("<table><tr bgcolor=#FFEFD5><td><table><tr>"+
"<td bgcolor=#CD55B4><font color=black>User</font></td><td>" +
"<input type=text size=20 name=username></td></tr>");
       out.println("<tr><td bgcolor=#CD55B4><font color=black>Password"+
"</font></td><td><input type=password size=20 name=password>"+
"</td></tr></table>");
       out.println("<tr bgcolor=#ADD8E6><td><input type=submit value=\"Ok\">");
       out.println("<input type=reset value=\"Clear\"></td></tr></table>");
       out.println("</form>");

    }
}
