import java.awt.*;
import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class Menu1verify extends HttpServlet implements Runnable
{
    String id_screen,id_movie,day,time,round,id_seat;
    String username,passwd;
    int id,credit;
    SQL mysql= new SQL();
    Connection conn;
    PrintWriter out;
    findNEXTVAL myFind;

    public void service(HttpServletRequest request,HttpServletResponse response)
        throws IOException, ServletException
    {  
        Vector seatVec = new Vector();
        myFind= new findNEXTVAL(); 
        out = response.getWriter();  
        getCookie MygetCookie = new getCookie();
        response.setContentType("text/html");
        username = request.getParameter("username");
        passwd = request.getParameter("passwd");
          id_movie = MygetCookie.getResult(request,"MovieCookie");
          String cookie2 = MygetCookie.getResult(request,"MovieCookie2");
          id_seat = MygetCookie.getResult(request,"MovieCookie3");
             int count = split.count(id_seat);
          id_screen = split.split(cookie2,0);
          int start = split.returnEnd();
          day = split.split(cookie2,start);
          start = split.returnEnd();
          time = split.split(cookie2,start);
          start = split.returnEnd();
          round = split.split(cookie2,start);
          boolean complete = true,clear = true;
        try
        {   
          conn =  mysql.Connect("customer","movie");
          selectUserData(conn,username);
           if (verify.verify(username,passwd))
              {   
                if (credit >= count)
                {
                 synchronized(this)
                 {
		 int j=0; 
                 String seat[]= new String[count];

                 conn.setAutoCommit(false);

                 for (int i=0;i<=count-1;i++)
		 {
                    seat[i]=split.split(id_seat,j);
                    j = split.returnEnd();
                       clear = query(conn,seat[i]);
                       if (clear) {
                                   updateTable6(conn,seat[i]);
                                   seatVec.addElement(seat[i]);
  		                  }
                       else {complete=false;
                            break;}
		 } 
                
                 if (complete)
                 {
                     credit -= count;
                     mysql.Update(conn," Update webapp.table1 "+
                                     " set credit ="+credit+
                                     " where id_customer="+id);
                    int tab8_seq = myFind.getNEXT("table8","id_order");
                    for (int i=0;i<seatVec.size();i++)
                    {
                     insertTable8(conn,(String)seatVec.elementAt(i),tab8_seq);
                     ++tab8_seq;
                    }
                     conn.commit();
                     conn.setAutoCommit(true);
                     out.println("<h2>Thankyou for use Application</h2>");
                     out.println("<br><br><center><h3>You can get tickets in front of screen</h3></center>");
                 }
                 else { 
                        conn.rollback();
                        conn.setAutoCommit(true);
                        out.println("This seat is ordered before you"); 
                      }
                }
                }
                else {out.println("You Do not have credit");}
              }
              else { out.println("SORRY YOU HAVE NOT PERMISSION<br>");
                   }
        }
        catch(SQLException e )
        { 
           out.println("Error:"+e);
           try{conn.close();}
           catch(SQLException ex) {out.println(ex);} 
        }   
     }

     public void run()
     {
     }

     private void insertTable8(Connection conn,String seat,int tab8_seq)
              throws SQLException
     {
                 mysql.Update(conn," insert into webapp.table8 " +
                            " values("+tab8_seq+ 
                             " ,"+ id +","+id_movie+ 
                             ","+id_screen+",'"+day+"','"+time+"','"+seat+
      		             "','false')");
     } 
     private void updateTable6(Connection conn,String seat)
              throws SQLException
     {
                 mysql.Update(conn," update webapp.table6 " +
                            " set state='order' "+
                             " where round="+round+
      		             " and seat='"+seat+"'");
     }
     private boolean query(Connection conn,String seat)
              throws SQLException
     {
           String state="";
           ResultSet Rs = mysql.Query(conn,"select state " +
                            " from webapp.table6 "+
                             " where round="+round+
                                " and seat='"+seat+"'");
           while (Rs.next())
           {state=Rs.getString(1);}
           if (state == null) return true; 
           return false;
     }
     private void selectUserData(Connection conn,String username)
              throws SQLException
     {
          ResultSet Rs = mysql.Query(conn," select id_customer,credit " +
                                         " from webapp.table1 "+
                                         " where username='"+username+"'");
           while (Rs.next())
           {id = Rs.getInt(1);
            credit=Rs.getInt(2);}
     }
} 
