import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class seatlist extends HttpServlet 
{
    public void service(HttpServletRequest request,HttpServletResponse response)
        throws IOException, ServletException
    {  
        PrintWriter out = response.getWriter();  
        getCookie MygetCookie;
        try
        {   
           MygetCookie = new getCookie();
           String id_movie = MygetCookie.getResult(request,"MovieCookie"); 
           String cookie2 = MygetCookie.getResult(request,"MovieCookie2"); 
           String id_screen = split.split(cookie2,0);
           int start = split.returnEnd();
           String day = split.split(cookie2,start);
           start = split.returnEnd();
           String time = split.split(cookie2,start);
           start = split.returnEnd();
           String round = split.split(cookie2,start);
     
           SQL mysql= new SQL();
           Connection conn =  mysql.Connect("customer","movie");

           ResultSet Rs = mysql.Query(conn," select seat,state "+ 
                                  " from webapp.table6 "+
                                  " where round="+round+" "+
                                  " order by seat"); 
 	   out.println("<form method=\"post\" action=page13.jhtml>");
           out.println("<table cellpadding=8><tr align=right>");
            int countTmp=0;
           while (Rs.next())
           { 
               String id_seat = Rs.getString(1);
               String state = Rs.getString(2);
               if (state == null) { 
                        out.println("<td>"+id_seat+":"+"<input type=checkbox value="+id_seat+" name="+id_seat+"></td>");
                                  }
               else  {
                        out.println("<td>"+id_seat+" :</td>");
                     }
               if (++countTmp==10) {out.println("</tr><tr align=right>");countTmp=0;}
           }
           out.println("</tr></table>");
           out.println("<br><table width=100% bgcolor=#006400><tr><td><input type=submit value=Submit>"); 
           out.println("<input type=reset value=Undo></td></tr></table>"); 
           out.println("</form></center>"); 
        }
        catch(SQLException e )
        { 
           out.println("Error:" + "<br>");
           out.println(e); 
        }   

     }
} 
