import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class movielist extends HttpServlet 
{
    public void service(HttpServletRequest _req,HttpServletResponse _res)
        throws IOException, ServletException
    {  
        PrintWriter out = _res.getWriter();  
        dateTime mydateTime = new dateTime();
        String movie_name = "";
        try
        {   
           SQL mysql= new SQL();
           _res.setContentType ("text/html");
           out.println("<script language=JavaScript>");
 	   out.println("<!--");
           out.println("function setCookie(id) {");
	   out.println("exp = new Date();");
	   out.println("exp.setTime(exp.getTime()+(24*60*60*1000));");
	   String cookie ="document.cookie=\"MovieCookie=\"+id+\";expires=\"+exp.toGMTString()+\";path=/\";";
	   out.println(cookie);
           out.println("}");  
	   out.println("//-->");
	   out.println("</script>");
  	   out.println("<center><table cellspacing=14>");
           Connection conn =  mysql.Connect("customer","movie");
           ResultSet Rs = mysql.Query(conn,"select id_movie,name,arrive,leave,URL from webapp.table4 order by id_movie");
               int tmp =0;
           while (Rs.next())
           { 
               String id_movie = Rs.getString(1);
               movie_name = Rs.getString(2);
               String arrive = Rs.getString(3);
               String leave = Rs.getString(4);
               String myURL = Rs.getString(5);
               int begin =mydateTime.compareTo(arrive);
               int end =mydateTime.compareTo(leave);
               if ((begin<=0) && (end>=0))
               { 
                out.println("<tr>");
                out.println("<td>");
out.println("<a href=page11.jhtml onClick=\"setCookie("+ id_movie +")\">");
                out.println((++tmp)+".<u> "+movie_name+"</u></a></td>");
                out.println("<td><a href="+myURL+">demo</a></td></tr>");
               }
           }
           out.println("</table></center>");
           conn.close();
        }
        catch(SQLException e )
        { 
           out.println("Error:" + "<br>");
           out.println(e); 
        }   
        if (movie_name.equals("")) out.println("<h2>No movie in my Thearter</h2>"); 
     }
} 
