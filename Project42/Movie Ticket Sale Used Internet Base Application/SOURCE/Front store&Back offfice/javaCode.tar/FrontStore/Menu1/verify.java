import java.sql.*;
import java.lang.*;
 
public class verify 
{
    static boolean pass=false;
    public static boolean verify(String username,String password)
    {
        try{
        String passwd_db="";
        SQL mysql= new SQL();
          Connection conn =  mysql.Connect("customer","movie");
          ResultSet Rs = mysql.Query(conn," select password " +
                                           " from webapp.table1 "+
                                           " where username='"+username+"'");
           while (Rs.next())
           {passwd_db=Rs.getString(1);}
           
           if (passwd_db.equals(password))
              {   
                 return pass =true;
              }
              else { return pass=false;};
        }
        catch(SQLException e )
        { 
          return pass = false;
        }   
    }
}
