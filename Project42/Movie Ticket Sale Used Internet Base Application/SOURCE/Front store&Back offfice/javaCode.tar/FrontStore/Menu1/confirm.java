import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class confirm extends HttpServlet 
{
    public void service(HttpServletRequest request,HttpServletResponse response)
        throws IOException, ServletException
    {  
        PrintWriter out = response.getWriter();  
        try
        {   
           String screen,id_screen,name,id_movie,day,time,id_seat;
     	   getCookie MygetCookie = new getCookie();
           id_seat="";name="";screen="";
           id_movie = MygetCookie.getResult(request,"MovieCookie");
           String cookie2 = MygetCookie.getResult(request,"MovieCookie2");
           id_screen = split.split(cookie2,0);
           int start = split.returnEnd();
           day = split.split(cookie2,start);
           start = split.returnEnd();
           time = split.split(cookie2,start);

           SQL mysql= new SQL();
           Connection conn =  mysql.Connect("customer","movie");
           ResultSet Rs = mysql.Query(conn,"select seat "+ 
                             " from webapp.table5 a,webapp.table6 b "+
                             " where screen="+id_screen+
                             " and day='"+day+"'"+
                             " and time='"+time+"'"+
                             " and a.round=b.round");
          while(Rs.next())
          {
              String tmp = Rs.getString(1);
              String seatTmp=request.getParameter(tmp);
              if (seatTmp != null)
              {
                 id_seat=id_seat+seatTmp+",";
              }
          }
          id_seat=id_seat.substring(0,id_seat.length()-1);
          
           response.setContentType ("text/html");
           out.println("<script language=JavaScript>");
           out.println("<!--");
           out.println("function setCookie(value) {");
           out.println("exp = new Date();");
           out.println("exp.setTime(exp.getTime()+(24*60*60*1000));");
           String cookie ="document.cookie=\"MovieCookie3=\"+value+\";expires=\"+exp.toGMTString()+\";path=/\";";
           out.println(cookie);
           out.println("}");
           out.println("//-->");
           out.println("</script>");

           Rs = mysql.Query(conn," select name "+ 
                                  " from webapp.table4 "+
                          " where id_movie='"+id_movie+"'"); 
           while (Rs.next())
           { 
            name = Rs.getString(1);
           }
           Rs = mysql.Query(conn," select type "+ 
                                 " from webapp.table7 "+
                                 " where id_screen='"+id_screen+"'"); 
           while (Rs.next())
           { 
            screen = Rs.getString(1);
           }
           out.println("<center><br>Movie Name  :  "+name);
           out.println("<br>Screen      :  screen "+id_screen+" ( "+screen+" )");
           out.println("<br>Day         :  "+day);
           out.println("<br>Time        :  "+time);
           out.println("<br>Seat Number :  "+id_seat);
out.println("<form method=\"post\" action=\"https://www.benz/page14.jhtml\" onSubmit=\"setCookie('"+id_seat+"')\";>");
//out.println("<form method=\"post\" action=page14.jhtml onSubmit=\"setCookie('"+id_seat+"')\";>");
           out.println("<table><tr bgcolor=#FFEFD5><td><table><tr><td bgcolor=#CD55B4><font color=black>User</font></td><td><input type=text size=20 name=username></td></tr>");
           out.println("<tr><td bgcolor=#CD55B4><font color=black>Password</font></td><td><input type=password size=20 name=passwd></td></tr></table>");
           out.println("<tr bgcolor=#ADD8E6><td><input type=submit value=\"Ok\">"); 
           out.println("<input type=reset value=\"Clear\"></td></tr></table>"); 
           out.println("</form>"); 
        }
        catch(SQLException e )
        { 
           out.println("Error:" + "<br>");
           out.println(e); 
           out.println("</form></center>"); 
        }   
        out.println("</center>"); 

     }
} 
