import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class SQL
{
   public Connection Connect(String user, String passwd)
   throws SQLException
   {
      String DB = "jdbc:oracle:thin:@benz:1521:yord"; 

      DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
      Connection conn = DriverManager.getConnection(DB,user,passwd);
      return conn;
   }

   public ResultSet Query (Connection conn, String QueryString)
   throws SQLException
   {
      Statement stmt = conn.createStatement();
      ResultSet rs   = stmt.executeQuery(QueryString);
      return rs;
   }
 public void Update (Connection conn, String UpdateString)
   throws SQLException
      {
         Statement stmt = conn.createStatement();
         stmt.executeUpdate(UpdateString);
      }
 public int UpdateGetCount (Connection conn, String UpdateString)
   throws SQLException
      {
         Statement stmt = conn.createStatement();
         stmt.executeUpdate(UpdateString);
         return stmt.getUpdateCount();
      }
}
