import java.io.*;
import java.lang.*;
 
public class split
{
    private static int end=0;
    public static String split(String txt ,int start)
    {
      String temp = "";
      end=txt.indexOf(',',start); 
      if (end == -1) {return temp = txt.substring(start,txt.length()); 
                     }
      else return temp = txt.substring(start,end); 
    }
    public static String split(String txt ,int start,int end)
    {
      String temp="";
      return temp = txt.substring(start,end);
    }
    public static int returnEnd()
    {
      return end+1;
    } 
    public static int count(String txt)
    {
      int i=0,j=0,count=0;
      while (i <= txt.length()-1)
      {  
 	 i = txt.indexOf(',',j);
         if (i== -1)  break;
         else count +=1;
         i+=1;j=i;
      }  
      return count+1;
    }
} 
