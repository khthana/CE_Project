import java.io.*;
import java.util.*;
import java.lang.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class getCookie extends HttpServlet
{
    private String result="";
    public String getResult(HttpServletRequest _req,String name)
                        throws IOException
    {
    try{return result = findValue(_req,name);}
    catch(Exception E) {return result;}
    }

    public String findValue(HttpServletRequest _req,String name) 
                        throws IOException
    {
    String value="";
    try{ 
        Cookie inCookie[];
        inCookie = _req.getCookies(); 
        if (inCookie == null) {return value ="Cookie invalid";}
        else {
               for (int x=0;x < inCookie.length;x++)
	 	  if ( inCookie[x].getName().equals(name) )
                       return value = inCookie[x].getValue();
             }
        return value;
       }
    catch(Exception E) {return value;}
    }
} 
