import java.awt.*;
import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class Menu1verify extends HttpServlet implements Runnable
{

    public void service(HttpServletRequest request,HttpServletResponse response)
        throws IOException, ServletException
    {  
        SQL mysql= new SQL();
        Vector seatVec = new Vector();
        findNEXTVAL myFind= new findNEXTVAL(); 
        PrintWriter out = response.getWriter();  
        getCookie MygetCookie = new getCookie();
        Connection conn=null;
        response.setContentType("text/html");

        String username = request.getParameter("username");
        String passwd = request.getParameter("passwd");
          String id_movie = MygetCookie.getResult(request,"MovieCookie");
          String cookie2 = MygetCookie.getResult(request,"MovieCookie2");
          String id_seat = MygetCookie.getResult(request,"MovieCookie3");
             int count = split.count(id_seat);
          String id_screen = split.split(cookie2,0);
          int start = split.returnEnd();
          String day = split.split(cookie2,start);
          start = split.returnEnd();
          String time = split.split(cookie2,start);
          start = split.returnEnd();
          String round = split.split(cookie2,start);
          boolean complete = false;

          if (verify.verify(username,passwd))
          {   
            try
            {
              conn = mysql.Connect("customer","movie"); 
              conn.setAutoCommit(false);
            }
            catch(SQLException e) {out.println(e);}

            int credit= selectCredit(conn,out,mysql,username);
            int id= selectId(conn,out,mysql,username);
             if (credit >= count)
             {
		int j=0; 
                for (int i=0;i<count;i++)
		{
                    seatVec.addElement(split.split(id_seat,j));
                    j = split.returnEnd();
                }
                synchronized(this) 
                { 
                  complete = updateTable6(conn,mysql,out,seatVec,round);
                  if (complete)
                  {
                    credit -= count;
                    updateTable1(conn,mysql,out,credit,id);

                    int tab8_seq = myFind.getNEXT("table8","id_order");
                    for (int i=0;i<seatVec.size();i++)
                    {
                      insertTable8(out,conn,mysql,(String)seatVec.elementAt(i),tab8_seq,id,id_movie,id_screen,day,time);
                      ++tab8_seq;
                    }

                    out.println("<h2>Thankyou for use Application</h2>");
                    out.println("<br><br><center><h3>You can get tickets in front of screen</h3></center>");
                  }
                  else { 
                         out.println("This seat is ordered before you"); 
                       }
               }
                  try{
                       conn.setAutoCommit(true);
                       conn.close();
                  }
                  catch(SQLException e){out.println(e);}
             }
             else out.println("You Do not have credit");
          }
          else out.println("SORRY YOU HAVE NOT PERMISSION<br>");

            out.println("<a href=http://www.benz/index.html><u>MainMenu</u></a>");
     }

     public void run()
     {
     }
    
     private void updateTable1(Connection conn,SQL mysql,PrintWriter out,int credit,int id)
     {
        try 
        {
          mysql.Update(conn," Update webapp.table1 "+
                          " set credit ="+credit+
                          " where id_customer="+id);
          conn.commit();
        }
        catch(SQLException e) {out.println(e);}
     }

     private void insertTable8(PrintWriter out,Connection conn,SQL mysql,String seat,int tab8_seq,int id,String id_movie,String id_screen,String day,String time)
     {
        try
        {
            mysql.Update(conn," insert into webapp.table8 " +
                          " values("+tab8_seq+ 
                          " ,"+ id +","+id_movie+ 
                          ","+id_screen+",'"+day+"','"+time+"','"+seat+
                          "','false')");
            conn.commit();
        }
        catch(SQLException e) {out.println(e);}
     } 

     private int selectCredit(Connection conn,PrintWriter out,SQL mysql,String username)
     {
          ResultSet Rs = null;
          int credit=0;
          try{
            Rs = mysql.Query(conn," select credit " +
                                         " from webapp.table1 "+
                                         " where username='"+username+"'");
            while (Rs.next())
            {  
              credit=Rs.getInt(1);
            }
          }
          catch(SQLException e) {out.println(e);}
          return credit;
     }
     private int selectId(Connection conn,PrintWriter out,SQL mysql,String username)
     {
          int id=0;
          ResultSet Rs = null;
          try{
             Rs = mysql.Query(conn," select id_customer " +
                                         " from webapp.table1 "+
                                         " where username='"+username+"'");
             while (Rs.next())
             {  
               id = Rs.getInt(1);
             }
          }
          catch(SQLException e) {out.println(e);}
          return id;
     }

     private boolean updateTable6(Connection conn,SQL mysql,PrintWriter out,Vector seatVec,String round)
     {
        int count=0;

        for (int i=0;i<seatVec.size();i++)
        {
          int tmp=0;
          try{
              tmp = mysql.UpdateGetCount(conn," update webapp.table6 " +
                                 " set state='order' "+
                                 " where round="+round+
                                 " and seat='"+seatVec.elementAt(i)+"'"+
                                 " and state is null ");
          }
          catch(SQLException e) {out.println(e);}
          if (tmp==1) { 
                        //out.println(seatVec.elementAt(i));
                        count++;
                      }
        }

       //out.println("updated = "+count);
       //out.println("<br>from all seat= "+seatVec.size());
       if (count==seatVec.size()) 
       {
          try{conn.commit();}catch(SQLException e){out.println(e);}
          return true;
       }
       else 
       {
          try{conn.rollback();}catch(SQLException e){out.println(e);}
          return false;
       }
     }

} 
