import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class timelist extends HttpServlet 
{
    public void service(HttpServletRequest _req,HttpServletResponse _res)
        throws IOException, ServletException
    {  
        String name="",CookieName="MovieCookie";
        String id_temp="",day_temp="";
        getCookie MygetCookie;
        PrintWriter out = _res.getWriter();  
        try
        {   
           MygetCookie = new getCookie();
           String id_movie = MygetCookie.getResult(_req,CookieName);
           SQL mysql= new SQL();
           Connection conn =  mysql.Connect("customer","movie");
           ResultSet Rs = mysql.Query(conn," select name from webapp.table4 where id_movie="+id_movie); 
           while ( Rs.next())
           { name=Rs.getString(1);}
           out.println("<script language=JavaScript>");
           out.println("<!--");
           out.println("function setCookie(value) {");
           out.println("exp = new Date();");
           out.println("exp.setTime(exp.getTime()+(24*60*60*1000));");
           String cookie ="document.cookie=\"MovieCookie2=\"+value+\";expires=\"+exp.toGMTString()+\";path=/\";";
           out.println(cookie);
           out.println("}");
           out.println("//-->");
           out.println("</script>");

           out.println("<table align=center cellpadding=8><tr><td bgcolor=FFFFACD><font color=black>Movie's Name :"+name+"</font></td></tr>");
  	   out.println("<tr bordercolor=#FFFFFF><td><table cellspacing=14 align=center>");
  	   out.println("<tr bgcolor=#F0E68C align = center><th><font color=#000000>Screen</font></th><th><font color=#000000>Day</font></th><th><font color=#000000>Time</font></th><th><font color=#000000>Free_Seat</font></th></tr>");
           Rs = mysql.Query(conn," select screen,day,time,round "+ 
                                  " from webapp.table5 "+
 			          " where id_movie="+id_movie +
                                  "      group by screen,day,time,round "+
                                  " order by round");
           while (Rs.next())
           { 
               String id_screen = Rs.getString(1);
               String day = Rs.getString(2);
               String time = Rs.getString(3);
               String round = Rs.getString(4);
               String CookieValue = id_screen+','+day+','+time+','+round;
 	                out.println("<tr align=center>");
                        if (id_screen.equals(id_temp))
                           out.println("<td></td>");
                        else   { 
                                 out.println("<td>"+id_screen+"</td>");
 				 id_temp = id_screen;
 			       }
                        if (day.equals(day_temp))
                           out.println("<td></td>");
                        else   { 
                                 out.println("<td>"+day+"</td>");
 				 day_temp = day;
 			       }
out.println("<td><a href=page12.jhtml onClick=\"setCookie('"+CookieValue+"');\">");
                        out.println(time+"</a></td>");

                ResultSet myRs=mysql.Query(conn,"select count(*) from webapp.table6 "+
                                       " where round="+round+" "+
                                       " and state='order'");          
                int numofOrder =0;
                while (myRs.next())
                {
                    numofOrder= myRs.getInt(1);
                }
                ResultSet myRs1=mysql.Query(conn,"select amount from webapp.table7 "+
                                       " where id_screen="+id_screen+" ");
                int numofSeat =0;
                while (myRs1.next())
                {
                    numofSeat= myRs1.getInt(1);
                }
                out.println("<td>"+(numofSeat-numofOrder)+"</td></tr>"); 
           }
           out.println("</table></td></tr></table><br>");
        }
        catch(SQLException e )
        { 
           out.println("Error:" + "<br>");
           out.println(e); 
        }   
     }
} 
