import java.awt.*;
import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class InsertTab1Mac extends HttpServlet 
{

      SQL mysql; 
      PrintWriter out;
      Connection conn;
    public void service(HttpServletRequest request,HttpServletResponse response)
        throws IOException, ServletException
    {  
        response.setContentType("text/html");
        out  = response.getWriter();
        genRandom myGen= new genRandom();
        dateTime myConvert = new dateTime();
        java.util.Date mydate = new java.util.Date();
        findNEXTVAL myFindNext = new findNEXTVAL();
        try
        {   
           mysql= new SQL();
           response.setContentType ("text/html");
           String name=request.getParameter("name");
           String surname=request.getParameter("surname");
           String email=request.getParameter("email");
           String phone=request.getParameter("phone");
           String username=myGen.gen();
           String password=myGen.gen();
           String credit=request.getParameter("credit");
           String date = myConvert.convertDate(mydate.toString());
           conn =  mysql.Connect("webapp","web");

         //out.println(name+"<br>"+surname+"<br>"+username+"<br>"+password+
         //          "<br>"+email+"<br>"+phone+"<br>"+credit+"<br>"+date);

           mysql.Update(conn,"insert into table1 values("+myFindNext.getNEXT("table1","id_customer")+
                        ",'"+username+"','"+name+"','"+surname+"','"+
                        password+"',"+credit+",'"+email+"','"+phone+"','"+
                       date+"')" );
         out.println("update Complete");
        }
        catch(SQLException e )
        {
           out.println("Error:" + "<br>");
           out.println(e);
        }  
    }
}
