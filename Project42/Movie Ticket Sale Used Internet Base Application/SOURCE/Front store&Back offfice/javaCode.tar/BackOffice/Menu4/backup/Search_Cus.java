import java.awt.*;
import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class Search_Cus extends HttpServlet 
{

        PrintWriter out;
    public void service(HttpServletRequest request,HttpServletResponse response)
        throws IOException, ServletException
    {  
        response.setContentType("text/html");
        out  = response.getWriter();
        String name = request.getParameter("name");
        String nameUp = name.toUpperCase();
        String surname = request.getParameter("surname");
        String surnameUp = surname.toUpperCase();
        boolean findIt =false;
               out.println("<center><table border=2>");
               out.println("<tr>");
               out.println("<th>ID_CUSTOMER</th>");
               out.println("<th>NAME</th>");
               out.println("<th>SURNAME</th>");
               out.println("<th>CREDIT</th>");
               out.println("</tr>");
         out.println("<form method=post action=\"http://www.benz/JSSI/UpdateTab1\">");

        try
        {   
           SQL mysql= new SQL();
           Connection conn =  mysql.Connect("webapp","web");
           ResultSet Rs = mysql.Query(conn,"select id_customer,name,surname,credit from table1 order by id_customer ");

           while (Rs.next())
           {
             if ((name!=null)&&(surname.equals("-")))
             {  
               String nameCus = Rs.getString(2);
               String nameCusUp = nameCus.toUpperCase();
              if (nameCusUp.equals(nameUp))
              {
                 int id_customer = Rs.getInt(1);
                 String surnameCus = Rs.getString(3);
                 String credit = Rs.getString(4);
                 showOutput(id_customer,nameCus,surnameCus,credit);
                 findIt = true;
              }
             }
             else if ((name.equals("-"))&&(surname!=null)) 
             {  
               String surnameCus = Rs.getString(3);
               String surnameCusUp = surnameCus.toUpperCase();
              if (surnameCusUp.equals(surnameUp))
              {
                 int id_customer = Rs.getInt(1);
                 String nameCus = Rs.getString(2);
                 String credit = Rs.getString(4);
                 showOutput(id_customer,nameCus,surnameCus,credit);
                 findIt = true;
              }
             }
             else if ((name!=null)&&(surname!=null)) 
             {  
               String nameCus = Rs.getString(2);
               String nameCusUp = nameCus.toUpperCase();
               String surnameCus = Rs.getString(3);
               String surnameCusUp = surnameCus.toUpperCase();
              if ((nameCusUp.equals(nameUp))&&(surnameCusUp.equals(surnameUp)))
              {
                 int id_customer = Rs.getInt(1);
                 String credit = Rs.getString(4);
                 showOutput(id_customer,nameCus,surnameCus,credit);
                 findIt = true;
              }
             }

           }
            if (!findIt)
            {
           out.println("</table><br><center>------Data NotFound-----</center>");
            }
            else 
            {
               out.println("</table><table>");
               out.println("<tr><td><input type=submit value=Update></td>");
               out.println("<td><input type=reset value=Undo></td></tr>");
               out.println("</table>");
            }
           out.println("</form></center>");
        }
        catch(SQLException e )
        { 
           out.println("Error:"+e);
        }
   }
   public void showOutput(int id_customer,String name,String surname,String credit)
   {
               out.println("<tr><td>"+id_customer+"</td>");
               out.println("<td><input type=text name=name"+id_customer+" value="+name+"></td>");
               out.println("<td><input type=text name=surname"+id_customer+" value="+surname+"></td>");
               out.println("<td><input type=text name=credit"+id_customer+" value="+credit+"></td>");
   }
}
