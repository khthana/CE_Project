import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class UpdateTab1 extends HttpServlet 
{
    Connection conn;
    SQL mysql; 
    PrintWriter out;
    int id_customer;
    String creditNew,credit,name,surname,nameNew,surnameNew;
 
    public void service(HttpServletRequest _req,HttpServletResponse _res)
        throws IOException, ServletException
    {  
     out = _res.getWriter();  
     mysql= new SQL();
     _res.setContentType ("text/html");
     try
     {   
           conn =  mysql.Connect("webapp","web");
           ResultSet Rs = mysql.Query(conn,"select id_customer,name,surname,credit from table1");
           while (Rs.next())
           {
             id_customer=Rs.getInt(1);
             name=Rs.getString(2); 
             nameNew=_req.getParameter("name"+id_customer);
             if ((!name.equals(nameNew))&&(nameNew!=null))
                update(id_customer,"name",nameNew,name);
             surname=Rs.getString(3); 
             surnameNew=_req.getParameter("surname"+id_customer);
             if ((!surname.equals(surnameNew))&&(surnameNew!=null))
                update(id_customer,"surname",surnameNew,surname);
             credit=Rs.getString(4); 
             creditNew=_req.getParameter("credit"+id_customer);
             if ((!credit.equals(creditNew))&&(creditNew!=null))
                update(id_customer,"credit",creditNew,credit);
           }

         out.println("update Complete");
     }
     catch(SQLException e )
     { 
        out.println("Error:" + "<br>");
        out.println(e); 
     }   
  }

 public void update(int id_customer,String colName,String newValue,String oldValue)
 {
    try{
     mysql.Update(conn,"update table1 set "+colName+"='"+newValue+
                "' where id_customer="+id_customer+" and "+colName+"='"+oldValue+"'"); 
    }
    catch(SQLException e )
    { 
        out.println("Error:" + "<br>");
        out.println(e); 
    }   
 }
} 
