import java.awt.*;
import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class InsertTab1Form extends HttpServlet 
{

    public void service(HttpServletRequest request,HttpServletResponse response)
        throws IOException, ServletException
    {  
        response.setContentType("text/html");
        PrintWriter out  = response.getWriter();
        try
        {   
            out.println("<table>");
            out.println("<form  method=post action=\"http://www.benz/JSSI/InsertTab1Mac\">");
            out.println("<tr><td>Your Name : </td><td><input size=20 type=text name=name value=\"\"></td></tr>");
            out.println("<tr><td>Surname  : </td><td><input size=20 type=text name=surname value=\"\"></td></tr>");
            out.println("<tr><td>Email : </td><td><input type=text size=20 name=email value=\"\"></td></tr>");
            out.println("<tr><td>Phone : </td><td><input type=text size=20 name=phone value=\"\"></td></tr>");
            out.println("<tr><td>Credit : </td><td><input type=text size=20 name=credit value=\"\"></td></tr>");
            out.println("</table>");
            out.println("<center><input type=submit value=submit>");
            out.println("<input type=reset value=Undo></center>");
            out.println("</form>");
        }
        catch(Exception e) {}
    }
}
