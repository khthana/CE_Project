import java.lang.*;

public class genRandom
{
  public String gen()
  {
     byte value[] = new byte[8];
     String myString;
     for (int i =0; i<8;i++)  
     {
      value[i] = (byte)(((Math.random()*100)%70)+50);
     }
      myString=new String(value);
      return myString;
  }
}
