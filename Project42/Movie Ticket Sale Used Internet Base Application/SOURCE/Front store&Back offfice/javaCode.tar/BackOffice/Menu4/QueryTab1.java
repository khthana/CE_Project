import java.awt.*;
import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class QueryTab1 extends HttpServlet 
{

    public void service(HttpServletRequest request,HttpServletResponse response)
        throws IOException, ServletException
    {  
        response.setContentType("text/html");
        PrintWriter out  = response.getWriter();
        String name,surname;
        int id_customer=0,credit;
        String id_dba = request.getParameter("id_customer");
        int id_session =0;
        try
        {   
           SQL mysql= new SQL();
           Connection conn =  mysql.Connect("webapp","web");
           id_session=testSession(mysql,conn,id_dba);
           if (id_session!=0)
           {

               out.println("<hr width=100% size=2 align=center >");
               out.println("<center>");
               out.println("<br>--All Customer--");
               out.println("<table border=2>");
               out.println("<tr>");
               out.println("<th>ID_CUSTOMER</th>");
               out.println("<th>NAME</th>");
               out.println("<th>SURNAME</th>");
               out.println("<th>CREDIT</th>");
               out.println("</tr>");
               out.println("<form method=post action=\"http://www.benz/JSSI/UpdateTab1\">");
           ResultSet Rs = mysql.Query(conn,"select id_customer,name,surname,credit from table1 order by id_customer");

           while (Rs.next())
           {
               id_customer = Rs.getInt(1);
               out.println("<tr><td>"+id_customer+"</td>");
               name = Rs.getString(2);
               out.println("<td><input type=text name=\"name"+id_customer+"\" value="+name+"></td>");
               surname = Rs.getString(3);
               out.println("<td><input type=text name=\"surname"+id_customer+"\" value="+surname+"></td>");
               credit = Rs.getInt(4);
               out.println("<td><input type=text name=credit"+id_customer+" value="+credit+"></td></tr>");
           }
           if (id_customer ==0)
           {
             out.println("</table>");
             out.println("<br>-------Data NotFound------<br></center>");
           }
           else  out.println("</table></center>");

            out.println("<table><tr><td><input type=submit value=Update></td>");
            out.println("<td><input type=reset value=Undo></td>");
            out.print("</form>");
             out.println("<form method=post action=\"http://www.benz/JSSI/InsertTab1Form\">");
             out.println("<td><input type=submit value=Insert></center></td></tr>");
             out.println("</form>");
             out.println("</table>");

          out.println("<hr width=100% size=2 align=center >");
          out.println("You can update specified customer by insert Customer's name");
          out.println("if you don't know value put \"-\"");
          out.println("<form method=post action=http://www.benz/JSSI/Search_Cus>");
          out.println("<table><tr><td>Name:<input type=text name=name size=20"+
                      " value=\"\"></td>");
          out.println("<td>SurName:<input type=text name=surname size=20"+
                      " value=\"\"></td>");
          out.println("<td><input type=submit value=\"Search\"></td></tr>");
          out.println("</table></form>");

         }
         else 
         {
             out.println("Please verify user,password");
             out.println("<a href=http://www.benz/BackOffice>Goto Login</a>");
         }
        }
        catch(SQLException e )
        { 
           out.println("Error:"+e);
        }
   }
  private int testSession(SQL mysql,Connection conn,String id_dba)
   {
       int id=0;
     try
     {
       ResultSet Rs = mysql.Query(conn,"select * from "+
                         " session_control where id_customer= "+id_dba);
       while (Rs.next())
       {
          id=Rs.getInt(1);
       }
       return id;
     }
     catch(SQLException e)
     {
       return id=0;
     }
   }

}
