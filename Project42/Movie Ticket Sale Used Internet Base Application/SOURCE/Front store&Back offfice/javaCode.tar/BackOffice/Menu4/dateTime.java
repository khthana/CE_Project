import java.util.*;

public class dateTime
{
   public String convertDate(String dateIn)
   {
      int start=0,end=0;
      Vector data=new Vector();
      boolean over=false;
      while (!over )
      {
         end = dateIn.indexOf(" ",start);   
         if (end == (-1)) 
         {
            data.addElement(dateIn.substring(start,dateIn.length()));
            over = true;
         }
         else
         {
            data.addElement(dateIn.substring(start,end));
            start = ++end;
         }
      }
      String dateOut = (String)data.elementAt(2)+"/"+(String)data.elementAt(1)+"/"+(String)data.elementAt(5);
      return dateOut;
   }
  
   public int convertMonth(String monIn)
   {
        if (monIn.equals("Jan")) return 0;
          else if (monIn.equals("Feb")) return 1;
          else if (monIn.equals("Mar")) return 2;
          else if (monIn.equals("Apr")) return 3;
          else if (monIn.equals("May")) return 4;
          else if (monIn.equals("Jun")) return 5;
          else if (monIn.equals("Jul")) return 6;
          else if (monIn.equals("Aug")) return 7;
          else if (monIn.equals("Sep")) return 8;
          else if (monIn.equals("Oct")) return 9;
          else if (monIn.equals("Nov")) return 10;
          else if (monIn.equals("Dec")) return 11;
       return 100;
   }
   public int compareTo(String dateIn)
   {
       int mushmore=0;
       Date myDate = new Date();
       String sysDate = convertDate(myDate.toString());

       int firstIn=dateIn.indexOf("/",0);
       int SecIn=dateIn.indexOf("/",(firstIn+1));
       int firstSys=sysDate.indexOf("/",0);
       int SecSys=sysDate.indexOf("/",(firstSys+1));
       if (Integer.parseInt(dateIn.substring((SecIn+1),dateIn.length())) < Integer.parseInt(sysDate.substring((SecSys+1),sysDate.length())))
          mushmore = -1;
       else if (Integer.parseInt(dateIn.substring((SecIn+1),dateIn.length())) > Integer.parseInt(sysDate.substring((SecSys+1),sysDate.length())))
            mushmore=1;
       else if (convertMonth(dateIn.substring((firstIn+1),SecIn)) < convertMonth(sysDate.substring((firstSys+1),SecSys)) )
          mushmore = -1;
       else if (convertMonth(dateIn.substring((firstIn+1),SecIn)) > convertMonth(sysDate.substring((firstSys+1),SecSys)) )
          mushmore = 1;
       else if (Integer.parseInt(dateIn.substring(0,firstIn)) < Integer.parseInt(sysDate.substring(0,firstSys)) )
          mushmore = -1;
       else if (Integer.parseInt(dateIn.substring(0,firstIn)) > Integer.parseInt(sysDate.substring(0,firstSys)) )
          mushmore = 1;

       return mushmore;
   }
}
