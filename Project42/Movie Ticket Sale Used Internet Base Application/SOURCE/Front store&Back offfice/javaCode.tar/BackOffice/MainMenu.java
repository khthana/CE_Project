import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class MainMenu extends HttpServlet 
{
    public void service(HttpServletRequest _req,HttpServletResponse _res)
        throws IOException, ServletException
    {  
        PrintWriter out = _res.getWriter();  
        _res.setContentType ("text/html");
        SQL mysql= new SQL();
           Connection conn=null;
           String id_customer=_req.getParameter("id_customer");
           int id=0;
             try
             {   
              conn =  mysql.Connect("webapp","web");
              ResultSet Rs = mysql.Query(conn,"select id_customer from session_control where id_customer="+id_customer);
               while (Rs.next())
               {
                 id = Rs.getInt(1);
               }
             }
             catch(SQLException e )
             { 
              out.println("Error:" + "<br>");
              out.println(e); 
             }
 
             if (id!=0)
             {
               out.println("<table align=center cellpadding=10 >");
               out.println("<tr bgcolor=#00BFBF><td><a href=http://www.benz/BackOffice/Menu1.jhtml?id_customer="+id_customer+"><u><font size= -1> 1. Manage Theater Data Menu</font></u></a></td></tr>");
               out.println("<tr bgcolor=#7FFFD4><td><a href=http://www.benz/BackOffice/Menu2.jhtml?id_customer="+id_customer+"><u><font size= -1> 2. Manage ShowTime Data Menu</font></u></a></td></tr>");
               out.println("<tr bgcolor=#00BFBF><td><a href=http://www.benz/BackOffice/Menu3.jhtml?id_customer="+id_customer+"><u><font size= -1> 3. Manage Movie Data Menu</font></u></a></td></tr>");
               out.println("<tr bgcolor=#7FFFD4><td><a href=http://www.benz/BackOffice/Menu4.jhtml?id_customer="+id_customer+"><u><font size= -1> 4. Manage Customer Data Menu</font></u></a></td></tr>");
               out.println("<tr bgcolor=#00BFBF><td><a href=http://www.benz/BackOffice/logout.jhtml?id_customer="+id_customer+"><u><font size= -1> 5. LOG OUT Menu</font></u></a></td></tr>");
               out.println("</table>");
             }
             else 
             {
                 out.println("Please verify user,password");
                 out.println("<a href=http://www.benz/BackOffice>Goto Login</a>");
             }
     }
} 
