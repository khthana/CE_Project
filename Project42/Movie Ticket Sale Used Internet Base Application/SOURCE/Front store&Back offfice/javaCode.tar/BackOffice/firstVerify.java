import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class firstVerify extends HttpServlet 
{
    public void doPost(HttpServletRequest _req,HttpServletResponse _res)
        throws IOException, ServletException
    {  
        PrintWriter out = _res.getWriter();  
        _res.setContentType ("text/html");
        SQL mysql= new SQL();
        String username=_req.getParameter("username");
        String password=_req.getParameter("password");

        if (username.equals("dba"))
        {
           if (verify.verify(username,password))
           {
             Connection conn=null;
             String id_customer="";
             SQLException myException=null;
             try
             {   
              conn =  mysql.Connect("webapp","web");
              ResultSet Rs = mysql.Query(conn,"select id_customer from table1 where username='dba'");
               while (Rs.next())
               {
                 id_customer = Rs.getString(1);
               }
             }
             catch(SQLException e )
             { 
              out.println("Error:" + "<br>");
              out.println(e); 
             }

             try
             {   
                mysql.Update(conn,"insert into session_control values("+
                                id_customer+")");
                out.println("Welcome to manage Theater Data");
             }
             catch(SQLException e )
             { 
                myException = e;
             }   
             if (myException !=null)
             {
                try
                {
                   _res.sendRedirect("http://www.benz/BackOffice/loginSecound.html?id_customer="+id_customer);
                }
                catch (IOException e)
                {
                   out.println(e);
                } 
                //out.println("You attempt to login more than one place ! ");
                //out.println("<a href=http://www.benz/BackOffice/Menu.jhtml?id_customer="+id_customer+">GoTo MainMenu</a>");
             }
             else 
             {
                out.println("you can pass");
                try
                {
                   _res.sendRedirect("http://www.benz/BackOffice/Menu.jhtml?id_customer="+id_customer);
                }
                catch (IOException e)
                {
                   out.println(e);
                } 
             }
          }
          else { out.println("You don't have permission");}
       }
       else { out.println("You don't have permission");}

     }
} 
