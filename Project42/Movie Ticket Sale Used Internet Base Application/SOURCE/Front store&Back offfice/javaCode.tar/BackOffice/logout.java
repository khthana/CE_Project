import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class logout extends HttpServlet 
{
    public void service(HttpServletRequest _req,HttpServletResponse _res)
        throws IOException, ServletException
    {  
        PrintWriter out = _res.getWriter();  
        _res.setContentType ("text/html");
        SQL mysql= new SQL();
        Connection conn=null;
        String id_customer = _req.getParameter("id_customer");
           try
           {   
              conn =  mysql.Connect("webapp","web");
              mysql.Update(conn,"delete session_control where "+
                                " id_customer="+id_customer);
              out.println("Logout complete,Thank you for use application");
           }
           catch(SQLException e )
           { 
              out.println("Logout not complete!");
           }   
 
     }
} 
