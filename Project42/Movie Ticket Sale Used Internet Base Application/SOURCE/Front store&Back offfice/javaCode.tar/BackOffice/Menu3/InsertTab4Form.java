import java.awt.*;
import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class InsertTab4Form extends HttpServlet 
{

    public void service(HttpServletRequest request,HttpServletResponse response)
        throws IOException, ServletException
    {  
        response.setContentType("text/html");
        PrintWriter out  = response.getWriter();
        try
        {   
            out.println("<table>");
            out.println("<form  method=post action=\"http://www.benz/JSSI/InsertTab4Mac\">");
            out.println("<tr><td>Name of Movie : </td><td><input type=text name=name value=\"movie's name\"></td></tr>");
            out.println("<tr><td>Type of Movie : </td><td><input type=text name=type value=action/comady/romantic></td></tr>");
            out.println("<tr><td>Arrive Date : </td><td><input type=text size=10 name=arrive value=\"DD/MM/YY\"></td></tr>");
            out.println("<tr><td>Leave Date : </td><td><input type=text size=10 name=leave value=\"DD/MM/YY\"></td></tr>");
            out.println("<tr><td>Demo URL : </td><td><input type=text size=25 name=demo value=\"demo/\"></td></tr>");
            out.println("</table>");
            out.println("<center><input type=submit value=submit></center>");
            out.println("</form>");
        }
        catch(Exception e) {}
    }
}
