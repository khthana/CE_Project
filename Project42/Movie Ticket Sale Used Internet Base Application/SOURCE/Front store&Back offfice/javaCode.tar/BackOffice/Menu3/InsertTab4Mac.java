import java.awt.*;
import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class InsertTab4Mac extends HttpServlet 
{

    public void service(HttpServletRequest request,HttpServletResponse response)
        throws IOException, ServletException
    {  
        String name="",type="",arrive,leave,demo;
        int id_movie=0;
        response.setContentType("text/html");
        PrintWriter out  = response.getWriter();
        findNEXTVAL myFindNext = new findNEXTVAL();
        try
        {   
           SQL mysql= new SQL();
           response.setContentType ("text/html");
           name=request.getParameter("name");
           type=request.getParameter("type");
           arrive=request.getParameter("arrive");
           leave=request.getParameter("leave");
           demo=request.getParameter("demo");
           Connection conn =  mysql.Connect("webapp","web");
          if ((name!=null)&&(type!=null)&&(arrive!=null)&&(leave!=null))
          {
           mysql.Update(conn,"insert into table4 values("+myFindNext.getNEXT("table4","id_movie")+
                        ",'"+name+"','"+type+"','"+arrive+"','"+leave+"','"+demo+"')");
          }
           ResultSet Rs=mysql.Query(conn,"select max(id_movie) from table4");
          while(Rs.next())
          {
            id_movie=Rs.getInt(1);
          }
           
        }
        catch(SQLException e )
        {
           out.println("Error:" + "<br>");
           out.println(e);
        }  
        try{
           response.sendRedirect("http://www.benz/JSSI/InsertTab56Form?id_movie="+id_movie+"&name="+name+"&type="+type);
           }
        catch(IOException e )
        {
           out.println("Error:" + "<br>");
           out.println(e);
        }  
    }
}
