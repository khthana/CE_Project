import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class UpdateTab4 extends HttpServlet 
{
    Connection conn;
    SQL mysql; 
    PrintWriter out;
    public void service(HttpServletRequest _req,HttpServletResponse _res)
        throws IOException, ServletException
    {  
     out = _res.getWriter();  
     mysql= new SQL();
     _res.setContentType ("text/html");
     String name,type,arrive,leave,demo;
     String nameNew,typeNew,arriveNew,leaveNew,demoNew;
     int id_movie;
     try
     {   
           conn =  mysql.Connect("webapp","web");
           ResultSet Rs = mysql.Query(conn,"select * from table4");
           while (Rs.next())
           {
             id_movie=Rs.getInt(1);
             name=Rs.getString(2); 
             nameNew=_req.getParameter("name"+id_movie);
             if ((!name.equals(nameNew))&&(nameNew!=null))
                update(id_movie,"name",nameNew,name);

             type=Rs.getString(3);
             typeNew=_req.getParameter("type"+id_movie);
             if ((!type.equals(typeNew))&&(typeNew!=null))
                update(id_movie,"type",typeNew,type);

             arrive=Rs.getString(4);
             arriveNew=_req.getParameter("arrive"+id_movie);
             if ((!arrive.equals(arriveNew))&&(arriveNew!=null))
                update(id_movie,"arrive",arriveNew,arrive);

             leave=Rs.getString(5);
             leaveNew=_req.getParameter("leave"+id_movie);
             if ((!leave.equals(leaveNew))&&(leaveNew!=null))
                update(id_movie,"leave",leaveNew,leave);

             demo=Rs.getString(6);
             demoNew=_req.getParameter("demo"+id_movie);
             if ((!demo.equals(demoNew))&&(demoNew!=null))
                update(id_movie,"URL",demoNew,demo);
           }

         out.println("update Complete");
     }
     catch(SQLException e )
     { 
        out.println("Error:" + "<br>");
        out.println(e); 
     }   
  }

 public void update(int id_movie,String colName,String newValue,String oldValue)
 {
    try{
     mysql.Update(conn,"update table4 set "+colName+"='"+newValue+
                "' where id_movie="+id_movie+" and "+colName+"='"+oldValue+"'"); 
    }
    catch(SQLException e )
    { 
        out.println("Error:" + "<br>");
        out.println(e); 
    }   
 }
} 
