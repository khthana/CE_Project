import java.awt.*;
import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class InsertTab56Mac extends HttpServlet 
{

    Connection conn;
    SQL mysql; 
    PrintWriter out;
    String id_movie;
    public void service(HttpServletRequest request,HttpServletResponse response)
        throws IOException, ServletException
    {  
        response.setContentType("text/html");
        out  = response.getWriter();
        id_movie=request.getParameter("id_movie");
       if (id_movie!=null)
       {
        try
        {   
           mysql= new SQL();
           conn =  mysql.Connect("webapp","web");
           ResultSet Rs;
           Rs = mysql.Query(conn,"select count(*) from table5");
           int amountRound=0;
           while (Rs.next())
           {
             amountRound=Rs.getInt(1);
           }
           for (int i=1;i<=amountRound;i++)
           {
              String id_movieTmp ="";
              Rs=mysql.Query(conn,"select id_movie from table5 where round="+i);
              while (Rs.next())
              {
                 id_movieTmp=Rs.getString(1);    
              }
              if ((id_movieTmp==null)||(id_movieTmp.equals(id_movie)))
              {
                 String round=request.getParameter(Integer.toString(i));
                 if ((round==null)&&(id_movieTmp!=null)&&(id_movieTmp.equals(id_movie)))
                     //out.println("update round="+i);
                          Update5Del6(i); 
                 else if ((round != null)&&(id_movieTmp==null))
                     //out.println("insert round="+round+" id_movie="+id_movie);
                          Insert56(round,id_movie);
              }
           }
           out.println("Update table5,table6 complete");
        }
        catch(SQLException e )
        { 
           out.println("Error:"+e);
        }
      }
   }
   public void Insert56(String round,String id_movie)
   {
      try
      {
         mysql.Update(conn," update table5 set id_movie="+id_movie+ 
                          " where round="+round);
         ResultSet Rs=mysql.Query(conn,"select amount from table5 a,table7 b "+
                          " where a.screen=b.id_screen and round="+round);
         int seatNum=0;
         while(Rs.next())
         {
            seatNum=Rs.getInt(1);  
         }

         int cols=10;
         int rows=seatNum/cols;
         char key=65;

         for (int i=0;i< rows;i++)
         {
           for (int j=0;j< cols;j++)
           {
             mysql.Update(conn,"insert into table6 values("+
                              round+",'"+key+j+"',null)");  
           }
           ++key;
         }
      }
      catch(SQLException e )
      { 
         out.println("Error:"+e);
      }
   }
   public void Update5Del6(int round)
   {
      try
      {
         mysql.Update(conn," update table5 set id_movie=null"+ 
                          " where round="+round);
         mysql.Update(conn," delete table6 "+ 
                          " where round="+round);
      }
      catch(SQLException e )
      { 
         out.println("Error:"+e);
      }
   }
}
