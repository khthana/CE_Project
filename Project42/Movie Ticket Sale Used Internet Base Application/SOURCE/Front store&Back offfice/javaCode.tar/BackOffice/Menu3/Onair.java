import java.awt.*;
import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class Onair extends HttpServlet 
{

    public void service(HttpServletRequest request,HttpServletResponse response)
        throws IOException, ServletException
    {  
        response.setContentType("text/html");
        PrintWriter out  = response.getWriter();
        dateTime mydateTime = new dateTime();
        boolean findIt = false;
               out.println("<center><table border=2>");
               out.println("<tr>");
               out.println("<th>ID_MOVIE</th>");
               out.println("<th>NAME</th>");
               out.println("<th>TYPE</th>");
               out.println("<th>ARRIVE</th>");
               out.println("<th>LEAVE</th>");
               out.println("</tr>");
         out.println("<form method=post action=\"http://www.benz/JSSI/UpdateTab4\">");

        try
        {   
           SQL mysql= new SQL();
           Connection conn =  mysql.Connect("webapp","web");
           ResultSet Rs = mysql.Query(conn,"select * from table4 order by id_movie ");

           while (Rs.next())
           {
              int begin = mydateTime.compareTo(Rs.getString(4));
              int end = mydateTime.compareTo(Rs.getString(5));
              if ((begin<=0) && (end>=0))
              {
                 int id_movie = Rs.getInt(1);
                 String name = Rs.getString(2);
                 String type = Rs.getString(3);
                 String arrive = Rs.getString(4);
                 String leave = Rs.getString(5);
                 
               out.println("<tr><td>"+id_movie+"</td>");
               out.println("<td><input type=text name=name"+id_movie+" value="+name+"></td>");
               out.println("<td><input type=text name=type"+id_movie+" value="+type+"></td>");
               out.println("<td><input type=text name=arrive"+id_movie+" value="+arrive+"></td>");
               out.println("<td><input type=text name=leave"+id_movie+" value="+leave+"></td></tr>");
               findIt=true;
              }
           }
            if (!findIt)
            {
           out.println("</table><br><center>------Data NotFound-----</center>");
            }
            else 
            {
               out.println("</table><table>");
               out.println("<tr><td><input type=submit value=Update></td>");
               out.println("<td><input type=reset value=Undo></td></tr>");
               out.println("</table>");
            }
           out.println("</form></center>");
        }
        catch(SQLException e )
        { 
           out.println("Error:"+e);
        }
   }
}
