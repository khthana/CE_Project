import java.awt.*;
import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class InsertTab6Form extends HttpServlet 
{

    public void service(HttpServletRequest request,HttpServletResponse response)
        throws IOException, ServletException
    {  
        response.setContentType("text/html");
        PrintWriter out  = response.getWriter();
        String name=request.getParameter("name");
        String type=request.getParameter("type");
        int round;
        int id_movie=Integer.parseInt(request.getParameter("id_movie"));
        String screen,day,time; 
        try
        {   
           SQL mysql= new SQL();
           Connection conn =  mysql.Connect("webapp","web");
           ResultSet Rs;
           out.println("Movie Name:  "+name+" ( "+type+" )");
           out.println("<hr width=80% align=center>");
           out.println("<form method=post action=\"http://www.benz/JSSI/InsertTab56Mac\">");
           out.println("<table cellpadding=10>");
           out.println("<tr>");
           out.println("<th>Screen</th>");
           out.println("<th>Day</th>");
           out.println("<th>Time</th>");
           out.println("</tr>");
           Rs = mysql.Query(conn,"select round,a.screen,b.type,day,time from table5 a , table7 b where a.screen = b.id_screen order by round");
           String screenTmp="",timeTmp="",dayTmp="";
           while (Rs.next())
           {
               round = Rs.getInt(1);
               screen = Integer.toString(Rs.getInt(2))+"("+Rs.getString(3)+")";
              if (!screenTmp.equals(screen)) 
              {
               out.println("<tr align=center><td>"+screen+"</td>"); 
               screenTmp = screen;
              }
              else
              { 
                   out.println("<tr align=center><td>    </td>");
              }

               day = Rs.getString(4);
              if (!dayTmp.equals(day)) 
              {
               out.println("<td>"+day+"</td>"); 
               dayTmp = day;
              }
              else
                {
                   out.println("<td>    </td>");
                }

               time = Rs.getString(5);
               out.println("<td>"+time+"</td>"); 

          out.println("<td align=right><input type=checkbox name="+round+" value="+round+">Show</td></tr>");
           }
           out.println("</table>");
           out.println("<input type=hidden name=id_movie value="+id_movie+">");
           out.println("<center><input type=submit value=Submit>");
           out.println("<input type=reset value=Clear></center>");
           out.print("</form>");
        }
        catch(SQLException e )
        { 
           out.println("Error:"+e);
        }

   }
}
