import java.awt.*;
import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class InsertTab56Form extends HttpServlet 
{

    public void service(HttpServletRequest request,HttpServletResponse response)
        throws IOException, ServletException
    {  
        response.setContentType("text/html");
        PrintWriter out  = response.getWriter();
        String name=request.getParameter("name");
        String type=request.getParameter("type");
        int round;
        String id_movie=request.getParameter("id_movie");
        String screen,day,time; 
        try
        {   
           SQL mysql= new SQL();
           Connection conn =  mysql.Connect("webapp","web");
           ResultSet Rs;
           if ((name==null)&&(type==null))
           {
              Rs=mysql.Query(conn,"select name,type from table4 where "+
                              " id_movie=" + id_movie);
              while(Rs.next())
              {
                 name = Rs.getString(1); 
                 type = Rs.getString(2); 
              }
           }
           out.println("Movie Name:  "+name+" ( "+type+" )");
           out.println("<hr width=80% align=center>");
           out.println("<form method=post action=\"http://www.benz/JSSI/InsertTab56Mac\">");
           out.println("<table border=2 cellpadding=10>");
           out.println("<tr>");
           out.println("<th>Screen</th>");
           out.println("<th>Day</th>");
           out.println("<th>Time</th>");
           out.println("<th>MovieName</th>");
           out.println("</tr>");
           Rs = mysql.Query(conn,"select round,a.screen,b.type,day,time,state,id_movie from table5 a , table7 b where a.screen = b.id_screen order by round");
           String screenTmp="",timeTmp="",dayTmp="";
           while (Rs.next())
           {
               round = Rs.getInt(1);
               screen = Integer.toString(Rs.getInt(2))+"("+Rs.getString(3)+")";
              if (!screenTmp.equals(screen)) 
              {
               out.println("<tr align=center><td>"+screen+"</td>"); 
               screenTmp = screen;
              }
              else
              { 
                   out.println("<tr align=center><td>    </td>");
              }

               day = Rs.getString(4);
              if (!dayTmp.equals(day)) 
              {
               out.println("<td>"+day+"</td>"); 
               dayTmp = day;
              }
              else
                {
                   out.println("<td>    </td>");
                }

               time = Rs.getString(5);
               out.println("<td>"+time+"</td>"); 

               String stateTmp = Rs.getString(6);
               if ( stateTmp.equals("open"))
              {
                 String id_movieTmp=Rs.getString(7);
                 if (id_movieTmp != null)
                 {
                    ResultSet Rs2 = mysql.Query(conn,"select name from table4 "+
                                       " where id_movie="+id_movieTmp);
                    String nameTmp="";
                    while (Rs2.next())
                       { nameTmp = Rs2.getString(1); }
                    if (!id_movieTmp.equals(id_movie))
                       out.println("<td align=center>"+nameTmp+"</td></tr>");
                    else 
                       out.println("<td align=center><input type=checkbox name="+round+" value="+round+" checked>"+nameTmp+"</td></tr>");
                 }
                 else 
                   out.println("<td align=center><input type=checkbox name="+round+" value="+round+" >ShowTime</td></tr>");
              }
              else out.println("<td align=center>Not Used</td></tr>");
           }
           out.println("</table>");
           out.println("<input type=hidden name=id_movie value="+id_movie+">");
           out.println("<center><input type=submit value=Submit>");
           out.println("<input type=reset value=Clear></center>");
           out.print("</form>");
        }
        catch(SQLException e )
        { 
           out.println("Error:"+e);
        }

   }
}
