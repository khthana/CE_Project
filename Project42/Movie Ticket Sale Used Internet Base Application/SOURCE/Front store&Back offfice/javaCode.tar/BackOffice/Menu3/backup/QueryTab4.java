import java.awt.*;
import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class QueryTab4 extends HttpServlet 
{

    public void service(HttpServletRequest request,HttpServletResponse response)
        throws IOException, ServletException
    {  
        response.setContentType("text/html");
        PrintWriter out  = response.getWriter();
           Vector data = new Vector();
           int id_movie=0,index=0;
           String type,arrive,leave,name;
        try
        {   
           SQL mysql= new SQL();
           Connection conn =  mysql.Connect("webapp","web");
               out.println("<center><table border=2>");
               out.println("<tr>");
               out.println("<th>ID_MOVIE</th>");
               out.println("<th>NAME</th>");
               out.println("<th>TYPE</th>");
               out.println("<th>ARRIVE</th>");
               out.println("<th>LEAVE</th>");
               out.println("</tr>");
               out.println("<form method=post action=\"http://www.benz/JSSI/UpdateTab4\">");
           ResultSet Rs = mysql.Query(conn,"select * from table4 order by id_movie ");

           while (Rs.next())
           {
               id_movie = Rs.getInt(1);
               out.println("<tr><td>"+id_movie+"</td>");
               name = Rs.getString(2);
               out.println("<td><input type=text name=name"+id_movie+" value="+name+"></td>");
               type = Rs.getString(3);
               out.println("<td><input type=text name=type"+id_movie+" value="+type+"></td>");
               arrive = Rs.getString(4);
               out.println("<td><input type=text name=arrive"+id_movie+" value="+arrive+"></td>");
               leave = Rs.getString(5);
               out.println("<td><input type=text name=leave"+id_movie+" value="+leave+"></td>");
           }
        }
        catch(SQLException e )
        { 
           out.println("Error:"+e);
        }
           if (id_movie==0)
           {
              out.println("</table>");
              out.println("<br>----------Data NotFound----------<br></center>");
           }
           else out.println("</table></center>");

            out.println("<table><tr><td><input type=submit value=Update></td>");
            out.println("<td><input type=reset value=Undo></td>");
             out.print("</form>");
             out.println("<form method=post action=\"http://www.benz/JSSI/InsertTab4Form\">");
             out.println("<td><input type=submit value=Insert></center></td></tr>");
             out.println("</table>");
             out.println("</form>");
             out.println("<hr align=center width=100%>");
            out.println("You can update ShowTime of movie by insert ID_MOVIE"); 
            out.println("<form method=post action=\"http://www.benz/JSSI/InsertTab56Form\"");
            out.println("<table><tr><td><input type=text name=id_movie size=7 value=\"\"></td>"); 
            out.println("<td><input type=submit value=\"insert ShowTime\"></td></tr>");
            out.println("</table></form>");
   }
}
