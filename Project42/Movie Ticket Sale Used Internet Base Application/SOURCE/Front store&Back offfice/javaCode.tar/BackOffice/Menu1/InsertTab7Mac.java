import java.awt.*;
import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class InsertTab7Mac extends HttpServlet 
{

    public void service(HttpServletRequest request,HttpServletResponse response)
        throws IOException, ServletException
    {  
        String type,state;
        int seatNum,showNum;
        response.setContentType("text/html");
        PrintWriter out  = response.getWriter();
        findNEXTVAL myFindNext = new findNEXTVAL();
        try
        {   
           SQL mysql= new SQL();
           response.setContentType ("text/html");
           seatNum=Integer.parseInt(request.getParameter("seatNum"));
           showNum=Integer.parseInt(request.getParameter("showNum"));
           type=request.getParameter("type");
           state=request.getParameter("state");
           Connection conn =  mysql.Connect("webapp","web");

           mysql.Update(conn,"insert into table7 values("+myFindNext.getNEXT("table7","id_screen")+
                        ","+seatNum+",'"+type+"','"+state+"')");
           for (int i =0;i<3;i++)
             for(int j=0;j<showNum;j++)
             {
           //ResultSet rs=mysql.Query(conn,"select * from table5 for update"); 
              mysql.Update(conn,"insert into table5 values("+myFindNext.getNEXT("table5","round")+
                        ","+myFindNext.getCURRT("table7","id_screen")+",'DD/MM/YY"+i+"','HH:mm"+j+"',null)");
              conn.commit();
             }
           out.println("Insert Complete");
           conn.close();
        }
        catch(SQLException e )
        {
           out.println("Error:" + "<br>");
           out.println(e);
        }  

    }
}
