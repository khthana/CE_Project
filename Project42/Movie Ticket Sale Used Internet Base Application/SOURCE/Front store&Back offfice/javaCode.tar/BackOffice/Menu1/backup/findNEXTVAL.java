import java.sql.*;
import java.util.*;
import java.lang.*;

public class findNEXTVAL
{
   Connection conn;
   SQL mysql;

   public int getNEXT(String table,String col)
   {
      String idReturn="";
      int id=0;
      try
      {
        mysql = new SQL();
        conn = mysql.Connect("webapp","web"); 
        ResultSet myRs= mysql.Query(conn,"select max("+col+
                      ") from "+table);
        while(myRs.next())
        {
          idReturn = myRs.getString(1);
        }
        if (idReturn==null) id=1 ;
        else
        {
          id = Integer.parseInt(idReturn);
          ++id;
        }
        conn.close();
      }
      catch(SQLException e ){}
      return id;
   }
   public int getCURRT(String table,String col)
   {
      String idReturn="";
      int id=0;
      try
      {
        mysql = new SQL();
        conn = mysql.Connect("webapp","web"); 
        ResultSet myRs= mysql.Query(conn,"select max("+col+
                      ") from "+table);
        while(myRs.next())
        {
          idReturn = myRs.getString(1);
        }
        if (idReturn!=null) 
        {
          id = Integer.parseInt(idReturn);
        }
        conn.close();
      }
      catch(SQLException e ){}
      return id;
   }
} 
