import java.awt.*;
import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class QueryTab7 extends HttpServlet 
{

    public void service(HttpServletRequest request,HttpServletResponse response)
        throws IOException, ServletException
    {  
        response.setContentType("text/html");
        PrintWriter out  = response.getWriter();
        try
        {   
           Vector data = new Vector();
           SQL mysql= new SQL();
           Connection conn =  mysql.Connect("webapp","web");
           ResultSet Rs = mysql.Query(conn,"select * from table7 order by "+
                                   " id_screen");
           int id_screen=0,seatNum=0;
           String type,state;
               out.println("<center><table border=2>");
               out.println("<tr>");
               out.println("<th>ID_SCREEN</th>");
               out.println("<th>SEAT</th>");
               out.println("<th>TYPE</th>");
               out.println("<th>STATE</th>");
               out.println("</tr>");
               out.println("<form method=post action=\"http://www.benz/JSSI/UpdateTab7\">");
           while (Rs.next())
           {
               id_screen = Rs.getInt(1);
               out.println("<tr><td>"+id_screen+"</td>");
               seatNum = Rs.getInt(2);
               out.println("<td>"+seatNum+"</td>");
               type = Rs.getString(3);
               out.println("<td>"+type+"</td>");
               state = Rs.getString(4);
               if (state.equals("open"))
               {
                  out.println("<td><input type=radio name=state"+id_screen+" value=open checked>open");
                  out.println("<input type=radio name=state"+id_screen+" value=close>close</td></tr>");
               }
               else 
               {
                  out.println("<td><input type=radio name=state"+id_screen+" value=open>open");
                  out.println("<input type=radio name=state"+id_screen+" value=close checked>close</td></tr>");
               }
           }

           if (id_screen ==0)
           {
             out.println("</table>");
             out.println("<br>-------Data NotFound------<br></center>");
           }
           else  out.println("</table></center>");
        }
        catch(SQLException e )
        { 
           out.println("Error:"+e);
        }

            out.println("<table><tr><td><input type=submit value=Update></td>");
            out.println("<td><input type=reset value=Undo></td>");
            out.print("</form>");
             out.println("<form method=post action=\"http://www.benz/JSSI/InsertTab7Form\">");
             out.println("<td><input type=submit value=Insert></center></td></tr>");
             out.println("</table>");
             out.println("</form>");
   }
}
