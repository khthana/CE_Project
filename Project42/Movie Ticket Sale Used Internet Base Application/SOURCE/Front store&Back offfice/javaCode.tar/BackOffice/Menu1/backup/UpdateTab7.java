import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class UpdateTab7 extends HttpServlet 
{
        String type,state,typeNew,stateNew,seatNum,seatNumNew;
        int id_screen;
        PrintWriter  out;
        SQL mysql;
        Connection conn;
    public void service(HttpServletRequest _req,HttpServletResponse _res)
        throws IOException, ServletException
    {  
        out = _res.getWriter();  
        try
        {   
           _res.setContentType ("text/html");
           mysql= new SQL();
           conn =  mysql.Connect("webapp","web");
          ResultSet Rs = mysql.Query(conn,"select id_screen,state from table7");
           while (Rs.next())
           {
               id_screen=Rs.getInt(1);

               state = Rs.getString(2);
               stateNew=_req.getParameter("state"+id_screen);
               if (!state.equals(stateNew))
               {
                  update(id_screen,"state",stateNew,state);
                  if ((state.equals("open"))&&(stateNew.equals("close")))
                  {
                      DelTab6(id_screen);
                      updateTab5(id_screen);
                  }
               }
           }
        }
        catch(SQLException e )
        { 
           out.println("Error:" + "<br>");
           out.println(e); 
        }   
           out.println("update Complete");
    }
    public void update(int id_screen,String colName,String newValue,String oldValue)
    {
        try
        {
         mysql.Update(conn,"update table7 set "+colName+"='"+newValue+
                    "' where id_screen="+id_screen+" and "+colName+"='"+oldValue+"'"); 
        }
        catch(SQLException e )
        { 
            out.println("Error:" + "<br>");
            out.println(e); 
        }   
    }
    public void updateTab5(int id_screen)
    {
        try
        {
           mysql.Update(conn,"update table5 set id_movie=null "+
                    " where screen="+id_screen); 
        }
        catch(SQLException e )
        { 
            out.println("Error:" + "<br>");
            out.println(e); 
        }   
    }
    public void DelTab6(int id_screen)
    {
        try
        {
           ResultSet myRs = mysql.Query(conn,"select round from table5"+
                            "  where screen = "+id_screen); 
           while (myRs.next())
           {
               int round = myRs.getInt(1);
               mysql.Update(conn,"delete table6 "+
                    " where round="+round); 
           }
        }
        catch(SQLException e )
        { 
            out.println("Error:" + "<br>");
            out.println(e); 
        }   
    }
} 
