import java.awt.*;
import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class QueryTab7 extends HttpServlet 
{

    public void service(HttpServletRequest request,HttpServletResponse response)
        throws IOException, ServletException
    {  
        response.setContentType("text/html");
        PrintWriter out  = response.getWriter();
        Connection conn=null;
        SQL mysql=null;
        String id_customer = request.getParameter("id_customer");
       try
       {
          mysql= new SQL();
          conn = mysql.Connect("webapp","web"); 
          ResultSet testSession = mysql.Query(conn,"select * from session_control where id_customer= "+id_customer); 
          int id=0;
          while (testSession.next())
          {
             id = testSession.getInt(1);
          }
          if (id!=0) 
          {
             try
             {   
                Vector data = new Vector();
                ResultSet Rs = mysql.Query(conn,"select * from table7 order by "+
                                        " id_screen");
                int id_screen=0,seatNum=0;
                String type,state;
                    out.println("<center><table border=2>");
                    out.println("<tr>");
                    out.println("<th>ID_SCREEN</th>");
                    out.println("<th>SEAT</th>");
                    out.println("<th>TYPE</th>");
                    out.println("<th>STATE</th>");
                    out.println("</tr>");
                    out.println("<form method=post action=\"http://www.benz/JSSI/UpdateTab7\">");
                while (Rs.next())
                {
                    id_screen = Rs.getInt(1);
                    out.println("<tr><td>"+id_screen+"</td>");
                    seatNum = Rs.getInt(2);
                    out.println("<td>"+seatNum+"</td>");
                    type = Rs.getString(3);
                    out.println("<td>"+type+"</td>");
                    state = Rs.getString(4);
                    if (state.equals("open"))
                    {
                       out.println("<td><input type=radio name=state"+id_screen+" value=open checked>open");
                       out.println("<input type=radio name=state"+id_screen+" value=close>close</td></tr>");
                    }
                    else 
                    {
                       out.println("<td><input type=radio name=state"+id_screen+" value=open>open");
                       out.println("<input type=radio name=state"+id_screen+" value=close checked>close</td></tr>");
                    }
                }

                if (id_screen ==0)
                {
                  out.println("</table>");
                  out.println("<br>-------Data NotFound------<br></center>");
                }
                else  out.println("</table></center>");
        }
        catch(SQLException e )
        { 
           out.println("Error:"+e);
        }

            out.println("<table><tr><td><input type=submit value=Update></td>");
            out.println("<td><input type=reset value=Undo></td>");
            out.print("</form>");
             out.println("<form method=post action=\"http://www.benz/JSSI/InsertTab7Form\">");
             out.println("<td><input type=submit value=Insert></center></td></tr>");
             out.println("</table>");
             out.println("</form>");
         }
         else 
         {
             out.println("Please verify user,password");
             out.println("<a href=http://www.benz/BackOffice>Goto Login</a>");
         }
       }
       catch(SQLException e)
       {
           out.println(e);
       }
   }
}
