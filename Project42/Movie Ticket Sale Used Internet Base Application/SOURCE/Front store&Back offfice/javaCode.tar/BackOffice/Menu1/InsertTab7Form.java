import java.awt.*;
import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class InsertTab7Form extends HttpServlet 
{

    public void service(HttpServletRequest request,HttpServletResponse response)
        throws IOException, ServletException
    {  
        response.setContentType("text/html");
        PrintWriter out  = response.getWriter();
        try
        {   
            out.println("<table>");
            out.println("<form  method=post action=\"http://www.benz/JSSI/InsertTab7Mac\">");
            out.println("<tr><td>Amount of Seat : </td><td><input type=text name=seatNum value=\"integer value\"> seats</td></tr>");
            out.println("<tr><td>Type of Theater : </td><td><input type=text name=type value=THX/SDDS/SRD-S></td></tr>");
            out.println("<tr><td>This Theater has perfomance to show : </td><td><input type=text size=10 name=showNum value=\"int value\">Times per a Day</td></tr>");
            out.println("<tr><td>State : <input type=radio name=state value=open checked>open</td>");
            out.println("<td><input type=radio name=state value=close>close</td>");
            out.println("</tr></table>");
            out.println("<center><input type=submit value=submit></center>");
            out.println("</form>");
        }
        catch(Exception e) {}
    }
}
