import java.awt.*;
import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class QueryTab5 extends HttpServlet 
{

    public void service(HttpServletRequest request,HttpServletResponse response)
        throws IOException, ServletException
    {  
        response.setContentType("text/html");
        PrintWriter out  = response.getWriter();
        int round,id_screen,id_screenTmp=0;
        String day,dayTmp="",time,timeTmp="";
        int id_session=0;
        try
        {   
           SQL mysql= new SQL();
           Connection conn =  mysql.Connect("webapp","web");
           ResultSet Rs;
           Rs = mysql.Query(conn,"select * from table5 order by round ");
           out.println("<table>");
           out.println("<form method=post action=\"http://www.benz/JSSI/UpdateTab5\">");
           while (Rs.next())
           {
               round = Rs.getInt(1);
               id_screen = Rs.getInt(2);
              if (id_screenTmp!=id_screen) 
              {
               out.println("<tr><td><hr width=100% align=center></td></tr>");
               out.println("<tr><td>Theater ID: "+id_screen+"</td></tr>"); 
               id_screenTmp = id_screen;
              }
               day = Rs.getString(3);
              if (!dayTmp.equals(day)) 
              {
               out.println("<tr><td>Date : <input type=text name="+id_screen+day+" value="+day+"></td>"); 
               dayTmp = day;
              }
              else
                {
                   out.println("<tr><td></td>");
                }
               time = Rs.getString(4);
              if (!timeTmp.equals(time)) 
              {
               out.println("<td>Time : <input type=text name="+id_screen+day+time+" value="+time+"></td></tr>"); 
               timeTmp = time;
              }
           }
           out.println("</table>");
           out.println("<center><input type=submit value=Update>");
           out.println("<input type=reset value=Undo></center>");
           out.print("</form>");
        }
        catch(SQLException e )
        { 
           out.println("Error:"+e);
        }

   }
}
