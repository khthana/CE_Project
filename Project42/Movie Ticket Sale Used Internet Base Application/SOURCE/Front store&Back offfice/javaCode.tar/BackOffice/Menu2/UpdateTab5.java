import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;
 
public class UpdateTab5 extends HttpServlet 
{
    int round;
    public void service(HttpServletRequest _req,HttpServletResponse _res)
        throws IOException, ServletException
    {  
     Vector screenVec = new Vector();
     PrintWriter out = _res.getWriter();  
     SQL mysql= new SQL();
     _res.setContentType ("text/html");
     try
     {   
           Connection conn =  mysql.Connect("webapp","web");
           ResultSet Rs = mysql.Query(conn,"select distinct(screen) from table5");
           while (Rs.next())
           {
              int tmp=Rs.getInt(1);
              screenVec.addElement(Integer.toString(tmp));
           }

       for (int i=0;i<screenVec.size();i++)
       {
          String dayOld="",timeOld="",day,screenTemp,time;
          Rs = mysql.Query(conn,"select min(screen),min(day),"+
                      " min(time) from table5 "+
                      " where screen="+screenVec.elementAt(i)+
                      " group by day,time ");
          while (Rs.next())
          {
            screenTemp=Integer.toString(Rs.getInt(1));
            dayOld=Rs.getString(2);
            timeOld=Rs.getString(3);
            String key = screenTemp+dayOld+timeOld;
            time = (_req.getParameter(key)); 
            if (!time.equals(timeOld)) 
            {
              mysql.Update(conn,"update table5 set time='"+time+"' where"+
                   " time='"+timeOld+"' and day='"+
                   dayOld+"' and screen="+screenTemp); 
            }
          }
         Rs = mysql.Query(conn,"select min(screen),min(day) from table5 "+
                      " where screen="+screenVec.elementAt(i)+
                      " group by day ");
         while (Rs.next())
         {
             screenTemp=Integer.toString(Rs.getInt(1));
             dayOld=Rs.getString(2);
             String key = screenTemp+dayOld;
             day = (_req.getParameter(key)); 
            if (!day.equals(dayOld)) 
            {
              mysql.Update(conn,"update table5 set day='"+day+"' where"+
                           " day='"+dayOld+"' and screen="+screenTemp); 
            }
         }
       }
         out.println("update Complete");
     }
     catch(SQLException e )
     { 
        out.println("Error:" + "<br>");
        out.println(e); 
     }   
  }
} 
