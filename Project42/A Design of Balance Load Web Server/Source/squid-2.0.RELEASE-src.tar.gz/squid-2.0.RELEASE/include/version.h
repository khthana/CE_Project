/*
 * $Id: version.h,v 1.119.2.1 1998/10/02 07:03:06 wessels Exp $
 *
 *  SQUID_VERSION - String for version id of this distribution
 */
#ifndef SQUID_VERSION
#define SQUID_VERSION	"2.0.RELEASE"
#endif

#ifndef SQUID_RELEASE_TIME
#define SQUID_RELEASE_TIME 907312161
#endif
