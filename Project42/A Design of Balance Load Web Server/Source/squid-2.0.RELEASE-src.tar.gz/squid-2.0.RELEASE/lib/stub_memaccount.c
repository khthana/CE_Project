/*
 * $Id: stub_memaccount.c,v 1.3 1998/09/23 17:16:13 wessels Exp $
 */

/* Stub function for programs not implementing statMemoryAccounted */
#include <config.h>
int 
statMemoryAccounted(void)
{
    return -1;
}
