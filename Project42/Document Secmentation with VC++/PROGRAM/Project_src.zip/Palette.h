// file Palette.h

#ifndef PALETTEH
#define PALETTEH

#include "stdafx.h"
#pragma hdrstop

/***************************************************************************/
/*                                                                         */
/* Palette Class: maintains the various identity palettes                  */
/*                                                                         */
/***************************************************************************/

class Palette {

 /***************************************************************************/
 /*                                                                         */
 /* Data Members                                                            */
 /*                                                                         */
 /***************************************************************************/

public:

CPalette    *ptrmainpal;              // main map color palette

protected:

// the master set of all palettes
static RGBQUAD     pal[256];
static LOGPALETTE *ptrlogpal;            // common work area

// identity palette members
RGBQUAD      maincoltbl [256];        // main map color table for BITMAPINFO

 /***************************************************************************/
 /*                                                                         */
 /* Functions:                                                              */
 /*                                                                         */
 /***************************************************************************/

public:
	BOOL SetPalette(BYTE *ptrdib);
	BOOL InitPalette();

             Palette ();               // makes a copy identity palette
            ~Palette ();                    // deletes the copy palette

//static BOOL  InitPalette (const char*);     // load or build initial pals
static void  DeletePalette ();              // remove common palette area
static void  ClearSystemPalette ();         // clear Palette Manager'sPal
static void  ClearSystemPalette (HDC&);
static void  ClearSystemPalette (CDC&);

CPalette*    GetPalette ();                 // member CPalette-not a copy
void         FillRgbColorTable (RGBQUAD*);  // copies RGBcolortbl for DIB
};
#endif
