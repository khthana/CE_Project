// file BitmapDC.CPP

#include "stdafx.h"
#pragma hdrstop

#include "BitmapDC.h"

/***************************************************************************/
/*                                                                         */
/* BitmapDC: constructor initializes class to NULL - must use Create to use*/
/*                                                                         */
/***************************************************************************/

BitmapDC::BitmapDC () {

// ptrpalette = NULL;
 hbmpdc     = 0;
 hbmp       = 0;
 height     = 0;
 width      = 0;
 isvalid    = FALSE;
}

BitmapDC::BitmapDC (long w, long h, Palette * ptrPal) {
 hbmpdc     = 0;
 hbmp       = 0;
 height     = h;
 width      = w; 
 isvalid = Create(w, h, ptrPal);
}

BitmapDC::BitmapDC (long w, long h, BYTE *pbit, Palette *ptrPal) {
 hbmpdc     = 0;
 hbmp       = 0;
 height     = h;
 width      = w; 
 isvalid = Create(w, h, ptrPal);
 SetBits(pbit);
}


/***************************************************************************/
/*                                                                         */
/* ~BitmapDC: destructor removes allocated objects                         */
/*                                                                         */
/***************************************************************************/

BitmapDC::~BitmapDC () {
 RemoveBitmap ();
}

/***************************************************************************/
/*                                                                         */
/* RemoveBitmap: removes the bitmap allocated objects                      */
/*                                                                         */
/***************************************************************************/

void BitmapDC::RemoveBitmap () {

 GdiFlush (); // NT synchronization let GDI finish any in progress actions
 if (hbmp) {
  SelectObject (hbmpdc, holdbmp);
  SelectPalette (hbmpdc, (HPALETTE) GetStockObject (DEFAULT_PALETTE), FALSE);
  DeleteObject (hbmp);
 }
 if (hbmpdc) DeleteDC (hbmpdc);

 hbmpdc     = 0;
// ptrpalette = NULL;
 hbmp       = 0;
 height     = 0;
 width      = 0;
}

/***************************************************************************/
/*                                                                         */
/* Create: construct a DIB Section and MemoryDC with a specific palette    */
/*                                                                         */
/***************************************************************************/

BOOL BitmapDC::Create (long w, long h, Palette * ptrPalettes) {

 if (w==0 || h==0) w = h = 1;//return FALSE;

 if (hbmpdc) RemoveBitmap ();

 ptrPalette = ptrPalettes->GetPalette (); // insert the palette to be used
 hbmpdc = ::CreateCompatibleDC (0);       // make a memory DC
 if (hbmpdc) {
  RealizePalette ();  // install identity palette

  widthOrg = w;
  BITMAPINFO* ptrinfo = MakeBITMAPINFO (w, h);  // make the BITMAPINFO header
  if (ptrinfo) {
   width = ptrinfo->bmiHeader.biWidth;
   height = h;
   ptrPalettes->FillRgbColorTable (ptrinfo->bmiColors); // install color table
   hbmp = CreateDIBSection (hbmpdc, ptrinfo, DIB_RGB_COLORS,
                           (void**) &ptrbits, NULL, 0);
   free (ptrinfo);
   // if successful, install DIB Section bitmap into the memory DC
   if (hbmp) {
    holdbmp = (HBITMAP) SelectObject (hbmpdc, hbmp);
    // clear all DIB bits
    memset (ptrbits, 0, width * height);
   }
   else {
    RemoveBitmap ();
    return FALSE;
   }
  }
  else {
   RemoveBitmap ();
   return FALSE;
  }
 }
 else {
  RemoveBitmap ();
  return FALSE;
 }
 return TRUE;
}

/***************************************************************************/
/*                                                                         */
/* MakeBITMAPINFO: constructs a BITMAPINFO structure with DWORD rounded wid*/
/*                                                                         */
/***************************************************************************/

BITMAPINFO* BitmapDC::MakeBITMAPINFO (long w, long h) {

 BITMAPINFO *ptrinfo;
 ptrinfo = (BITMAPINFO*) malloc (sizeof(BITMAPINFO) + 256 * sizeof (RGBQUAD));
 if (ptrinfo) {
  w = w % 4 > 0 ? 4 - w % 4 + w : w; // force width onto 32-bit boundary
  ptrinfo->bmiHeader.biSize = sizeof (BITMAPINFOHEADER);
  ptrinfo->bmiHeader.biWidth = w;
  ptrinfo->bmiHeader.biHeight = -h;
  ptrinfo->bmiHeader.biPlanes = 1;
  ptrinfo->bmiHeader.biBitCount = 8;
  ptrinfo->bmiHeader.biCompression = BI_RGB;
  ptrinfo->bmiHeader.biSizeImage = 0;
  ptrinfo->bmiHeader.biXPelsPerMeter = 0;
  ptrinfo->bmiHeader.biYPelsPerMeter = 0;
  ptrinfo->bmiHeader.biClrUsed = 0;
  ptrinfo->bmiHeader.biClrImportant = 0;
  return ptrinfo;
 }
 else return NULL;
}

/***************************************************************************/
/*                                                                         */
/* RealizePalette: forces Palette Manager to completely reinstall new pal  */
/*                                                                         */
/***************************************************************************/

void BitmapDC::RealizePalette () {

 if (hbmpdc) {
  // force Palette Manager to reset the master color table so the next palette
  // that is realized gets its colors mapped into the order of use in the logpal
  Palette::ClearSystemPalette (hbmpdc);
  ::SelectPalette (hbmpdc, (HPALETTE) ptrPalette->GetSafeHandle (), FALSE);
  ::RealizePalette (hbmpdc);
 }
}

/***************************************************************************/
/*                                                                         */
/* RealizePalette: forces Palette Manager to reinstall new identity palette*/
/*                 on another DC - user must restore the DC's palette      */
/*                                                                         */
/***************************************************************************/

void BitmapDC::RealizePalette (CDC &dc) {

 if (hbmpdc) {
  // force Palette Manager to reset the master color table so the next palette
  // that is realized gets its colors mapped into the order of use in the logpal
  Palette::ClearSystemPalette (dc);
  dc.SelectPalette (ptrPalette, FALSE);
  dc.RealizePalette ();
 }
}

/***************************************************************************/
/*                                                                         */
/* GetBits: returns the address of the bitmap bits in the DIB Section      */
/*                                                                         */
/***************************************************************************/

BYTE* BitmapDC::GetBits () {
 GdiFlush (); // NT synchronization let GDI finish any in progress actions
 if (hbmpdc) return ptrbits;
 else return NULL;
}

/***************************************************************************/
/*                                                                         */
/* Height: returns the actual height of this bitmap                        */
/*                                                                         */
/***************************************************************************/

long      BitmapDC::Height () {

 return height;
}

/***************************************************************************/
/*                                                                         */
/* Width: returns the actual width of this bitmap                          */
/*                                                                         */
/***************************************************************************/

long      BitmapDC::Width () {

 return width;
}

/***************************************************************************/
/*                                                                         */
/* TotalBits: returns the total number of bits in this bitmap              */
/*                                                                         */
/***************************************************************************/

long      BitmapDC::TotalBits () {

 return height * width;
}

/***************************************************************************/
/*                                                                         */
/* GetPixel: returns the bmp pixel color index                             */
/*                                                                         */
/***************************************************************************/

BYTE      BitmapDC::GetPixel (CPoint &p) {

 long r;

 if (p.y >= height || p.y <0) return 0;
 if (p.x >= width  || p.x <0) return 0;

 r  = p.y * width + p.x;
 return (r >= TotalBits ()) ? (BYTE) 0 : *(ptrbits + r);
}

/***************************************************************************/
/*                                                                         */
/* Read: input a bitmap and copy the bits into the DIB Section             */
/*                                                                         */
/***************************************************************************/
// I'm not used :ksemsant
/*
BOOL      BitmapDC::Read (const char *filename, Palette *ptrpalettes) {

 CFile file;
 CFileException file_err; // used if more info on errors is desired
 file.Open (filename, CFile::modeRead, &file_err);

 BITMAPFILEHEADER bmfh;
 UINT             actsz;

 HANDLE hdib = 0;
 // input the BITMAPFILEHEADER structure
 actsz = file.Read ((LPSTR) &bmfh, sizeof (BITMAPFILEHEADER));
 // verify it is a .BMP file
 if (actsz != sizeof (BITMAPFILEHEADER) || bmfh.bfType != * (WORD *) "BM") {
  AfxMessageBox ("Invalid bmp game file", MB_OK);
  file.Close ();
  return FALSE;
 }
 
 // calculate the size of the file less the file header
 // and allocate memory for the dib
 DWORD dwDibSize = bmfh.bfSize - sizeof (BITMAPFILEHEADER);
 hdib = GlobalAlloc (GMEM_MOVEABLE, dwDibSize);
 BYTE *ptrdib = (BYTE*) GlobalLock (hdib);
 if (!ptrdib) {
  AfxMessageBox ("Cannot allocate memory for bmp file", MB_OK);
  file.Close ();
  if (hdib) GlobalFree (hdib);
  return FALSE;
 }
 
 // read in the rest of the DIB - 
 actsz = file.Read ((LPSTR) ptrdib, dwDibSize);
 file.Close ();
 if (actsz != dwDibSize) { // error, wrong number of bytes
  AfxMessageBox ("Invalid bmp game file", MB_OK);
  GlobalUnlock (hdib);
  GlobalFree (hdib);
  return FALSE;
  }
 
 // check the validity of the size of the info header - fail OS2 bitmaps
 if (((BITMAPINFOHEADER*) ptrdib)->biSize <= sizeof(BITMAPCOREHEADER)) {
  AfxMessageBox ("Invalid bmp game file", MB_OK);
  GlobalUnlock (hdib);
  GlobalFree (hdib);
  return FALSE;
 }
 
 WORD bitcount = ((BITMAPINFOHEADER*) ptrdib)->biBitCount;
 DWORD numcolors = ((BITMAPINFOHEADER*) ptrdib)->biClrUsed;
 if (numcolors == 0 && bitcount != 24) numcolors = 1L << bitcount;
 if (numcolors == 0) {
  AfxMessageBox ("Invalid bmp game file", MB_OK);
  GlobalUnlock (hdib);
  GlobalFree (hdib);
  return FALSE;
 }

 width = ((BITMAPINFOHEADER*) ptrdib)->biWidth;
 height = ((BITMAPINFOHEADER*) ptrdib)->biHeight;

 if (!Create (width, height, ptrpalettes)) {
  GlobalUnlock (hdib);
  GlobalFree (hdib);
  return FALSE;
 }

 BYTE *ptrsrc = ptrdib + ((BITMAPINFOHEADER*) ptrdib)->biSize + numcolors * sizeof (RGBQUAD);
 BYTE *ptrdes = GetBits ();
 long i = 0;
 ptrsrc += (height -1) * width;
 while (i < height) {
  memcpy (ptrdes, ptrsrc, width);
  ptrsrc -= width;
  ptrdes += width;
  i++;
 }
 GlobalUnlock (hdib);
 GlobalFree (hdib);
 return TRUE;
 }
*/

BOOL BitmapDC::Read(CFile *ptrfile, Palette *ptrpalettes)
{

 // CFile file;
 CFileException file_err; // used if more info on errors is desired
 //file.Open (filename, CFile::modeRead, &file_err);
 //file = ptrfile;
 BITMAPFILEHEADER bmfh;
 UINT             actsz;

 HANDLE hdib = 0;
 // input the BITMAPFILEHEADER structure
 actsz = ptrfile->Read ((LPSTR) &bmfh, sizeof (BITMAPFILEHEADER));
 // verify it is a .BMP file
 if (actsz != sizeof (BITMAPFILEHEADER) || bmfh.bfType != * (WORD *) "BM") {
  AfxMessageBox ("Invalid bmp game file", MB_OK);
  //ptrfile->Close ();
  return FALSE;
 }
 
 // calculate the size of the file less the file header
 // and allocate memory for the dib
 DWORD dwDibSize = bmfh.bfSize - sizeof (BITMAPFILEHEADER);
 hdib = GlobalAlloc (GMEM_MOVEABLE, dwDibSize);
 BYTE *ptrdib = (BYTE*) GlobalLock (hdib);
 if (!ptrdib) {
  AfxMessageBox ("Cannot allocate memory for bmp file", MB_OK);
  //ptrfile->Close ();
  if (hdib) GlobalFree (hdib);
  return FALSE;
 }
 
 // read in the rest of the DIB - 
 actsz = ptrfile->Read ((LPSTR) ptrdib, dwDibSize);
 //ptrfile->Close ();
 if (actsz != dwDibSize) { // error, wrong number of bytes
  AfxMessageBox ("Invalid bmp game file", MB_OK);
  GlobalUnlock (hdib);
  GlobalFree (hdib);
  return FALSE;
 }
 
 // check the validity of the size of the info header - fail OS2 bitmaps
 if (((BITMAPINFOHEADER*) ptrdib)->biSize <= sizeof(BITMAPCOREHEADER)) {
  AfxMessageBox ("Invalid bmp game file", MB_OK);
  GlobalUnlock (hdib);
  GlobalFree (hdib);
  return FALSE;
 }
 
 WORD bitcount = ((BITMAPINFOHEADER*) ptrdib)->biBitCount;
 DWORD numcolors = ((BITMAPINFOHEADER*) ptrdib)->biClrUsed;
 if (numcolors == 0 && bitcount != 24) numcolors = 1L << bitcount;
 if (numcolors == 0) {
  AfxMessageBox ("Invalid bmp game file", MB_OK);
  GlobalUnlock (hdib);
  GlobalFree (hdib);
  return FALSE;
 }

 width = ((BITMAPINFOHEADER*) ptrdib)->biWidth;
 height = ((BITMAPINFOHEADER*) ptrdib)->biHeight;
 
 //////////////////////////
 // modify Color Palette
 //////////////////////////
 ptrpalettes->SetPalette(ptrdib);
 //////////////////////////


 if (!Create (width, height, ptrpalettes)) {
  GlobalUnlock (hdib);
  GlobalFree (hdib);
  return FALSE;
 }

 BYTE *ptrsrc = ptrdib + ((BITMAPINFOHEADER*) ptrdib)->biSize + numcolors * sizeof (RGBQUAD);
 BYTE *ptrdes = GetBits ();
 long i = 0;
 
 ptrsrc += (height -1) * width;
 while (i < height) {
  memcpy (ptrdes, ptrsrc, width);
  ptrsrc -= width;
  ptrdes += width;
  i++;
 }

 // Delete error bit for 32 bit CreateDIBsection function
 ptrdes = GetBits();
 long wold = ((BITMAPINFOHEADER*) ptrdib)->biWidth;
 int wdif = width - wold;
 for ( i=0; i<height; i++)  {
   for (int j=wdif; j>0; j--)  {
      ptrdes[(i*width)+wold+j-1] = 255;
   }
 }

 GlobalUnlock (hdib);
 GlobalFree (hdib);
 return TRUE;
}

void BitmapDC::SetBits(BYTE * ptrsrc)
{
 //BYTE *ptrsrc = ptrdib + ((BITMAPINFOHEADER*) ptrdib)->biSize + numcolors * sizeof (RGBQUAD);
 BYTE *ptrdes = GetBits ();
 long i = 0;
 
 //ptrsrc += (height -1) * width;
 while (i < height) {
  memcpy (ptrdes, ptrsrc, widthOrg);
  ptrsrc += widthOrg;
  ptrdes += widthOrg;
  for(int j=widthOrg; j<width; j++) {
    memset(ptrdes, 255, 1);
    ptrdes++;
  }
  i++;
 }


}

BOOL BitmapDC::Isvalid()
{
  return isvalid;
}
