// file BitmapDC.H

#ifndef BITMAPDCH
#define BITMAPDCH

#include "stdafx.h"
#pragma hdrstop

#include "Palette.h"

/***************************************************************************/
/*                                                                         */
/* BitmapDC Class: bitmap object in memory DC class                        */
/*                                                                         */
/***************************************************************************/

class BitmapDC {

 /***************************************************************************/
 /*                                                                         */
 /* Data Members                                                            */
 /*                                                                         */
 /***************************************************************************/

public:

 HDC              hbmpdc;     // memory DC with DIB Section bitmap and palette
 BOOL             isvalid;

protected:

 HBITMAP          hbmp;       // Bitmap DIB Section style
 HBITMAP          holdbmp;    // old monochrome bitmap for deletion
 BYTE            *ptrbits;    // ptr to the bits of the bitmap once drawn
 CPalette        *ptrPalette;
 long             width;      // actual bitmap scanline dimensions
 long             height;
 long             widthOrg;      // original width

 /***************************************************************************/
 /*                                                                         */
 /* Functions:                                                              */
 /*                                                                         */
 /***************************************************************************/

public:
	BOOL Isvalid();
void SetBits(BYTE *);
BOOL Read(CFile*, Palette *ptrpalettes);
      BitmapDC ();      // constructor inits ptrs to NULL
      BitmapDC (long w, long h, Palette * ptrPalettes);
      BitmapDC (long w, long h, BYTE *pbit, Palette *ptrPal);
      ~BitmapDC ();      // remove the DIB Section and TMemoryDC
                                // create the actual DIB Section and TMemoryDC
BOOL  Create (long w, long h, Palette * ptrpalettes);
void  RealizePalette ();// complete Palette Manager reinitialization
void  RealizePalette (CDC&);// force Palette Manager reinit on anotherDC

BYTE* GetBits ();       // returns the address of the bitmap bits
long  Height ();        // returns real height of DIB Section bm
long  Width ();         // returns real width of DIB Section bm
long  TotalBits ();     // returns total bitmap bits in DIB Section
//BOOL  Read (const char*, Palette*);  // construct bm from file in RLE
BYTE  GetPixel (CPoint&);            // retrieve color idx of this pel
                                // translate & update colors to green to id obj
protected:

void   RemoveBitmap ();  // removes a DIB Section
BITMAPINFO*   MakeBITMAPINFO (long w, long h); // makes a BITMAPINFO structure

};
#endif
