// CopyDialog.cpp : implementation file
//

#include "stdafx.h"
#include "Project.h"
#include "CopyDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCopyDialog dialog


CCopyDialog::CCopyDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CCopyDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCopyDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CCopyDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCopyDialog)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCopyDialog, CDialog)
	//{{AFX_MSG_MAP(CCopyDialog)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCopyDialog message handlers
