// ProjectView.cpp : implementation of the CProjectView class
//

#include "stdafx.h"
#include "Project.h"

#include "ProjectDoc.h"
#include "ProjectView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CProjectView

IMPLEMENT_DYNCREATE(CProjectView, CScrollView)

BEGIN_MESSAGE_MAP(CProjectView, CScrollView)
	//{{AFX_MSG_MAP(CProjectView)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	ON_COMMAND(ID_EDIT_HISTOGRAM, OnEditHistogram)
	ON_WM_LBUTTONDBLCLK()
	ON_COMMAND(ID_EDIT_ORIGINAL, OnEditOriginal)
	ON_COMMAND(ID_EDIT_ZOOM, OnEditZoom)
	ON_COMMAND(ID_EDIT_MARGIN, OnEditMargin)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CProjectView construction/destruction

CProjectView::CProjectView()
{
	Ready=FALSE;
	Zoom=FALSE;
	newHeight=1;
	newWidth=1;
}

CProjectView::~CProjectView()
{
}

BOOL CProjectView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CScrollView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CProjectView drawing

void CProjectView::OnDraw(CDC* pDC)
{
	CProjectDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	int nHeight;
	int nWidth;

	if (Ready)
	{
		nHeight=pbBitmap.Height();
		nWidth=pbBitmap.Width();

//		if(Zoom)
//		{
//			nHeight=newHeight;
//			nWidth=newWidth;
//		}

		BitBlt(pDC->m_hDC,0,0,nWidth,nHeight,pbBitmap.hbmpdc,0,0,SRCCOPY);
		CSize sizePic;
		sizePic.cx=nWidth;
		sizePic.cy=nHeight;
		SetScrollSizes(MM_TEXT,sizePic);
		
	}
}

void CProjectView::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();

	CSize sizeTotal;
	// TODO: calculate the total size of this view
	sizeTotal.cx = sizeTotal.cy = 100;

	SetScrollSizes(MM_TEXT, sizeTotal);

}

/////////////////////////////////////////////////////////////////////////////
// CProjectView printing

BOOL CProjectView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CProjectView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CProjectView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CProjectView diagnostics

#ifdef _DEBUG
void CProjectView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CProjectView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CProjectDoc* CProjectView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CProjectDoc)));
	return (CProjectDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CProjectView message handlers
/////////////////////////////////////////////////////////////////////////////

void CProjectView::OnFileOpen() 
{
	int i,j;

	CFileDialog dlg(TRUE,".bmp","",OFN_OVERWRITEPROMPT,
		"Bitmap file (*.bmp)|*.bmp|All files (*.*)|*.*||");
	CString m_strFilename;
	//initial value in array of bitmap

	if (dlg.DoModal() != IDOK)
	{
		Ready=FALSE;
		return;
	}
	m_strFilename=dlg.GetFileName();

	fileBmp.Open(m_strFilename,CFile::modeRead);
	pbBitmap.Read(&fileBmp,&palBmp);
	
	for (j=0;j<pbBitmap.Height();j++)
	{
		for (i=0;i<pbBitmap.Width();i++)
		{
			pBitmap[i+j*pbBitmap.Width()]=*(pbBitmap.GetBits()+i+j*pbBitmap.Width());
		}
	}
	Initial();
	pbBitmap.SetBits((BYTE*)&pBitmap);
	fileBmp.Close();

	GetNumberTable();
	GetDocument()->UpdateAllViews(NULL);

	Ready=TRUE;
	hasHistogram=FALSE;
	Histogram=FALSE;

}

void CProjectView::OnEditHistogram() 
{
	int his[600];
	int i;
	int j;
if (!hasHistogram)
{
	for (j=0;j<pbBitmap.Height();j++)
	{
		his[j]=0;
		for (i=0;i<pbBitmap.Width();i++)
		{
			if (pBitmap[i+pbBitmap.Width()*j] == 0)
			{
				his[j]++;
			}
		}
	}
	for(j=0;j<pbBitmap.Height();j++)
	{
		for (i=0;i<pbBitmap.Width();i++)
		{
			if (his[j] != 0)
			{
				pHistogram[i+pbBitmap.Width()*j]=0;
				his[j]--;
			} else
				pHistogram[i+pbBitmap.Width()*j]=255;
		}
	}
	hasHistogram=TRUE;
}	
	pbBitmap.SetBits((BYTE*)&pHistogram);
	// however we must set pointer to pHistogram anyway...
	// now gonna get how much line in the document
/*
this part is 1's.
	int line=0;
*/
	Histogram=TRUE;
	GetDocument()->UpdateAllViews(NULL);


}

BOOL CProjectView::found(CPoint p,int around)
{
	if (around==1) {p.x--;p.y--;} else
	if (around==2) {p.y--;} else
	if (around==3) {p.x++;p.y--;} else
	if (around==4) {p.x--;} else
	if (around==6) {p.x++;} else
	if (around==7) {p.x--;p.y++;} else
	if (around==8) {p.y++;} else
	if (around==9) {p.x++;p.y++;}

	if (pbBitmap.GetPixel(p)==0) return TRUE;
	return FALSE;
}

int CProjectView::AroundPixel(CPoint point,int direction)
{
	if (direction==1)
	{
		if (found(point,8)) return 8;
		else if (found(point,7)) return 7;
		else if (found(point,4)) return 4;
		else if (found(point,1)) return 1;
		else if (found(point,2)) return 2;
		else if (found(point,3)) return 3;
		else if (found(point,6)) return 6;
		return 9;
	}

	if (direction==2)
	{
		if (found(point,7)) return 7;
		else if (found(point,4)) return 4;
		else if (found(point,1)) return 1;
		else if (found(point,2)) return 2;
		else if (found(point,3)) return 3;
		else if (found(point,6)) return 6;
		else if (found(point,9)) return 9;
		return 8;
	}
	if (direction==3)
	{
		if (found(point,4)) return 4;
		else if (found(point,1)) return 1;
		else if (found(point,2)) return 2;
		else if (found(point,3)) return 3;
		else if (found(point,6)) return 6;
		else if (found(point,9)) return 9;
		else if (found(point,8)) return 8;
		return 7;
	}
	if (direction==6)
	{
		if (found(point,1)) return 1;
		else if (found(point,2)) return 2;
		else if (found(point,3)) return 3;
		else if (found(point,6)) return 6;
		else if (found(point,9)) return 9;
		else if (found(point,8)) return 8;
		else if (found(point,7)) return 7;
		return 4;
	}
	if (direction==9)
	{
		if (found(point,2)) return 2;
		else if (found(point,3)) return 3;
		else if (found(point,6)) return 6;
		else if (found(point,9)) return 9;
		else if (found(point,8)) return 8;
		else if (found(point,7)) return 7;
		else if (found(point,4)) return 4;
		return 1;
	}
	if (direction==8)
	{
		if (found(point,3)) return 3;
		else if (found(point,6)) return 6;
		else if (found(point,9)) return 9;
		else if (found(point,8)) return 8;
		else if (found(point,7)) return 7;
		else if (found(point,4)) return 4;
		else if (found(point,1)) return 1;
		return 2;
	}
	if (direction==7)
	{
		if (found(point,6)) return 6;
		else if (found(point,9)) return 9;
		else if (found(point,8)) return 8;
		else if (found(point,7)) return 7;
		else if (found(point,4)) return 4;
		else if (found(point,1)) return 1;
		else if (found(point,2)) return 2;
		return 3;
	}
	if (direction==4)
	{
		if (found(point,9)) return 9;
		else if (found(point,8)) return 8;
		else if (found(point,7)) return 7;
		else if (found(point,4)) return 4;
		else if (found(point,1)) return 1;
		else if (found(point,2)) return 2;
		else if (found(point,3)) return 3;
		return 6;
	}
	return 0;
}

void CProjectView::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
if (!Histogram)
{
	CPoint pointCopy=point;
	int i,j;

	for (i=0;i<pbBitmap.Width();i++)
		for (j=0;j<pbBitmap.Height();j++)
			pSelection[i+j*pbBitmap.Width()]=pBitmap[i+j*pbBitmap.Width()];

	if (pbBitmap.GetPixel(point) == 0)
	{
		CPoint pointNew;
		pointNew.x=point.x-1;
		pointNew.y=point.y;

		while ((pbBitmap.GetPixel(pointNew) == 0)&&(pointNew.x>=0))
		{
			point.x=pointNew.x;
			pointNew.x--;
		}

		CPoint Startpoint;
		Startpoint=point;
		// now 'point' is on the rim of picture or alphabet
		// and will track on border and find min and max
		// coordination
		int xmin=point.x,xmax=0,ymin=point.y,ymax=0;
		int direction=6;
		BOOL firsttime;
		firsttime=TRUE;

		while ((point != Startpoint) || firsttime)
		{
			firsttime=FALSE;
			if (AroundPixel(point,direction) == 1)
			{
				point.x--;
				point.y--;
				direction=1;
			} else
			if (AroundPixel(point,direction) == 2)
			{
				point.y--;
				direction=2;
			} else
			if (AroundPixel(point,direction) == 3)
			{
				point.x++;
				point.y--;
				direction=3;
			} else
			if (AroundPixel(point,direction) == 4)
			{
				point.x--;
				direction=4;
			} else
			if (AroundPixel(point,direction) == 6)
			{
				point.x++;
				direction=6;
			} else
			if (AroundPixel(point,direction) == 7)
			{
				point.x--;
				point.y++;
				direction=7;
			} else
			if (AroundPixel(point,direction) == 8)
			{
				point.y++;
				direction=8;
			} else
			if (AroundPixel(point,direction) == 9)
			{
				point.x++;
				point.y++;
				direction=9;
			}

			if (point.x <= xmin) xmin=point.x;
			if (point.y <= ymin) ymin=point.y;
			if (point.x >= xmax) xmax=point.x;
			if (point.y >= ymax) ymax=point.y;

		} // while

		if (Zoom)
		{
			xmin=xmin*pbBitmap.Width()/newWidth;
			xmax=xmax*pbBitmap.Width()/newWidth+3;
			ymin=ymin*pbBitmap.Height()/newHeight;
			ymax=ymax*pbBitmap.Height()/newHeight+3;
		}

		int xel,xex;
		xel=((ymin-1)*pbBitmap.Width()+xmin);
		xex=((ymax+1)*pbBitmap.Width()+xmin);
		for (i=0;i<=xmax-xmin+2;i++)
		{
			// line in x axis
			pSelection[i+xel-1]=187;
			pSelection[i+xex-1]=187;
		}
		xel=xel+(pbBitmap.Width()-1);
		xex=(ymin*pbBitmap.Width()+xmax+1);
		for (i=0;i<=ymax-ymin;i++)
		{
			// line in y axis
			pSelection[xel+i*pbBitmap.Width()]=187;
			pSelection[xex+i*pbBitmap.Width()]=187;
		}
		pbBitmap.SetBits((BYTE*)&pSelection);

	} // if
}	
	GetDocument()->UpdateAllViews(NULL);
	Zoom=FALSE;

}

void CProjectView::OnEditOriginal() 
{
	pbBitmap.SetBits((BYTE*)&pBitmap);
	Histogram=FALSE;
	Zoom=FALSE;
	GetDocument()->UpdateAllViews(NULL);
}

int CProjectView::Treshole()
{ return 127;}

void CProjectView::Initial()
{
	// this method will convert the document to monochrome
	// by find the threshold and convert to black and white
	int tres=Treshole();
	int i,j;
	for (j=0;j<pbBitmap.Height();j++)
		for (i=0;i<pbBitmap.Width();i++)
			if (pBitmap[i+j*pbBitmap.Width()]>=tres)
				pBitmap[i+j*pbBitmap.Width()]=255;
			else pBitmap[i+j*pbBitmap.Width()]=0;
	for (i=0;i<600;i++)
		for (j=0;j<600;j++)
		{
			nLRWhite[j][i]=0;
			nRLWhite[j][i]=0;
			nUDWhite[j][i]=0;
			nDUWhite[j][i]=0;
		}
}

void initZoom(BYTE* picture)
{
	int i=0;

	for (i=0;i<360000;i++)
		picture[i]=255;
}
void CProjectView::ClearZoom(int maxx,int maxy)
{
	int i=0;
	int j=0;
	for (i=1;i<maxx;i++)
	{
		for (j=maxy;j<pbBitmap.Height();j++)
		{
			pZoom[i+j*pbBitmap.Width()]=255;
		}
	}
}

void CProjectView::OnEditZoom() 
{
	CZoomDialog zdlgZoom;
	if (zdlgZoom.DoModal() != IDOK)
		return;

	int nPercent=100-zdlgZoom.m_nPercent;
	int i,j;	//for looping
	int x,y;	//for new location
	int maxx,maxy;
	int xindex,yindex;
	BYTE temp=255;

	initZoom(pZoom);
	maxx=(nPercent*pbBitmap.Width())/100;
	maxy=(nPercent*pbBitmap.Height())/100;
	xindex=pbBitmap.Width()/maxx;
	yindex=pbBitmap.Height()/maxy;
	x=-1;y=-1;

	for (j=0;j<pbBitmap.Height();j++)
	{
		for (i=0;i<pbBitmap.Width();i++)
		{
			temp=temp*pBitmap[i+j*pbBitmap.Width()];
			if ((i%xindex)==(xindex-1))
			{
				x++;
				pZoom[x+j*pbBitmap.Width()]=temp;
				temp=255;
			}
		}
		x=-1;
	}


	temp=255;
	for (i=0;i<maxx;i++)
	{
		for (j=0;j<pbBitmap.Height();j++)
		{
			temp=temp*pZoom[i+j*pbBitmap.Width()];
			if ((j%yindex)==(yindex-1))
			{
				y++;
				pZoom[i+y*pbBitmap.Width()]=temp;
				temp=255;
			}
		}
		y=-1;
	}
	ClearZoom(maxx,maxy);
	pbBitmap.SetBits((BYTE*)pZoom);
	GetDocument()->UpdateAllViews(NULL);
	Zoom=TRUE;
	newHeight=maxy;
	newWidth=maxx;

}

void CProjectView::GetNumberTable()
{
	int i,j;
	int tmp=0;
/*
	for (i=0;i<pbBitmap.Width();i++)
	{
		for (j=0;j<pbBitmap.Height();j++)
		{
			if (pBitmap[i+j*pbBitmap.Width()]==255)
			{
				tmp++;
				nUDWhite[i][j]=tmp;
			}
			else tmp=0;
		} // for(i)
		tmp=0;
	} // for(j)
*/
	for (i=pbBitmap.Width()-1;i>=0;i--)
	{
		for (j=pbBitmap.Height()-1;j>=0;j--)
		{
			if (pBitmap[i+j*pbBitmap.Width()]==255)
			{
				tmp++;
				nDUWhite[i][j]=tmp;
			} 
			else tmp=0;
		}
		tmp=0;
	}

	for (i=0;i<pbBitmap.Width();i++)
	{
		for (j=0;j<pbBitmap.Height();j++)
		{
			if (pBitmap[i+j*pbBitmap.Width()]==255)
			{
				tmp++;
				nUDWhite[i][j]=tmp;
			}
			else tmp=0;
		} // for(i)
		tmp=0;
	} // for(j)

//------------------------------------------------
	for (j=0;j<pbBitmap.Height();j++)
	{
		for (i=0;i<pbBitmap.Width();i++)
		{
			if (pBitmap[i+j*pbBitmap.Width()]==255)
			{
				tmp++;
				nLRWhite[i][j]=tmp;
			}
			else tmp=0;
		} // for(i)
		tmp=0;
	} // for(j)
	

	for (j=pbBitmap.Height()-1;j>=0;j--)
	{
		for (i=pbBitmap.Width()-1;i>=0;i--)
		{
			if (pBitmap[i+j*pbBitmap.Width()]==255)
			{
				tmp++;
				nRLWhite[i][j]=tmp;
			} 
			else tmp=0;
		}
		tmp=0;
	}


}
void CProjectView::drawvline(int x,int y,int nlong)
{
	int i;
//	for (i=ymin;i<ymax;i++)
	for (i=0;i<nlong;i++)
	{
		pNotshow[x+y*pbBitmap.Width()+i]=187;
	}
}
void CProjectView::drawhline(int x,int y,int nlong)
{
	int i;
//	for (i=xmin;i<xmax;i++)
	for (i=0;i<nlong;i++)
	{
		pNotshow[x+(y+i)*pbBitmap.Width()]=187;
	}
}

void CProjectView::OnEditMargin() 
{
	int i=0,j=0;
	int max=0;
	int length=0;

	for (i=0;i<pbBitmap.Width();i++)
		for (j=0;j<pbBitmap.Height();j++)
			pNotshow[i+j*pbBitmap.Width()]=pBitmap[i+j*pbBitmap.Width()];
	length=pbBitmap.Height()/2;

	for (i=2;i<pbBitmap.Width()-2;i++)
	{
		for (j=2;j<pbBitmap.Height()-2;j++)
		{
			if (nUDWhite[i][j]+nDUWhite[i][j]>=length &&
				nUDWhite[i-1][j]+nDUWhite[i-1][j]>=length &&
				nUDWhite[i+1][j]+nDUWhite[i+1][j]>=length &&
				nUDWhite[i-2][j]+nDUWhite[i-2][j]>=length &&
				nUDWhite[i+2][j]+nDUWhite[i+2][j]>=length)

				drawhline(i,j,nDUWhite[i][j]-2);

			if (nLRWhite[i][j]+nRLWhite[i][j]>=pbBitmap.Width() &&
				nLRWhite[i-1][j]+nRLWhite[i-1][j]>=pbBitmap.Width() &&
				nLRWhite[i+1][j]+nRLWhite[i+1][j]>=pbBitmap.Width() &&
				nLRWhite[i-2][j]+nRLWhite[i-2][j]>=pbBitmap.Width() &&
				nLRWhite[i+2][j]+nRLWhite[i+2][j]>=pbBitmap.Width())
				drawvline(i,j,nRLWhite[i][j]-2);
		}
	}
	pbBitmap.SetBits((BYTE*)pNotshow);
	GetDocument()->UpdateAllViews(NULL);
}	
