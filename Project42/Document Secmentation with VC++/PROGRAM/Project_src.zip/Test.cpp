// Test.cpp : implementation file
//

#include "stdafx.h"
#include "Project.h"
#include "Test.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTest

IMPLEMENT_DYNCREATE(CTest, CEditView)

CTest::CTest()
{
}

CTest::~CTest()
{
}


BEGIN_MESSAGE_MAP(CTest, CEditView)
	//{{AFX_MSG_MAP(CTest)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTest drawing

void CTest::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CTest diagnostics

#ifdef _DEBUG
void CTest::AssertValid() const
{
	CEditView::AssertValid();
}

void CTest::Dump(CDumpContext& dc) const
{
	CEditView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTest message handlers
