// ProjectView.h : interface of the CProjectView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROJECTVIEW_H__967FFE2F_DE8A_11D3_B213_10CB4AC10000__INCLUDED_)
#define AFX_PROJECTVIEW_H__967FFE2F_DE8A_11D3_B213_10CB4AC10000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "BitmapDC.h"
#include "Palette.h"
#include "ZoomDialog.h"
#include "CopyDialog.h"

class CProjectView : public CScrollView
{
protected: // create from serialization only
	CProjectView();
	DECLARE_DYNCREATE(CProjectView)
	int AroundPixel(CPoint point,int direction);
	BOOL found(CPoint p,int around);
	void Initial();
	int Treshole();
	void GetNumberTable();
	void ClearZoom(int maxx,int maxy);
	void drawvline(int x,int y,int nlong);
	void drawhline(int x,int y,int nlong);
// Attributes
public:
	CProjectDoc* GetDocument();
	BitmapDC pbBitmap;

private:
	Palette palBmp;
	CFile fileBmp;

	BOOL Ready;
	BOOL Histogram;
	BOOL hasHistogram;
	BOOL Zoom;

	BYTE pHistogram[360000];
	BYTE pBitmap[360000];
	BYTE pSelection[360000];
	BYTE pZoom[360000];
	BYTE pNotshow[360000];

	int nUDWhite[600][600];
	int nDUWhite[600][600];
	int nLRWhite[600][600];
	int nRLWhite[600][600];

	int newHeight;
	int newWidth;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CProjectView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL
// Implementation
public:
	virtual ~CProjectView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CProjectView)
	afx_msg void OnFileOpen();
	afx_msg void OnEditHistogram();
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnEditOriginal();
	afx_msg void OnEditZoom();
	afx_msg void OnEditMargin();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in ProjectView.cpp
inline CProjectDoc* CProjectView::GetDocument()
   { return (CProjectDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROJECTVIEW_H__967FFE2F_DE8A_11D3_B213_10CB4AC10000__INCLUDED_)
