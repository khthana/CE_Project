// file: PALETTE.CPP

#include "stdafx.h"
#pragma hdrstop

#include "Palette.h"
#include "resource.h"

RGBQUAD     Palette::pal[256];
LOGPALETTE *Palette::ptrlogpal = NULL;

/***************************************************************************/
/*                                                                         */
/* static InitPalette: loads the master palette                            */
/*                                                                         */
/***************************************************************************/
/*
BOOL      Palette::InitPalette (const char *filename) {

 // allocate the common logical palette
 ptrlogpal = (LOGPALETTE*) malloc (sizeof(LOGPALETTE) +
                                   256 * sizeof (PALETTEENTRY));
 if (!ptrlogpal) {
  AfxMessageBox ("Palette Error: Unable to allocate memory for palette", MB_OK);
  return FALSE;
 }
 ptrlogpal->palVersion = 0x300;       // set for Windows 3.0 and later
 ptrlogpal->palNumEntries = 256;      // set for 256-color

 CFileException file_err; // used if more info on errors is desired
 CFile palfile;
 palfile.Open (filename, CFile::modeRead, &file_err);
 UINT actsz = palfile.Read ((LPSTR) &pal[0], sizeof (pal));
 palfile.Close ();
 if (actsz != sizeof (pal)) {
   AfxMessageBox ("Palette Error: Unable to Load the .PAL file", MB_OK);
   return FALSE;
 }
 return TRUE;
}
*/
/***************************************************************************/
/*                                                                         */
/* static DeletePalette: remove the common palette work area               */
/*                                                                         */
/***************************************************************************/

void      Palette::DeletePalette () {

 if (ptrlogpal) free (ptrlogpal);
}


/***************************************************************************/
/*                                                                         */
/* Palette: Constructor - setup the requested country palette              */
/*                                                                         */
/***************************************************************************/

Palette::Palette () {

 ptrmainpal   = NULL;
 //ok = FALSE;
 InitPalette();

 long i;
 HDC hdc = CreateDC ("DISPLAY", NULL, NULL, NULL);
 ::GetSystemPaletteEntries (hdc, 0, 256, ptrlogpal->palPalEntry);
  
 // now merge in the user's palette into the main map color table
 for (i=0; i<256; i++) {
  ptrlogpal->palPalEntry[i].peBlue  = pal[i].rgbBlue;
  ptrlogpal->palPalEntry[i].peGreen = pal[i].rgbGreen;
  ptrlogpal->palPalEntry[i].peRed   = pal[i].rgbRed;
  ptrlogpal->palPalEntry[i].peFlags = PC_RESERVED;
 }

 // now copy these to the main map color table
 for (i=0; i<256; i++) {
  maincoltbl[i].rgbBlue  = ptrlogpal->palPalEntry[i].peBlue;
  maincoltbl[i].rgbGreen = ptrlogpal->palPalEntry[i].peGreen;
  maincoltbl[i].rgbRed   = ptrlogpal->palPalEntry[i].peRed;
  maincoltbl[i].rgbReserved = 0;
 }

 // make our new main map palette
 ptrmainpal = new CPalette ();
 ptrmainpal->CreatePalette (ptrlogpal);
 if (!ptrmainpal) {
  AfxMessageBox ("Palette Error: Unable to Create a Palette", MB_OK);
  DeleteDC (hdc);
  return;
 }

 // force Palette Manager to reset the master color table
 // so the next palette that is realized gets its colors
 // mapped into the order of use in the logical palette
 // install our new palette, realize it to map the logical palette
 // into the master palette, then remove the palette from the DC
 ClearSystemPalette (hdc);
 HPALETTE holdpal = SelectPalette (hdc, (HPALETTE) ptrmainpal->GetSafeHandle (), FALSE);
 RealizePalette (hdc);
 SelectPalette (hdc, holdpal, FALSE);
 DeleteDC (hdc);
 //ok = TRUE;
}

/***************************************************************************/
/*                                                                         */
/* ~Palette: remove allocated objects                                      */
/*                                                                         */
/***************************************************************************/

   Palette::~Palette () {

 if (ptrmainpal)   delete ptrmainpal;
}

/***************************************************************************/
/*                                                                         */
/* ClearSystemPalette: force Palette Manager to reload colors - several forms*/
/*                                                                         */
/***************************************************************************/

void      Palette::ClearSystemPalette () {

 HDC hdc = CreateDC ("DISPLAY", NULL, NULL, NULL);
 SetSystemPaletteUse (hdc, SYSPAL_NOSTATIC);
 SetSystemPaletteUse (hdc, SYSPAL_STATIC);
 DeleteDC (hdc);
}

void      Palette::ClearSystemPalette (CDC &dc) {

 SetSystemPaletteUse (dc.GetSafeHdc (), SYSPAL_NOSTATIC);
 SetSystemPaletteUse (dc.GetSafeHdc (), SYSPAL_STATIC);
}

void      Palette::ClearSystemPalette (HDC &hdc) {

 SetSystemPaletteUse (hdc, SYSPAL_NOSTATIC);
 SetSystemPaletteUse (hdc, SYSPAL_STATIC);
}

/***************************************************************************/
/*                                                                         */
/* GetPalette: returns a ptr to the indicated identity palette             */
/*                                                                         */
/***************************************************************************/

CPalette* Palette::GetPalette () {

 return ptrmainpal ? ptrmainpal : NULL;
}

/***************************************************************************/
/*                                                                         */
/* FillRgbColorTable: copies the indicated identity color table to ptrdest */
/*                                                                         */
/***************************************************************************/

void      Palette::FillRgbColorTable (RGBQUAD *ptrdest) {

 if (!ptrmainpal) return; // defensive - not initied
 memcpy ((void*) ptrdest, (void*) maincoltbl, 256 * sizeof (RGBQUAD));
}

BOOL Palette::InitPalette()
{
 // allocate the common logical palette
 ptrlogpal = (LOGPALETTE*) malloc (sizeof(LOGPALETTE) +
                     256 * sizeof (PALETTEENTRY));
 if (!ptrlogpal) {
  AfxMessageBox ("Palette Error: Unable to allocate memory for palette", MB_OK);
  return FALSE;
 }
 ptrlogpal->palVersion = 0x300;       // set for Windows 3.0 and later
 ptrlogpal->palNumEntries = 256;      // set for 256-color

 for(int i=0; i<256; i++)  {
   pal[i].rgbBlue = i;
   pal[i].rgbGreen = i;
   pal[i].rgbRed = i;
 }
 return TRUE;
}

BOOL Palette::SetPalette(BYTE *ptrdib)
{
 //ok = FALSE;
 LPBITMAPINFO ptrinfo = (LPBITMAPINFO) ptrdib;

 long i;
 HDC hdc = CreateDC ("DISPLAY", NULL, NULL, NULL);
 ::GetSystemPaletteEntries (hdc, 0, 256, ptrlogpal->palPalEntry);
  
 // now merge in the user's palette into the main map color table
 for (i=0; i<256; i++) {
  ptrlogpal->palPalEntry[i].peBlue  = ptrinfo->bmiColors[i].rgbBlue;
  ptrlogpal->palPalEntry[i].peGreen = ptrinfo->bmiColors[i].rgbGreen;
  ptrlogpal->palPalEntry[i].peRed   = ptrinfo->bmiColors[i].rgbRed;
  ptrlogpal->palPalEntry[i].peFlags = PC_RESERVED;
 }

 // now copy these to the main map color table
 for (i=0; i<256; i++) {
  maincoltbl[i].rgbBlue  = ptrlogpal->palPalEntry[i].peBlue;
  maincoltbl[i].rgbGreen = ptrlogpal->palPalEntry[i].peGreen;
  maincoltbl[i].rgbRed   = ptrlogpal->palPalEntry[i].peRed;
  maincoltbl[i].rgbReserved = 0;
 }

 // make our new main map palette
 if(!ptrmainpal) delete ptrmainpal;
 ptrmainpal = new CPalette ();
 ptrmainpal->CreatePalette (ptrlogpal);
 if (!ptrmainpal) {
  AfxMessageBox ("Palette Error: Unable to Create a Palette", MB_OK);
  DeleteDC (hdc);
  return FALSE;
 }

 // force Palette Manager to reset the master color table
 // so the next palette that is realized gets its colors
 // mapped into the order of use in the logical palette
 // install our new palette, realize it to map the logical palette
 // into the master palette, then remove the palette from the DC
 ClearSystemPalette (hdc);
 HPALETTE holdpal = SelectPalette (hdc, (HPALETTE) ptrmainpal->GetSafeHandle (), FALSE);
 RealizePalette (hdc);
 SelectPalette (hdc, holdpal, FALSE);
 DeleteDC (hdc);
 //ok = TRUE;

return TRUE;
}
