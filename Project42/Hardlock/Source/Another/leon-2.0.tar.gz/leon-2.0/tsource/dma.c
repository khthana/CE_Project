#include "leon.h"
#include "test.h"


dma_test()
{
	int testarr[8],i;
	int maddr = (int) &testarr;

	/* burst write */
	lr->dummy9 = maddr;
	if (lr->dummy9 != maddr) return(0);

	report(DMA_TEST);
	lr->dummy10 = 0x1086b;
	flush();
	for (i=0; i < 8; i++) if (testarr[i] != (~maddr) + i) break;
	if (i != 8) fail(i);

	/* burst read */
	lr->dummy9 = (int) &testarr;
	lr->dummy10 = 0x108eb;
	if (lr->dummy9 != maddr + (8*4)) return(0);
}
