ShellExecute Demo Project - 00:31 25/02/98

This project demonstrates how to open files in their default applications.

For more VB Demo Projects, as well as tips and links, please visit Jelsoft VB-World at:
http://www.jelsoft.com/vbw/

If you have a query about this demo project, please send an email to:
vbw@jelsoft.com
