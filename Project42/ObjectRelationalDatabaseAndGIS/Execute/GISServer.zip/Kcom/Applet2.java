
//Title:       Your Product Name
//Version:
//Copyright:   Copyright (c) 1998
//Author:      Your Name
//Company:     Your Company
//Description: Your description

package KCOM;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import com.sun.java.swing.*;
import java.util.*;
import com.sun.java.swing.JComponent;
//import com.sun.java.swing.*;

//import com.sun.java.swing.UIManager;
public class Applet2 extends JApplet {
  boolean isStandalone = false;
  JDesktopPane jd;

//Get a parameter value

  public String getParameter(String key, String def) {
    return isStandalone ? System.getProperty(key, def) :
      (getParameter(key) != null ? getParameter(key) : def);
  }

  //Construct the applet

  public Applet2() {
  }
//Initialize the applet

  public void init() {
    try {
    jbInit();
    }
    catch (Exception e) {
    e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    try  {
      UIManager.setLookAndFeel(new com.sun.java.swing.plaf.windows.WindowsLookAndFeel());
      //UIManager.setLookAndFeel(new com.sun.java.swing.plaf.motif.MotifLookAndFeel());
      //UIManager.setLookAndFeel(new com.sun.java.swing.plaf.metal.MetalLookAndFeel());
    }
    catch (Exception e) {
    }
    SwingUtilities.updateComponentTreeUI(this);

   jd = new JDesktopPane();
   this.getContentPane().setLayout(new BorderLayout());
   this.setContentPane(jd);
   jd.requestFocus();
    jd.addKeyListener(new java.awt.event.KeyAdapter() {
      public void keyPressed(KeyEvent e) {
        jd_keyPressed(e);
      }
    });
    this.addKeyListener(new java.awt.event.KeyAdapter() {
      public void keyPressed(KeyEvent e) {
        this_keyPressed(e);
      }
    });
   //jd.putClientProperty("JDesktopPane.dragMode", "outline");
   this.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseClicked(MouseEvent e) {
        this_mouseClicked(e);
      }
    });

   //this.setContentPane(jd);
  }
//Start the applet

  public void start() {
  }
//Stop the applet

  public void stop() {
  }
//Destroy the applet

  public void destroy() {
  }
//Get Applet information

  public String getAppletInfo() {
    return "Applet Information";
  }
//Get parameter info

  public String[][] getParameterInfo() {
    return null;
  }

  void this_mouseClicked(MouseEvent e) {
   JInternalFrame ji = new JInternalFrame("hello",true,true,true,true);

   ji.setPreferredSize(new Dimension(200,100));
   ji.setBounds(50,50,100,100);
   ji.pack();
   ji.show(true);
   jd.add(ji,JLayeredPane.PALETTE_LAYER);
      try {
            ji.setSelected(true);
        } catch (java.beans.PropertyVetoException ek) {}

  }

  void this_keyPressed(KeyEvent e) {

  }

  void jd_keyPressed(KeyEvent e) {
   System.out.println("new frame");
   KViewerInternalFrame ji  = new KViewerInternalFrame();
   ji.setClosable(true);
   ji.setIconifiable(true);
   ji.setMaximizable(true);


   ji.setPreferredSize(new Dimension(200,100));
   ji.setBounds(50,50,100,100);
   ji.pack();
   ji.show(true);
   ji.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
   jd.add(ji,JLayeredPane.PALETTE_LAYER);
   try {
            ji.setSelected(true);
        } catch (java.beans.PropertyVetoException ek) {}
  }


}


