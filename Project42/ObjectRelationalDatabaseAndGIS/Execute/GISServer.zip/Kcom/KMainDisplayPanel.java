
//Title:       Your Product Name
//Version:
//Copyright:   Copyright (c) 1998
//Author:      Sakshart Ngamluan
//Company:     KMITL
//Description: Your description
package KCOM;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.util.Vector;
import com.sun.java.swing.*;
import com.sun.java.accessibility.*;
public class KMainDisplayPanel extends KDisplayPanel implements Scrollable{
  public KMainDisplayPanel() {
  this.setBackground(Color.black);
  this.setLayout(borderLayout1);
  }
}

