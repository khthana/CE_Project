package IsecQ;

import java.io.*;

public class DATA_REF
{
/*		public static String NUM_USERS;
		public static String LIST;
		public static String MESSAGE_TYPE;
		public static String MESSAGE_LENGTH;
		public static String MESSAGE_TEXT;
*/		
/*		public static MSG_TEXT;
		public static MSG_URL;
		public static MSG_AUTH_REQ;
		public static MSG_AUTH; 
		public static MSG_USER_ADDED; 
		public static MSG_CONTACTS;
*/		
		public static String SERVER = "161.246.10.21\n";
		public static short   SERVER_LENGTH = (short) SERVER.length();
		public static String PORT = "4000\n";
		public static short   PORT_LENGTH = (short) PORT.length();
		//public static int PORT_LENGTH = ?????;
		public static String USER_IP = "161.246.5.1\n";
		public static short   USER_IP_LENGTH = (short) USER_IP.length();
		public static String USER_PORT = "2000\n";
		public static short   USER_PORT_LENGTH = (short) USER_PORT.length();
		//public static PASS_LENGTH;
		public static String PASSWORD = "0123456\n";
		public static short   PASSWORD_LENGTH = (short) PASSWORD.length();
		//public static String PASS             = "0123456\n";
		//public static String IP = "161.246.5.24";
/*		public static STATUS;
		public static STATUS_ONLINE;
		public static STATUS_AWAY;
		public static STATUS_DND;
		public static STATUS_INVISIBLE;
		public static STATUS_OCCUPIED;
		public static STATUS_NA;
		public static STATUS_CHAT;
*/
		public static String UIN = "60931264\n"; 
		public static short   UIN_LENGTH = (short) UIN.length();
		public static String NICK = "test01\n";
		public static short  NICK_LENGTH = (short) NICK.length();
		public static String FIRST = "Weera01\n";
		public static short  FIRST_LENGTH = (short) FIRST.length();
		public static String LAST = "Wiangchaisree\n";
		public static short  LAST_LENGTH = (short) LAST.length();
		public static String EMAIL = "weeraw@yahoo.com\n";
		public static short  EMAIL_LENGTH = (short) EMAIL.length();		 

/*			 data_out.write(b);						 data_out.write(b2, 0 ,b2.length);
			 data_out.writeBoolean(true);	 data_out.writeChar(a);
			 data_out.writeBytes(c);			 data_out.writeChars(c);
			 data_out.writeUTF(c);				 data_out.writeUTF("abc\n");
			 data_out.write(b);						 data_out.writeShort(d);*/
}
