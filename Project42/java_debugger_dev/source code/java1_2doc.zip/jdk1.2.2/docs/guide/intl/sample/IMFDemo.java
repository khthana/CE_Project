/*
 * @(#)IMFDemo.java	1.2 98/06/05
 * 
 * Copyright 1997-1998 by Sun Microsystems, Inc.,
 * 901 San Antonio Road, Palo Alto, California, 94303, U.S.A.
 * All rights reserved.
 */

import java.applet.Applet;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

public class IMFDemo extends Applet {

    public void init() {
        addComponents();
    }
    
    public void start() {
    }
    
    public void stop() {
    }
    
    public void addComponents() {
        setLayout(new GridLayout(4, 1, 10, 10));
        add(new LWTextComponent("Lightweight component, non-client", false));
        add(new LWTextComponent("Lightweight component, passive client", true));
        add(new ActiveClient("Lightweight component, active client"));
        add(new PeeredTextArea());
    }

    public static void main(String argv[]) {
        final IMFDemo applet = new IMFDemo();
        applet.init();
        applet.start();
        makeFrame(applet, "Input Method Framework Demo");
    }

    public static void makeFrame(Applet applet, String title) {
        Frame frame = new Frame(title);
        frame.pack(); // adds peer
        frame.add("Center", applet);
        frame.setSize(400, 400);
        WindowListener listener = new AppletWindowListener(applet);
        frame.addWindowListener(listener);
        frame.pack();
        frame.show();
    }
}

class AppletWindowListener extends WindowAdapter {

    private Applet applet;

    AppletWindowListener(Applet applet) {
        this.applet = applet;
    }

    public void windowClosing(WindowEvent e) {
        e.getWindow().dispose();
        System.exit(0);
    }
}
