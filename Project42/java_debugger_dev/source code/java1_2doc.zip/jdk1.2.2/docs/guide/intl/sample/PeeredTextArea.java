/*
 * @(#)PeeredTextArea.java	1.2 98/06/09
 * 
 * Copyright 1997-1998 by Sun Microsystems, Inc.,
 * 901 San Antonio Road, Palo Alto, California, 94303, U.S.A.
 * All rights reserved.
 */

import java.awt.Color;
import java.awt.Dimension;
import java.awt.TextArea;

public class PeeredTextArea extends TextArea {

    public PeeredTextArea() {
        super();
        setText("Peered component\n");
        setSize(300, 80);
        setBackground(Color.white);
	setVisible(true);
	setEnabled(true);
    }
    
    public Dimension getPreferredSize() {
        return new Dimension(300, 80);
    }
}
