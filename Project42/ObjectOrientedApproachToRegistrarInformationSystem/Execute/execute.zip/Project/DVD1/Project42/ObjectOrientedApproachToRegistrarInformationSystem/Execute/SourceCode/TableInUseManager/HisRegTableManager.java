package TableInUseManager;

/**
 * This type was created in VisualAge.
 */
import TableInUse.*;
public class HisRegTableManager {
	private HisRegTableModel aHisRegTableModel;
	
/**
 * HisTableManager constructor comment.
 */
public HisRegTableManager() {
	super();
}
/**
 * HisTableManager constructor comment.
 */
public HisRegTableManager(HisRegTableModel htm) {
	super();
	aHisRegTableModel = htm;
}
/**
 * This method was created in VisualAge.
 * @param ob java.lang.Object
 */
public void setValuesInTable(Object ob,int row,int col) {
	aHisRegTableModel.setValueAt(ob,row,col);
}
}