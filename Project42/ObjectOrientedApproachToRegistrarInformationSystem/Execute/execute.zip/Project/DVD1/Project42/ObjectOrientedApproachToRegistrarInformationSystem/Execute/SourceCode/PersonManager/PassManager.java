package PersonManager;

/**
 * This type was created in VisualAge.
 */
import Person.*;
import java.sql.*;
import java.math.*;
import java.io.*;

public class PassManager {
	private Pass aPass;
	private boolean entry;
	
	
/**
 * PassManager constructor comment.
 */
public PassManager() {
	super();
}
/**
 * PassManager constructor comment.
 */
public PassManager(Pass p) {
	super();
	aPass = p;
}
/**
 * This method was created in VisualAge.
 * @return boolean
 * @param user java.lang.String
 * @param passwd java.lang.String
 * @exception java.lang.Throwable The exception description.
 */
public boolean checkPassword(String user,String passwd)  {
	String strUser="";
	String strPasswd="";
	
	try
	{
		aPass.getPass(user,passwd);
		//System.out.println("chekcPass");
		strUser = aPass.getUser();
		strPasswd = aPass.getPasswd();
	
	}catch (SQLException e){}	
	int u = strUser.compareTo(user);
	int p = strPasswd.compareTo(passwd);
	
	if(u==0&&p==0) return true;
	else 
	   return false;
}
/**
 * This method was created in VisualAge.
 * @return boolean
 * @param user java.lang.String
 * @param pass java.lang.String
 * @param stdid java.lang.String
 */
public boolean checkSameUser(String user,String stdid) {
	int same = user.compareTo(stdid);
	
	if(same == 0) return true;
	else 
	   return false;
}
/**
 * This method was created in VisualAge.
 * @return boolean
 */
public boolean isEntry() {
	if (entry==true) {entry = false;
		return true;}
	else
	return false;
}
/**
 * This method was created in VisualAge.
 */
public void setEntry() {
	entry = true;
}
}