package UIStudent;

/**
 * This type was created in VisualAge.
 */
import java.sql.*;
import java.lang.*;
import Person.*;
import PersonManager.*;
import TableInUse.*;
import TableInUseManager.*;
public class Password extends com.sun.java.swing.JFrame implements java.awt.event.ActionListener {
	private com.sun.java.swing.JPanel ivjJFrameContentPane = null;
	private com.sun.java.swing.JPasswordField ivjJPasswordFieldPasswd = null;
	private com.sun.java.swing.JLabel ivjJLabelpassword = null;
	private com.sun.java.swing.JButton ivjJButtonPasswdCancel = null;
	private com.sun.java.swing.JButton ivjJButtonPaswdOK = null;
	private com.sun.java.swing.JLabel ivjJLabelPasswd = null;
	private com.sun.java.swing.JTextField ivjJTextFieldUserName = null;
	//
	//password
	private Pass aPass;
	private PassManager aPassManager;
	//student
	private Student aStudent;
	private StudentManager aStudentManager;
	//subjects
	private Subjects aSubjects;
	private SubjectsManager aSubjectsManager;

	//register_Detail
	private Register_Detail aRegister_Detail;
	private Register_DetailManager aRegister_DetailManager;

	//register_Header
	private Register_Header aRegister_Header;
	private Register_HeaderManager aRegister_HeaderManager;
	
	//register_course
	private Register_Course aRegister_Course;
	private Register_CourseManager aRegister_CourseManager;

	//Semester
	private Semester aSemester;
	private SemesterManager aSemesterManager;

	//TableReg
	private RegisterTableModel aRegisterTableModel;
	private RegisterTableManager aRegisterTableManager;
	//TableAdd
	private AddSubjectTableModel aAddSubjectTableModel;
	private AddSubjectTableManager aAddSubjectTableManager;
	//TableDel
	private DelSubjectTableModel aDelSubjectTableModel;
	private DelSubjectTableManager aDelSubjectTableManager;
	//TableAdd
	private HisRegTableModel aHisRegTableModel;
	private HisRegTableManager aHisRegTableManager;

	//TableHisGradeInfo
	private HisGradeInfoTableModel aHisGradeInfoTableModel;
	private HisGradeInfoTableManager aHisGradeInfoTableManager;
	
	//UI
	private UiMain aUiMain;
	private Faculty aFaculty;
	private Yr_Term aYear_Term;
	private RegisterOption aRegisterOption;
	private Information aInformation;
	
	private NotFound aNotFound;
	
	
	private String user;
	private String password;
	private String struser;
	private String strpasswd;
	
	

	
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public Password() {
	super();
	initialize();
}
/**
 * Password constructor comment.
 * @param title java.lang.String
 */
public Password(String title) {
	super(title);
}
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public Password(UiMain um,Faculty f,Yr_Term yt) {
	super();
	aUiMain = um;
	aFaculty = f;
	aYear_Term = yt;
	initialize();
}
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void actionPerformed(java.awt.event.ActionEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == getJButtonPaswdOK()) ) {
		connEtoC2();
	}
	if ((e.getSource() == getJButtonPasswdCancel()) ) {
		connEtoC3();
	}
	if ((e.getSource() == getJPasswordFieldPasswd()) ) {
		connEtoC1();
	}
	// user code begin {2}
	// user code end
}
/**
 * This method was created in VisualAge.
 */
public void addSubject() {
	String stdid = getUser();
						String yr = aYear_Term.getYear();
						String tm = aYear_Term.getTerm();
						try
						{
							aSubjectsManager.setFirstValues();
							aRegister_DetailManager.addSubToDBforScondReg(stdid,yr,tm);
						}catch (SQLException e){}
						
}
/**
 * This method was created in VisualAge.
 * @return boolean
 * @param user java.lang.String
 * @param pass java.lang.String
 * @param stdid java.lang.String
 */
public boolean checkSameUser(String user,String stdid) {
	return aPassManager.checkSameUser(user,stdid);
}
/**
 * This method was created in VisualAge.
 */
public void clearUser() {
	ivjJPasswordFieldPasswd.setText("");
			
}
/**
 * This method was created in VisualAge.
 */
public void close() {
				clearUser();
				setVisible(false);
				dispose();
				
}
/**
 * connEtoC1:  (JPasswordField1.action. --> Password.jPasswordField1_ActionEvents()V)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC1() {
	try {
		// user code begin {1}
		// user code end
		this.jPasswordFieldPasswd_ActionEvents();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC2:  (JButtonPaswdOK.action. --> Password.jButtonPaswdOK_ActionEvents()V)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC2() {
	try {
		// user code begin {1}
		// user code end
		this.jButtonPaswdOK_ActionEvents();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC3:  (JButtonPasswdCancel.action. --> Password.jButtonPasswdCancel_ActionEvents()V)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC3() {
	try {
		// user code begin {1}
		// user code end
		this.jButtonPasswdCancel_ActionEvents();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * Return the JButtonPasswdCancel property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JButton getJButtonPasswdCancel() {
	if (ivjJButtonPasswdCancel == null) {
		try {
			ivjJButtonPasswdCancel = new com.sun.java.swing.JButton();
			ivjJButtonPasswdCancel.setName("JButtonPasswdCancel");
			ivjJButtonPasswdCancel.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJButtonPasswdCancel.setText("\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01");
			ivjJButtonPasswdCancel.setBounds(350, 87, 69, 25);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJButtonPasswdCancel;
}
/**
 * Return the JButtonPaswdOK property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JButton getJButtonPaswdOK() {
	if (ivjJButtonPaswdOK == null) {
		try {
			ivjJButtonPaswdOK = new com.sun.java.swing.JButton();
			ivjJButtonPaswdOK.setName("JButtonPaswdOK");
			ivjJButtonPaswdOK.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJButtonPaswdOK.setText("\u0E15\u0E01\u0E25\u0E07");
			ivjJButtonPaswdOK.setBounds(351, 41, 69, 25);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJButtonPaswdOK;
}
/**
 * Return the JFrameContentPane property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JPanel getJFrameContentPane() {
	if (ivjJFrameContentPane == null) {
		try {
			ivjJFrameContentPane = new com.sun.java.swing.JPanel();
			ivjJFrameContentPane.setName("JFrameContentPane");
			ivjJFrameContentPane.setLayout(null);
			getJFrameContentPane().add(getJPasswordFieldPasswd(), getJPasswordFieldPasswd().getName());
			getJFrameContentPane().add(getJLabelpassword(), getJLabelpassword().getName());
			getJFrameContentPane().add(getJTextFieldUserName(), getJTextFieldUserName().getName());
			getJFrameContentPane().add(getJLabelPasswd(), getJLabelPasswd().getName());
			getJFrameContentPane().add(getJButtonPaswdOK(), getJButtonPaswdOK().getName());
			getJFrameContentPane().add(getJButtonPasswdCancel(), getJButtonPasswdCancel().getName());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJFrameContentPane;
}
/**
 * Return the JLabelPasswd property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JLabel getJLabelPasswd() {
	if (ivjJLabelPasswd == null) {
		try {
			ivjJLabelPasswd = new com.sun.java.swing.JLabel();
			ivjJLabelPasswd.setName("JLabelPasswd");
			ivjJLabelPasswd.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelPasswd.setText("\u0E23\u0E2B\u0E31\u0E2A\u0E19\u0E31\u0E01\u0E28\u0E36\u0E01\u0E29\u0E32 :");
			ivjJLabelPasswd.setBounds(74, 49, 89, 15);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelPasswd;
}
/**
 * Return the JLabelpassword property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JLabel getJLabelpassword() {
	if (ivjJLabelpassword == null) {
		try {
			ivjJLabelpassword = new com.sun.java.swing.JLabel();
			ivjJLabelpassword.setName("JLabelpassword");
			ivjJLabelpassword.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelpassword.setText("\u0E23\u0E2B\u0E31\u0E2A\u0E1C\u0E48\u0E32\u0E19 :");
			ivjJLabelpassword.setBounds(100, 93, 58, 14);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelpassword;
}
/**
 * Return the JPasswordField1 property value.
 * @return com.sun.java.swing.JPasswordField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JPasswordField getJPasswordFieldPasswd() {
	if (ivjJPasswordFieldPasswd == null) {
		try {
			ivjJPasswordFieldPasswd = new com.sun.java.swing.JPasswordField();
			ivjJPasswordFieldPasswd.setName("JPasswordFieldPasswd");
			ivjJPasswordFieldPasswd.setBounds(171, 87, 130, 27);
			// user code begin {1}
			
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJPasswordFieldPasswd;
}
/**
 * Return the JTextField1 property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JTextField getJTextFieldUserName() {
	if (ivjJTextFieldUserName == null) {
		try {
			ivjJTextFieldUserName = new com.sun.java.swing.JTextField();
			ivjJTextFieldUserName.setName("JTextFieldUserName");
			ivjJTextFieldUserName.setBounds(172, 43, 130, 27);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldUserName;
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getPassword() {
	return ivjJPasswordFieldPasswd.getText();
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getUser() {
	return ivjJTextFieldUserName.getText();
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() {
	// user code begin {1}
	// user code end
	getJButtonPaswdOK().addActionListener(this);
	getJButtonPasswdCancel().addActionListener(this);
	getJPasswordFieldPasswd().addActionListener(this);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	// user code begin {1}
	//Table Reg
	aRegisterTableModel = new RegisterTableModel() ;
	aRegisterTableManager = new RegisterTableManager(aRegisterTableModel) ;
	//Table Add
	aAddSubjectTableModel = new AddSubjectTableModel();
	aAddSubjectTableManager = new AddSubjectTableManager(aAddSubjectTableModel);
	//Table Del
	aDelSubjectTableModel = new DelSubjectTableModel();
	aDelSubjectTableManager = new DelSubjectTableManager(aDelSubjectTableModel);
	//Table His
	aHisRegTableModel = new HisRegTableModel();
	aHisRegTableManager = new HisRegTableManager(aHisRegTableModel);
	//Table HisGradeInfo
	aHisGradeInfoTableModel = new HisGradeInfoTableModel();
	aHisGradeInfoTableManager = new HisGradeInfoTableManager(aHisGradeInfoTableModel);
	//Person	
	aPass = new Pass();
	aPassManager = new PassManager(aPass);
	aPassManager.setEntry(); //set Password befor Register
	
	aStudent = new Student();
	aStudentManager = new StudentManager(aStudent);

	aSemester = new Semester();
	aSemesterManager = new SemesterManager(aSemester);

	aRegister_Header = new Register_Header();
	aRegister_HeaderManager = new Register_HeaderManager(aRegister_Header,aStudentManager);
		
	aRegister_Course = new Register_Course();
	aRegister_CourseManager = new Register_CourseManager(aRegister_Course,aRegisterTableManager);

	aSubjects = new Subjects();
	aSubjectsManager = new SubjectsManager(aSubjects,aRegisterTableManager,aAddSubjectTableManager,
		aDelSubjectTableManager,aRegister_CourseManager);

	aRegister_Detail = new Register_Detail();
	aRegister_DetailManager = new Register_DetailManager(aRegister_Detail,aRegisterTableManager,
		aAddSubjectTableManager,aDelSubjectTableManager,aHisRegTableManager,aHisGradeInfoTableManager,
		aSubjectsManager,aRegister_CourseManager);
	
	//UI
	aRegisterOption = new RegisterOption(aUiMain,aFaculty,aYear_Term,aSubjectsManager,
		aRegisterTableModel,aAddSubjectTableModel,aDelSubjectTableModel,this);

	//
	aInformation = new Information(aUiMain,aRegister_DetailManager,aHisRegTableModel,
									aHisGradeInfoTableModel,this);
	//

	aNotFound = new NotFound();
	
	setLocation(170,200);
	// user code end
	setName("Password");
	setDefaultCloseOperation(com.sun.java.swing.WindowConstants.DISPOSE_ON_CLOSE);
	setSize(471, 164);
	setTitle("\u0E1B\u0E49\u0E2D\u0E19\u0E23\u0E2B\u0E31\u0E2A\u0E19\u0E31\u0E01\u0E28\u0E36\u0E01\u0E29\u0E32\u0E41\u0E25\u0E30\u0E23\u0E2B\u0E31\u0E2A\u0E1C\u0E48\u0E32\u0E19");
	setContentPane(getJFrameContentPane());
	initConnections();
	// user code begin {2}
	// user code end
}
/**
 * Comment
 */
public void jButtonPasswdCancel_ActionEvents() {
	String choose = aUiMain.getNeed();
	if(choose.equals("Register"))
		aRegisterOption.show();
	else
		aInformation.show();
		
	setVisible(false);
	dispose();
	return;
}
/**
 * Comment
 */
public void jButtonPaswdOK_ActionEvents() {
	String user = getUser();
	String passwd = getPassword();
	String stdidTextField = aRegisterOption.getStudentId();
	if (aPassManager.checkPassword(user, passwd)) {
		String choose = aUiMain.getNeed(); // what are u need?
		if (choose.equals("Register")) {
			if (aPassManager.isEntry()) {
				
				String faculty = aFaculty.getFaculty();
				String year = aYear_Term.getYear();
				String term = aYear_Term.getTerm();

				//get student
				aStudentManager.getStudent(user, faculty);
				if (aStudentManager.foundStd())
				{
					aRegisterOption.show();
					String stdId = aStudentManager.getStdId();
					String stdName = aStudentManager.getStdName();
					String fac = aStudentManager.getFaculty();
					String dept = aStudentManager.getDepartment();
					aRegisterOption.showInfoStudent(stdId, stdName, fac, dept, year, term);
				
					//get subject
					try {
						aRegister_CourseManager.getConstrainSubjects(stdId, term);
					} catch (SQLException e) {}
				close();
				} //end if aStudent.foundStd()
				
				else {aNotFound.setMessage("\u0E44\u0E21\u0E48\u0E21\u0E35\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E04\u0E13\u0E30\u0E1C\u0E34\u0E14");
					  aNotFound.show();}
				
			//end if aPassManager.isEntry()
			} else {
				int i = aRegisterOption.getChooseTabbedPane();
				//register
				if (i == 0 && checkSameUser(user, stdidTextField)) {
					String stdid = getUser();
					String yr = aYear_Term.getYear();
					String tm = aYear_Term.getTerm();
					try {
						if (aRegister_DetailManager.isTotalCredit12up()) {
							if (!aRegister_DetailManager.registerAlready(stdid, yr, tm)) {
								aRegister_DetailManager.addSubToDBforFirstReg(stdid, yr, tm);
								aSemesterManager.add(stdid,yr,tm);
								//Register_Header
								int totalCrd = aRegister_DetailManager.getTotalCredit(stdid, yr, tm);
								aRegister_HeaderManager.addRegister_Header(stdid, yr, tm, totalCrd);
								int cst_total = aRegister_HeaderManager.getCst_total();
								aRegisterOption.showTotalOfRegister(totalCrd, cst_total);
								aNotFound.setMessage("\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19\u0E40\u0E23\u0E35\u0E22\u0E19\u0E23\u0E49\u0E2D\u0E22");
								aNotFound.show();
								} 
								else {
								aNotFound.setMessage("\u0E04\u0E38\u0E13\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19\u0E41\u0E25\u0E49\u0E27\u0E44\u0E21\u0E48\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E25\u0E07\u0E44\u0E14\u0E49\u0E2D\u0E35\u0E01");
								aNotFound.show();
							}
						} else {
							aNotFound.setMessage("\u0E2B\u0E19\u0E48\u0E27\u0E22\u0E01\u0E34\u0E08\u0E23\u0E27\u0E21\u0E44\u0E21\u0E48\u0E16\u0E36\u0E07  12  \u0E2B\u0E19\u0E48\u0E27\u0E22\u0E44\u0E21\u0E48\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19\u0E44\u0E14\u0E49");
							aNotFound.show();
						}
					} catch (SQLException e) {
					}
					close();
				}
				//add
				else
					if (i == 1 && checkSameUser(user, stdidTextField)) 
					{
						String stdid = getUser();
						String yr = aYear_Term.getYear();
						String tm = aYear_Term.getTerm();
						try {
							if (aRegister_DetailManager.canYouAdd(stdid,yr,tm))
							{
								
								aRegister_DetailManager.addSubToDBforScondReg(stdid, yr, tm);
								int totalCredit = aRegister_DetailManager.getTotalCredit(stdid, yr, tm);
								aRegisterOption.showTotalOfAdd(totalCredit);
								aNotFound.setMessage("\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E27\u0E34\u0E0A\u0E32\u0E40\u0E23\u0E35\u0E22\u0E1A\u0E23\u0E49\u0E2D\u0E22");
								aNotFound.show();
							}
							else{   aNotFound.setMessage("\u0E40\u0E01\u0E34\u0E14\u0E04\u0E27\u0E32\u0E21\u0E0B\u0E49\u0E33\u0E0B\u0E49\u0E2D\u0E19\u0E44\u0E21\u0E48\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E27\u0E34\u0E0A\u0E32\u0E44\u0E14\u0E49");
								aNotFound.show();}
						} catch (SQLException e) {
						}
						close();
					}
					//Delete
					else
						if (i == 2 && checkSameUser(user, stdidTextField)) {
							String stdid = getUser();
							String yr = aYear_Term.getYear();
							String tm = aYear_Term.getTerm();
							try {
									if (aRegister_DetailManager.canYouDel(stdid,yr,tm))
									{
										aRegister_DetailManager.delSubInDB(stdid, yr, tm);
						
										aNotFound.setMessage("\u0E16\u0E2D\u0E19\u0E27\u0E34\u0E0A\u0E32\u0E40\u0E23\u0E35\u0E22\u0E1A\u0E23\u0E49\u0E2D\u0E22");
										aNotFound.show();
									}
									else
									{	aNotFound.setMessage("\u0E44\u0E21\u0E48\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E16\u0E2D\u0E19\u0E27\u0E34\u0E0A\u0E32\u0E44\u0E14\u0E49");
										aNotFound.show();}
							} catch (SQLException e) {
							}
							close();
						} else {
							aNotFound.setMessage("\u0E23\u0E2B\u0E31\u0E2A\u0E1C\u0E39\u0E49\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
							aNotFound.show();
						}
						//get Student	

			} //end else

		} //end if choose
		else
			if (choose.equals("Information")) {
				
				String faculty = aFaculty.getFaculty();
				String year = aYear_Term.getYear();
				String term = aYear_Term.getTerm();
				
				//get student
				aStudentManager.getStudent(user, faculty);
				if (aStudentManager.foundStd())
				{
					aInformation.show();
					
					String stdId = aStudentManager.getStdId();
					String stdName = aStudentManager.getStdName();
					String fac = aStudentManager.getFaculty();
					String dept = aStudentManager.getDepartment();
					aInformation.showInfoStudent(stdId, stdName, fac, dept, year, term);

					//get subject

					try {
					//show detail register
						aRegister_DetailManager.getRegister_Detail(stdId, year, term);

					//show detail grade
						aRegister_DetailManager.getGrade(stdId, year, term);
					//get MetaTotalCredit
						int credit = aRegister_DetailManager.getMetaTotalCredit(stdId, year, term);

					//gpxxx
						aSemesterManager.getGpxxx(stdId, year, term);
						float gps = aSemester.getGps();
						float gpa = aSemester.getGpa();
						aInformation.showGpxxx(gps, gpa, credit);
					} catch (SQLException e) {}
				close();
				} //end aStudent.foundStd()
				else {aNotFound.setMessage("\u0E44\u0E21\u0E48\u0E21\u0E35\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E04\u0E13\u0E30\u0E1C\u0E34\u0E14"); 
					 aNotFound.show();}
			
			} //end if information
	} //end if check pass
	else {
		aNotFound.setMessage("\u0E23\u0E2B\u0E31\u0E2A\u0E1C\u0E48\u0E32\u0E19\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
		aNotFound.show();
	}
	return;
}
/**
 * Comment
 */
public void jPasswordFieldPasswd_ActionEvents() {
	String user = getUser();
	String passwd = getPassword();
	String stdidTextField = aRegisterOption.getStudentId();
	if (aPassManager.checkPassword(user, passwd)) {
		String choose = aUiMain.getNeed(); // what are u need?
		if (choose.equals("Register")) {
			if (aPassManager.isEntry()) {
				
				String faculty = aFaculty.getFaculty();
				String year = aYear_Term.getYear();
				String term = aYear_Term.getTerm();

				//get student
				aStudentManager.getStudent(user, faculty);
				if (aStudentManager.foundStd())
				{
					aRegisterOption.show();
					String stdId = aStudentManager.getStdId();
					String stdName = aStudentManager.getStdName();
					String fac = aStudentManager.getFaculty();
					String dept = aStudentManager.getDepartment();
					aRegisterOption.showInfoStudent(stdId, stdName, fac, dept, year, term);
				
					//get subject
					try {
						aRegister_CourseManager.getConstrainSubjects(stdId, term);
					} catch (SQLException e) {}
				close();
				} //end if aStudent.foundStd()
				
				else {aNotFound.setMessage("\u0E44\u0E21\u0E48\u0E21\u0E35\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E04\u0E13\u0E30\u0E1C\u0E34\u0E14");
					  aNotFound.show();}
				
			//end if aPassManager.isEntry()
			} else {
				int i = aRegisterOption.getChooseTabbedPane();
				//register
				if (i == 0 && checkSameUser(user, stdidTextField)) {
					String stdid = getUser();
					String yr = aYear_Term.getYear();
					String tm = aYear_Term.getTerm();
					try {
						if (aRegister_DetailManager.isTotalCredit12up()) {
							if (!aRegister_DetailManager.registerAlready(stdid, yr, tm)) {
								aRegister_DetailManager.addSubToDBforFirstReg(stdid, yr, tm);
								aSemesterManager.add(stdid,yr,tm);
								//Register_Header
								int totalCrd = aRegister_DetailManager.getTotalCredit(stdid, yr, tm);
								aRegister_HeaderManager.addRegister_Header(stdid, yr, tm, totalCrd);
								int cst_total = aRegister_HeaderManager.getCst_total();
								aRegisterOption.showTotalOfRegister(totalCrd, cst_total);
								aNotFound.setMessage("\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19\u0E40\u0E23\u0E35\u0E22\u0E19\u0E23\u0E49\u0E2D\u0E22");
								aNotFound.show();
								} 
								else {
								aNotFound.setMessage("\u0E04\u0E38\u0E13\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19\u0E41\u0E25\u0E49\u0E27\u0E44\u0E21\u0E48\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E25\u0E07\u0E44\u0E14\u0E49\u0E2D\u0E35\u0E01");
								aNotFound.show();
							}
						} else {
							aNotFound.setMessage("\u0E2B\u0E19\u0E48\u0E27\u0E22\u0E01\u0E34\u0E08\u0E23\u0E27\u0E21\u0E44\u0E21\u0E48\u0E16\u0E36\u0E07  12  \u0E2B\u0E19\u0E48\u0E27\u0E22\u0E44\u0E21\u0E48\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19\u0E44\u0E14\u0E49");
							aNotFound.show();
						}
					} catch (SQLException e) {
					}
					close();
				}
				//add
				else
					if (i == 1 && checkSameUser(user, stdidTextField)) 
					{
						String stdid = getUser();
						String yr = aYear_Term.getYear();
						String tm = aYear_Term.getTerm();
						try {
							if (aRegister_DetailManager.canYouAdd(stdid,yr,tm))
							{
								
								aRegister_DetailManager.addSubToDBforScondReg(stdid, yr, tm);
								int totalCredit = aRegister_DetailManager.getTotalCredit(stdid, yr, tm);
								aRegisterOption.showTotalOfAdd(totalCredit);
								aNotFound.setMessage("\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E27\u0E34\u0E0A\u0E32\u0E40\u0E23\u0E35\u0E22\u0E1A\u0E23\u0E49\u0E2D\u0E22");
								aNotFound.show();
							}
							else{   aNotFound.setMessage("\u0E40\u0E01\u0E34\u0E14\u0E04\u0E27\u0E32\u0E21\u0E0B\u0E49\u0E33\u0E0B\u0E49\u0E2D\u0E19\u0E44\u0E21\u0E48\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E27\u0E34\u0E0A\u0E32\u0E44\u0E14\u0E49");
								aNotFound.show();}
						} catch (SQLException e) {
						}
						close();
					}
					//Delete
					else
						if (i == 2 && checkSameUser(user, stdidTextField)) {
							String stdid = getUser();
							String yr = aYear_Term.getYear();
							String tm = aYear_Term.getTerm();
							try {
									if (aRegister_DetailManager.canYouDel(stdid,yr,tm))
									{
										aRegister_DetailManager.delSubInDB(stdid, yr, tm);
										aNotFound.setMessage("\u0E16\u0E2D\u0E19\u0E27\u0E34\u0E0A\u0E32\u0E40\u0E23\u0E35\u0E22\u0E1A\u0E23\u0E49\u0E2D\u0E22");
										aNotFound.show();
									}
									else
									{	aNotFound.setMessage("\u0E44\u0E21\u0E48\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E16\u0E2D\u0E19\u0E27\u0E34\u0E0A\u0E32\u0E44\u0E14\u0E49");
										aNotFound.show();}
							} catch (SQLException e) {
							}
							close();
						} else {
							aNotFound.setMessage("\u0E23\u0E2B\u0E31\u0E2A\u0E1C\u0E39\u0E49\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
							aNotFound.show();
						}
						//get Student	

			} //end else

		} //end if choose
		else
			if (choose.equals("Information")) {
				
				String faculty = aFaculty.getFaculty();
				String year = aYear_Term.getYear();
				String term = aYear_Term.getTerm();
				
				//get student
				aStudentManager.getStudent(user, faculty);
				if (aStudentManager.foundStd())
				{
					aInformation.show();
					
					String stdId = aStudentManager.getStdId();
					String stdName = aStudentManager.getStdName();
					String fac = aStudentManager.getFaculty();
					String dept = aStudentManager.getDepartment();
					aInformation.showInfoStudent(stdId, stdName, fac, dept, year, term);

					//get subject

					try {
					//show detail register
						aRegister_DetailManager.getRegister_Detail(stdId, year, term);

					//show detail grade
						aRegister_DetailManager.getGrade(stdId, year, term);
					//get MetaTotalCredit
						int credit = aRegister_DetailManager.getMetaTotalCredit(stdId, year, term);

					//gpxxx
						aSemesterManager.getGpxxx(stdId, year, term);
						float gps = aSemester.getGps();
						float gpa = aSemester.getGpa();
						aInformation.showGpxxx(gps, gpa, credit);
					} catch (SQLException e) {}
				close();
				} //end aStudent.foundStd()
				else {aNotFound.setMessage("\u0E44\u0E21\u0E48\u0E21\u0E35\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E04\u0E13\u0E30\u0E1C\u0E34\u0E14"); 
					 aNotFound.show();}
			
			} //end if information
	} //end if check pass
	else {
		aNotFound.setMessage("\u0E23\u0E2B\u0E31\u0E2A\u0E1C\u0E48\u0E32\u0E19\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
		aNotFound.show();
	}
	return;
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		Password aPassword;
		aPassword = new Password();
		try {
			Class aCloserClass = Class.forName("com.ibm.uvm.abt.edit.WindowCloser");
			Class parmTypes[] = { java.awt.Window.class };
			Object parms[] = { aPassword };
			java.lang.reflect.Constructor aCtor = aCloserClass.getConstructor(parmTypes);
			aCtor.newInstance(parms);
		} catch (java.lang.Throwable exc) {};
		aPassword.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of com.sun.java.swing.JFrame");
		exception.printStackTrace(System.out);
	}
}
/**
 * This method was created in VisualAge.
 */
public void setEntry() {
	aPassManager.setEntry();
	aRegister_CourseManager.clearValue();
}
}