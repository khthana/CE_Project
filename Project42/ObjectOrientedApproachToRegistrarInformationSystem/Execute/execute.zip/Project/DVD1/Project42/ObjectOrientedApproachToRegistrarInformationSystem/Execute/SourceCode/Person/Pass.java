package Person;

/**
 * This type was created in VisualAge.
 */

import java.sql.*;
import java.math.*;
import java.io.*;
public class Pass {
	Connection          conn;
	Statement stmt;
	ResultSet rs;
	String strUser="";
	String strPasswd="";
/**
 * Pass constructor comment.
 */
public Pass() {
	super();
}
/**
 * This method was created in VisualAge.
 * @exception java.sql.SQLException The exception description.
 */
public void close() throws SQLException {
	stmt.close();
	rs.close();
	conn.close();
}
/**
 * This method was created in VisualAge.
 * @exception java.sql.SQLException The exception description.
 */
public void connectDB() throws SQLException {
	
	DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());

	 conn =
		DriverManager.getConnection ("jdbc:oracle:thin:@dbserver:1521:orcl","database","0ew,jwfh");
	conn.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
	conn.setAutoCommit(false);
	
}
/**
 * This method was created in VisualAge.
 * @return java.sql.ResultSet
 * @param stdid java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public void getPass(String user,String passwd) throws SQLException{
	
	try
	{
		connectDB();
		
		String query = "SELECT stdid,pass "+
					 "FROM password "+
					 "WHERE stdid = '" +
					 user + "' AND pass = '"+
					 passwd + "'";
		
		
		stmt = conn.createStatement();
		
		rs = stmt.executeQuery(query);	
		ResultSetMetaData rsmd = rs.getMetaData();
		int cols = rsmd.getColumnCount();
		
		while (rs.next())
		{
		
			for(int i=1;i<=cols;i++)
			{
				if (i==1) {strUser = rs.getString(i); }
				else if (i==2) {strPasswd = rs.getString(i);}
				
			}
		}
		close();
	}
	catch (SQLException e) {System.err.println(e.getMessage());}
	
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getPasswd() {
	return strPasswd;
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getUser() {
	return strUser;
}
}