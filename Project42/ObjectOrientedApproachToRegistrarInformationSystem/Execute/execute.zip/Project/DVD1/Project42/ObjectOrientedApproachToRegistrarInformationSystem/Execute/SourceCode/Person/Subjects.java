package Person;

/**
 * This type was created in VisualAge.
 */
import java.sql.*;
import java.math.*;
import java.io.*;
public class Subjects {
		Connection          conn;
		ResultSet 		rs;
		Statement stmt;
		String subId;
		String subName;
		String credit;
		int rows;
	
/**
 * Subjects constructor comment.
 */
public Subjects() {
	super();
}
/**
 * This method was created in VisualAge.
 * @exception java.sql.SQLException The exception description.
 */
public void close() throws SQLException {
	stmt.close();
	rs.close();
	conn.close();
}
/**
 * This method was created in VisualAge.
 * @exception java.sql.SQLException The exception description.
 */
public void connectDB() throws SQLException {
	
	DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());

	conn =
		DriverManager.getConnection ("jdbc:oracle:thin:@dbserver:1521:orcl","database","0ew,jwfh");
	conn.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
	conn.setAutoCommit(false);
	
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getCredit() {
	return credit;
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getSubId() {
	return subId;
}
/**
 * This method was created in VisualAge.
 * @param subid java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public ResultSet getSubjects(String subid) throws java.sql.SQLException {
	try
	{
		connectDB();
		String query = "SELECT subid,ename,credit "+
					 "FROM subject  "+
					 "WHERE subid = '" +
					 subid + "'";
		stmt = conn.createStatement();
		rs = stmt.executeQuery(query);
		
	}
	catch (SQLException e) {}

return rs;
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getSubName() {
	return subName;
}
}