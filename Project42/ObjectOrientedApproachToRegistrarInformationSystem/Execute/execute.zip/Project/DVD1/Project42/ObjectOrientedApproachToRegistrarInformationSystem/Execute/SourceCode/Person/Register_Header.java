package Person;

/**
 * This type was created in VisualAge.
 */
 import java.sql.*;
import java.math.*;
import java.io.*;
public class Register_Header {
	Connection          conn;
	PreparedStatement   pstmt;
	Statement 	stmt;
	ResultSet           rs;
	
/**
 * Register_Header constructor comment.
 */
public Register_Header() {
	super();
}
/**
 * This method was created in VisualAge.
 * @param stdid java.lang.String
 * @param yr java.lang.String
 * @param term java.lang.String
 * @param totalcrd java.lang.String
 * @param freecrd java.lang.String
 * @param cst_credit java.lang.String
 * @param cst_accident java.lang.String
 * @param cst_free java.lang.String
 * @param cst_lib java.lang.String
 * @param cst_health java.lang.String
 * @param cst_activity java.lang.String
 * @param cst_support java.lang.String
 * @param cst_total java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public void addRegister_Header(String stdid,String yr,String term,String regid,int totalcrd,
	int freecrd,int cst_credit,int cst_accident,int cst_free,int cst_lib,
	int cst_health,int cst_activity,int cst_support,int cst_total) throws java.sql.SQLException {
	
	String sql = "INSERT INTO Register_header (stdid,yr,term,regid,totalcrd,freecrd,cst_credit,"+
			"cst_accident,cst_free,cst_lib,cst_health,cst_activity,cst_support,cst_total) "+
			"VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		try {
			connectDB();
		    pstmt = conn.prepareStatement(sql);
			pstmt.setString(1,stdid);
			pstmt.setString(2,yr);
			pstmt.setString(3,term);
			pstmt.setString(4,regid);
			pstmt.setInt(5,totalcrd);
			pstmt.setInt(6,freecrd);
			pstmt.setInt(7,cst_credit);
			pstmt.setInt(8,cst_accident);
			pstmt.setInt(9,cst_free);
			pstmt.setInt(10,cst_lib);
			pstmt.setInt(11,cst_health);
			pstmt.setInt(12,cst_activity);
			pstmt.setInt(13,cst_support);
			pstmt.setInt(14,cst_total);
			pstmt.executeUpdate();
			
			pstmt.close();
			conn.commit();
			conn.close();
			
		}catch (SQLException e) {System.err.println(e.getMessage());}

}
	public void close() throws SQLException {
		stmt.close();
		rs.close();
		conn.close();
	}
/**
 * This method was created in VisualAge.
 * @exception java.sql.SQLException The exception description.
 */
public void connectDB() throws SQLException {
	
	DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());

	conn =
		DriverManager.getConnection ("jdbc:oracle:thin:@dbserver:1521:orcl","database","0ew,jwfh");
	conn.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
	conn.setAutoCommit(false);
	
}
/**
 * This method was created in VisualAge.
 * @return java.sql.ResultSet
 * @param stdid java.lang.String
 * @param yr java.lang.String
 * @param term java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public ResultSet getReg_Header(String stdid,String yr,String term) throws SQLException{
	try
	{
		connectDB();
		String query = "SELECT stdid,yr,term "+
					 "FROM register_header "+
					 "WHERE stdid = '" +
					 stdid + 
					 "' "+
					 "AND yr = '" +
					 yr +
					 "' "+
					 "AND term = '" +
					 term +
					 "'";
		stmt = conn.createStatement();
		rs = stmt.executeQuery(query);
		
		
	}
	catch (SQLException e) {}
	
	
	return rs;
}
}