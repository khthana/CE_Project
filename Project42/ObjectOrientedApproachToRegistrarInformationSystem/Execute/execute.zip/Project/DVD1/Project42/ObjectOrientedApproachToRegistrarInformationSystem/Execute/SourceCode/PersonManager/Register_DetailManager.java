package PersonManager;

/**
 * This type was created in VisualAge.
 */
 import java.sql.*;
import java.math.*;
import java.io.*;
import TableInUseManager.*;
import Person.*;
public class Register_DetailManager {
	private Register_Detail aRegister_Detail;
	private RegisterTableManager aRegisterTableManager;
	private AddSubjectTableManager aAddSubjectTableManager;
	private DelSubjectTableManager aDelSubjectTableManager;
	private HisRegTableManager aHisRegTableManager;
	private HisGradeInfoTableManager aHisGradeInfoTableManager;
	private SubjectsManager aSubjectsManager;
	private Register_CourseManager aRegister_CourseManager;

	
/**
 * Register_DetailManager constructor comment.
 */
public Register_DetailManager() {
	super();
}
/**
 * Register_DetailManager constructor comment.
 */
public Register_DetailManager(Register_Detail rd,RegisterTableManager rtm,AddSubjectTableManager atm,
	DelSubjectTableManager dtm, HisRegTableManager htm,HisGradeInfoTableManager hgitm,
	SubjectsManager sm,Register_CourseManager rcm) {
	super();
	aRegister_Detail = rd;
	aRegisterTableManager = rtm;
	aAddSubjectTableManager = atm;
	aDelSubjectTableManager = dtm;
	aHisRegTableManager = htm;
	aHisGradeInfoTableManager = hgitm;
	aSubjectsManager = sm;
	aRegister_CourseManager = rcm;
	
}
/**
 * This method was created in VisualAge.
 * @return boolean
 * @param stdid java.lang.String
 * @param yr java.lang.String
 * @param term java.lang.String
 * @param ob java.lang.Object
 * @exception java.sql.SQLException The exception description.
 */
public boolean addAlready(String stdid,String yr,String term,Object ob) throws SQLException {
		boolean macth = false;
		String obSubid = (String)ob;
		ResultSet rs = aRegister_Detail.getSubjectId(stdid,yr,term);
		while (rs.next())
		{
				String subid = rs.getString(1);
				
				int m = subid.compareTo(obSubid);
				if (m==0) macth = true;
				
		} //end while
		aRegister_Detail.close();
	
	if (macth)return true;
	else return false;
}
/**
 * This method was created in VisualAge.
 * @param stdid java.lang.String
 * @param yr java.lang.String
 * @param term java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public void addSubToDBforFirstReg(String stdid,String yr,String term) throws java.sql.SQLException {
	
	String subid ="";
	String subname = "";
	int credit = 0;
	String mregid = "1";
	int r=0;
	int c=0;

		
		if(aSubjectsManager.isUseSubjectManager())
		{
			r = aSubjectsManager.getCountRow();
			c = aSubjectsManager.getCountCols();

		}
		else {
			r = aRegister_CourseManager.getCountRow();
			c = aRegister_CourseManager.getCountCols();
		
		}
	
		//getValue and insertValue
	
		int i,j;
		for (i=0;i<r;i++)
		{
		
			for (j=1;j<=c;j++)
			{
				if (j==1){
					Object ob_subId = aRegisterTableManager.getValuesInTable(i,j);
					subid = (String)ob_subId;
					//System.out.println(subid);
					}
				else if (j==2) {
					Object ob_subName = aRegisterTableManager.getValuesInTable(i,j);
					subname = (String)ob_subName;
					//System.out.println(subname);
					}
				else {
					Object ob_credit = aRegisterTableManager.getValuesInTable(i,j);
					String str_credit = (String)ob_credit;
					credit = Integer.parseInt(str_credit);
					
					}
					
			} //end j col

	
			try
			{
				aRegister_Detail.addRegister_Detail(stdid,yr,term,mregid,subid,credit);
			}catch (SQLException e) {}
			
	
		}//end i row


	
	//end insert
}
/**
 * This method was created in VisualAge.
 * @param stdid java.lang.String
 * @param yr java.lang.String
 * @param term java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public void addSubToDBforScondReg(String stdid,String yr,String term) throws SQLException {

	String subid ="";
	String subname = "";
	int credit = 0;
	
	int max = aRegister_Detail.getMaxRegID(stdid); max++;
	
	String mregid = ""+max;
	
	
	int r = aSubjectsManager.getCountRowOfAdd();
	int c = aSubjectsManager.getCountCols();
	
	//getValue and insertValue
	int i,j;
	for (i=0;i<r;i++)
	{
		for (j=1;j<=c;j++)
		{
			if (j==1){
					Object ob_subId = aAddSubjectTableManager.getValuesInTable(i,j);
					subid = (String)ob_subId;
					//System.out.println(subId);
					}
			else if (j==2) {
					Object ob_subName = aAddSubjectTableManager.getValuesInTable(i,j);
					subname = (String)ob_subName;
					//System.out.println(subName);
					}
			else {
					Object ob_credit = aAddSubjectTableManager.getValuesInTable(i,j);
					String str_credit = (String)ob_credit;
					credit = Integer.parseInt(str_credit);
					
					}
					
		} //end j

		try
		{
			
			aRegister_Detail.addRegister_Detail(stdid,yr,term,mregid,subid,credit);
		}
		catch (SQLException e){}
	}//end i
	
	
	//end insert
}
/**
 * This method was created in VisualAge.
 * @return boolean
 */
public boolean canYouAdd(String stdid,String yr,String term) {
	int r = aSubjectsManager.getCountRowOfAdd();
	int i=0;
	boolean found=false;
	
	while(i<r && !found)
	{
		Object ob_subId = aAddSubjectTableManager.getValuesInTable(i,1);
		try
		{
		found = addAlready(stdid,yr,term,ob_subId);
		}catch (SQLException e){}
	i++;
	}
	
	if (found) return false;
	else return true;
}
/**
 * This method was created in VisualAge.
 * @return boolean
 * @param stdid java.lang.String
 * @param yr java.lang.String
 * @param term java.lang.String
 */
public boolean canYouDel(String stdid,String yr,String term) {
	
	int r = aSubjectsManager.getCountRowOfDel();
	int i=0;
	boolean found=true;
	//boolean foundInCourse = false;

	while(i<r && found)
	{
		Object ob_subId = aDelSubjectTableManager.getValuesInTable(i,1);
		try
		{
		found = addAlready(stdid,yr,term,ob_subId);
		//foundInCourse = aRegister_CourseManager.isCourse(stdid,yr,ob_subId);		
		}catch (SQLException e){}
	i++;
	}

	if (found) return true;
	else return false;
}
/**
 * This method was created in VisualAge.
 * @param stdid java.lang.String
 * @param yr java.lang.String
 * @param term java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public void delSubInDB(String stdid,String yr,String term) throws SQLException {
	
	String subid ="";
	
	
	int r = aSubjectsManager.getCountRowOfDel();
	int c = aSubjectsManager.getCountCols();
	//getValue and insertValue
	int i,j;
	for (i=0;i<r;i++)
	{
		for (j=1;j<=c;j++)
		{
			if (j==1){
					Object ob_subId = aDelSubjectTableManager.getValuesInTable(i,j);
					subid = (String)ob_subId;
		
			}
					
		} //end j

		try
		{
			
				aRegister_Detail.deleteRegister_Detail(stdid,yr,term,subid);
			
			
		}
		catch (SQLException e){}
	}//end i
	
	
	//end insert
}
/**
 * This method was created in VisualAge.
 * @param stdid java.lang.String
 * @param yr java.lang.String
 * @param term java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public void getGrade(String stdid,String yr,String term) throws SQLException {
	ResultSet rs = aRegister_Detail.getGrade(stdid,yr,term);
		
		ResultSetMetaData rsmd = rs.getMetaData();
		int countCols = rsmd.getColumnCount();
		int rowInTableHisGrade= -1;
		while (rs.next())
		{
			rowInTableHisGrade++;
			for(int i=1;i<=countCols;i++)
			{
				if (i==1) {String subid = rs.getString(i);
							Object ob = (Object)subid;
							aHisGradeInfoTableManager.setValuesInTable(ob,rowInTableHisGrade,0);}
				else if (i==2){String subname= rs.getString(i);
							Object ob = (Object)subname;
							aHisGradeInfoTableManager.setValuesInTable(ob,rowInTableHisGrade,1); }
				else if (i==3) {int credit = rs.getInt(i);
							String strCredit = ""+credit;
							Object ob = (Object)strCredit;
							aHisGradeInfoTableManager.setValuesInTable(ob,rowInTableHisGrade,2); }
				else {String grade = rs.getString(i);
					Object ob;	
					if (rs.wasNull())
						ob = "";
					else
						ob = (Object)grade;
						aHisGradeInfoTableManager.setValuesInTable(ob,rowInTableHisGrade,3);}
				
				
			}//end i
		} //end while
		aRegister_Detail.close();
	
}
/**
 * This method was created in VisualAge.
 * @return int
 * @param stdid java.lang.String
 * @param yr java.lang.String
 * @param term java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public int getMetaTotalCredit(String stdid,String yr,String term) throws SQLException {
	return aRegister_Detail.metaTotalCredit(stdid,yr,term);
}
/**
 * This method was created in VisualAge.
 * @param stdid java.lang.String
 * @param yr java.lang.String
 * @param term java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public void getRegister_Detail(String stdid,String yr,String term) throws SQLException {
	String exDate="";
	String exBegTime="";
	String exEndTime="";
	String dateAndTime="";
	int tempCol=0;
	ResultSet rs = aRegister_Detail.getReg_detail(stdid,yr,term);
	
		ResultSetMetaData rsmd = rs.getMetaData();
		int countCols = rsmd.getColumnCount(); 
		int rowInTableHis= -1;
		
		while (rs.next())
		{
			rowInTableHis++;
			for(int i=1;i<=countCols;i++)
			{
				
				if (i==1) {String subId = rs.getString(i);
						   Object ob = (Object)subId;
						   aHisRegTableManager.setValuesInTable(ob,rowInTableHis,0);}
				//SubName
				else if (i==2) {String subname = rs.getString(i);		
						   Object ob = (Object)subname;
							aHisRegTableManager.setValuesInTable(ob,rowInTableHis,1);}
				//Credit
				else if (i==3){String credit= rs.getString(i);
							Object ob = (Object)credit;
							aHisRegTableManager.setValuesInTable(ob,rowInTableHis,2); }
				//ExDate
				else if (i==4){exDate = rs.getString(i);	tempCol = 3;	}
				//ExBegTime
				else if (i==5) exBegTime = rs.getString(i);
							
				//ExEndTime
				else {exEndTime = rs.getString(i);
						dateAndTime = exDate+" , "+exBegTime+" - "+exEndTime;
							Object ob = (Object)dateAndTime;
							aHisRegTableManager.setValuesInTable(ob,rowInTableHis,tempCol);}
				
			}//end i
		} //end while
		aRegister_Detail.close();
	
}
/**
 * This method was created in VisualAge.
 * @return int
 * @param stdid java.lang.String
 * @param yr java.lang.String
 * @param term java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public int getTotalCredit(String stdid,String yr,String term) throws SQLException {
		
	return aRegister_Detail.totalCredit(stdid,yr,term);
}
/**
 * This method was created in VisualAge.
 * @return boolean
 */
public boolean isTotalCredit12up() {
	String subid ="";
	String subname = "";
	int tCredit = 0;
	int r =0;
	int c=0;
	if(aSubjectsManager.isUseSubjectManager())
	{
		r = aSubjectsManager.getCountRow();
		c = aSubjectsManager.getCountCols();

	}
	else {
		r = aRegister_CourseManager.getCountRow();
		c = aRegister_CourseManager.getCountCols();
		
	}
	//getValue and checkTotalCredit >=12?
	
	int i,j;
	for (i=0;i<r;i++)
	{
		
		for (j=1;j<=c;j++)
		{
			
			if (j==3) {
					Object ob_credit = aRegisterTableManager.getValuesInTable(i,j);
					String str_credit = (String)ob_credit;
					tCredit += Integer.parseInt(str_credit);
					
					}
					
		} //end j
	}//end i
	
	if (tCredit >= 12) return true;
	else return false;
}
/**
 * This method was created in VisualAge.
 * @return boolean
 * @param stdid java.lang.String
 * @param yr java.lang.String
 * @param term java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public boolean registerAlready(String stdid,String yr,String term) throws SQLException {
		boolean already = false;
		
		ResultSet rs = aRegister_Detail.getReg_detail(stdid,yr,term);
		
		ResultSetMetaData rsmd = rs.getMetaData();
		//int countCols = rsmd.getColumnCount();
		
		while (rs.next())
		{
			//for(int i=1;i<=countCols;i++)
				String subid = rs.getString(1);
				if (!rs.wasNull()) already = true;		
		} //end while
		aRegister_Detail.close();
	if (already) return true;
	else return false;
}
}