package TableInUseManager;

/**
 * This type was created in VisualAge.
 */
import TableInUse.*;
public class RegisterTableManager {
	private RegisterTableModel aRegisterTableModel;
/**
 * RegisterTableManager constructor comment.
 */
public RegisterTableManager() {
	super();
}
/**
 * RegisterTableManager constructor comment.
 */
public RegisterTableManager(RegisterTableModel rtm) {
	super();
	aRegisterTableModel = rtm;
}
/**
 * This method was created in VisualAge.
 */
public void clearTable() {
	aRegisterTableModel.clearTable();
}
/**
 * This method was created in VisualAge.
 * @return java.lang.Object
 * @param row int
 * @param col int
 */
public Object getValuesInTable(int row,int col) {
	Object ob = aRegisterTableModel.getValueAt(row,col);
	return ob;
}
/**
 * This method was created in VisualAge.
 * @param ob java.lang.Object
 */
public void setValuesInTable(Object ob,int row,int col) {
	aRegisterTableModel.setValueAt(ob,row,col);
}
}