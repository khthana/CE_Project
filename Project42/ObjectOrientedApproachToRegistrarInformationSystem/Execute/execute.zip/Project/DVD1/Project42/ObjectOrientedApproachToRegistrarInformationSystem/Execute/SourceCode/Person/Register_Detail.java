package Person;

/**
 * This type was created in VisualAge.
 */
import java.sql.*;
import java.math.*;
import java.io.*;
public class Register_Detail {
	Connection          conn;
	PreparedStatement   pstmt;
	Statement 	stmt;
	ResultSet           rs;

	
/**
 * Register_Detail constructor comment.
 */
public Register_Detail() {
	super();
}
/**
 * This method was created in VisualAge.
 * @param stdid java.lang.String
 * @param yr java.lang.String
 * @param term java.lang.String
 * @param regid java.lang.String
 * @param subid java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public void addRegister_Detail(String stdid,String yr,String term,
	String regid,String subid,int credit) throws SQLException{
	
	String sql = "INSERT INTO Register_Detail (STDID,YR,TERM,REGID,SUBID,CREDIT) VALUES(?,?,?,?,?,?)";
		try {
			connectDB();
		    pstmt = conn.prepareStatement(sql);
			pstmt.setString(1,stdid);
			pstmt.setString(2,yr);
			pstmt.setString(3,term);
			pstmt.setString(4,regid);
			pstmt.setString(5,subid);
			pstmt.setInt(6,credit);
			pstmt.executeUpdate();
			
			pstmt.close();
			conn.commit();
			conn.close();
			
		}catch (SQLException e) {System.err.println(e.getMessage());} 
		
}
	public void close() throws SQLException {
		stmt.close();
		rs.close();
		conn.close();
	}
/**
 * This method was created in VisualAge.
 * @exception java.sql.SQLException The exception description.
 */
public void connectDB() throws SQLException {
	
	DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());

	conn =
		DriverManager.getConnection ("jdbc:oracle:thin:@dbserver:1521:orcl","database","0ew,jwfh");
	conn.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
	conn.setAutoCommit(false);
	
}
/**
 * This method was created in VisualAge.
 * @param stdid java.lang.String
 * @param yr java.lang.String
 * @param term java.lang.String
 * @param regid java.lang.String
 * @param subid java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public void deleteRegister_Detail(String stdid,String yr,String term,
	String subid) throws SQLException {
		String sql =  "DELETE FROM Register_Detail WHERE STDID = ? " +
			"AND YR = ? AND TERM = ? AND SUBID = ?";
		try {
			connectDB();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1,stdid);
			pstmt.setString(2,yr);
			pstmt.setString(3,term);
			pstmt.setString(4,subid);
			pstmt.executeUpdate();
			pstmt.close();
			conn.commit();
			conn.close();
		}catch (SQLException e) {System.err.println(e.getMessage());}
}
/**
 * This method was created in VisualAge.
 * @return java.sql.ResultSet
 * @param stdid java.lang.String
 * @param term java.lang.String
 * @param yr java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public ResultSet getGrade(String stdid,String yr,String term) throws SQLException {
	try
	{
		connectDB();
		String query = "SELECT sub.subid,sub.ename,sub.credit,reg.grade "+
					 "FROM register_detail reg,subject sub  "+
					 "WHERE  reg.subid = sub.subid "+ 
					 "AND stdid = '" +
					 stdid + 
					 "' "+
					 "AND yr = '" +
					 yr +
					 "' "+
					 "AND term = '" +
					 term +
					 "'";
					
		stmt = conn.createStatement();
		rs = stmt.executeQuery(query);
		
		
	}
	catch (SQLException e) {}
	
	
	
	return rs;
}
/**
 * This method was created in VisualAge.
 * @return int
 */
public int getMaxRegID(String stdid) {
	
	int haveData = 0, maxRegId=0;
	try
	{
		connectDB();
		String query = "SELECT max(regid) "+
					 "FROM register_detail "+
					 "WHERE stdid = '" +
					 stdid +  
					 "'";
		
		stmt = conn.createStatement();
		rs = stmt.executeQuery(query);
	
		ResultSetMetaData rsmd = rs.getMetaData();
		int cols = rsmd.getColumnCount(),rows = 0; 
		// row from ResultSet If have result rows++ else rows =0; ***
		
		while (rs.next())
		{
			rows++;  // count row for check meet result or not meet result
			
			for(int i = 1;i<=cols;i++)
			{
				
				String  strMax = rs.getString(i);
				haveData = Integer.parseInt(strMax);
				
			}
			
		}
		
		if (rows == 0) maxRegId = rows;
		else maxRegId = haveData;
		close();

	}
	catch (SQLException e) {System.err.println(e.getMessage());}
	return maxRegId;
	
	
}
/**
 * This method was created in VisualAge.
 * @return java.sql.ResultSet
 * @param stdid java.lang.String
 * @param yr java.lang.String
 * @param term java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public ResultSet getReg_detail(String stdid,String yr,String term) throws SQLException{
	try
	{
		connectDB();
		String query = "SELECT reg.subid,sub.ename,sub.credit,sub.exdate,sub.exbegtime,sub.exendtime "+
					 "FROM register_detail reg,subject sub  "+
					 "WHERE stdid = '" +
					 stdid + 
					 "' "+
					 "AND yr = '" +
					 yr +
					 "' "+
					 "AND term = '" +
					 term +
					 "' "+
					 "AND reg.subid = sub.subid";
		stmt = conn.createStatement();
		rs = stmt.executeQuery(query);
		
	}
	catch (SQLException e) {}
	
	
	return rs;
}
/**
 * This method was created in VisualAge.
 * @return Resultset
 * @param stdid java.lang.String
 * @param yr java.lang.String
 * @param term java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public ResultSet getSubjectId(String stdid,String yr,String term) throws SQLException {
	try
	{
		connectDB();
		String query = "SELECT subid "+
					 "FROM register_detail "+
					 "WHERE stdid = '" +
					 stdid + 
					 "' "+
					 "AND yr = '" +
					 yr +
					 "' "+
					 "AND term = '" +
					 term +
					 "'";
					
		stmt = conn.createStatement();
		rs = stmt.executeQuery(query);
		
	}
	catch (SQLException e) {}
	
	return rs;
}
/**
 * This method was created in VisualAge.
 * @return int
 * @param stdid java.lang.String
 * @param yr java.lang.String
 * @param term java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public int metaTotalCredit(String stdid,String yr,String term) throws SQLException {
	int total=0;		
	 String tc = "";
	try
	{
		connectDB();
		
		String query = "SELECT sum(credit) "+
					 "FROM register_detail "+
					 "WHERE  stdid = '" +
					 stdid +
					 "' "+
					 "AND yr = '" +
					 yr +
					 "' "+
					 "AND term = '" +
					 term +
					 "'";
					
			
		stmt = conn.createStatement();
	
		rs = stmt.executeQuery(query);
	
		while (rs.next ()) 
		{
			tc = rs.getString(1);		
			if (!rs.wasNull())
				total = Integer.parseInt(tc);
			else
			total = 0;
		}
	
		close();
		
	}
	catch (SQLException e) {}
	
	return total;
}
/**
 * This method was created in VisualAge.
 * @return int
 * @exception java.sql.SQLException The exception description.
 */
public int totalCredit(String stdid,String yr,String term) throws SQLException {
	 int total=0;		
	 String tc = "";
	try
	{
		connectDB();
		
		String query = "SELECT sum(credit) "+
					 "FROM register_detail "+
					 "WHERE regid = (select max(regid) from register_detail " +
					  "WHERE  stdid = '" +
					 stdid +
					 "' "+
					 "AND yr = '" +
					 yr +
					 "' "+
					 "AND term = '" +
					 term +
					 "') "+
					
					 "AND stdid = '" +
					 stdid +
					 "' "+
					 "AND yr = '" +
					 yr +
					 "' "+
					 "AND term = '" +
					 term +
					 "'";
					
			
		stmt = conn.createStatement();
	
		rs = stmt.executeQuery(query);
	
		while (rs.next ()) 
		{
			tc = rs.getString(1);		
			if (!rs.wasNull())
				total = Integer.parseInt(tc);
			else
			total = 0;
		}
	
		close();
		
	}
	catch (SQLException e) {}
	
	
	return total;
}
}