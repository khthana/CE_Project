package PersonManager;

/**
 * This type was created in VisualAge.
 */
 import java.sql.*;
import java.math.*;
import java.io.*;
import Person.*;
public class SemesterManager {
	private Semester aSemester;

/**
 * SemesterManager constructor comment.
 */
public SemesterManager() {
	super();
}
/**
 * SemesterManager constructor comment.
 */
public SemesterManager(Semester smt) {
	super();
	aSemester = smt;
}
/**
 * This method was created in VisualAge.
 * @param stdid java.lang.String
 * @param yr java.lang.String
 * @param term java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public void add(String stdid,String yr,String term) throws SQLException {
	aSemester.add(stdid,yr,term);
}
/**
 * This method was created in VisualAge.
 * @param stdid java.lang.String
 * @param yr java.lang.String
 * @param term java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public void getGpxxx(String stdid,String yr,String term) throws SQLException {
	aSemester.getGpxxx(stdid,yr,term);
}
}