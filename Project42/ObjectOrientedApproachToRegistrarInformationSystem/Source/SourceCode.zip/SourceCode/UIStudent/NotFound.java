package UIStudent;

/**
 * This type was created in VisualAge.
 */
public class NotFound extends com.sun.java.swing.JFrame implements java.awt.event.ActionListener {
	private com.sun.java.swing.JButton ivjJButtonAgain = null;
	private com.sun.java.swing.JPanel ivjJFrameContentPane = null;
	//
	private RegisterOption aRegisterOption;
	private com.sun.java.swing.JLabel ivjJLabelMessage = null;
	private com.sun.java.swing.JButton ivjJButtonI = null;
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public NotFound() {
	super();
	initialize();
}
/**
 * NotFound constructor comment.
 * @param title java.lang.String
 */
public NotFound(String title) {
	super(title);
}
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public NotFound(RegisterOption ro) {
	super();
	aRegisterOption = ro;
	initialize();
}
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void actionPerformed(java.awt.event.ActionEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == getJButtonAgain()) ) {
		connEtoC1();
	}
	// user code begin {2}
	// user code end
}
/**
 * connEtoC1:  (JButtonAgain.action. --> NotFound.jButtonAgain_ActionEvents()V)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC1() {
	try {
		// user code begin {1}
		// user code end
		this.jButtonAgain_ActionEvents();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * Return the JButtonAgain property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JButton getJButtonAgain() {
	if (ivjJButtonAgain == null) {
		try {
			ivjJButtonAgain = new com.sun.java.swing.JButton();
			ivjJButtonAgain.setName("JButtonAgain");
			ivjJButtonAgain.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJButtonAgain.setText("\u0E15\u0E01\u0E25\u0E07");
			ivjJButtonAgain.setBackground(java.awt.SystemColor.control);
			ivjJButtonAgain.setBounds(111, 102, 93, 25);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJButtonAgain;
}
/**
 * Return the JButtonI property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JButton getJButtonI() {
	if (ivjJButtonI == null) {
		try {
			ivjJButtonI = new com.sun.java.swing.JButton();
			ivjJButtonI.setName("JButtonI");
			ivjJButtonI.setIcon(new com.sun.java.swing.ImageIcon("E:\\Picture\\VisualAge\\i.jpg"));
			ivjJButtonI.setBorder(new com.sun.java.swing.plaf.metal.MetalMenuBarBorder());
			ivjJButtonI.setText("");
			ivjJButtonI.setBackground(java.awt.SystemColor.control);
			ivjJButtonI.setBounds(55, 5, 73, 50);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJButtonI;
}
/**
 * Return the JFrameContentPane property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JPanel getJFrameContentPane() {
	if (ivjJFrameContentPane == null) {
		try {
			ivjJFrameContentPane = new com.sun.java.swing.JPanel();
			ivjJFrameContentPane.setName("JFrameContentPane");
			ivjJFrameContentPane.setLayout(null);
			ivjJFrameContentPane.setBackground(java.awt.SystemColor.control);
			getJFrameContentPane().add(getJButtonAgain(), getJButtonAgain().getName());
			getJFrameContentPane().add(getJLabelMessage(), getJLabelMessage().getName());
			getJFrameContentPane().add(getJButtonI(), getJButtonI().getName());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJFrameContentPane;
}
/**
 * Return the JLabelMessage property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JLabel getJLabelMessage() {
	if (ivjJLabelMessage == null) {
		try {
			ivjJLabelMessage = new com.sun.java.swing.JLabel();
			ivjJLabelMessage.setName("JLabelMessage");
			ivjJLabelMessage.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelMessage.setText("");
			ivjJLabelMessage.setBounds(15, 58, 285, 14);
			ivjJLabelMessage.setForeground(java.awt.Color.black);
			ivjJLabelMessage.setHorizontalAlignment(com.sun.java.swing.SwingConstants.CENTER);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelMessage;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() {
	// user code begin {1}
	// user code end
	getJButtonAgain().addActionListener(this);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	// user code begin {1}
	setLocation(230,200);
	// user code end
	setName("NotFound");
	setDefaultCloseOperation(com.sun.java.swing.WindowConstants.DISPOSE_ON_CLOSE);
	setSize(315, 165);
	setTitle("information");
	setContentPane(getJFrameContentPane());
	initConnections();
	// user code begin {2}
	// user code end
}
/**
 * Comment
 */
public void jButtonAgain_ActionEvents() {
	
	setVisible(false);
	dispose();
	return;
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		NotFound aNotFound;
		aNotFound = new NotFound();
		try {
			Class aCloserClass = Class.forName("com.ibm.uvm.abt.edit.WindowCloser");
			Class parmTypes[] = { java.awt.Window.class };
			Object parms[] = { aNotFound };
			java.lang.reflect.Constructor aCtor = aCloserClass.getConstructor(parmTypes);
			aCtor.newInstance(parms);
		} catch (java.lang.Throwable exc) {};
		aNotFound.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of com.sun.java.swing.JFrame");
		exception.printStackTrace(System.out);
	}
}
/**
 * This method was created in VisualAge.
 * @param message java.lang.String
 */
public void setMessage(String message) {
	ivjJLabelMessage.setText(message);
	
}
}