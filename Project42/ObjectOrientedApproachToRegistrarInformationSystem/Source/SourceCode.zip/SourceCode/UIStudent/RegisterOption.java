package UIStudent;

/**
 * This type was created in VisualAge.
 */

import com.sun.java.swing.*;
import java.sql.*;
import java.math.*;
import java.io.*;
import java.awt.*;
import TableInUse.*;
import PersonManager.*;


public class RegisterOption extends JFrame implements java.awt.event.ActionListener {
	private JPanel ivjJFrameContentPane = null;
	private JPanel ivjJPanelAddSub = null;
	private JPanel ivjJPanelDelSub = null;
	private JPanel ivjJPanelRegister = null;
	private JTabbedPane ivjJTabbedPaneRegister = null;
	private JLabel ivjJLabelID = null;
	private JLabel ivjJLabelName = null;
	private JTextField ivjJTextFieldID = null;
	private JTextField ivjJTextFieldName = null;
	private JLabel ivjJLabelYear = null;
	private JLabel ivjJLabelBranch = null;
	private JLabel ivjJLabelFaculty = null;
	private JLabel ivjJLabelTerm = null;
	private JTextField ivjJTextFieldBranch = null;
	private JButton ivjJButtonOK = null;
	private JTextField ivjJTextFieldFaculty = null;
	private JTextField ivjJTextFieldYear = null;
	private JTextField ivjJTextFieldTerm = null;
	private JTable ivjScrollPaneTableRegister = null;
	private JLabel ivjJLabelID_Add = null;
	private JLabel ivjJLabelYear_Add = null;
	private JScrollPane ivjJScrollPaneAddSub = null;
	//
	private UiMain aUiMain;
	private Yr_Term aYear_Term;
	private Faculty aFaculty;
	private Password aPassword;
	private NotFound aNotFound;
	private InputSubjectID aInputSubjectID;
	private RegisterTableModel aRegisterTableModel;  //Table reg
	private DelSubjectTableModel aDelSubjectTableModel; //Table del
	private AddSubjectTableModel aAddSubjectTableModel; // Table add
	//manager
	private SubjectsManager aSubjectsManager;
	private JButton ivjDefaultToolBarButton = null;
	private JButton ivjJButtonCancel = null;
	private JMenu ivjJMenuField = null;
	private JMenu ivjJMenuHelp = null;
	private JMenuItem ivjJMenuItemHelp = null;
	private JMenuBar ivjRegisterOptionJMenuBar = null;
	private JLabel ivjJLabelID_DelSub = null;
	private JLabel ivjJLabelName_DelSub = null;
	private JScrollPane ivjJScrollPaneDelSub = null;
	private JScrollPane ivjJScrollPaneRegister = null;
	private JButton ivjJButtonDelSub_Cancel = null;
	private JButton ivjJButtonDelSub_OK = null;
	private JLabel ivjJLabelDept_DelSub = null;
	private JLabel ivjJLabelFac_DelSub = null;
	private JLabel ivjJLabelTerm_DelSub = null;
	private JLabel ivjJLabelYr_DelSub = null;
	private JTextField ivjJTextFieldDept_DelSub = null;
	private JTextField ivjJTextFieldFac_DelSub = null;
	private JTextField ivjJTextFieldName_DelSub = null;
	private JTextField ivjJTextFieldTerm_DelSub = null;
	private JTextField ivjJTextFieldYR_DelSub = null;
	private JTable ivjScrollPaneTableDelSub = null;
	private JTextField ivjJTextFieldID_DelSub = null;
	private JLabel ivjJLabelDept_AddSub = null;
	private JLabel ivjJLabelFaculty_AddSub = null;
	private JLabel ivjJLabelName_AddSub = null;
	private JLabel ivjJLabelTerm_AddSub = null;
	private JMenuItem ivjJMenuItemExit = null;
	private JTextField ivjJTextFieldDept_AddSub = null;
	private JTextField ivjJTextFieldFac_AddSub = null;
	private JTextField ivjJTextFieldID_AddSub = null;
	private JTextField ivjJTextFieldName_AddSub = null;
	private JTextField ivjJTextFieldTerm_AddSub = null;
	private JTextField ivjJTextFieldYR_AddSub = null;
	private JButton ivjJToolBarButtonExit = null;
	private JButton ivjJButtonAddSub_Cancel = null;
	private JButton ivjJButtonAddSub_OK = null;
	private JButton ivjJToolBarButtonMain = null;
	private JTable ivjScrollPaneTableAddSub = null;
	private JToolBar ivjJToolBarMain = null;
	private JLabel ivjJLabelAdd_Total = null;
	private JLabel ivjJLabelRegister_Total = null;
	private JLabel ivjJLabelAdd_Subject = null;
	private JLabel ivjJLabelDelete_Subject = null;
	private JLabel ivjJLabelRegister = null;
//
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public RegisterOption() {
	super();
	initialize();
}
/**
 * RegisterOption constructor comment.
 * @param title java.lang.String
 */
public RegisterOption(String title) {
	super(title);
}
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public RegisterOption(UiMain m,Faculty f,Yr_Term t,SubjectsManager sm,
	RegisterTableModel rtm,AddSubjectTableModel atm,DelSubjectTableModel dtm, Password pw) {
	super();
	aUiMain = m;
	aFaculty = f;
	aYear_Term = t;
	aSubjectsManager = sm;
	aRegisterTableModel = rtm;
	aAddSubjectTableModel = atm;
	aDelSubjectTableModel = dtm;
	aPassword = pw;
	initialize();
}
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void actionPerformed(java.awt.event.ActionEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == getDefaultToolBarButton()) ) {
		connEtoC2();
	}
	if ((e.getSource() == getJButtonOK()) ) {
		connEtoC4();
	}
	if ((e.getSource() == getJButtonCancel()) ) {
		connEtoC5();
	}
	if ((e.getSource() == getJToolBarButtonExit()) ) {
		connEtoC7();
	}
	if ((e.getSource() == getJButtonDelSub_OK()) ) {
		connEtoC8();
	}
	if ((e.getSource() == getJButtonDelSub_Cancel()) ) {
		connEtoC9();
	}
	if ((e.getSource() == getJMenuItemExit()) ) {
		connEtoC3();
	}
	if ((e.getSource() == getJToolBarButtonMain()) ) {
		connEtoC10();
	}
	if ((e.getSource() == getJButtonAddSub_OK()) ) {
		connEtoC12();
	}
	if ((e.getSource() == getJButtonAddSub_Cancel()) ) {
		connEtoC13();
	}
	// user code begin {2}
	// user code end
}
/**
 * connEtoC10:  (JToolBarButtonMain.action. --> RegisterOption.jToolBarButtonMain_ActionEvents()V)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC10() {
	try {
		// user code begin {1}
		// user code end
		this.jToolBarButtonMain_ActionEvents();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC12:  (JButtonAddSub_OK.action. --> RegisterOption.jButtonAddSub_OK_ActionEvents()V)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC12() {
	try {
		// user code begin {1}
		// user code end
		this.jButtonAddSub_OK_ActionEvents();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC13:  (JButtonAddSub_Cancel.action. --> RegisterOption.jButtonAddSub_Cancel_ActionEvents()V)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC13() {
	try {
		// user code begin {1}
		// user code end
		this.jButtonAddSub_Cancel_ActionEvents();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC2:  (DefaultToolBarButton.action. --> RegisterOption.defaultToolBarButton_ActionEvents()V)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC2() {
	try {
		// user code begin {1}
		// user code end
		this.defaultToolBarButton_ActionEvents();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC3:  (JMenuItemExit.action. --> RegisterOption.jMenuItemExit_ActionEvents()V)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC3() {
	try {
		// user code begin {1}
		// user code end
		this.jMenuItemExit_ActionEvents();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC4:  (JButtonOK.action. --> RegisterOption.jButtonOK_ActionEvents()V)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC4() {
	try {
		// user code begin {1}
		// user code end
		this.jButtonOK_ActionEvents();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC5:  (JButtonCancel.action. --> RegisterOption.jButtonCancel_ActionEvents()V)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC5() {
	try {
		// user code begin {1}
		// user code end
		this.jButtonCancel_ActionEvents();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC7:  (JToolBarButton2.action. --> RegisterOption.jToolBarExit_ActionEvents()V)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC7() {
	try {
		// user code begin {1}
		// user code end
		this.jToolBarExit_ActionEvents();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC8:  (JButtonDelSub_OK.action. --> RegisterOption.jButtonDelSub_OK_ActionEvents()V)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC8() {
	try {
		// user code begin {1}
		// user code end
		this.jButtonDelSub_OK_ActionEvents();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC9:  (JButtonDelSub_Cancel.action. --> RegisterOption.jButtonDelSub_Cancel_ActionEvents()V)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC9() {
	try {
		// user code begin {1}
		// user code end
		this.jButtonDelSub_Cancel_ActionEvents();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * Comment
 */
public void defaultToolBarButton_ActionEvents() {
	aInputSubjectID.setVisible(true);
	aInputSubjectID.show();
	return;
}
/**
 * Comment
 */
public void defaultToolBarButton1_ActionEvents() {
	setVisible(false);
	dispose();
	System.exit(0);
	return;
}
/**
 * This method was created in VisualAge.
 * @return int
 */
public int  getChooseTabbedPane() {
	
	return ivjJTabbedPaneRegister.getSelectedIndex();
}
/**
 * Return the DefaultToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getDefaultToolBarButton() {
	if (ivjDefaultToolBarButton == null) {
		try {
			ivjDefaultToolBarButton = new com.sun.java.swing.JButton();
			ivjDefaultToolBarButton.setName("DefaultToolBarButton");
			ivjDefaultToolBarButton.setToolTipText("\u0E1B\u0E49\u0E2D\u0E19\u0E27\u0E34\u0E0A\u0E32");
			ivjDefaultToolBarButton.setBorder(new com.sun.java.swing.plaf.metal.Flush3DBorder());
			ivjDefaultToolBarButton.setText("");
			ivjDefaultToolBarButton.setBackground(new java.awt.Color(206,206,206));
			ivjDefaultToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjDefaultToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjDefaultToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("E:\\Picture\\VisualAge\\INPUTSUB.jpg"));
			ivjDefaultToolBarButton.setFont(new java.awt.Font("dialog", 0, 12));
			ivjDefaultToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDefaultToolBarButton;
}
/**
 * Return the JButtonAddSub_Cancel property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getJButtonAddSub_Cancel() {
	if (ivjJButtonAddSub_Cancel == null) {
		try {
			ivjJButtonAddSub_Cancel = new com.sun.java.swing.JButton();
			ivjJButtonAddSub_Cancel.setName("JButtonAddSub_Cancel");
			ivjJButtonAddSub_Cancel.setIcon(new com.sun.java.swing.ImageIcon("E:\\Picture\\VisualAge\\Cancel.jpg"));
			ivjJButtonAddSub_Cancel.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJButtonAddSub_Cancel.setText("\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01");
			ivjJButtonAddSub_Cancel.setBackground(java.awt.SystemColor.control);
			ivjJButtonAddSub_Cancel.setBounds(448, 427, 117, 25);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJButtonAddSub_Cancel;
}
/**
 * Return the JButtonAddSub_OK property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getJButtonAddSub_OK() {
	if (ivjJButtonAddSub_OK == null) {
		try {
			ivjJButtonAddSub_OK = new com.sun.java.swing.JButton();
			ivjJButtonAddSub_OK.setName("JButtonAddSub_OK");
			ivjJButtonAddSub_OK.setIcon(new com.sun.java.swing.ImageIcon("E:\\Picture\\VisualAge\\OK.jpg"));
			ivjJButtonAddSub_OK.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJButtonAddSub_OK.setText("\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E27\u0E34\u0E0A\u0E32");
			ivjJButtonAddSub_OK.setBackground(java.awt.SystemColor.control);
			ivjJButtonAddSub_OK.setBounds(293, 427, 117, 25);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJButtonAddSub_OK;
}
/**
 * Return the JButton1 property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getJButtonCancel() {
	if (ivjJButtonCancel == null) {
		try {
			ivjJButtonCancel = new com.sun.java.swing.JButton();
			ivjJButtonCancel.setName("JButtonCancel");
			ivjJButtonCancel.setText("\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01");
			ivjJButtonCancel.setBackground(java.awt.SystemColor.control);
			ivjJButtonCancel.setActionCommand("JButtonCancel");
			ivjJButtonCancel.setIcon(new com.sun.java.swing.ImageIcon("E:\\Picture\\VisualAge\\Cancel.jpg"));
			ivjJButtonCancel.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJButtonCancel.setBounds(445, 427, 117, 25);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJButtonCancel;
}
/**
 * Return the JButtonDelSub_Cancel property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getJButtonDelSub_Cancel() {
	if (ivjJButtonDelSub_Cancel == null) {
		try {
			ivjJButtonDelSub_Cancel = new com.sun.java.swing.JButton();
			ivjJButtonDelSub_Cancel.setName("JButtonDelSub_Cancel");
			ivjJButtonDelSub_Cancel.setIcon(new com.sun.java.swing.ImageIcon("E:\\Picture\\VisualAge\\Cancel.jpg"));
			ivjJButtonDelSub_Cancel.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJButtonDelSub_Cancel.setText("\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01");
			ivjJButtonDelSub_Cancel.setBackground(java.awt.SystemColor.control);
			ivjJButtonDelSub_Cancel.setBounds(448, 427, 117, 25);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJButtonDelSub_Cancel;
}
/**
 * Return the JButtonDelSub_OK property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getJButtonDelSub_OK() {
	if (ivjJButtonDelSub_OK == null) {
		try {
			ivjJButtonDelSub_OK = new com.sun.java.swing.JButton();
			ivjJButtonDelSub_OK.setName("JButtonDelSub_OK");
			ivjJButtonDelSub_OK.setIcon(new com.sun.java.swing.ImageIcon("E:\\Picture\\VisualAge\\OK.jpg"));
			ivjJButtonDelSub_OK.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJButtonDelSub_OK.setText("\u0E16\u0E2D\u0E19\u0E27\u0E34\u0E0A\u0E32");
			ivjJButtonDelSub_OK.setBackground(java.awt.SystemColor.control);
			ivjJButtonDelSub_OK.setBounds(293, 427, 117, 25);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJButtonDelSub_OK;
}
/**
 * Return the JButtonOK property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getJButtonOK() {
	if (ivjJButtonOK == null) {
		try {
			ivjJButtonOK = new com.sun.java.swing.JButton();
			ivjJButtonOK.setName("JButtonOK");
			ivjJButtonOK.setIcon(new com.sun.java.swing.ImageIcon("E:\\Picture\\VisualAge\\OK.jpg"));
			ivjJButtonOK.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJButtonOK.setText("\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19");
			ivjJButtonOK.setBackground(java.awt.SystemColor.control);
			ivjJButtonOK.setBounds(290, 427, 125, 25);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJButtonOK;
}
/**
 * Return the JFrameContentPane property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getJFrameContentPane() {
	if (ivjJFrameContentPane == null) {
		try {
			ivjJFrameContentPane = new com.sun.java.swing.JPanel();
			ivjJFrameContentPane.setName("JFrameContentPane");
			ivjJFrameContentPane.setLayout(null);
			ivjJFrameContentPane.setBackground(new java.awt.Color(126,122,120));
			getJFrameContentPane().add(getJTabbedPaneRegister(), getJTabbedPaneRegister().getName());
			getJFrameContentPane().add(getJToolBarMain(), getJToolBarMain().getName());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJFrameContentPane;
}
/**
 * Return the JLabelAdd_Subject property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getJLabelAdd_Subject() {
	if (ivjJLabelAdd_Subject == null) {
		try {
			ivjJLabelAdd_Subject = new com.sun.java.swing.JLabel();
			ivjJLabelAdd_Subject.setName("JLabelAdd_Subject");
			ivjJLabelAdd_Subject.setFont(new java.awt.Font("dialog", 1, 14));
			ivjJLabelAdd_Subject.setText("*****  \u0E40\u0E1E\u0E34\u0E48\u0E21\u0E27\u0E34\u0E0A\u0E32  *****");
			ivjJLabelAdd_Subject.setBounds(292, 132, 229, 14);
			ivjJLabelAdd_Subject.setForeground(java.awt.Color.blue);
			ivjJLabelAdd_Subject.setHorizontalAlignment(com.sun.java.swing.SwingConstants.CENTER);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelAdd_Subject;
}
/**
 * Return the JLabelAdd_Total property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getJLabelAdd_Total() {
	if (ivjJLabelAdd_Total == null) {
		try {
			ivjJLabelAdd_Total = new com.sun.java.swing.JLabel();
			ivjJLabelAdd_Total.setName("JLabelAdd_Total");
			ivjJLabelAdd_Total.setFont(new java.awt.Font("dialog", 1, 14));
			ivjJLabelAdd_Total.setText("");
			ivjJLabelAdd_Total.setBounds(317, 377, 453, 33);
			ivjJLabelAdd_Total.setForeground(java.awt.Color.blue);
			ivjJLabelAdd_Total.setHorizontalAlignment(com.sun.java.swing.SwingConstants.RIGHT);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelAdd_Total;
}
/**
 * Return the JLabelBranch property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getJLabelBranch() {
	if (ivjJLabelBranch == null) {
		try {
			ivjJLabelBranch = new com.sun.java.swing.JLabel();
			ivjJLabelBranch.setName("JLabelBranch");
			ivjJLabelBranch.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelBranch.setText("\u0E20\u0E32\u0E04\u0E27\u0E34\u0E0A\u0E32");
			ivjJLabelBranch.setBounds(318, 81, 46, 14);
			ivjJLabelBranch.setForeground(java.awt.Color.black);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelBranch;
}
/**
 * Return the JLabelDelete_Subject property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getJLabelDelete_Subject() {
	if (ivjJLabelDelete_Subject == null) {
		try {
			ivjJLabelDelete_Subject = new com.sun.java.swing.JLabel();
			ivjJLabelDelete_Subject.setName("JLabelDelete_Subject");
			ivjJLabelDelete_Subject.setFont(new java.awt.Font("dialog", 1, 14));
			ivjJLabelDelete_Subject.setText("*****  \u0E16\u0E2D\u0E19\u0E27\u0E34\u0E0A\u0E32  *****");
			ivjJLabelDelete_Subject.setBounds(293, 132, 212, 14);
			ivjJLabelDelete_Subject.setForeground(java.awt.Color.blue);
			ivjJLabelDelete_Subject.setHorizontalAlignment(com.sun.java.swing.SwingConstants.CENTER);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelDelete_Subject;
}
/**
 * Return the JLabelBranch_Add property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getJLabelDept_AddSub() {
	if (ivjJLabelDept_AddSub == null) {
		try {
			ivjJLabelDept_AddSub = new com.sun.java.swing.JLabel();
			ivjJLabelDept_AddSub.setName("JLabelDept_AddSub");
			ivjJLabelDept_AddSub.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelDept_AddSub.setText("\u0E20\u0E32\u0E04\u0E27\u0E34\u0E0A\u0E32");
			ivjJLabelDept_AddSub.setBounds(318, 81, 46, 14);
			ivjJLabelDept_AddSub.setForeground(java.awt.Color.black);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelDept_AddSub;
}
/**
 * Return the JLabelDept_DelSub property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getJLabelDept_DelSub() {
	if (ivjJLabelDept_DelSub == null) {
		try {
			ivjJLabelDept_DelSub = new com.sun.java.swing.JLabel();
			ivjJLabelDept_DelSub.setName("JLabelDept_DelSub");
			ivjJLabelDept_DelSub.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelDept_DelSub.setText("\u0E20\u0E32\u0E04\u0E27\u0E34\u0E0A\u0E32");
			ivjJLabelDept_DelSub.setBounds(318, 81, 46, 14);
			ivjJLabelDept_DelSub.setForeground(java.awt.Color.black);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelDept_DelSub;
}
/**
 * Return the JLabelFac_DelSub property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getJLabelFac_DelSub() {
	if (ivjJLabelFac_DelSub == null) {
		try {
			ivjJLabelFac_DelSub = new com.sun.java.swing.JLabel();
			ivjJLabelFac_DelSub.setName("JLabelFac_DelSub");
			ivjJLabelFac_DelSub.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelFac_DelSub.setText("\u0E04\u0E13\u0E30");
			ivjJLabelFac_DelSub.setBounds(60, 80, 46, 14);
			ivjJLabelFac_DelSub.setForeground(java.awt.Color.black);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelFac_DelSub;
}
/**
 * Return the JLabelFaculty property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getJLabelFaculty() {
	if (ivjJLabelFaculty == null) {
		try {
			ivjJLabelFaculty = new com.sun.java.swing.JLabel();
			ivjJLabelFaculty.setName("JLabelFaculty");
			ivjJLabelFaculty.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelFaculty.setText("\u0E04\u0E13\u0E30");
			ivjJLabelFaculty.setBounds(60, 80, 46, 14);
			ivjJLabelFaculty.setForeground(java.awt.Color.black);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelFaculty;
}
/**
 * Return the JLabelFaculty_Add property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getJLabelFaculty_AddSub() {
	if (ivjJLabelFaculty_AddSub == null) {
		try {
			ivjJLabelFaculty_AddSub = new com.sun.java.swing.JLabel();
			ivjJLabelFaculty_AddSub.setName("JLabelFaculty_AddSub");
			ivjJLabelFaculty_AddSub.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelFaculty_AddSub.setText("\u0E04\u0E13\u0E30");
			ivjJLabelFaculty_AddSub.setBounds(60, 80, 46, 14);
			ivjJLabelFaculty_AddSub.setForeground(java.awt.Color.black);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelFaculty_AddSub;
}
/**
 * Return the JLabelID property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getJLabelID() {
	if (ivjJLabelID == null) {
		try {
			ivjJLabelID = new com.sun.java.swing.JLabel();
			ivjJLabelID.setName("JLabelID");
			ivjJLabelID.setText("\u0E23\u0E2B\u0E31\u0E2A");
			ivjJLabelID.setForeground(java.awt.Color.black);
			ivjJLabelID.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjJLabelID.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelID.setBounds(33, 35, 46, 14);
			ivjJLabelID.setHorizontalAlignment(com.sun.java.swing.SwingConstants.CENTER);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelID;
}
/**
 * Return the JLabelID_Add property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getJLabelID_Add() {
	if (ivjJLabelID_Add == null) {
		try {
			ivjJLabelID_Add = new com.sun.java.swing.JLabel();
			ivjJLabelID_Add.setName("JLabelID_Add");
			ivjJLabelID_Add.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelID_Add.setText("\u0E23\u0E2B\u0E31\u0E2A");
			ivjJLabelID_Add.setBounds(33, 35, 46, 14);
			ivjJLabelID_Add.setForeground(java.awt.Color.black);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelID_Add;
}
/**
 * Return the JLabelID_DelSub property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getJLabelID_DelSub() {
	if (ivjJLabelID_DelSub == null) {
		try {
			ivjJLabelID_DelSub = new com.sun.java.swing.JLabel();
			ivjJLabelID_DelSub.setName("JLabelID_DelSub");
			ivjJLabelID_DelSub.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelID_DelSub.setText("\u0E23\u0E2B\u0E31\u0E2A");
			ivjJLabelID_DelSub.setBounds(33, 35, 46, 14);
			ivjJLabelID_DelSub.setForeground(java.awt.Color.black);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelID_DelSub;
}
/**
 * Return the JLabelName property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getJLabelName() {
	if (ivjJLabelName == null) {
		try {
			ivjJLabelName = new com.sun.java.swing.JLabel();
			ivjJLabelName.setName("JLabelName");
			ivjJLabelName.setText("\u0E0A\u0E37\u0E48\u0E2D\u0E41\u0E25\u0E30\u0E19\u0E32\u0E21\u0E2A\u0E01\u0E38\u0E25");
			ivjJLabelName.setForeground(java.awt.Color.black);
			ivjJLabelName.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjJLabelName.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelName.setBounds(225, 34, 80, 14);
			ivjJLabelName.setHorizontalAlignment(com.sun.java.swing.SwingConstants.CENTER);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelName;
}
/**
 * Return the JLabelName_Add property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getJLabelName_AddSub() {
	if (ivjJLabelName_AddSub == null) {
		try {
			ivjJLabelName_AddSub = new com.sun.java.swing.JLabel();
			ivjJLabelName_AddSub.setName("JLabelName_AddSub");
			ivjJLabelName_AddSub.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelName_AddSub.setText("\u0E0A\u0E37\u0E48\u0E2D\u0E41\u0E25\u0E30\u0E19\u0E32\u0E21\u0E2A\u0E01\u0E38\u0E25");
			ivjJLabelName_AddSub.setBounds(225, 34, 80, 14);
			ivjJLabelName_AddSub.setForeground(java.awt.Color.black);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelName_AddSub;
}
/**
 * Return the JLabelName_DelSub property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getJLabelName_DelSub() {
	if (ivjJLabelName_DelSub == null) {
		try {
			ivjJLabelName_DelSub = new com.sun.java.swing.JLabel();
			ivjJLabelName_DelSub.setName("JLabelName_DelSub");
			ivjJLabelName_DelSub.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelName_DelSub.setText("\u0E0A\u0E37\u0E48\u0E2D\u0E41\u0E25\u0E30\u0E19\u0E32\u0E21\u0E2A\u0E01\u0E38\u0E25");
			ivjJLabelName_DelSub.setBounds(225, 34, 80, 14);
			ivjJLabelName_DelSub.setForeground(java.awt.Color.black);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelName_DelSub;
}
/**
 * Return the JLabelRegister property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getJLabelRegister() {
	if (ivjJLabelRegister == null) {
		try {
			ivjJLabelRegister = new com.sun.java.swing.JLabel();
			ivjJLabelRegister.setName("JLabelRegister");
			ivjJLabelRegister.setFont(new java.awt.Font("dialog", 1, 14));
			ivjJLabelRegister.setText("*****  \u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19 *****");
			ivjJLabelRegister.setBounds(260, 132, 270, 14);
			ivjJLabelRegister.setForeground(java.awt.Color.blue);
			ivjJLabelRegister.setHorizontalAlignment(com.sun.java.swing.SwingConstants.CENTER);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelRegister;
}
/**
 * Return the JLabelRegister_Total property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getJLabelRegister_Total() {
	if (ivjJLabelRegister_Total == null) {
		try {
			ivjJLabelRegister_Total = new com.sun.java.swing.JLabel();
			ivjJLabelRegister_Total.setName("JLabelRegister_Total");
			ivjJLabelRegister_Total.setFont(new java.awt.Font("dialog", 1, 14));
			ivjJLabelRegister_Total.setText("");
			ivjJLabelRegister_Total.setBounds(306, 387, 446, 30);
			ivjJLabelRegister_Total.setForeground(java.awt.Color.blue);
			ivjJLabelRegister_Total.setHorizontalAlignment(com.sun.java.swing.SwingConstants.RIGHT);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelRegister_Total;
}
/**
 * Return the JLabelTerm property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getJLabelTerm() {
	if (ivjJLabelTerm == null) {
		try {
			ivjJLabelTerm = new com.sun.java.swing.JLabel();
			ivjJLabelTerm.setName("JLabelTerm");
			ivjJLabelTerm.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelTerm.setText("\u0E40\u0E17\u0E2D\u0E21");
			ivjJLabelTerm.setBounds(600, 80, 46, 14);
			ivjJLabelTerm.setForeground(java.awt.Color.black);
			ivjJLabelTerm.setHorizontalAlignment(com.sun.java.swing.SwingConstants.RIGHT);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelTerm;
}
/**
 * Return the JLabel2 property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getJLabelTerm_AddSub() {
	if (ivjJLabelTerm_AddSub == null) {
		try {
			ivjJLabelTerm_AddSub = new com.sun.java.swing.JLabel();
			ivjJLabelTerm_AddSub.setName("JLabelTerm_AddSub");
			ivjJLabelTerm_AddSub.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelTerm_AddSub.setText("\u0E40\u0E17\u0E2D\u0E21");
			ivjJLabelTerm_AddSub.setBounds(600, 80, 46, 14);
			ivjJLabelTerm_AddSub.setForeground(java.awt.Color.black);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelTerm_AddSub;
}
/**
 * Return the JLabelTerm_DelSub property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getJLabelTerm_DelSub() {
	if (ivjJLabelTerm_DelSub == null) {
		try {
			ivjJLabelTerm_DelSub = new com.sun.java.swing.JLabel();
			ivjJLabelTerm_DelSub.setName("JLabelTerm_DelSub");
			ivjJLabelTerm_DelSub.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelTerm_DelSub.setText("\u0E40\u0E17\u0E2D\u0E21");
			ivjJLabelTerm_DelSub.setBounds(600, 80, 46, 14);
			ivjJLabelTerm_DelSub.setForeground(java.awt.Color.black);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelTerm_DelSub;
}
/**
 * Return the JLabelYear property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getJLabelYear() {
	if (ivjJLabelYear == null) {
		try {
			ivjJLabelYear = new com.sun.java.swing.JLabel();
			ivjJLabelYear.setName("JLabelYear");
			ivjJLabelYear.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelYear.setText("\u0E1B\u0E35\u0E01\u0E32\u0E23\u0E28\u0E36\u0E01\u0E29\u0E32");
			ivjJLabelYear.setBounds(590, 33, 70, 14);
			ivjJLabelYear.setForeground(java.awt.Color.black);
			ivjJLabelYear.setHorizontalAlignment(com.sun.java.swing.SwingConstants.CENTER);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelYear;
}
/**
 * Return the JLabelYear_Add property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getJLabelYear_Add() {
	if (ivjJLabelYear_Add == null) {
		try {
			ivjJLabelYear_Add = new com.sun.java.swing.JLabel();
			ivjJLabelYear_Add.setName("JLabelYear_Add");
			ivjJLabelYear_Add.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelYear_Add.setText("\u0E1B\u0E35\u0E01\u0E32\u0E23\u0E28\u0E36\u0E01\u0E29\u0E32");
			ivjJLabelYear_Add.setBounds(590, 33, 70, 14);
			ivjJLabelYear_Add.setForeground(java.awt.Color.black);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelYear_Add;
}
/**
 * Return the JLabelYr_DelSub property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getJLabelYr_DelSub() {
	if (ivjJLabelYr_DelSub == null) {
		try {
			ivjJLabelYr_DelSub = new com.sun.java.swing.JLabel();
			ivjJLabelYr_DelSub.setName("JLabelYr_DelSub");
			ivjJLabelYr_DelSub.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelYr_DelSub.setText("\u0E1B\u0E35\u0E01\u0E32\u0E23\u0E28\u0E36\u0E01\u0E29\u0E32");
			ivjJLabelYr_DelSub.setBounds(590, 33, 70, 14);
			ivjJLabelYr_DelSub.setForeground(java.awt.Color.black);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelYr_DelSub;
}
/**
 * Return the JMenuField property value.
 * @return com.sun.java.swing.JMenu
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JMenu getJMenuField() {
	if (ivjJMenuField == null) {
		try {
			ivjJMenuField = new com.sun.java.swing.JMenu();
			ivjJMenuField.setName("JMenuField");
			ivjJMenuField.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJMenuField.setText("File");
			ivjJMenuField.add(getJMenuItemExit());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJMenuField;
}
/**
 * Return the JMenuHelp property value.
 * @return com.sun.java.swing.JMenu
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JMenu getJMenuHelp() {
	if (ivjJMenuHelp == null) {
		try {
			ivjJMenuHelp = new com.sun.java.swing.JMenu();
			ivjJMenuHelp.setName("JMenuHelp");
			ivjJMenuHelp.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJMenuHelp.setText("Help");
			ivjJMenuHelp.add(getJMenuItemHelp());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJMenuHelp;
}
/**
 * Return the JMenuItem1 property value.
 * @return com.sun.java.swing.JMenuItem
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JMenuItem getJMenuItemExit() {
	if (ivjJMenuItemExit == null) {
		try {
			ivjJMenuItemExit = new com.sun.java.swing.JMenuItem();
			ivjJMenuItemExit.setName("JMenuItemExit");
			ivjJMenuItemExit.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJMenuItemExit.setText("Exit");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJMenuItemExit;
}
/**
 * Return the JMenuItemHelp property value.
 * @return com.sun.java.swing.JMenuItem
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JMenuItem getJMenuItemHelp() {
	if (ivjJMenuItemHelp == null) {
		try {
			ivjJMenuItemHelp = new com.sun.java.swing.JMenuItem();
			ivjJMenuItemHelp.setName("JMenuItemHelp");
			ivjJMenuItemHelp.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJMenuItemHelp.setText("About");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJMenuItemHelp;
}
/**
 * Return the JPanelAddSub property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getJPanelAddSub() {
	if (ivjJPanelAddSub == null) {
		try {
			ivjJPanelAddSub = new com.sun.java.swing.JPanel();
			ivjJPanelAddSub.setName("JPanelAddSub");
			ivjJPanelAddSub.setLayout(null);
			ivjJPanelAddSub.setBackground(java.awt.SystemColor.control);
			getJPanelAddSub().add(getJLabelID_Add(), getJLabelID_Add().getName());
			getJPanelAddSub().add(getJTextFieldID_AddSub(), getJTextFieldID_AddSub().getName());
			getJPanelAddSub().add(getJLabelName_AddSub(), getJLabelName_AddSub().getName());
			getJPanelAddSub().add(getJTextFieldName_AddSub(), getJTextFieldName_AddSub().getName());
			getJPanelAddSub().add(getJLabelYear_Add(), getJLabelYear_Add().getName());
			getJPanelAddSub().add(getJTextFieldYR_AddSub(), getJTextFieldYR_AddSub().getName());
			getJPanelAddSub().add(getJLabelFaculty_AddSub(), getJLabelFaculty_AddSub().getName());
			getJPanelAddSub().add(getJTextFieldFac_AddSub(), getJTextFieldFac_AddSub().getName());
			getJPanelAddSub().add(getJLabelDept_AddSub(), getJLabelDept_AddSub().getName());
			getJPanelAddSub().add(getJTextFieldDept_AddSub(), getJTextFieldDept_AddSub().getName());
			getJPanelAddSub().add(getJLabelTerm_AddSub(), getJLabelTerm_AddSub().getName());
			getJPanelAddSub().add(getJTextFieldTerm_AddSub(), getJTextFieldTerm_AddSub().getName());
			getJPanelAddSub().add(getJButtonAddSub_OK(), getJButtonAddSub_OK().getName());
			getJPanelAddSub().add(getJButtonAddSub_Cancel(), getJButtonAddSub_Cancel().getName());
			getJPanelAddSub().add(getJScrollPaneAddSub(), getJScrollPaneAddSub().getName());
			getJPanelAddSub().add(getJLabelAdd_Total(), getJLabelAdd_Total().getName());
			getJPanelAddSub().add(getJLabelAdd_Subject(), getJLabelAdd_Subject().getName());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJPanelAddSub;
}
/**
 * Return the JPanelDelSub property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getJPanelDelSub() {
	if (ivjJPanelDelSub == null) {
		try {
			ivjJPanelDelSub = new com.sun.java.swing.JPanel();
			ivjJPanelDelSub.setName("JPanelDelSub");
			ivjJPanelDelSub.setLayout(null);
			ivjJPanelDelSub.setBackground(java.awt.SystemColor.control);
			getJPanelDelSub().add(getJScrollPaneDelSub(), getJScrollPaneDelSub().getName());
			getJPanelDelSub().add(getJTextFieldID_DelSub(), getJTextFieldID_DelSub().getName());
			getJPanelDelSub().add(getJLabelID_DelSub(), getJLabelID_DelSub().getName());
			getJPanelDelSub().add(getJLabelName_DelSub(), getJLabelName_DelSub().getName());
			getJPanelDelSub().add(getJTextFieldName_DelSub(), getJTextFieldName_DelSub().getName());
			getJPanelDelSub().add(getJLabelYr_DelSub(), getJLabelYr_DelSub().getName());
			getJPanelDelSub().add(getJTextFieldYR_DelSub(), getJTextFieldYR_DelSub().getName());
			getJPanelDelSub().add(getJTextFieldTerm_DelSub(), getJTextFieldTerm_DelSub().getName());
			getJPanelDelSub().add(getJLabelTerm_DelSub(), getJLabelTerm_DelSub().getName());
			getJPanelDelSub().add(getJTextFieldDept_DelSub(), getJTextFieldDept_DelSub().getName());
			getJPanelDelSub().add(getJLabelDept_DelSub(), getJLabelDept_DelSub().getName());
			getJPanelDelSub().add(getJTextFieldFac_DelSub(), getJTextFieldFac_DelSub().getName());
			getJPanelDelSub().add(getJLabelFac_DelSub(), getJLabelFac_DelSub().getName());
			getJPanelDelSub().add(getJButtonDelSub_Cancel(), getJButtonDelSub_Cancel().getName());
			getJPanelDelSub().add(getJButtonDelSub_OK(), getJButtonDelSub_OK().getName());
			getJPanelDelSub().add(getJLabelDelete_Subject(), getJLabelDelete_Subject().getName());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJPanelDelSub;
}
/**
 * Return the PageRegister property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getJPanelRegister() {
	if (ivjJPanelRegister == null) {
		try {
			ivjJPanelRegister = new com.sun.java.swing.JPanel();
			ivjJPanelRegister.setName("JPanelRegister");
			ivjJPanelRegister.setToolTipText("");
			ivjJPanelRegister.setLayout(null);
			ivjJPanelRegister.setBackground(java.awt.SystemColor.control);
			ivjJPanelRegister.setMaximumSize(new java.awt.Dimension(0, 0));
			ivjJPanelRegister.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJPanelRegister.setMinimumSize(new java.awt.Dimension(0, 0));
			getJPanelRegister().add(getJLabelID(), getJLabelID().getName());
			getJPanelRegister().add(getJTextFieldID(), getJTextFieldID().getName());
			getJPanelRegister().add(getJLabelName(), getJLabelName().getName());
			getJPanelRegister().add(getJTextFieldName(), getJTextFieldName().getName());
			getJPanelRegister().add(getJLabelYear(), getJLabelYear().getName());
			getJPanelRegister().add(getJTextFieldYear(), getJTextFieldYear().getName());
			getJPanelRegister().add(getJLabelFaculty(), getJLabelFaculty().getName());
			getJPanelRegister().add(getJTextFieldFaculty(), getJTextFieldFaculty().getName());
			getJPanelRegister().add(getJLabelBranch(), getJLabelBranch().getName());
			getJPanelRegister().add(getJTextFieldBranch(), getJTextFieldBranch().getName());
			getJPanelRegister().add(getJLabelTerm(), getJLabelTerm().getName());
			getJPanelRegister().add(getJTextFieldTerm(), getJTextFieldTerm().getName());
			getJPanelRegister().add(getJButtonOK(), getJButtonOK().getName());
			getJPanelRegister().add(getJButtonCancel(), getJButtonCancel().getName());
			getJPanelRegister().add(getJScrollPaneRegister(), getJScrollPaneRegister().getName());
			getJPanelRegister().add(getJLabelRegister_Total(), getJLabelRegister_Total().getName());
			getJPanelRegister().add(getJLabelRegister(), getJLabelRegister().getName());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJPanelRegister;
}
/**
 * Return the JScrollPaneAddSub property value.
 * @return com.sun.java.swing.JScrollPane
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JScrollPane getJScrollPaneAddSub() {
	if (ivjJScrollPaneAddSub == null) {
		try {
			ivjJScrollPaneAddSub = new com.sun.java.swing.JScrollPane();
			ivjJScrollPaneAddSub.setName("JScrollPaneAddSub");
			ivjJScrollPaneAddSub.setVerticalScrollBarPolicy(com.sun.java.swing.JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
			ivjJScrollPaneAddSub.setHorizontalScrollBarPolicy(com.sun.java.swing.JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
			ivjJScrollPaneAddSub.setFont(new java.awt.Font("dialog", 0, 14));
			ivjJScrollPaneAddSub.setBackground(java.awt.Color.cyan);
			ivjJScrollPaneAddSub.setBounds(51, 157, 720, 200);
			getJScrollPaneAddSub().setViewportView(getScrollPaneTableAddSub());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJScrollPaneAddSub;
}
/**
 * Return the JScrollPaneDelSub property value.
 * @return com.sun.java.swing.JScrollPane
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JScrollPane getJScrollPaneDelSub() {
	if (ivjJScrollPaneDelSub == null) {
		try {
			ivjJScrollPaneDelSub = new com.sun.java.swing.JScrollPane();
			ivjJScrollPaneDelSub.setName("JScrollPaneDelSub");
			ivjJScrollPaneDelSub.setVerticalScrollBarPolicy(com.sun.java.swing.JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
			ivjJScrollPaneDelSub.setHorizontalScrollBarPolicy(com.sun.java.swing.JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
			ivjJScrollPaneDelSub.setFont(new java.awt.Font("dialog", 0, 14));
			ivjJScrollPaneDelSub.setBackground(java.awt.Color.cyan);
			ivjJScrollPaneDelSub.setBounds(51, 157, 720, 200);
			getJScrollPaneDelSub().setViewportView(getScrollPaneTableDelSub());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJScrollPaneDelSub;
}
/**
 * Return the JScrollPane1 property value.
 * @return com.sun.java.swing.JScrollPane
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JScrollPane getJScrollPaneRegister() {
	if (ivjJScrollPaneRegister == null) {
		try {
			ivjJScrollPaneRegister = new com.sun.java.swing.JScrollPane();
			ivjJScrollPaneRegister.setName("JScrollPaneRegister");
			ivjJScrollPaneRegister.setVerticalScrollBarPolicy(com.sun.java.swing.JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
			ivjJScrollPaneRegister.setHorizontalScrollBarPolicy(com.sun.java.swing.JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
			ivjJScrollPaneRegister.setBackground(java.awt.Color.cyan);
			ivjJScrollPaneRegister.setBounds(51, 157, 720, 200);
			getJScrollPaneRegister().setViewportView(getScrollPaneTableRegister());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJScrollPaneRegister;
}
/**
 * Return the JTabbedPaneStd property value.
 * @return com.sun.java.swing.JTabbedPane
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTabbedPane getJTabbedPaneRegister() {
	if (ivjJTabbedPaneRegister == null) {
		try {
			ivjJTabbedPaneRegister = new com.sun.java.swing.JTabbedPane();
			ivjJTabbedPaneRegister.setName("JTabbedPaneRegister");
			ivjJTabbedPaneRegister.setAutoscrolls(false);
			ivjJTabbedPaneRegister.setAlignmentY(0.5F);
			ivjJTabbedPaneRegister.setBackground(new java.awt.Color(204,204,204));
			ivjJTabbedPaneRegister.setTabPlacement(com.sun.java.swing.JTabbedPane.TOP);
			ivjJTabbedPaneRegister.setFont(new java.awt.Font("dialoginput", 1, 12));
			ivjJTabbedPaneRegister.setBounds(0, 45, 800, 523);
			ivjJTabbedPaneRegister.setMinimumSize(new java.awt.Dimension(5, 31));
			ivjJTabbedPaneRegister.insertTab("Register", new com.sun.java.swing.ImageIcon("E:\\Picture\\jpg\\Reg.jpg"), getJPanelRegister(), "\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19", 0);
			ivjJTabbedPaneRegister.setBackgroundAt(0, java.awt.SystemColor.control);
			ivjJTabbedPaneRegister.insertTab("Add  Subject", new com.sun.java.swing.ImageIcon("E:\\Picture\\VisualAge\\Add.jpg"), getJPanelAddSub(), "\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E27\u0E34\u0E0A\u0E32", 1);
			ivjJTabbedPaneRegister.setBackgroundAt(1, java.awt.SystemColor.control);
			ivjJTabbedPaneRegister.insertTab("Delete  Subject", new com.sun.java.swing.ImageIcon("E:\\Picture\\VisualAge\\Del.jpg"), getJPanelDelSub(), "\u0E16\u0E2D\u0E19\u0E27\u0E34\u0E0A\u0E32", 2);
			ivjJTabbedPaneRegister.setBackgroundAt(2, java.awt.SystemColor.control);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTabbedPaneRegister;
}
/**
 * Return the JTextFieldBranch property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getJTextFieldBranch() {
	if (ivjJTextFieldBranch == null) {
		try {
			ivjJTextFieldBranch = new com.sun.java.swing.JTextField();
			ivjJTextFieldBranch.setName("JTextFieldBranch");
			ivjJTextFieldBranch.setBackground(java.awt.Color.white);
			ivjJTextFieldBranch.setBounds(370, 80, 180, 18);
			ivjJTextFieldBranch.setEditable(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldBranch;
}
/**
 * Return the JTextFieldBranch_Add property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getJTextFieldDept_AddSub() {
	if (ivjJTextFieldDept_AddSub == null) {
		try {
			ivjJTextFieldDept_AddSub = new com.sun.java.swing.JTextField();
			ivjJTextFieldDept_AddSub.setName("JTextFieldDept_AddSub");
			ivjJTextFieldDept_AddSub.setBackground(java.awt.Color.white);
			ivjJTextFieldDept_AddSub.setBounds(370, 80, 180, 18);
			ivjJTextFieldDept_AddSub.setEditable(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldDept_AddSub;
}
/**
 * Return the JTextFieldDept_DelSub property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getJTextFieldDept_DelSub() {
	if (ivjJTextFieldDept_DelSub == null) {
		try {
			ivjJTextFieldDept_DelSub = new com.sun.java.swing.JTextField();
			ivjJTextFieldDept_DelSub.setName("JTextFieldDept_DelSub");
			ivjJTextFieldDept_DelSub.setBackground(java.awt.Color.white);
			ivjJTextFieldDept_DelSub.setBounds(370, 80, 180, 18);
			ivjJTextFieldDept_DelSub.setEditable(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldDept_DelSub;
}
/**
 * Return the JTextFieldFaculty_Add property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getJTextFieldFac_AddSub() {
	if (ivjJTextFieldFac_AddSub == null) {
		try {
			ivjJTextFieldFac_AddSub = new com.sun.java.swing.JTextField();
			ivjJTextFieldFac_AddSub.setName("JTextFieldFac_AddSub");
			ivjJTextFieldFac_AddSub.setBackground(java.awt.Color.white);
			ivjJTextFieldFac_AddSub.setBounds(115, 80, 160, 18);
			ivjJTextFieldFac_AddSub.setEditable(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldFac_AddSub;
}
/**
 * Return the JTextFieldFac_DelSub property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getJTextFieldFac_DelSub() {
	if (ivjJTextFieldFac_DelSub == null) {
		try {
			ivjJTextFieldFac_DelSub = new com.sun.java.swing.JTextField();
			ivjJTextFieldFac_DelSub.setName("JTextFieldFac_DelSub");
			ivjJTextFieldFac_DelSub.setBackground(java.awt.Color.white);
			ivjJTextFieldFac_DelSub.setBounds(115, 80, 160, 18);
			ivjJTextFieldFac_DelSub.setEditable(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldFac_DelSub;
}
/**
 * Return the JTextField3 property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getJTextFieldFaculty() {
	if (ivjJTextFieldFaculty == null) {
		try {
			ivjJTextFieldFaculty = new com.sun.java.swing.JTextField();
			ivjJTextFieldFaculty.setName("JTextFieldFaculty");
			ivjJTextFieldFaculty.setBackground(java.awt.Color.white);
			ivjJTextFieldFaculty.setBounds(115, 80, 160, 18);
			ivjJTextFieldFaculty.setEditable(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldFaculty;
}
/**
 * Return the JTextFieldID property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getJTextFieldID() {
	if (ivjJTextFieldID == null) {
		try {
			ivjJTextFieldID = new com.sun.java.swing.JTextField();
			ivjJTextFieldID.setName("JTextFieldID");
			ivjJTextFieldID.setBackground(java.awt.Color.white);
			ivjJTextFieldID.setBounds(86, 34, 125, 18);
			ivjJTextFieldID.setEditable(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldID;
}
/**
 * Return the JTextFieldID_Add property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getJTextFieldID_AddSub() {
	if (ivjJTextFieldID_AddSub == null) {
		try {
			ivjJTextFieldID_AddSub = new com.sun.java.swing.JTextField();
			ivjJTextFieldID_AddSub.setName("JTextFieldID_AddSub");
			ivjJTextFieldID_AddSub.setBackground(java.awt.Color.white);
			ivjJTextFieldID_AddSub.setBounds(86, 34, 125, 18);
			ivjJTextFieldID_AddSub.setEditable(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldID_AddSub;
}
/**
 * Return the JTextFieldID_Del property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getJTextFieldID_DelSub() {
	if (ivjJTextFieldID_DelSub == null) {
		try {
			ivjJTextFieldID_DelSub = new com.sun.java.swing.JTextField();
			ivjJTextFieldID_DelSub.setName("JTextFieldID_DelSub");
			ivjJTextFieldID_DelSub.setDisabledTextColor(java.awt.Color.white);
			ivjJTextFieldID_DelSub.setBackground(java.awt.Color.white);
			ivjJTextFieldID_DelSub.setBounds(86, 34, 125, 18);
			ivjJTextFieldID_DelSub.setEditable(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldID_DelSub;
}
/**
 * Return the JTextFieldName property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getJTextFieldName() {
	if (ivjJTextFieldName == null) {
		try {
			ivjJTextFieldName = new com.sun.java.swing.JTextField();
			ivjJTextFieldName.setName("JTextFieldName");
			ivjJTextFieldName.setBackground(java.awt.Color.white);
			ivjJTextFieldName.setBounds(320, 32, 250, 18);
			ivjJTextFieldName.setEditable(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldName;
}
/**
 * Return the JTextFieldName_Add property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getJTextFieldName_AddSub() {
	if (ivjJTextFieldName_AddSub == null) {
		try {
			ivjJTextFieldName_AddSub = new com.sun.java.swing.JTextField();
			ivjJTextFieldName_AddSub.setName("JTextFieldName_AddSub");
			ivjJTextFieldName_AddSub.setBackground(java.awt.Color.white);
			ivjJTextFieldName_AddSub.setBounds(320, 32, 250, 18);
			ivjJTextFieldName_AddSub.setEditable(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldName_AddSub;
}
/**
 * Return the JTextField2 property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getJTextFieldName_DelSub() {
	if (ivjJTextFieldName_DelSub == null) {
		try {
			ivjJTextFieldName_DelSub = new com.sun.java.swing.JTextField();
			ivjJTextFieldName_DelSub.setName("JTextFieldName_DelSub");
			ivjJTextFieldName_DelSub.setBackground(java.awt.Color.white);
			ivjJTextFieldName_DelSub.setBounds(320, 32, 250, 18);
			ivjJTextFieldName_DelSub.setEditable(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldName_DelSub;
}
/**
 * Return the JTextField4 property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getJTextFieldTerm() {
	if (ivjJTextFieldTerm == null) {
		try {
			ivjJTextFieldTerm = new com.sun.java.swing.JTextField();
			ivjJTextFieldTerm.setName("JTextFieldTerm");
			ivjJTextFieldTerm.setBackground(java.awt.Color.white);
			ivjJTextFieldTerm.setBounds(660, 80, 40, 18);
			ivjJTextFieldTerm.setEditable(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldTerm;
}
/**
 * Return the JTextFieldRoom_Add property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getJTextFieldTerm_AddSub() {
	if (ivjJTextFieldTerm_AddSub == null) {
		try {
			ivjJTextFieldTerm_AddSub = new com.sun.java.swing.JTextField();
			ivjJTextFieldTerm_AddSub.setName("JTextFieldTerm_AddSub");
			ivjJTextFieldTerm_AddSub.setBackground(java.awt.Color.white);
			ivjJTextFieldTerm_AddSub.setBounds(660, 80, 40, 18);
			ivjJTextFieldTerm_AddSub.setEditable(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldTerm_AddSub;
}
/**
 * Return the JTextFieldTerm_DelSub property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getJTextFieldTerm_DelSub() {
	if (ivjJTextFieldTerm_DelSub == null) {
		try {
			ivjJTextFieldTerm_DelSub = new com.sun.java.swing.JTextField();
			ivjJTextFieldTerm_DelSub.setName("JTextFieldTerm_DelSub");
			ivjJTextFieldTerm_DelSub.setBackground(java.awt.Color.white);
			ivjJTextFieldTerm_DelSub.setBounds(660, 80, 40, 18);
			ivjJTextFieldTerm_DelSub.setEditable(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldTerm_DelSub;
}
/**
 * Return the JTextField1 property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getJTextFieldYear() {
	if (ivjJTextFieldYear == null) {
		try {
			ivjJTextFieldYear = new com.sun.java.swing.JTextField();
			ivjJTextFieldYear.setName("JTextFieldYear");
			ivjJTextFieldYear.setBackground(java.awt.Color.white);
			ivjJTextFieldYear.setBounds(660, 31, 80, 18);
			ivjJTextFieldYear.setEditable(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldYear;
}
/**
 * Return the JTextFieldYear_Add property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getJTextFieldYR_AddSub() {
	if (ivjJTextFieldYR_AddSub == null) {
		try {
			ivjJTextFieldYR_AddSub = new com.sun.java.swing.JTextField();
			ivjJTextFieldYR_AddSub.setName("JTextFieldYR_AddSub");
			ivjJTextFieldYR_AddSub.setBackground(java.awt.Color.white);
			ivjJTextFieldYR_AddSub.setBounds(660, 31, 80, 18);
			ivjJTextFieldYR_AddSub.setEditable(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldYR_AddSub;
}
/**
 * Return the JTextFieldYR_DelSub property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getJTextFieldYR_DelSub() {
	if (ivjJTextFieldYR_DelSub == null) {
		try {
			ivjJTextFieldYR_DelSub = new com.sun.java.swing.JTextField();
			ivjJTextFieldYR_DelSub.setName("JTextFieldYR_DelSub");
			ivjJTextFieldYR_DelSub.setBackground(java.awt.Color.white);
			ivjJTextFieldYR_DelSub.setBounds(660, 31, 80, 18);
			ivjJTextFieldYR_DelSub.setEditable(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldYR_DelSub;
}
/**
 * Return the JToolBarButton2 property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getJToolBarButtonExit() {
	if (ivjJToolBarButtonExit == null) {
		try {
			ivjJToolBarButtonExit = new com.sun.java.swing.JButton();
			ivjJToolBarButtonExit.setName("JToolBarButtonExit");
			ivjJToolBarButtonExit.setToolTipText("\u0E08\u0E1A\u0E01\u0E32\u0E23\u0E17\u0E33\u0E07\u0E32\u0E19");
			ivjJToolBarButtonExit.setBorder(new com.sun.java.swing.plaf.metal.Flush3DBorder());
			ivjJToolBarButtonExit.setText("");
			ivjJToolBarButtonExit.setBackground(new java.awt.Color(206,206,206));
			ivjJToolBarButtonExit.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjJToolBarButtonExit.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjJToolBarButtonExit.setIcon(new com.sun.java.swing.ImageIcon("E:\\Picture\\VisualAge\\EXIT.jpg"));
			ivjJToolBarButtonExit.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJToolBarButtonExit.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJToolBarButtonExit;
}
/**
 * Return the JToolBarButtonDelete property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getJToolBarButtonMain() {
	if (ivjJToolBarButtonMain == null) {
		try {
			ivjJToolBarButtonMain = new com.sun.java.swing.JButton();
			ivjJToolBarButtonMain.setName("JToolBarButtonMain");
			ivjJToolBarButtonMain.setToolTipText("\u0E2B\u0E19\u0E49\u0E32\u0E08\u0E2D\u0E2B\u0E25\u0E31\u0E01");
			ivjJToolBarButtonMain.setBorder(new com.sun.java.swing.plaf.metal.Flush3DBorder());
			ivjJToolBarButtonMain.setText("");
			ivjJToolBarButtonMain.setBackground(new java.awt.Color(206,206,206));
			ivjJToolBarButtonMain.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjJToolBarButtonMain.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjJToolBarButtonMain.setIcon(new com.sun.java.swing.ImageIcon("E:\\Picture\\VisualAge\\HOME.jpg"));
			ivjJToolBarButtonMain.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJToolBarButtonMain.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJToolBarButtonMain;
}
/**
 * Return the JToolBar1 property value.
 * @return com.sun.java.swing.JToolBar
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JToolBar getJToolBarMain() {
	if (ivjJToolBarMain == null) {
		try {
			ivjJToolBarMain = new com.sun.java.swing.JToolBar();
			ivjJToolBarMain.setName("JToolBarMain");
			ivjJToolBarMain.setToolTipText("");
			ivjJToolBarMain.setBounds(0, 0, 800, 45);
			getJToolBarMain().add(getJToolBarButtonMain(), getJToolBarButtonMain().getName());
			ivjJToolBarMain.addSeparator();
			ivjJToolBarMain.add(getDefaultToolBarButton());
			ivjJToolBarMain.addSeparator();
			getJToolBarMain().add(getJToolBarButtonExit(), getJToolBarButtonExit().getName());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJToolBarMain;
}
/**
 * Return the RegisterOptionJMenuBar property value.
 * @return com.sun.java.swing.JMenuBar
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JMenuBar getRegisterOptionJMenuBar() {
	if (ivjRegisterOptionJMenuBar == null) {
		try {
			ivjRegisterOptionJMenuBar = new com.sun.java.swing.JMenuBar();
			ivjRegisterOptionJMenuBar.setName("RegisterOptionJMenuBar");
			ivjRegisterOptionJMenuBar.add(getJMenuField());
			ivjRegisterOptionJMenuBar.add(getJMenuHelp());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjRegisterOptionJMenuBar;
}
/**
 * Return the ScrollPaneTableAddSub property value.
 * @return com.sun.java.swing.JTable
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTable getScrollPaneTableAddSub() {
	if (ivjScrollPaneTableAddSub == null) {
		try {
			ivjScrollPaneTableAddSub = new com.sun.java.swing.JTable(aAddSubjectTableModel);
			ivjScrollPaneTableAddSub.setName("ScrollPaneTableAddSub");
			getJScrollPaneAddSub().setColumnHeaderView(ivjScrollPaneTableAddSub.getTableHeader());
			getJScrollPaneAddSub().getViewport().setBackingStoreEnabled(true);
			ivjScrollPaneTableAddSub.setFont(new java.awt.Font("dialog", 0, 14));
			ivjScrollPaneTableAddSub.setBackground(java.awt.Color.cyan);
			ivjScrollPaneTableAddSub.setBounds(33, 39, 720, 230);
			// user code begin {1}
			com.sun.java.swing.table.TableColumn column = null;
			for(int i=0;i<4;i++)
			{
				column = ivjScrollPaneTableAddSub.getColumnModel().getColumn(i);
				if(i==0) {column.setWidth(50);
						column.setResizable(false);}
				else if (i==1) {column.setWidth(200);
						column.setResizable(false);}
				else if (i==2) {column.setWidth(300);
						column.setResizable(false);}
				else {column.setWidth(50);
						column.setResizable(false);}
			}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjScrollPaneTableAddSub;
}
/**
 * Return the ScrollPaneTable property value.
 * @return com.sun.java.swing.JTable
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTable getScrollPaneTableDelSub() {
	if (ivjScrollPaneTableDelSub == null) {
		try {
			ivjScrollPaneTableDelSub = new com.sun.java.swing.JTable(aDelSubjectTableModel);
			ivjScrollPaneTableDelSub.setName("ScrollPaneTableDelSub");
			getJScrollPaneDelSub().setColumnHeaderView(ivjScrollPaneTableDelSub.getTableHeader());
			getJScrollPaneDelSub().getViewport().setBackingStoreEnabled(true);
			ivjScrollPaneTableDelSub.setFont(new java.awt.Font("dialog", 0, 14));
			ivjScrollPaneTableDelSub.setBackground(java.awt.Color.cyan);
			ivjScrollPaneTableDelSub.setBounds(0, 0, 200, 200);
			// user code begin {1}
			com.sun.java.swing.table.TableColumn column = null;
			for(int i=0;i<4;i++)
			{
				column = ivjScrollPaneTableDelSub.getColumnModel().getColumn(i);
				if(i==0) {column.setWidth(50);
						column.setResizable(false);}
				else if (i==1) {column.setWidth(200);
						column.setResizable(false);}
				else if (i==2) {column.setWidth(300);
						column.setResizable(false);}
				else {column.setWidth(50);
						column.setResizable(false);}
			}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjScrollPaneTableDelSub;
}
/**
 * Return the ScrollPaneTableRegister property value.
 * @return com.sun.java.swing.JTable
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTable getScrollPaneTableRegister() {
	if (ivjScrollPaneTableRegister == null) {
		try {
			ivjScrollPaneTableRegister = new com.sun.java.swing.JTable(aRegisterTableModel);
			ivjScrollPaneTableRegister.setName("ScrollPaneTableRegister");
			getJScrollPaneRegister().setColumnHeaderView(ivjScrollPaneTableRegister.getTableHeader());
			getJScrollPaneRegister().getViewport().setBackingStoreEnabled(true);
			ivjScrollPaneTableRegister.setBackground(java.awt.Color.cyan);
			ivjScrollPaneTableRegister.setBounds(0, 0, 200, 180);
			// user code begin {1}
			com.sun.java.swing.table.TableColumn column = null;
			for(int i=0;i<4;i++)
			{
				column = ivjScrollPaneTableRegister.getColumnModel().getColumn(i);
				if(i==0){ column.setWidth(50);
						  column.setResizable(false);
				}
				else if (i==1) {column.setWidth(200);
						  column.setResizable(false);}
				else if (i==2) {column.setWidth(300);
								  column.setResizable(false);}
				else {column.setWidth(50);
					  column.setResizable(false);}
			}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjScrollPaneTableRegister;
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getStudentId() {
	return ivjJTextFieldID.getText();
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() {
	// user code begin {1}
	// user code end
	getDefaultToolBarButton().addActionListener(this);
	getJButtonOK().addActionListener(this);
	getJButtonCancel().addActionListener(this);
	getJToolBarButtonExit().addActionListener(this);
	getJButtonDelSub_OK().addActionListener(this);
	getJButtonDelSub_Cancel().addActionListener(this);
	getJMenuItemExit().addActionListener(this);
	getJToolBarButtonMain().addActionListener(this);
	getJButtonAddSub_OK().addActionListener(this);
	getJButtonAddSub_Cancel().addActionListener(this);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	// user code begin {1}
	
	
	
	aInputSubjectID = new InputSubjectID(aSubjectsManager,this);
	
	aNotFound = new NotFound();
	//aNotFound = new NotFound(this);
	
	// user code end
	setName("RegisterOption");
	setDefaultCloseOperation(com.sun.java.swing.WindowConstants.DISPOSE_ON_CLOSE);
	setJMenuBar(getRegisterOptionJMenuBar());
	setBackground(new java.awt.Color(204,204,204));
	setSize(800, 630);
	setTitle("\u0E23\u0E30\u0E1A\u0E1A\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19\u0E01\u0E32\u0E23\u0E28\u0E36\u0E01\u0E29\u0E32");
	setContentPane(getJFrameContentPane());
	initConnections();
	// user code begin {2}
	// user code end
}
/**
 * Comment
 */
public void jButtonAddSub_Cancel_ActionEvents() {
	aAddSubjectTableModel.clearTable();
	aSubjectsManager.setFirstValuesForAdd();
	return;
}
/**
 * Comment
 */
public void jButtonAddSub_OK_ActionEvents() {
	aInputSubjectID.setVisible(false);
	aPassword.clearUser();
	aPassword.show();
	
	return;
}
/**
 * Comment
 */
public void jButtonCancel_ActionEvents() {
	
	return;
}
/**
 * Comment
 */
public void jButtonDelSub_Cancel_ActionEvents() {
	aDelSubjectTableModel.clearTable();
	aSubjectsManager.setFirstValuesForDel();
	return;
}
/**
 * Comment
 */
public void jButtonDelSub_OK_ActionEvents() {
	aInputSubjectID.setVisible(false);
	aPassword.clearUser();
	aPassword.show();
	
	return;
}
/**
 * Comment
 */
public void jButtonOK_ActionEvents() {
	aInputSubjectID.setVisible(false);
	aPassword.clearUser();
	aPassword.show();
	
	
	
	return;
}
/**
 * Comment
 */
public void jMenuItemExit_ActionEvents() {
	setVisible(false);
	dispose();
	System.exit(0);
	return;
}
/**
 * Comment
 */
public void jMenuItemHelp_Accelerator(com.sun.java.swing.KeyStroke arg1) {
	
	return;
}
/**
 * Comment
 */
public void jTextFieldID_ActionEvents(){
	
		
	return ;
}
/**
 * Comment
 */
public void jTextFieldID_DelSub_ActionEvents() {
	
	return ;
}
/**
 * Comment
 */
public void jTextFieldID_HisReg_ActionEvents() {
	
	return;
}
/**
 * Comment
 */
public void jToolBarButtonMain_ActionEvents() {
	
	aPassword.setEntry();
	aRegisterTableModel.clearTable();
	
	aAddSubjectTableModel.clearTable();
	aSubjectsManager.setFirstValuesForAdd();
	
	aDelSubjectTableModel.clearTable();
	aSubjectsManager.setFirstValuesForDel();

	ivjJLabelRegister_Total.setText("");
	ivjJLabelAdd_Total.setText("");
	
	aUiMain.setVisible(true);
	aUiMain.show();
	dispose();
	return;
}
/**
 * Comment
 */
public void jToolBarExit_ActionEvents() {
	setVisible(false);
	dispose();
	System.exit(0);
	return;
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		RegisterOption aRegisterOption;
		aRegisterOption = new RegisterOption();
		try {
			Class aCloserClass = Class.forName("com.ibm.uvm.abt.edit.WindowCloser");
			Class parmTypes[] = { java.awt.Window.class };
			Object parms[] = { aRegisterOption };
			java.lang.reflect.Constructor aCtor = aCloserClass.getConstructor(parmTypes);
			aCtor.newInstance(parms);
		} catch (java.lang.Throwable exc) {};
		aRegisterOption.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of com.sun.java.swing.JFrame");
		exception.printStackTrace(System.out);
	}
}
/**
 * This method was created in VisualAge.
 */
public void notFound(Exception e) {
	
		aNotFound.setVisible(true);
		aNotFound.show();
	
}
/**
 * This method was created in VisualAge.
 * @param stdid java.lang.String
 * @param stdName java.lang.String
 * @param fac java.lang.String
 * @param Dept java.lang.String
 * @param yr java.lang.String
 * @param term java.lang.String
 */
public void showInfoStudent(String stdid,String stdName,String fac,String dept,
	String yr,String term ) {
	//Register
	ivjJTextFieldID.setText(stdid);
	ivjJTextFieldName.setText(stdName);
	ivjJTextFieldFaculty.setText(fac);
	ivjJTextFieldBranch.setText(dept);
	ivjJTextFieldYear.setText(yr);
	ivjJTextFieldTerm.setText(term);
	//AddSubject
	ivjJTextFieldID_AddSub.setText(stdid);
	ivjJTextFieldName_AddSub.setText(stdName);
	ivjJTextFieldFac_AddSub.setText(fac);
	ivjJTextFieldDept_AddSub.setText(dept);
	ivjJTextFieldYR_AddSub.setText(yr);
	ivjJTextFieldTerm_AddSub.setText(term);
	//DeleteSubject
	ivjJTextFieldID_DelSub.setText(stdid);
	ivjJTextFieldName_DelSub.setText(stdName);
	ivjJTextFieldFac_DelSub.setText(fac);
	ivjJTextFieldDept_DelSub.setText(dept);
	ivjJTextFieldYR_DelSub.setText(yr);
	ivjJTextFieldTerm_DelSub.setText(term);


}
/**
 * This method was created in VisualAge.
 * @param totalCredit int
 */
public void showTotalOfAdd(int totalCredit) {
	String total_credit = ""+totalCredit;
	String cost_total = ""+totalCredit*100;
	ivjJLabelAdd_Total.setText("\u0E2B\u0E19\u0E48\u0E27\u0E22\u0E01\u0E34\u0E08\u0E23\u0E27\u0E21  "
									+total_credit+"  \u0E2B\u0E19\u0E48\u0E27\u0E22\u0E01\u0E34\u0E08     "
									+"\u0E08\u0E33\u0E19\u0E27\u0E19\u0E40\u0E07\u0E34\u0E19  "
									+cost_total+"   \u0E1A\u0E32\u0E17");
}
/**
 * This method was created in VisualAge.
 * @param totalCredit int
 */
public void showTotalOfRegister(int totalCrd,int cst_total) {
	String total_Credit = ""+totalCrd;
	String cost_total = ""+cst_total;
	ivjJLabelRegister_Total.setText("\u0E2B\u0E19\u0E48\u0E27\u0E22\u0E01\u0E34\u0E08\u0E23\u0E27\u0E21  "
									+total_Credit+"  \u0E2B\u0E19\u0E48\u0E27\u0E22\u0E01\u0E34\u0E08     "
									+"\u0E08\u0E33\u0E19\u0E27\u0E19\u0E40\u0E07\u0E34\u0E19  "
									+cost_total+"   \u0E1A\u0E32\u0E17");
}
}