package UIStudent;

/**
 * This type was created in VisualAge.
 */
import com.sun.java.swing.*;
import Person.*;
import PersonManager.*;
import TableInUse.*;
public class UiMain extends com.sun.java.swing.JFrame implements java.awt.event.ActionListener {
	private com.sun.java.swing.JButton ivjJButtonQuit = null;
	private com.sun.java.swing.JButton ivjJButtonStd = null;
	private com.sun.java.swing.JPanel ivjJFrameContentPane = null;
	//
	
	
	//person
	
	
	//manager
	
	
	//class
	private Faculty aFaculty;
	private String need=""; // 
	private com.sun.java.swing.JButton ivjJButtonInformation = null;
	private com.sun.java.swing.JLabel ivjJLabelName = null;
	private com.sun.java.swing.JButton ivjJButtonSnoopy = null;
	private com.sun.java.swing.JButton ivjJButtonBook = null;
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public UiMain() {
	super();
	initialize();
}
/**
 * UiMain constructor comment.
 * @param title java.lang.String
 */
public UiMain(String title) {
	super(title);
}
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void actionPerformed(java.awt.event.ActionEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == getJButtonStd()) ) {
		connEtoC2();
	}
	if ((e.getSource() == getJButtonInformation()) ) {
		connEtoC1();
	}
	if ((e.getSource() == getJButtonQuit()) ) {
		connEtoC3();
	}
	// user code begin {2}
	// user code end
}
/**
 * connEtoC1:  (JButtonInformation.action. --> UiMain.jButtonInformation_ActionEvents()V)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC1() {
	try {
		// user code begin {1}
		// user code end
		this.jButtonInformation_ActionEvents();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC2:  (JButtonStd.action. --> UiMain.jButtonStd_ActionEvents()V)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC2() {
	try {
		// user code begin {1}
		// user code end
		this.jButtonStd_ActionEvents();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC3:  (JButtonQuit.action. --> UiMain.jButtonQuit_ActionEvents()V)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC3() {
	try {
		// user code begin {1}
		// user code end
		this.jButtonQuit_ActionEvents();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * Return the JButtonBook property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JButton getJButtonBook() {
	if (ivjJButtonBook == null) {
		try {
			ivjJButtonBook = new com.sun.java.swing.JButton();
			ivjJButtonBook.setName("JButtonBook");
			ivjJButtonBook.setIcon(new com.sun.java.swing.ImageIcon("E:\\Picture\\VisualAge\\book.jpg"));
			ivjJButtonBook.setBorder(new com.sun.java.swing.plaf.metal.MetalMenuBarBorder());
			ivjJButtonBook.setText("");
			ivjJButtonBook.setBackground(java.awt.SystemColor.activeCaptionBorder);
			ivjJButtonBook.setBounds(29, 228, 93, 49);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJButtonBook;
}
/**
 * Return the JButtonAdmin property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JButton getJButtonInformation() {
	if (ivjJButtonInformation == null) {
		try {
			ivjJButtonInformation = new com.sun.java.swing.JButton();
			ivjJButtonInformation.setName("JButtonInformation");
			ivjJButtonInformation.setFont(new java.awt.Font("dialog", 1, 14));
			ivjJButtonInformation.setText("\u0E23\u0E30\u0E1A\u0E1A\u0E2A\u0E32\u0E23\u0E2A\u0E19\u0E40\u0E17\u0E28\u0E19\u0E31\u0E01\u0E28\u0E36\u0E01\u0E29\u0E32");
			ivjJButtonInformation.setBounds(159, 125, 203, 37);
			ivjJButtonInformation.setForeground(java.awt.Color.darkGray);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJButtonInformation;
}
/**
 * Return the JButtonQuit property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JButton getJButtonQuit() {
	if (ivjJButtonQuit == null) {
		try {
			ivjJButtonQuit = new com.sun.java.swing.JButton();
			ivjJButtonQuit.setName("JButtonQuit");
			ivjJButtonQuit.setFont(new java.awt.Font("dialog", 1, 14));
			ivjJButtonQuit.setText("\u0E08\u0E1A\u0E01\u0E32\u0E23\u0E17\u0E33\u0E07\u0E32\u0E19");
			ivjJButtonQuit.setBounds(157, 239, 204, 37);
			ivjJButtonQuit.setForeground(java.awt.Color.darkGray);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJButtonQuit;
}
/**
 * Return the JButtonSnoopy property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JButton getJButtonSnoopy() {
	if (ivjJButtonSnoopy == null) {
		try {
			ivjJButtonSnoopy = new com.sun.java.swing.JButton();
			ivjJButtonSnoopy.setName("JButtonSnoopy");
			ivjJButtonSnoopy.setIcon(new com.sun.java.swing.ImageIcon("E:\\Picture\\VisualAge\\snoopy.jpg"));
			ivjJButtonSnoopy.setBorder(new com.sun.java.swing.plaf.metal.MetalMenuBarBorder());
			ivjJButtonSnoopy.setText("JButton1");
			ivjJButtonSnoopy.setBackground(java.awt.SystemColor.control);
			ivjJButtonSnoopy.setBounds(398, 133, 125, 141);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJButtonSnoopy;
}
/**
 * Return the JButtonStd property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JButton getJButtonStd() {
	if (ivjJButtonStd == null) {
		try {
			ivjJButtonStd = new com.sun.java.swing.JButton();
			ivjJButtonStd.setName("JButtonStd");
			ivjJButtonStd.setFont(new java.awt.Font("dialog", 1, 14));
			ivjJButtonStd.setText("\u0E23\u0E30\u0E1A\u0E1A\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19\u0E01\u0E32\u0E23\u0E28\u0E36\u0E01\u0E29\u0E32");
			ivjJButtonStd.setBounds(158, 182, 205, 37);
			ivjJButtonStd.setForeground(java.awt.Color.darkGray);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJButtonStd;
}
/**
 * Return the JFrameContentPane property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JPanel getJFrameContentPane() {
	if (ivjJFrameContentPane == null) {
		try {
			ivjJFrameContentPane = new com.sun.java.swing.JPanel();
			ivjJFrameContentPane.setName("JFrameContentPane");
			ivjJFrameContentPane.setLayout(null);
			ivjJFrameContentPane.setBackground(new java.awt.Color(204,204,204));
			getJFrameContentPane().add(getJButtonStd(), getJButtonStd().getName());
			getJFrameContentPane().add(getJButtonInformation(), getJButtonInformation().getName());
			getJFrameContentPane().add(getJButtonQuit(), getJButtonQuit().getName());
			getJFrameContentPane().add(getJLabelName(), getJLabelName().getName());
			getJFrameContentPane().add(getJButtonSnoopy(), getJButtonSnoopy().getName());
			getJFrameContentPane().add(getJButtonBook(), getJButtonBook().getName());
			// user code begin {1}
			
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJFrameContentPane;
}
/**
 * Return the JLabelName property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JLabel getJLabelName() {
	if (ivjJLabelName == null) {
		try {
			ivjJLabelName = new com.sun.java.swing.JLabel();
			ivjJLabelName.setName("JLabelName");
			ivjJLabelName.setFont(new java.awt.Font("dialog", 1, 24));
			ivjJLabelName.setText("\u0E23\u0E30\u0E1A\u0E1A\u0E2A\u0E32\u0E23\u0E2A\u0E19\u0E40\u0E17\u0E28\u0E19\u0E31\u0E01\u0E28\u0E36\u0E01\u0E29\u0E32");
			ivjJLabelName.setBounds(121, 46, 285, 34);
			ivjJLabelName.setForeground(java.awt.Color.blue);
			ivjJLabelName.setHorizontalAlignment(com.sun.java.swing.SwingConstants.CENTER);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelName;
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getNeed() {
	return need;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() {
	// user code begin {1}
	// user code end
	getJButtonStd().addActionListener(this);
	getJButtonInformation().addActionListener(this);
	getJButtonQuit().addActionListener(this);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	// user code begin {1}
	aFaculty = new Faculty(this);
	setLocation(150,150);	
	// user code end
	setName("UiMain");
	setDefaultCloseOperation(com.sun.java.swing.WindowConstants.DISPOSE_ON_CLOSE);
	setTitle("\u0E23\u0E30\u0E1A\u0E1A\u0E2A\u0E32\u0E23\u0E2A\u0E19\u0E40\u0E17\u0E28\u0E19\u0E31\u0E01\u0E28\u0E36\u0E01\u0E29\u0E32");
	setBackground(new java.awt.Color(204,204,204));
	setVisible(true);
	setSize(538, 343);
	setResizable(false);
	setContentPane(getJFrameContentPane());
	initConnections();
	// user code begin {2}
	
	// user code end
}
/**
 * Comment
 */
public void jButtonInformation_ActionEvents() {
	setNeed("Information");
	aFaculty.show();
	dispose();
	return;
}
/**
 * Comment
 */
public void jButtonQuit_ActionEvents() {
	setVisible(true);
	dispose();
	System.exit(0);
	return;
}
/**
 * Comment
 */
public void jButtonStd_ActionEvents() {
	setNeed("Register");
	aFaculty.show();
	dispose();
	return;
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		UiMain aUiMain;
		aUiMain = new UiMain();
		try {
			Class aCloserClass = Class.forName("com.ibm.uvm.abt.edit.WindowCloser");
			Class parmTypes[] = { java.awt.Window.class };
			Object parms[] = { aUiMain };
			java.lang.reflect.Constructor aCtor = aCloserClass.getConstructor(parmTypes);
			aCtor.newInstance(parms);
		} catch (java.lang.Throwable exc) {};
		aUiMain.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of com.sun.java.swing.JFrame");
		exception.printStackTrace(System.out);
	}
}
/**
 * This method was created in VisualAge.
 */
public void setNeed(String n) {
	need = n;
}
}