package UIStudent;

/**
 * This type was created in VisualAge.
 */

import TableInUse.*;
import PersonManager.*;
public class Information extends com.sun.java.swing.JFrame implements java.awt.event.ActionListener {
	private com.sun.java.swing.JButton ivjDefaultToolBarButtonInfoMain = null;
	private com.sun.java.swing.JMenuBar ivjInformationJMenuBar = null;
	private com.sun.java.swing.JPanel ivjJFrameContentPane = null;
	private com.sun.java.swing.JLabel ivjJLabelInfo_Dept = null;
	private com.sun.java.swing.JLabel ivjJLabelInfo_Fac = null;
	private com.sun.java.swing.JLabel ivjJLabelInfo_ID = null;
	private com.sun.java.swing.JLabel ivjJLabelInfo_Name = null;
	private com.sun.java.swing.JLabel ivjJLabelInfo_Term = null;
	private com.sun.java.swing.JLabel ivjJLabelInfo_Year = null;
	private com.sun.java.swing.JMenu ivjJMenuHelpInfl = null;
	private com.sun.java.swing.JMenu ivjJMenuInfo = null;
	private com.sun.java.swing.JMenuItem ivjJMenuItemInfo_Exit = null;
	private com.sun.java.swing.JScrollPane ivjJScrollPaneInfo = null;
	private com.sun.java.swing.JTabbedPane ivjJTabbedPaneInfo = null;
	private com.sun.java.swing.JTextField ivjJTextFieldInfo_Dept = null;
	private com.sun.java.swing.JTextField ivjJTextFieldInfo_Fac = null;
	private com.sun.java.swing.JTextField ivjJTextFieldInfo_ID = null;
	private com.sun.java.swing.JTextField ivjJTextFieldInfo_Name = null;
	private com.sun.java.swing.JTextField ivjJTextFieldInfo_Term = null;
	private com.sun.java.swing.JTextField ivjJTextFieldInfo_Year = null;
	private com.sun.java.swing.JButton ivjJToolBarButtonInfoExit = null;
	private com.sun.java.swing.JToolBar ivjJToolBarInfo = null;
	private com.sun.java.swing.JPanel ivjPageInfoReg = null;
	private com.sun.java.swing.JTable ivjScrollPaneTableInfo = null;
	private com.sun.java.swing.JLabel ivjJLabelGrade_Dept = null;
	private com.sun.java.swing.JLabel ivjJLabelGrade_Fac = null;
	private com.sun.java.swing.JLabel ivjJLabelGrade_Id = null;
	private com.sun.java.swing.JLabel ivjJLabelGrade_Name = null;
	private com.sun.java.swing.JLabel ivjJLabelGrade_Term = null;
	private com.sun.java.swing.JLabel ivjJLabelGrade_YR = null;
	private com.sun.java.swing.JPanel ivjJPanelGrade = null;
	private com.sun.java.swing.JTextField ivjJTextFieldGrade_Dept = null;
	private com.sun.java.swing.JTextField ivjJTextFieldGrade_fac = null;
	private com.sun.java.swing.JTextField ivjJTextFieldGrade_Id = null;
	private com.sun.java.swing.JTextField ivjJTextFieldGrade_Name = null;
	private com.sun.java.swing.JTextField ivjJTextFieldGrade_Term = null;
	private com.sun.java.swing.JTextField ivjJTextFieldGrade_YR = null;
	private com.sun.java.swing.JScrollPane ivjJScrollPaneGradeInfo = null;
	private com.sun.java.swing.JTable ivjScrollPaneTableGradeInfo = null;
	//
	private UiMain aUiMain;
	private Register_DetailManager aRegister_DetailManager;
	private HisRegTableModel aHisRegTableModel;
	private HisGradeInfoTableModel aHisGradeInfoTableModel;
	private Password aPassword;
	private com.sun.java.swing.JLabel ivjJLabelGpa = null;
	private com.sun.java.swing.JLabel ivjJLabelGradeInfo = null;
	private com.sun.java.swing.JLabel ivjJLabelInfoReg = null;
	private com.sun.java.swing.JLabel ivjJLabelGps = null;
	private com.sun.java.swing.JLabel ivjJLabelGrade_TotalCredit = null;
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public Information() {
	super();
	initialize();
}
/**
 * Information constructor comment.
 * @param title java.lang.String
 */
public Information(String title) {
	super(title);
}
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public Information(UiMain um,Register_DetailManager rdm,HisRegTableModel htm,
					HisGradeInfoTableModel hgitm,Password pw) {
	super();
	aUiMain = um;
	aRegister_DetailManager = rdm;
	aHisRegTableModel = htm;
	aHisGradeInfoTableModel = hgitm;
	aPassword = pw;
	initialize();
}
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void actionPerformed(java.awt.event.ActionEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == getDefaultToolBarButtonInfoMain()) ) {
		connEtoC1();
	}
	if ((e.getSource() == getJToolBarButtonInfoExit()) ) {
		connEtoC2();
	}
	if ((e.getSource() == getJMenuItemInfo_Exit()) ) {
		connEtoC3();
	}
	// user code begin {2}
	// user code end
}
/**
 * connEtoC1:  (DefaultToolBarButtonInfoMain.action. --> Information.defaultToolBarButtonInfoMain_ActionEvents()V)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC1() {
	try {
		// user code begin {1}
		// user code end
		this.defaultToolBarButtonInfoMain_ActionEvents();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC2:  (JToolBarButtonInfoExit.action. --> Information.jToolBarButtonInfoExit_ActionEvents()V)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC2() {
	try {
		// user code begin {1}
		// user code end
		this.jToolBarButtonInfoExit_ActionEvents();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC3:  (JMenuItemInfo_Exit.action. --> Information.jMenuItemInfo_Exit_ActionEvents()V)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC3() {
	try {
		// user code begin {1}
		// user code end
		this.jMenuItemInfo_Exit_ActionEvents();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * Comment
 */
public void defaultToolBarButtonInfoMain_ActionEvents() {
	//clear table
	aHisRegTableModel.clearTable();
	aHisGradeInfoTableModel.clearTable();
	aUiMain.setVisible(true);
	aUiMain.show();
	dispose();
	return;
}
/**
 * This method was created in VisualAge.
 * @return int
 */
public int  getChooseTabbedPane() {
	
	return ivjJTabbedPaneInfo.getSelectedIndex();
}
/**
 * Return the DefaultToolBarButtonInfoMain property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JButton getDefaultToolBarButtonInfoMain() {
	if (ivjDefaultToolBarButtonInfoMain == null) {
		try {
			ivjDefaultToolBarButtonInfoMain = new com.sun.java.swing.JButton();
			ivjDefaultToolBarButtonInfoMain.setName("DefaultToolBarButtonInfoMain");
			ivjDefaultToolBarButtonInfoMain.setToolTipText("\u0E2B\u0E19\u0E49\u0E32\u0E08\u0E2D\u0E2B\u0E25\u0E31\u0E01");
			ivjDefaultToolBarButtonInfoMain.setBorder(new com.sun.java.swing.plaf.metal.Flush3DBorder());
			ivjDefaultToolBarButtonInfoMain.setText("");
			ivjDefaultToolBarButtonInfoMain.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjDefaultToolBarButtonInfoMain.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjDefaultToolBarButtonInfoMain.setIcon(new com.sun.java.swing.ImageIcon("E:\\Picture\\VisualAge\\HOME.jpg"));
			ivjDefaultToolBarButtonInfoMain.setFont(new java.awt.Font("dialog", 0, 12));
			ivjDefaultToolBarButtonInfoMain.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDefaultToolBarButtonInfoMain;
}
/**
 * Return the InformationJMenuBar property value.
 * @return com.sun.java.swing.JMenuBar
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JMenuBar getInformationJMenuBar() {
	if (ivjInformationJMenuBar == null) {
		try {
			ivjInformationJMenuBar = new com.sun.java.swing.JMenuBar();
			ivjInformationJMenuBar.setName("InformationJMenuBar");
			ivjInformationJMenuBar.add(getJMenuInfo());
			ivjInformationJMenuBar.add(getJMenuHelpInfl());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjInformationJMenuBar;
}
/**
 * Return the JFrameContentPane property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JPanel getJFrameContentPane() {
	if (ivjJFrameContentPane == null) {
		try {
			ivjJFrameContentPane = new com.sun.java.swing.JPanel();
			ivjJFrameContentPane.setName("JFrameContentPane");
			ivjJFrameContentPane.setLayout(null);
			getJFrameContentPane().add(getJToolBarInfo(), getJToolBarInfo().getName());
			getJFrameContentPane().add(getJTabbedPaneInfo(), getJTabbedPaneInfo().getName());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJFrameContentPane;
}
/**
 * Return the JLabelGpa property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JLabel getJLabelGpa() {
	if (ivjJLabelGpa == null) {
		try {
			ivjJLabelGpa = new com.sun.java.swing.JLabel();
			ivjJLabelGpa.setName("JLabelGpa");
			ivjJLabelGpa.setText("");
			ivjJLabelGpa.setForeground(java.awt.Color.blue);
			ivjJLabelGpa.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjJLabelGpa.setFont(new java.awt.Font("dialog", 1, 18));
			ivjJLabelGpa.setBounds(128, 432, 528, 23);
			ivjJLabelGpa.setHorizontalAlignment(com.sun.java.swing.SwingConstants.CENTER);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelGpa;
}
/**
 * Return the JLabelGps property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JLabel getJLabelGps() {
	if (ivjJLabelGps == null) {
		try {
			ivjJLabelGps = new com.sun.java.swing.JLabel();
			ivjJLabelGps.setName("JLabelGps");
			ivjJLabelGps.setFont(new java.awt.Font("dialog", 1, 18));
			ivjJLabelGps.setText("");
			ivjJLabelGps.setBounds(131, 401, 525, 23);
			ivjJLabelGps.setForeground(java.awt.Color.blue);
			ivjJLabelGps.setHorizontalAlignment(com.sun.java.swing.SwingConstants.CENTER);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelGps;
}
/**
 * Return the JLabelGrade_Dept property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JLabel getJLabelGrade_Dept() {
	if (ivjJLabelGrade_Dept == null) {
		try {
			ivjJLabelGrade_Dept = new com.sun.java.swing.JLabel();
			ivjJLabelGrade_Dept.setName("JLabelGrade_Dept");
			ivjJLabelGrade_Dept.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelGrade_Dept.setText("\u0E20\u0E32\u0E04\u0E27\u0E34\u0E0A\u0E32");
			ivjJLabelGrade_Dept.setBounds(363, 80, 46, 14);
			ivjJLabelGrade_Dept.setForeground(java.awt.Color.black);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelGrade_Dept;
}
/**
 * Return the JLabelGrade_Fac property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JLabel getJLabelGrade_Fac() {
	if (ivjJLabelGrade_Fac == null) {
		try {
			ivjJLabelGrade_Fac = new com.sun.java.swing.JLabel();
			ivjJLabelGrade_Fac.setName("JLabelGrade_Fac");
			ivjJLabelGrade_Fac.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelGrade_Fac.setText("\u0E04\u0E13\u0E30");
			ivjJLabelGrade_Fac.setBounds(100, 81, 34, 14);
			ivjJLabelGrade_Fac.setForeground(java.awt.Color.black);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelGrade_Fac;
}
/**
 * Return the JLabelGrade_Id property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JLabel getJLabelGrade_Id() {
	if (ivjJLabelGrade_Id == null) {
		try {
			ivjJLabelGrade_Id = new com.sun.java.swing.JLabel();
			ivjJLabelGrade_Id.setName("JLabelGrade_Id");
			ivjJLabelGrade_Id.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelGrade_Id.setText("\u0E23\u0E2B\u0E31\u0E2A");
			ivjJLabelGrade_Id.setBounds(58, 37, 37, 14);
			ivjJLabelGrade_Id.setForeground(java.awt.Color.black);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelGrade_Id;
}
/**
 * Return the JLabelGrade_Name property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JLabel getJLabelGrade_Name() {
	if (ivjJLabelGrade_Name == null) {
		try {
			ivjJLabelGrade_Name = new com.sun.java.swing.JLabel();
			ivjJLabelGrade_Name.setName("JLabelGrade_Name");
			ivjJLabelGrade_Name.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelGrade_Name.setText("\u0E0A\u0E37\u0E48\u0E2D\u0E41\u0E25\u0E30\u0E19\u0E32\u0E21\u0E2A\u0E01\u0E38\u0E25");
			ivjJLabelGrade_Name.setBounds(241, 37, 80, 14);
			ivjJLabelGrade_Name.setForeground(java.awt.Color.black);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelGrade_Name;
}
/**
 * Return the JLabelGrade_Term property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JLabel getJLabelGrade_Term() {
	if (ivjJLabelGrade_Term == null) {
		try {
			ivjJLabelGrade_Term = new com.sun.java.swing.JLabel();
			ivjJLabelGrade_Term.setName("JLabelGrade_Term");
			ivjJLabelGrade_Term.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelGrade_Term.setText("\u0E40\u0E17\u0E2D\u0E21");
			ivjJLabelGrade_Term.setBounds(620, 80, 41, 14);
			ivjJLabelGrade_Term.setForeground(java.awt.Color.black);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelGrade_Term;
}
/**
 * Return the JLabelGrade_TotalCredit property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JLabel getJLabelGrade_TotalCredit() {
	if (ivjJLabelGrade_TotalCredit == null) {
		try {
			ivjJLabelGrade_TotalCredit = new com.sun.java.swing.JLabel();
			ivjJLabelGrade_TotalCredit.setName("JLabelGrade_TotalCredit");
			ivjJLabelGrade_TotalCredit.setFont(new java.awt.Font("dialog", 1, 18));
			ivjJLabelGrade_TotalCredit.setText("");
			ivjJLabelGrade_TotalCredit.setBounds(131, 367, 525, 25);
			ivjJLabelGrade_TotalCredit.setForeground(java.awt.Color.blue);
			ivjJLabelGrade_TotalCredit.setHorizontalAlignment(com.sun.java.swing.SwingConstants.CENTER);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelGrade_TotalCredit;
}
/**
 * Return the JLabelGrade_YR property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JLabel getJLabelGrade_YR() {
	if (ivjJLabelGrade_YR == null) {
		try {
			ivjJLabelGrade_YR = new com.sun.java.swing.JLabel();
			ivjJLabelGrade_YR.setName("JLabelGrade_YR");
			ivjJLabelGrade_YR.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelGrade_YR.setText("\u0E1B\u0E35\u0E01\u0E32\u0E23\u0E28\u0E36\u0E01\u0E29\u0E32");
			ivjJLabelGrade_YR.setBounds(560, 40, 64, 14);
			ivjJLabelGrade_YR.setForeground(java.awt.Color.black);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelGrade_YR;
}
/**
 * Return the JLabelGradeInfo property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JLabel getJLabelGradeInfo() {
	if (ivjJLabelGradeInfo == null) {
		try {
			ivjJLabelGradeInfo = new com.sun.java.swing.JLabel();
			ivjJLabelGradeInfo.setName("JLabelGradeInfo");
			ivjJLabelGradeInfo.setFont(new java.awt.Font("dialog", 1, 14));
			ivjJLabelGradeInfo.setText("***** \u0E1C\u0E25\u0E01\u0E32\u0E23\u0E28\u0E36\u0E01\u0E29\u0E32 *****");
			ivjJLabelGradeInfo.setBounds(302, 126, 198, 14);
			ivjJLabelGradeInfo.setForeground(java.awt.Color.red);
			ivjJLabelGradeInfo.setHorizontalAlignment(com.sun.java.swing.SwingConstants.CENTER);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelGradeInfo;
}
/**
 * Return the JLabelInfo_Dept property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JLabel getJLabelInfo_Dept() {
	if (ivjJLabelInfo_Dept == null) {
		try {
			ivjJLabelInfo_Dept = new com.sun.java.swing.JLabel();
			ivjJLabelInfo_Dept.setName("JLabelInfo_Dept");
			ivjJLabelInfo_Dept.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelInfo_Dept.setText("\u0E20\u0E32\u0E04\u0E27\u0E34\u0E0A\u0E32");
			ivjJLabelInfo_Dept.setBounds(352, 80, 60, 14);
			ivjJLabelInfo_Dept.setForeground(java.awt.Color.black);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelInfo_Dept;
}
/**
 * Return the JLabelInfo_Fac property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JLabel getJLabelInfo_Fac() {
	if (ivjJLabelInfo_Fac == null) {
		try {
			ivjJLabelInfo_Fac = new com.sun.java.swing.JLabel();
			ivjJLabelInfo_Fac.setName("JLabelInfo_Fac");
			ivjJLabelInfo_Fac.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelInfo_Fac.setText("\u0E04\u0E13\u0E30");
			ivjJLabelInfo_Fac.setBounds(90, 80, 46, 14);
			ivjJLabelInfo_Fac.setForeground(java.awt.Color.black);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelInfo_Fac;
}
/**
 * Return the JLabelInfo_ID property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JLabel getJLabelInfo_ID() {
	if (ivjJLabelInfo_ID == null) {
		try {
			ivjJLabelInfo_ID = new com.sun.java.swing.JLabel();
			ivjJLabelInfo_ID.setName("JLabelInfo_ID");
			ivjJLabelInfo_ID.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelInfo_ID.setText("\u0E23\u0E2B\u0E31\u0E2A");
			ivjJLabelInfo_ID.setBounds(58, 37, 46, 14);
			ivjJLabelInfo_ID.setForeground(java.awt.Color.black);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelInfo_ID;
}
/**
 * Return the JLabelInfo_Name property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JLabel getJLabelInfo_Name() {
	if (ivjJLabelInfo_Name == null) {
		try {
			ivjJLabelInfo_Name = new com.sun.java.swing.JLabel();
			ivjJLabelInfo_Name.setName("JLabelInfo_Name");
			ivjJLabelInfo_Name.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelInfo_Name.setText("\u0E0A\u0E37\u0E48\u0E2D\u0E41\u0E25\u0E30\u0E19\u0E32\u0E21\u0E2A\u0E01\u0E38\u0E25");
			ivjJLabelInfo_Name.setBounds(272, 37, 81, 14);
			ivjJLabelInfo_Name.setForeground(java.awt.Color.black);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelInfo_Name;
}
/**
 * Return the JLabelInfo_Term property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JLabel getJLabelInfo_Term() {
	if (ivjJLabelInfo_Term == null) {
		try {
			ivjJLabelInfo_Term = new com.sun.java.swing.JLabel();
			ivjJLabelInfo_Term.setName("JLabelInfo_Term");
			ivjJLabelInfo_Term.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelInfo_Term.setText("\u0E40\u0E17\u0E2D\u0E21");
			ivjJLabelInfo_Term.setBounds(635, 80, 46, 14);
			ivjJLabelInfo_Term.setForeground(java.awt.Color.black);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelInfo_Term;
}
/**
 * Return the JLabelInfo_Year property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JLabel getJLabelInfo_Year() {
	if (ivjJLabelInfo_Year == null) {
		try {
			ivjJLabelInfo_Year = new com.sun.java.swing.JLabel();
			ivjJLabelInfo_Year.setName("JLabelInfo_Year");
			ivjJLabelInfo_Year.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelInfo_Year.setText("\u0E1B\u0E35\u0E01\u0E32\u0E23\u0E28\u0E36\u0E01\u0E29\u0E32");
			ivjJLabelInfo_Year.setBounds(612, 37, 58, 14);
			ivjJLabelInfo_Year.setForeground(java.awt.Color.black);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelInfo_Year;
}
/**
 * Return the JLabelInfoReg property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JLabel getJLabelInfoReg() {
	if (ivjJLabelInfoReg == null) {
		try {
			ivjJLabelInfoReg = new com.sun.java.swing.JLabel();
			ivjJLabelInfoReg.setName("JLabelInfoReg");
			ivjJLabelInfoReg.setFont(new java.awt.Font("dialog", 1, 14));
			ivjJLabelInfoReg.setText("*****  \u0E23\u0E32\u0E22\u0E25\u0E30\u0E40\u0E2D\u0E35\u0E22\u0E14\u0E01\u0E32\u0E23\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19  *****");
			ivjJLabelInfoReg.setBounds(241, 138, 314, 14);
			ivjJLabelInfoReg.setForeground(java.awt.Color.magenta);
			ivjJLabelInfoReg.setHorizontalAlignment(com.sun.java.swing.SwingConstants.CENTER);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelInfoReg;
}
/**
 * Return the JMenuHelpInfl property value.
 * @return com.sun.java.swing.JMenu
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JMenu getJMenuHelpInfl() {
	if (ivjJMenuHelpInfl == null) {
		try {
			ivjJMenuHelpInfl = new com.sun.java.swing.JMenu();
			ivjJMenuHelpInfl.setName("JMenuHelpInfl");
			ivjJMenuHelpInfl.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJMenuHelpInfl.setText("Help");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJMenuHelpInfl;
}
/**
 * Return the JMenuInfo property value.
 * @return com.sun.java.swing.JMenu
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JMenu getJMenuInfo() {
	if (ivjJMenuInfo == null) {
		try {
			ivjJMenuInfo = new com.sun.java.swing.JMenu();
			ivjJMenuInfo.setName("JMenuInfo");
			ivjJMenuInfo.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJMenuInfo.setText("File");
			ivjJMenuInfo.add(getJMenuItemInfo_Exit());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJMenuInfo;
}
/**
 * Return the JMenuItemInfo_Exit property value.
 * @return com.sun.java.swing.JMenuItem
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JMenuItem getJMenuItemInfo_Exit() {
	if (ivjJMenuItemInfo_Exit == null) {
		try {
			ivjJMenuItemInfo_Exit = new com.sun.java.swing.JMenuItem();
			ivjJMenuItemInfo_Exit.setName("JMenuItemInfo_Exit");
			ivjJMenuItemInfo_Exit.setText("Exit");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJMenuItemInfo_Exit;
}
/**
 * Return the JPanelGrade property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JPanel getJPanelGrade() {
	if (ivjJPanelGrade == null) {
		try {
			ivjJPanelGrade = new com.sun.java.swing.JPanel();
			ivjJPanelGrade.setName("JPanelGrade");
			ivjJPanelGrade.setToolTipText("\u0E1C\u0E25\u0E01\u0E32\u0E23\u0E28\u0E36\u0E01\u0E29\u0E32");
			ivjJPanelGrade.setLayout(null);
			ivjJPanelGrade.setBackground(java.awt.SystemColor.control);
			getJPanelGrade().add(getJLabelGrade_Id(), getJLabelGrade_Id().getName());
			getJPanelGrade().add(getJTextFieldGrade_Id(), getJTextFieldGrade_Id().getName());
			getJPanelGrade().add(getJLabelGrade_Name(), getJLabelGrade_Name().getName());
			getJPanelGrade().add(getJTextFieldGrade_Name(), getJTextFieldGrade_Name().getName());
			getJPanelGrade().add(getJLabelGrade_YR(), getJLabelGrade_YR().getName());
			getJPanelGrade().add(getJTextFieldGrade_YR(), getJTextFieldGrade_YR().getName());
			getJPanelGrade().add(getJLabelGrade_Fac(), getJLabelGrade_Fac().getName());
			getJPanelGrade().add(getJTextFieldGrade_fac(), getJTextFieldGrade_fac().getName());
			getJPanelGrade().add(getJLabelGrade_Dept(), getJLabelGrade_Dept().getName());
			getJPanelGrade().add(getJTextFieldGrade_Dept(), getJTextFieldGrade_Dept().getName());
			getJPanelGrade().add(getJLabelGrade_Term(), getJLabelGrade_Term().getName());
			getJPanelGrade().add(getJTextFieldGrade_Term(), getJTextFieldGrade_Term().getName());
			getJPanelGrade().add(getJScrollPaneGradeInfo(), getJScrollPaneGradeInfo().getName());
			getJPanelGrade().add(getJLabelGradeInfo(), getJLabelGradeInfo().getName());
			getJPanelGrade().add(getJLabelGrade_TotalCredit(), getJLabelGrade_TotalCredit().getName());
			getJPanelGrade().add(getJLabelGps(), getJLabelGps().getName());
			getJPanelGrade().add(getJLabelGpa(), getJLabelGpa().getName());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJPanelGrade;
}
/**
 * Return the JScrollPane1 property value.
 * @return com.sun.java.swing.JScrollPane
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JScrollPane getJScrollPaneGradeInfo() {
	if (ivjJScrollPaneGradeInfo == null) {
		try {
			ivjJScrollPaneGradeInfo = new com.sun.java.swing.JScrollPane();
			ivjJScrollPaneGradeInfo.setName("JScrollPaneGradeInfo");
			ivjJScrollPaneGradeInfo.setVerticalScrollBarPolicy(com.sun.java.swing.JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
			ivjJScrollPaneGradeInfo.setHorizontalScrollBarPolicy(com.sun.java.swing.JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
			ivjJScrollPaneGradeInfo.setBackground(java.awt.Color.cyan);
			ivjJScrollPaneGradeInfo.setBounds(131, 156, 527, 201);
			getJScrollPaneGradeInfo().setViewportView(getScrollPaneTableGradeInfo());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJScrollPaneGradeInfo;
}
/**
 * Return the JScrollPaneInfo property value.
 * @return com.sun.java.swing.JScrollPane
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JScrollPane getJScrollPaneInfo() {
	if (ivjJScrollPaneInfo == null) {
		try {
			ivjJScrollPaneInfo = new com.sun.java.swing.JScrollPane();
			ivjJScrollPaneInfo.setName("JScrollPaneInfo");
			ivjJScrollPaneInfo.setVerticalScrollBarPolicy(com.sun.java.swing.JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
			ivjJScrollPaneInfo.setHorizontalScrollBarPolicy(com.sun.java.swing.JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
			ivjJScrollPaneInfo.setBackground(java.awt.Color.cyan);
			ivjJScrollPaneInfo.setBounds(33, 167, 720, 230);
			getJScrollPaneInfo().setViewportView(getScrollPaneTableInfo());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJScrollPaneInfo;
}
/**
 * Return the JTabbedPaneInfo property value.
 * @return com.sun.java.swing.JTabbedPane
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JTabbedPane getJTabbedPaneInfo() {
	if (ivjJTabbedPaneInfo == null) {
		try {
			ivjJTabbedPaneInfo = new com.sun.java.swing.JTabbedPane();
			ivjJTabbedPaneInfo.setName("JTabbedPaneInfo");
			ivjJTabbedPaneInfo.setBackground(new java.awt.Color(133,168,157));
			ivjJTabbedPaneInfo.setBounds(0, 40, 800, 585);
			ivjJTabbedPaneInfo.insertTab("Register Information", new com.sun.java.swing.ImageIcon("E:\\Picture\\VisualAge\\INFOReg.jpg"), getPageInfoReg(), null, 0);
			ivjJTabbedPaneInfo.setBackgroundAt(0, java.awt.SystemColor.control);
			ivjJTabbedPaneInfo.insertTab("Grade Information", new com.sun.java.swing.ImageIcon("E:\\Picture\\VisualAge\\InfoGrade.jpg"), getJPanelGrade(), null, 1);
			ivjJTabbedPaneInfo.setBackgroundAt(1, java.awt.SystemColor.control);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTabbedPaneInfo;
}
/**
 * Return the JTextFieldGrade_Dept property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JTextField getJTextFieldGrade_Dept() {
	if (ivjJTextFieldGrade_Dept == null) {
		try {
			ivjJTextFieldGrade_Dept = new com.sun.java.swing.JTextField();
			ivjJTextFieldGrade_Dept.setName("JTextFieldGrade_Dept");
			ivjJTextFieldGrade_Dept.setBounds(432, 80, 178, 18);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldGrade_Dept;
}
/**
 * Return the JTextFieldGrade_fac property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JTextField getJTextFieldGrade_fac() {
	if (ivjJTextFieldGrade_fac == null) {
		try {
			ivjJTextFieldGrade_fac = new com.sun.java.swing.JTextField();
			ivjJTextFieldGrade_fac.setName("JTextFieldGrade_fac");
			ivjJTextFieldGrade_fac.setBackground(java.awt.Color.white);
			ivjJTextFieldGrade_fac.setBounds(144, 80, 193, 18);
			ivjJTextFieldGrade_fac.setEnabled(true);
			ivjJTextFieldGrade_fac.setEditable(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldGrade_fac;
}
/**
 * Return the JTextFieldGrade_Id property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JTextField getJTextFieldGrade_Id() {
	if (ivjJTextFieldGrade_Id == null) {
		try {
			ivjJTextFieldGrade_Id = new com.sun.java.swing.JTextField();
			ivjJTextFieldGrade_Id.setName("JTextFieldGrade_Id");
			ivjJTextFieldGrade_Id.setBackground(java.awt.Color.white);
			ivjJTextFieldGrade_Id.setBounds(103, 37, 111, 18);
			ivjJTextFieldGrade_Id.setEditable(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldGrade_Id;
}
/**
 * Return the JTextFieldGrade_Name property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JTextField getJTextFieldGrade_Name() {
	if (ivjJTextFieldGrade_Name == null) {
		try {
			ivjJTextFieldGrade_Name = new com.sun.java.swing.JTextField();
			ivjJTextFieldGrade_Name.setName("JTextFieldGrade_Name");
			ivjJTextFieldGrade_Name.setBackground(java.awt.Color.white);
			ivjJTextFieldGrade_Name.setBounds(333, 37, 209, 18);
			ivjJTextFieldGrade_Name.setEditable(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldGrade_Name;
}
/**
 * Return the JTextFieldGrade_Term property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JTextField getJTextFieldGrade_Term() {
	if (ivjJTextFieldGrade_Term == null) {
		try {
			ivjJTextFieldGrade_Term = new com.sun.java.swing.JTextField();
			ivjJTextFieldGrade_Term.setName("JTextFieldGrade_Term");
			ivjJTextFieldGrade_Term.setBackground(java.awt.Color.white);
			ivjJTextFieldGrade_Term.setBounds(673, 80, 27, 18);
			ivjJTextFieldGrade_Term.setEditable(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldGrade_Term;
}
/**
 * Return the JTextFieldGrade_YR property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JTextField getJTextFieldGrade_YR() {
	if (ivjJTextFieldGrade_YR == null) {
		try {
			ivjJTextFieldGrade_YR = new com.sun.java.swing.JTextField();
			ivjJTextFieldGrade_YR.setName("JTextFieldGrade_YR");
			ivjJTextFieldGrade_YR.setBackground(java.awt.Color.white);
			ivjJTextFieldGrade_YR.setBounds(643, 37, 63, 18);
			ivjJTextFieldGrade_YR.setEditable(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldGrade_YR;
}
/**
 * Return the JTextFieldInfo_Dept property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JTextField getJTextFieldInfo_Dept() {
	if (ivjJTextFieldInfo_Dept == null) {
		try {
			ivjJTextFieldInfo_Dept = new com.sun.java.swing.JTextField();
			ivjJTextFieldInfo_Dept.setName("JTextFieldInfo_Dept");
			ivjJTextFieldInfo_Dept.setBounds(423, 80, 187, 18);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldInfo_Dept;
}
/**
 * Return the JTextFieldInfo_Fac property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JTextField getJTextFieldInfo_Fac() {
	if (ivjJTextFieldInfo_Fac == null) {
		try {
			ivjJTextFieldInfo_Fac = new com.sun.java.swing.JTextField();
			ivjJTextFieldInfo_Fac.setName("JTextFieldInfo_Fac");
			ivjJTextFieldInfo_Fac.setBounds(145, 80, 171, 18);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldInfo_Fac;
}
/**
 * Return the JTextFieldInfo_ID property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JTextField getJTextFieldInfo_ID() {
	if (ivjJTextFieldInfo_ID == null) {
		try {
			ivjJTextFieldInfo_ID = new com.sun.java.swing.JTextField();
			ivjJTextFieldInfo_ID.setName("JTextFieldInfo_ID");
			ivjJTextFieldInfo_ID.setBounds(109, 37, 127, 18);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldInfo_ID;
}
/**
 * Return the JTextFieldInfo_Name property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JTextField getJTextFieldInfo_Name() {
	if (ivjJTextFieldInfo_Name == null) {
		try {
			ivjJTextFieldInfo_Name = new com.sun.java.swing.JTextField();
			ivjJTextFieldInfo_Name.setName("JTextFieldInfo_Name");
			ivjJTextFieldInfo_Name.setBounds(363, 37, 223, 18);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldInfo_Name;
}
/**
 * Return the JTextFieldInfo_Term property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JTextField getJTextFieldInfo_Term() {
	if (ivjJTextFieldInfo_Term == null) {
		try {
			ivjJTextFieldInfo_Term = new com.sun.java.swing.JTextField();
			ivjJTextFieldInfo_Term.setName("JTextFieldInfo_Term");
			ivjJTextFieldInfo_Term.setBounds(681, 78, 27, 18);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldInfo_Term;
}
/**
 * Return the JTextFieldInfo_Year property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JTextField getJTextFieldInfo_Year() {
	if (ivjJTextFieldInfo_Year == null) {
		try {
			ivjJTextFieldInfo_Year = new com.sun.java.swing.JTextField();
			ivjJTextFieldInfo_Year.setName("JTextFieldInfo_Year");
			ivjJTextFieldInfo_Year.setBounds(675, 37, 67, 18);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldInfo_Year;
}
/**
 * Return the JToolBarButtonInfoExit property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JButton getJToolBarButtonInfoExit() {
	if (ivjJToolBarButtonInfoExit == null) {
		try {
			ivjJToolBarButtonInfoExit = new com.sun.java.swing.JButton();
			ivjJToolBarButtonInfoExit.setName("JToolBarButtonInfoExit");
			ivjJToolBarButtonInfoExit.setToolTipText("\u0E08\u0E1A\u0E01\u0E32\u0E23\u0E17\u0E33\u0E07\u0E32\u0E19");
			ivjJToolBarButtonInfoExit.setBorder(new com.sun.java.swing.plaf.metal.Flush3DBorder());
			ivjJToolBarButtonInfoExit.setText("");
			ivjJToolBarButtonInfoExit.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjJToolBarButtonInfoExit.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjJToolBarButtonInfoExit.setIcon(new com.sun.java.swing.ImageIcon("E:\\Picture\\VisualAge\\EXIT.jpg"));
			ivjJToolBarButtonInfoExit.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJToolBarButtonInfoExit.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJToolBarButtonInfoExit;
}
/**
 * Return the JToolBarInfo property value.
 * @return com.sun.java.swing.JToolBar
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JToolBar getJToolBarInfo() {
	if (ivjJToolBarInfo == null) {
		try {
			ivjJToolBarInfo = new com.sun.java.swing.JToolBar();
			ivjJToolBarInfo.setName("JToolBarInfo");
			ivjJToolBarInfo.setBounds(0, 0, 800, 45);
			ivjJToolBarInfo.add(getDefaultToolBarButtonInfoMain());
			ivjJToolBarInfo.addSeparator();
			getJToolBarInfo().add(getJToolBarButtonInfoExit(), getJToolBarButtonInfoExit().getName());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJToolBarInfo;
}
/**
 * Return the PageInfoReg property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JPanel getPageInfoReg() {
	if (ivjPageInfoReg == null) {
		try {
			ivjPageInfoReg = new com.sun.java.swing.JPanel();
			ivjPageInfoReg.setName("PageInfoReg");
			ivjPageInfoReg.setToolTipText("\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E01\u0E32\u0E23\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19");
			ivjPageInfoReg.setLayout(null);
			ivjPageInfoReg.setBackground(java.awt.SystemColor.control);
			getPageInfoReg().add(getJLabelInfo_ID(), getJLabelInfo_ID().getName());
			getPageInfoReg().add(getJTextFieldInfo_ID(), getJTextFieldInfo_ID().getName());
			getPageInfoReg().add(getJLabelInfo_Name(), getJLabelInfo_Name().getName());
			getPageInfoReg().add(getJTextFieldInfo_Name(), getJTextFieldInfo_Name().getName());
			getPageInfoReg().add(getJLabelInfo_Year(), getJLabelInfo_Year().getName());
			getPageInfoReg().add(getJLabelInfo_Fac(), getJLabelInfo_Fac().getName());
			getPageInfoReg().add(getJTextFieldInfo_Fac(), getJTextFieldInfo_Fac().getName());
			getPageInfoReg().add(getJLabelInfo_Dept(), getJLabelInfo_Dept().getName());
			getPageInfoReg().add(getJTextFieldInfo_Dept(), getJTextFieldInfo_Dept().getName());
			getPageInfoReg().add(getJLabelInfo_Term(), getJLabelInfo_Term().getName());
			getPageInfoReg().add(getJScrollPaneInfo(), getJScrollPaneInfo().getName());
			getPageInfoReg().add(getJTextFieldInfo_Year(), getJTextFieldInfo_Year().getName());
			getPageInfoReg().add(getJTextFieldInfo_Term(), getJTextFieldInfo_Term().getName());
			getPageInfoReg().add(getJLabelInfoReg(), getJLabelInfoReg().getName());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjPageInfoReg;
}
/**
 * Return the ScrollPaneTable property value.
 * @return com.sun.java.swing.JTable
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JTable getScrollPaneTableGradeInfo() {
	if (ivjScrollPaneTableGradeInfo == null) {
		try {
			ivjScrollPaneTableGradeInfo = new com.sun.java.swing.JTable(aHisGradeInfoTableModel);
			ivjScrollPaneTableGradeInfo.setName("ScrollPaneTableGradeInfo");
			getJScrollPaneGradeInfo().setColumnHeaderView(ivjScrollPaneTableGradeInfo.getTableHeader());
			getJScrollPaneGradeInfo().getViewport().setBackingStoreEnabled(true);
			ivjScrollPaneTableGradeInfo.setFont(new java.awt.Font("dialog", 0, 14));
			ivjScrollPaneTableGradeInfo.setSelectionForeground(new java.awt.Color(85,85,85));
			ivjScrollPaneTableGradeInfo.setBackground(java.awt.Color.cyan);
			ivjScrollPaneTableGradeInfo.setBounds(0, 0, 200, 200);
			ivjScrollPaneTableGradeInfo.setGridColor(new java.awt.Color(153,153,153));
			// user code begin {1}
			com.sun.java.swing.table.TableColumn column = null;
			for(int i=0;i<4;i++)
			{			
				column = ivjScrollPaneTableGradeInfo.getColumnModel().getColumn(i);
				if(i==0) {column.setWidth(40);
						column.setResizable(false);}
				else if (i==1){ column.setWidth(120);
						column.setResizable(false);}
				else if (i==2) {column.setWidth(20);
						column.setResizable(false);}
				else {column.setWidth(20);
						column.setResizable(false);}
				
			}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjScrollPaneTableGradeInfo;
}
/**
 * Return the ScrollPaneTableInfo property value.
 * @return com.sun.java.swing.JTable
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JTable getScrollPaneTableInfo() {
	if (ivjScrollPaneTableInfo == null) {
		try {
			ivjScrollPaneTableInfo = new com.sun.java.swing.JTable(aHisRegTableModel);
			ivjScrollPaneTableInfo.setName("ScrollPaneTableInfo");
			getJScrollPaneInfo().setColumnHeaderView(ivjScrollPaneTableInfo.getTableHeader());
			getJScrollPaneInfo().getViewport().setBackingStoreEnabled(true);
			ivjScrollPaneTableInfo.setFont(new java.awt.Font("dialog", 0, 14));
			ivjScrollPaneTableInfo.setBackground(java.awt.Color.cyan);
			ivjScrollPaneTableInfo.setBounds(0, 0, 200, 200);
			ivjScrollPaneTableInfo.setForeground(java.awt.Color.black);
			// user code begin {1}
			com.sun.java.swing.table.TableColumn column = null;
			for(int i=0;i<4;i++)
			{
				column = ivjScrollPaneTableInfo.getColumnModel().getColumn(i);
				if(i==0) {column.setWidth(80);
						column.setResizable(false);}
				else if (i==1){ column.setWidth(250);
						column.setResizable(false);}
				else if (i==2) {column.setWidth(50);
						column.setResizable(false);}
				else {column.setWidth(220);
						column.setResizable(false);}
			}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjScrollPaneTableInfo;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() {
	// user code begin {1}
	// user code end
	getDefaultToolBarButtonInfoMain().addActionListener(this);
	getJToolBarButtonInfoExit().addActionListener(this);
	getJMenuItemInfo_Exit().addActionListener(this);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	// user code begin {1}
	// user code end
	setName("Information");
	setDefaultCloseOperation(com.sun.java.swing.WindowConstants.DISPOSE_ON_CLOSE);
	setResizable(false);
	setJMenuBar(getInformationJMenuBar());
	setSize(800, 630);
	setTitle("\u0E23\u0E30\u0E1A\u0E1A\u0E2A\u0E32\u0E23\u0E2A\u0E19\u0E40\u0E17\u0E28\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E19\u0E31\u0E01\u0E28\u0E36\u0E01\u0E29\u0E32");
	setContentPane(getJFrameContentPane());
	initConnections();
	// user code begin {2}
	// user code end
}
/**
 * Comment
 */
public void jMenuItemInfo_Exit_ActionEvents() {
	setVisible(false);
	dispose();
	System.exit(0);
	return;
}
/**
 * Comment
 */
public void jToolBarButtonInfoExit_ActionEvents() {
	setVisible(false);
	dispose();
	System.exit(0);
	return;
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		Information aInformation;
		aInformation = new Information();
		try {
			Class aCloserClass = Class.forName("com.ibm.uvm.abt.edit.WindowCloser");
			Class parmTypes[] = { java.awt.Window.class };
			Object parms[] = { aInformation };
			java.lang.reflect.Constructor aCtor = aCloserClass.getConstructor(parmTypes);
			aCtor.newInstance(parms);
		} catch (java.lang.Throwable exc) {};
		aInformation.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of com.sun.java.swing.JFrame");
		exception.printStackTrace(System.out);
	}
}
/**
 * This method was created in VisualAge.
 * @param gps float
 * @param gpa float
 */
public void showGpxxx(float gps,float gpa,int credit) {
	String strGps;
	String strGpa;
	String strCredit;
	
	//check totalCredit
	if (credit==0)
	{
		strCredit = "\u0E02\u0E2D\u0E2D\u0E20\u0E31\u0E22\u0E1C\u0E25\u0E01\u0E32\u0E23\u0E28\u0E36\u0E01\u0E29\u0E32\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E2D\u0E2D\u0E01";
		strGps = "";
		strGpa = "";
		ivjJLabelGrade_TotalCredit.setText(strCredit);
		ivjJLabelGps.setText(strGps);
		ivjJLabelGpa.setText(strGpa);
	}
	else
	{	strCredit = "\u0E2B\u0E19\u0E48\u0E27\u0E22\u0E01\u0E34\u0E08\u0E23\u0E27\u0E21  "
				+credit+"  \u0E2B\u0E19\u0E48\u0E27\u0E22\u0E01\u0E34\u0E08";
		ivjJLabelGrade_TotalCredit.setText(strCredit);
	
	 	 strGps = "GPS  "+gps;
		ivjJLabelGps.setText(strGps);
	
	
	   strGpa = "GPA  "+gpa;
		ivjJLabelGpa.setText(strGpa);
	}
}
/**
 * This method was created in VisualAge.
 * @param stdid java.lang.String
 * @param stdName java.lang.String
 * @param fac java.lang.String
 * @param Dept java.lang.String
 * @param yr java.lang.String
 * @param term java.lang.String
 */
public void showInfoStudent(String stdid,String stdName,String fac,String dept,
	String yr,String term ) {
	//Information
	ivjJTextFieldInfo_ID.setText(stdid);
	ivjJTextFieldInfo_Name.setText(stdName);
	ivjJTextFieldInfo_Fac.setText(fac);
	ivjJTextFieldInfo_Dept.setText(dept);
	ivjJTextFieldInfo_Year.setText(yr);
	ivjJTextFieldInfo_Term.setText(term);
	//GradeInfo
	ivjJTextFieldGrade_Id.setText(stdid);
	ivjJTextFieldGrade_Name.setText(stdName);
	ivjJTextFieldGrade_fac.setText(fac);
	ivjJTextFieldGrade_Dept.setText(dept);
	ivjJTextFieldGrade_YR.setText(yr);
	ivjJTextFieldGrade_Term.setText(term);
	

}
}