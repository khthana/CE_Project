package UIStudent;

/**
 * This type was created in VisualAge.
 */
import java.sql.*;
import PersonManager.*;
public class InputSubjectID extends com.sun.java.swing.JFrame implements java.awt.event.ActionListener {
	private com.sun.java.swing.JButton ivjJButtonCancel = null;
	private com.sun.java.swing.JButton ivjJButtonOK = null;
	private com.sun.java.swing.JPanel ivjJFrameContentPane = null;
	private com.sun.java.swing.JLabel ivjJLabel1 = null;
	private com.sun.java.swing.JTextField ivjJTextFieldSubject = null;
	//
	
	private RegisterOption aRegisterOption;
	//manager
	private SubjectsManager aSubjectsManager;
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public InputSubjectID() {
	super();
	initialize();
}
/**
 * InputSubjectID constructor comment.
 * @param title java.lang.String
 */
public InputSubjectID(String title) {
	super(title);
}
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public InputSubjectID(SubjectsManager sm,RegisterOption ro) {
	super();
	aSubjectsManager = sm;
	aRegisterOption = ro;
	initialize();
}
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void actionPerformed(java.awt.event.ActionEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == getJButtonOK()) ) {
		connEtoC1();
	}
	if ((e.getSource() == getJButtonCancel()) ) {
		connEtoC2();
	}
	if ((e.getSource() == getJTextFieldSubject()) ) {
		connEtoC3();
	}
	// user code begin {2}
	// user code end
}
/**
 * This method was created in VisualAge.
 */
public void clearSubject() {
	ivjJTextFieldSubject.setText("");
}
/**
 * connEtoC1:  (JButtonOK.action. --> InputSubjectID.jButtonOK_ActionEvents()V)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC1() {
	try {
		// user code begin {1}
		// user code end
		this.jButtonOK_ActionEvents();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC2:  (JButtonCancel.action. --> InputSubjectID.jButtonCancel_ActionEvents()V)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC2() {
	try {
		// user code begin {1}
		// user code end
		this.jButtonCancel_ActionEvents();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC3:  (JTextFieldSubject.action. --> InputSubjectID.jTextFieldSubject_ActionEvents()V)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC3() {
	try {
		// user code begin {1}
		// user code end
		this.jTextFieldSubject_ActionEvents();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * Return the JButtonCancel property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JButton getJButtonCancel() {
	if (ivjJButtonCancel == null) {
		try {
			ivjJButtonCancel = new com.sun.java.swing.JButton();
			ivjJButtonCancel.setName("JButtonCancel");
			ivjJButtonCancel.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJButtonCancel.setText("\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01");
			ivjJButtonCancel.setBounds(191, 127, 69, 25);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJButtonCancel;
}
/**
 * Return the JButtonOK property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JButton getJButtonOK() {
	if (ivjJButtonOK == null) {
		try {
			ivjJButtonOK = new com.sun.java.swing.JButton();
			ivjJButtonOK.setName("JButtonOK");
			ivjJButtonOK.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJButtonOK.setText("\u0E15\u0E01\u0E25\u0E07");
			ivjJButtonOK.setBounds(102, 128, 68, 25);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJButtonOK;
}
/**
 * Return the JFrameContentPane property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JPanel getJFrameContentPane() {
	if (ivjJFrameContentPane == null) {
		try {
			ivjJFrameContentPane = new com.sun.java.swing.JPanel();
			ivjJFrameContentPane.setName("JFrameContentPane");
			ivjJFrameContentPane.setLayout(null);
			getJFrameContentPane().add(getJTextFieldSubject(), getJTextFieldSubject().getName());
			getJFrameContentPane().add(getJLabel1(), getJLabel1().getName());
			getJFrameContentPane().add(getJButtonOK(), getJButtonOK().getName());
			getJFrameContentPane().add(getJButtonCancel(), getJButtonCancel().getName());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJFrameContentPane;
}
/**
 * Return the JLabel1 property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JLabel getJLabel1() {
	if (ivjJLabel1 == null) {
		try {
			ivjJLabel1 = new com.sun.java.swing.JLabel();
			ivjJLabel1.setName("JLabel1");
			ivjJLabel1.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabel1.setText("\u0E23\u0E2B\u0E31\u0E2A\u0E27\u0E34\u0E0A\u0E32");
			ivjJLabel1.setBounds(45, 68, 46, 14);
			ivjJLabel1.setForeground(java.awt.Color.black);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabel1;
}
/**
 * Return the JTextField1 property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JTextField getJTextFieldSubject() {
	if (ivjJTextFieldSubject == null) {
		try {
			ivjJTextFieldSubject = new com.sun.java.swing.JTextField();
			ivjJTextFieldSubject.setName("JTextFieldSubject");
			ivjJTextFieldSubject.setBounds(118, 65, 122, 18);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldSubject;
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getSubject() {
	return ivjJTextFieldSubject.getText();;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() {
	// user code begin {1}
	// user code end
	getJButtonOK().addActionListener(this);
	getJButtonCancel().addActionListener(this);
	getJTextFieldSubject().addActionListener(this);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	// user code begin {1}
	setLocation(220,100);
	// user code end
	setName("InputSubjectID");
	setDefaultCloseOperation(com.sun.java.swing.WindowConstants.DISPOSE_ON_CLOSE);
	setSize(350, 200);
	setTitle("\u0E01\u0E23\u0E38\u0E13\u0E32\u0E43\u0E2A\u0E48\u0E23\u0E2B\u0E31\u0E2A\u0E27\u0E34\u0E0A\u0E32");
	setContentPane(getJFrameContentPane());
	initConnections();
	// user code begin {2}
	// user code end
}
/**
 * Comment
 */
public void jButtonCancel_ActionEvents() {
	setVisible(false);
	dispose();
	return;
}
/**
 * Comment
 */
public void jButtonOK_ActionEvents() {
	
	String subid = getSubject();
	int chooseTab = aRegisterOption.getChooseTabbedPane();
	try
	{	
		
		if (chooseTab == 0)
		{	if (!aSubjectsManager.isExistAlreadyForContinue(subid))
				aSubjectsManager.getSubjectsContinue(subid);
		}
		else if (chooseTab == 1)
		{
			if (!aSubjectsManager.isExistAlreadyForAdd(subid))
				aSubjectsManager.getSubjectsForAdd(subid);
		}
		else
		{	if (!aSubjectsManager.isExistAlreadyForDel(subid)) 
				aSubjectsManager.getSubjectsForDel(subid);

		}
	}catch (SQLException e){}
	clearSubject();
	return;
}
/**
 * Comment
 */
public void jTextFieldSubject_ActionEvents() {
	String subid = getSubject();
	int chooseTab = aRegisterOption.getChooseTabbedPane();
	try
	{	
		
		if (chooseTab == 0)
		{	if (!aSubjectsManager.isExistAlreadyForContinue(subid))
				aSubjectsManager.getSubjectsContinue(subid);
		}
		else if (chooseTab == 1)
		{
			if (!aSubjectsManager.isExistAlreadyForAdd(subid))
				aSubjectsManager.getSubjectsForAdd(subid);
		}
		else
		{	if (!aSubjectsManager.isExistAlreadyForDel(subid)) 
				aSubjectsManager.getSubjectsForDel(subid);

		}
	}catch (SQLException e){}
	clearSubject();
	return;
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		InputSubjectID aInputSubjectID;
		aInputSubjectID = new InputSubjectID();
		try {
			Class aCloserClass = Class.forName("com.ibm.uvm.abt.edit.WindowCloser");
			Class parmTypes[] = { java.awt.Window.class };
			Object parms[] = { aInputSubjectID };
			java.lang.reflect.Constructor aCtor = aCloserClass.getConstructor(parmTypes);
			aCtor.newInstance(parms);
		} catch (java.lang.Throwable exc) {};
		aInputSubjectID.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of com.sun.java.swing.JFrame");
		exception.printStackTrace(System.out);
	}
}
}