package TableInUse;

/**
 * This type was created in VisualAge.
 */
import java.sql.*;
public class AddSubjectTableModel extends com.sun.java.swing.table.AbstractTableModel {
	
	final String[] columnNames = {"\u0E25\u0E33\u0E14\u0E31\u0E1A",
									  "\u0E23\u0E2B\u0E31\u0E2A\u0E27\u0E34\u0E0A\u0E32",
									  "\u0E23\u0E32\u0E22\u0E0A\u0E37\u0E48\u0E2D\u0E27\u0E34\u0E0A\u0E32",
									  "\u0E2B\u0E19\u0E48\u0E27\u0E22\u0E01\u0E34\u0E08"};
		final Object[][] data = {
			{"", "", 
			 "", ""},
			{"", "", 
			 "", ""},
			{"", "",
			 "", ""},
			{"", "",
			 "", ""},
			{"", "",
			 "", ""},
			{"", "", 
			 "", ""},
			{"", "", 
			 "", ""},
			{"", "", 
			 "", ""},
			{"", "", 
			 "", ""},
			{"", "", 
			 "", ""},
			{"", "", 
			 "", ""},
			{"", "", 
			 "", ""},
		};
/**
 * AddSubjectTableModel constructor comment.
 */
public AddSubjectTableModel() {
	super();
}
/**
 * This method was created in VisualAge.
 */
public void clearTable() {
	int cols = getColumnCount();
	int row = getRowCount();

	for (int i = 0;i<row;i++)
	{
		for(int j = 0;j<cols;j++)
		{
				
						String str = "";
						Object ob = (Object)str;
						setValueAt(ob,i,j);
				
		}//end for j			
	}//end for i
}
/**
 * This method was created in VisualAge.
 * @return java.lang.Class
 * @param c int
 */
public Class getColumnClass(int c) {
	return getValueAt(0, c).getClass();
}
/**
 * getColumnCount method comment.
 */
public int getColumnCount() {
	return columnNames.length;
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 * @param col int
 */
public String getColumnName(int col) {
	return columnNames[col];
}
/**
 * getRowCount method comment.
 */
public int getRowCount() {
	return data.length;
}
/**
 * getValueAt method comment.
 */
public Object getValueAt(int row, int col) {
	return  data[row][col];
}
/**
 * This method was created in VisualAge.
 * @return boolean
 * @param row int
 * @param col int
 */
public boolean isCellEditable(int row,int col) {
	return true;
	
}
/**
 * This method was created in VisualAge.
 * @param value java.lang.Object
 * @param row int
 * @param col int
 */
public void setValueAt(Object value,int row,int col) {
	data[row][col] = value;
	fireTableCellUpdated(row, col);
}
}