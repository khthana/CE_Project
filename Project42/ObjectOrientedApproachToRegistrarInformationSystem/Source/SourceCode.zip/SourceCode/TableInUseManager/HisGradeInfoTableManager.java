package TableInUseManager;

/**
 * This type was created in VisualAge.
 */
 import TableInUse.*;
public class HisGradeInfoTableManager {
	private HisGradeInfoTableModel aHisGradeInfoTableModel;
/**
 * HisGradeInfoTableManager constructor comment.
 */
public HisGradeInfoTableManager() {
	super();
}
/**
 * HisGradeInfoTableManager constructor comment.
 */
public HisGradeInfoTableManager(HisGradeInfoTableModel hgitm) {
	super();
	aHisGradeInfoTableModel = hgitm;
}
/**
 * This method was created in VisualAge.
 * @param ob java.lang.Object
 */
public void setValuesInTable(Object ob,int row,int col) {
	aHisGradeInfoTableModel.setValueAt(ob,row,col);
}
}