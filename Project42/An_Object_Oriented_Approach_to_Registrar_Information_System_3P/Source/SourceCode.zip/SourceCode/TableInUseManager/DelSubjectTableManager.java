package TableInUseManager;

/**
 * This type was created in VisualAge.
 */
import TableInUse.*;
public class DelSubjectTableManager {
	private  DelSubjectTableModel aDelSubjectTableModel;
/**
 * DelSubjectTableManager constructor comment.
 */
public DelSubjectTableManager() {
	super();
}
/**
 * DelSubjectTableManager constructor comment.
 */
public DelSubjectTableManager(DelSubjectTableModel dtm) {
	super();
	aDelSubjectTableModel = dtm;
}
/**
 * This method was created in VisualAge.
 * @return java.lang.Object
 * @param row int
 * @param col int
 */
public Object getValuesInTable(int row,int col) {
	Object ob = aDelSubjectTableModel.getValueAt(row,col);
	return ob;
}
/**
 * This method was created in VisualAge.
 * @param ob java.lang.Object
 * @param row int
 * @param col int
 */
public void setValuesInTable(Object ob,int row,int col) {
	aDelSubjectTableModel.setValueAt(ob,row,col);
}
}