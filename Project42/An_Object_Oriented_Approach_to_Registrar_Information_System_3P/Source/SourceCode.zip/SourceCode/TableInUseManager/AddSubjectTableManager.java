package TableInUseManager;

/**
 * This type was created in VisualAge.
 */
import TableInUse.*;

public class AddSubjectTableManager {
	private AddSubjectTableModel aAddSubjectTableModel;
/**
 * AddSubjectTableManager constructor comment.
 */
public AddSubjectTableManager() {
	super();
}
/**
 * AddSubjectTableManager constructor comment.
 */
public AddSubjectTableManager(AddSubjectTableModel atm) {
	super();
	aAddSubjectTableModel = atm;
}
/**
 * This method was created in VisualAge.
 * @return java.lang.Object
 * @param row int
 * @param col int
 */
public Object getValuesInTable(int row,int col) {
	Object ob = aAddSubjectTableModel.getValueAt(row,col);
	return ob;
}
/**
 * This method was created in VisualAge.
 * @param ob java.lang.Object
 * @param row int
 * @param col int
 */
public void setValuesInTable(Object ob,int row,int col) {
	aAddSubjectTableModel.setValueAt(ob,row,col);
}
}