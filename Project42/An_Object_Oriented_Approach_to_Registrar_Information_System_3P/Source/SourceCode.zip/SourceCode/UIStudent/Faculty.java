package UIStudent;

/**
 * This type was created in VisualAge.
 */
public class Faculty extends java.awt.Frame implements java.awt.event.ActionListener, java.awt.event.WindowListener {
	private java.awt.Button ivjButtonCancel = null;
	private java.awt.Button ivjButtonOK = null;
	private java.awt.Choice ivjChoiceFaculty = null;
	private java.awt.Panel ivjContentsPane = null;
	//
	private UiMain aUiMain;
	private Yr_Term aYear_Term;
	private String currentItem;
	private java.awt.Label ivjLabel1 = null;
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public Faculty() {
	super();
	initialize();
}
/**
 * Faculty constructor comment.
 * @param title java.lang.String
 */
public Faculty(String title) {
	super(title);
}
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public Faculty(UiMain um) {
	super();
	aUiMain = um;
	initialize();
}
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void actionPerformed(java.awt.event.ActionEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == getButtonOK()) ) {
		connEtoC2();
	}
	if ((e.getSource() == getButtonCancel()) ) {
		connEtoC3();
	}
	// user code begin {2}
	// user code end
}
/**
 * Comment
 */
public void buttonCancel_ActionEvents() {
	aUiMain.show();
	setVisible(false);
	dispose();
	
	return;
}
/**
 * Comment
 */
public void buttonOK_ActionEvents() {
	currentItem = ivjChoiceFaculty .getSelectedItem();

	aYear_Term.show();
	dispose();
	return;
}
/**
 * connEtoC1:  (Faculty.window.windowClosing(java.awt.event.WindowEvent) --> Faculty.dispose()V)
 * @param arg1 java.awt.event.WindowEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC1(java.awt.event.WindowEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.dispose();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC2:  (ButtonOK.action. --> Faculty.buttonOK_ActionEvents()V)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC2() {
	try {
		// user code begin {1}
	
		// user code end
		this.buttonOK_ActionEvents();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC3:  (ButtonCancel.action. --> Faculty.buttonCancel_ActionEvents()V)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC3() {
	try {
		// user code begin {1}
		// user code end
		this.buttonCancel_ActionEvents();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * Return the ButtonCancel property value.
 * @return java.awt.Button
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private java.awt.Button getButtonCancel() {
	if (ivjButtonCancel == null) {
		try {
			ivjButtonCancel = new java.awt.Button();
			ivjButtonCancel.setName("ButtonCancel");
			ivjButtonCancel.setBounds(287, 97, 59, 22);
			ivjButtonCancel.setForeground(java.awt.Color.blue);
			ivjButtonCancel.setLabel("\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjButtonCancel;
}
/**
 * Return the ButtonOK property value.
 * @return java.awt.Button
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private java.awt.Button getButtonOK() {
	if (ivjButtonOK == null) {
		try {
			ivjButtonOK = new java.awt.Button();
			ivjButtonOK.setName("ButtonOK");
			ivjButtonOK.setFont(new java.awt.Font("dialog", 0, 12));
			ivjButtonOK.setBounds(287, 56, 59, 22);
			ivjButtonOK.setForeground(java.awt.Color.blue);
			ivjButtonOK.setLabel("\u0E15\u0E01\u0E25\u0E07");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjButtonOK;
}
/**
 * Return the ChoiceFaculty property value.
 * @return java.awt.Choice
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private java.awt.Choice getChoiceFaculty() {
	if (ivjChoiceFaculty == null) {
		try {
			ivjChoiceFaculty = new java.awt.Choice();
			ivjChoiceFaculty.setName("ChoiceFaculty");
			ivjChoiceFaculty.setBackground(java.awt.Color.white);
			ivjChoiceFaculty.setBounds(127, 55, 138, 22);
			// user code begin {1}
			ivjChoiceFaculty.add("Engineering");
			ivjChoiceFaculty.add("Science");
			ivjChoiceFaculty.add("Architecture");
			ivjChoiceFaculty.add("Industrial Education");
			ivjChoiceFaculty.add("Agricultural Technology");
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjChoiceFaculty;
}
/**
 * Return the ContentsPane property value.
 * @return java.awt.Panel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private java.awt.Panel getContentsPane() {
	if (ivjContentsPane == null) {
		try {
			ivjContentsPane = new java.awt.Panel();
			ivjContentsPane.setName("ContentsPane");
			ivjContentsPane.setLayout(null);
			getContentsPane().add(getChoiceFaculty(), getChoiceFaculty().getName());
			getContentsPane().add(getButtonOK(), getButtonOK().getName());
			getContentsPane().add(getButtonCancel(), getButtonCancel().getName());
			getContentsPane().add(getLabel1(), getLabel1().getName());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjContentsPane;
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getFaculty() {
	return currentItem;
}
/**
 * Return the Label1 property value.
 * @return java.awt.Label
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private java.awt.Label getLabel1() {
	if (ivjLabel1 == null) {
		try {
			ivjLabel1 = new java.awt.Label();
			ivjLabel1.setName("Label1");
			ivjLabel1.setText("\u0E04\u0E13\u0E30\u0E27\u0E34\u0E0A\u0E32");
			ivjLabel1.setBounds(68, 56, 49, 22);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjLabel1;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() {
	// user code begin {1}
	// user code end
	this.addWindowListener(this);
	getButtonOK().addActionListener(this);
	getButtonCancel().addActionListener(this);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	// user code begin {1}
		aYear_Term = new Yr_Term(aUiMain,this);
	
	setLocation(210,200);
	// user code end
	setName("Faculty");
	setLayout(new java.awt.BorderLayout());
	setBackground(java.awt.SystemColor.control);
	setSize(393, 180);
	setTitle("\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E04\u0E13\u0E30");
	add(getContentsPane(), "Center");
	initConnections();
	// user code begin {2}
	// user code end
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		Faculty aFaculty;
		aFaculty = new Faculty();
		try {
			Class aCloserClass = Class.forName("com.ibm.uvm.abt.edit.WindowCloser");
			Class parmTypes[] = { java.awt.Window.class };
			Object parms[] = { aFaculty };
			java.lang.reflect.Constructor aCtor = aCloserClass.getConstructor(parmTypes);
			aCtor.newInstance(parms);
		} catch (java.lang.Throwable exc) {};
		aFaculty.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of java.awt.Frame");
		exception.printStackTrace(System.out);
	}
}
/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void windowActivated(java.awt.event.WindowEvent e) {
	// user code begin {1}
	// user code end
	// user code begin {2}
	// user code end
}
/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void windowClosed(java.awt.event.WindowEvent e) {
	// user code begin {1}
	// user code end
	// user code begin {2}
	// user code end
}
/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void windowClosing(java.awt.event.WindowEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == this) ) {
		connEtoC1(e);
	}
	// user code begin {2}
	// user code end
}
/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void windowDeactivated(java.awt.event.WindowEvent e) {
	// user code begin {1}
	// user code end
	// user code begin {2}
	// user code end
}
/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void windowDeiconified(java.awt.event.WindowEvent e) {
	// user code begin {1}
	// user code end
	// user code begin {2}
	// user code end
}
/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void windowIconified(java.awt.event.WindowEvent e) {
	// user code begin {1}
	// user code end
	// user code begin {2}
	// user code end
}
/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void windowOpened(java.awt.event.WindowEvent e) {
	// user code begin {1}
	// user code end
	// user code begin {2}
	// user code end
}
}