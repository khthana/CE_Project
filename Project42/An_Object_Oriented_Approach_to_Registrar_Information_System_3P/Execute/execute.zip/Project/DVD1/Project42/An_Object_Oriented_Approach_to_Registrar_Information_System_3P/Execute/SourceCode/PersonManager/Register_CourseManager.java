package PersonManager;

/**
 * This type was created in VisualAge.
 */
import java.lang.*;
import java.sql.*;
import java.math.*;
import java.io.*;
import Person.*;
import TableInUseManager.*;
public class Register_CourseManager {
	private Register_Course aRegister_Course;
	private RegisterTableManager aRegisterTableManager;
	int countRow = 0;
	int rowInTable = -1;
	int cols=0;
	
	
/**
 * Register_CourseManager constructor comment.
 */
public Register_CourseManager() {
	super();
}
/**
 * Register_CourseManager constructor comment.
 */
public Register_CourseManager(Register_Course rc,RegisterTableManager rtm) {
	super();
	aRegister_Course = rc;
	aRegisterTableManager = rtm;
}
/**
 * This method was created in VisualAge.
 */
public void clearValue() {
	countRow = 0;
	rowInTable = -1;
	cols = 0;
}
/**
 * This method was created in VisualAge.
 * @return java.sql.ResultSet
 * @param stdId java.lang.String
 * @param term java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public void getConstrainSubjects(String stdId,String term) throws SQLException {
		ResultSet rs = aRegister_Course.getConstrainSubjects(stdId,term);
		
		ResultSetMetaData rsmd = rs.getMetaData();
		cols = rsmd.getColumnCount();
	
		while (rs.next())
		{
			countRow++;
			rowInTable++;
			for(int i=0;i<=cols;i++)
			{
				if (i==0){	String rr = ""+countRow;
							Object ob = (Object)rr;
							aRegisterTableManager.setValuesInTable(ob,rowInTable,i);}
				else if (i==1) {String subid = rs.getString(i);
							Object ob = (Object)subid;
							aRegisterTableManager.setValuesInTable(ob,rowInTable,i);}
				else if (i==2){String subname= rs.getString(i);
							Object ob = (Object)subname;
							aRegisterTableManager.setValuesInTable(ob,rowInTable,i);}
				else {String credit = rs.getString(i);
							Object ob = (Object)credit;
							aRegisterTableManager.setValuesInTable(ob,rowInTable,i);}
			
				
			}
		}
		aRegister_Course.close();
	
}
/**
 * This method was created in VisualAge.
 * @return int
 */
public int getCountCols() {
	return cols;
}
/**
 * This method was created in VisualAge.
 * @return int
 */
public int getCountRow() {
	return countRow;
}
/**
 * This method was created in VisualAge.
 * @return int
 */
public int getRowInTable() {
	return rowInTable;
}
/**
 * This method was created in VisualAge.
 * @return boolean
 * @param stdid java.lang.String
 * @param yr java.lang.String
 * @param term java.lang.String
 * @param ob java.lang.Object
 * @exception java.sql.SQLException The exception description.
 */
public boolean isCourse(String stdid,String term,Object ob) throws SQLException {
		boolean macth = false;
		String obSubid = (String)ob;
			System.out.println(obSubid);
		ResultSet rs = aRegister_Course.getConstrainSubjects(stdid,term);
		
		
	
		while (rs.next())
		{
				String subid = rs.getString(1);
				int m = subid.compareTo(obSubid);
				
				if (m==0) macth = true;
				
		} //end while
		aRegister_Course.close();
	
	if (macth)return true;
	else return false;
}
}