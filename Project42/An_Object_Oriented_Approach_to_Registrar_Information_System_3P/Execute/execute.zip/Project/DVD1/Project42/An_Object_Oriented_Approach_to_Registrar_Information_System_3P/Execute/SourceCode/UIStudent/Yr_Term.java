package UIStudent;

/**
 * This type was created in VisualAge.
 */
public class Yr_Term extends com.sun.java.swing.JFrame implements java.awt.event.ActionListener {
	private com.sun.java.swing.JPanel ivjJFrameContentPane = null;
	private com.sun.java.swing.JLabel ivjJLabelTerm = null;
	private com.sun.java.swing.JLabel ivjJLabelYear = null;
	private com.sun.java.swing.JTextField ivjJTextFieldTerm = null;
	private com.sun.java.swing.JTextField ivjJTextFieldYear = null;
	private com.sun.java.swing.JButton ivjJButtonCancel = null;
	private com.sun.java.swing.JButton ivjJButtonOK = null;

	private UiMain aUiMain;
	private Password aPassword;
	private Faculty aFaculty;

	private String year;
	private String term;
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public Yr_Term() {
	super();
	initialize();
}
/**
 * InputSub constructor comment.
 * @param title java.lang.String
 */
public Yr_Term(String title) {
	super(title);
}
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public Yr_Term(UiMain m,Faculty f) {
	super();
	aUiMain = m;
	aFaculty = f;
	initialize();
}
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void actionPerformed(java.awt.event.ActionEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == getJTextFieldYear()) ) {
		connEtoC1();
	}
	if ((e.getSource() == getJTextFieldTerm()) ) {
		connEtoC2();
	}
	if ((e.getSource() == getJButtonOK()) ) {
		connEtoC3();
	}
	if ((e.getSource() == getJButtonCancel()) ) {
		connEtoC4();
	}
	// user code begin {2}
	// user code end
}
/**
 * connEtoC1:  (JTextFieldYear.action. --> InputSub.jTextFieldYear_ActionEvents()V)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC1() {
	try {
		// user code begin {1}
		// user code end
		this.jTextFieldYear_ActionEvents();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC2:  (JTextFieldTerm.action. --> InputSub.jTextFieldTerm_ActionEvents()V)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC2() {
	try {
		// user code begin {1}
		// user code end
		this.jTextFieldTerm_ActionEvents();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC3:  (JButtonOK.action. --> InputSub.jButtonOK_ActionEvents()V)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC3() {
	try {
		// user code begin {1}
		// user code end
		this.jButtonOK_ActionEvents();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC4:  (JButtonCancel.action. --> InputSub.jButtonCancel_ActionEvents()V)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC4() {
	try {
		// user code begin {1}
		// user code end
		this.jButtonCancel_ActionEvents();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * Return the JButtonCancel property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JButton getJButtonCancel() {
	if (ivjJButtonCancel == null) {
		try {
			ivjJButtonCancel = new com.sun.java.swing.JButton();
			ivjJButtonCancel.setName("JButtonCancel");
			ivjJButtonCancel.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJButtonCancel.setText("\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01");
			ivjJButtonCancel.setBounds(144, 141, 66, 25);
			ivjJButtonCancel.setForeground(java.awt.Color.black);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJButtonCancel;
}
/**
 * Return the JButtonOK property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JButton getJButtonOK() {
	if (ivjJButtonOK == null) {
		try {
			ivjJButtonOK = new com.sun.java.swing.JButton();
			ivjJButtonOK.setName("JButtonOK");
			ivjJButtonOK.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJButtonOK.setText("\u0E15\u0E01\u0E25\u0E07");
			ivjJButtonOK.setBounds(49, 142, 72, 25);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJButtonOK;
}
/**
 * Return the JFrameContentPane property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JPanel getJFrameContentPane() {
	if (ivjJFrameContentPane == null) {
		try {
			ivjJFrameContentPane = new com.sun.java.swing.JPanel();
			ivjJFrameContentPane.setName("JFrameContentPane");
			ivjJFrameContentPane.setLayout(null);
			getJFrameContentPane().add(getJTextFieldYear(), getJTextFieldYear().getName());
			getJFrameContentPane().add(getJTextFieldTerm(), getJTextFieldTerm().getName());
			getJFrameContentPane().add(getJLabelYear(), getJLabelYear().getName());
			getJFrameContentPane().add(getJLabelTerm(), getJLabelTerm().getName());
			getJFrameContentPane().add(getJButtonOK(), getJButtonOK().getName());
			getJFrameContentPane().add(getJButtonCancel(), getJButtonCancel().getName());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJFrameContentPane;
}
/**
 * Return the JLabelTerm property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JLabel getJLabelTerm() {
	if (ivjJLabelTerm == null) {
		try {
			ivjJLabelTerm = new com.sun.java.swing.JLabel();
			ivjJLabelTerm.setName("JLabelTerm");
			ivjJLabelTerm.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelTerm.setText("\u0E20\u0E32\u0E04\u0E40\u0E23\u0E35\u0E22\u0E19\u0E17\u0E35\u0E48(1,2)");
			ivjJLabelTerm.setBounds(52, 93, 82, 14);
			ivjJLabelTerm.setForeground(java.awt.Color.black);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelTerm;
}
/**
 * Return the JLabelYear property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JLabel getJLabelYear() {
	if (ivjJLabelYear == null) {
		try {
			ivjJLabelYear = new com.sun.java.swing.JLabel();
			ivjJLabelYear.setName("JLabelYear");
			ivjJLabelYear.setFont(new java.awt.Font("dialog", 0, 12));
			ivjJLabelYear.setText("\u0E1B\u0E35\u0E01\u0E32\u0E23\u0E28\u0E36\u0E01\u0E29\u0E32(xxxx)");
			ivjJLabelYear.setBounds(42, 51, 100, 14);
			ivjJLabelYear.setForeground(java.awt.Color.black);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabelYear;
}
/**
 * Return the JTextFieldTerm property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JTextField getJTextFieldTerm() {
	if (ivjJTextFieldTerm == null) {
		try {
			ivjJTextFieldTerm = new com.sun.java.swing.JTextField();
			ivjJTextFieldTerm.setName("JTextFieldTerm");
			ivjJTextFieldTerm.setBounds(161, 94, 37, 18);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldTerm;
}
/**
 * Return the JTextFieldYear property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JTextField getJTextFieldYear() {
	if (ivjJTextFieldYear == null) {
		try {
			ivjJTextFieldYear = new com.sun.java.swing.JTextField();
			ivjJTextFieldYear.setName("JTextFieldYear");
			ivjJTextFieldYear.setBounds(160, 49, 63, 18);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTextFieldYear;
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getTerm() {
	return term;
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getYear() {
	return year;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() {
	// user code begin {1}
	// user code end
	getJTextFieldYear().addActionListener(this);
	getJTextFieldTerm().addActionListener(this);
	getJButtonOK().addActionListener(this);
	getJButtonCancel().addActionListener(this);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	// user code begin {1}
	aPassword= new Password(aUiMain,aFaculty,this);
	setLocation(250,200);
	// user code end
	setName("InputSub");
	setDefaultCloseOperation(com.sun.java.swing.WindowConstants.DISPOSE_ON_CLOSE);
	setSize(265, 211);
	setTitle("\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E1B\u0E35\u0E01\u0E32\u0E23\u0E28\u0E36\u0E01\u0E29\u0E32");
	setContentPane(getJFrameContentPane());
	initConnections();
	// user code begin {2}
	// user code end
}
/**
 * Comment
 */
public void jButtonCancel_ActionEvents() {
	aUiMain.show();
	setVisible(false);
	dispose();
	return;
}
/**
 * Comment
 */
public void jButtonOK_ActionEvents() {
	year = ivjJTextFieldYear.getText();
	term = ivjJTextFieldTerm.getText();
	
	
	
	aPassword.show();
	dispose();
	return;
}
/**
 * Comment
 */
public void jTextFieldTerm_ActionEvents() {
	return;
}
/**
 * Comment
 */
public void jTextFieldYear_ActionEvents() {
	return;
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		Yr_Term aYr_Term;
		aYr_Term = new Yr_Term();
		try {
			Class aCloserClass = Class.forName("com.ibm.uvm.abt.edit.WindowCloser");
			Class parmTypes[] = { java.awt.Window.class };
			Object parms[] = { aYr_Term };
			java.lang.reflect.Constructor aCtor = aCloserClass.getConstructor(parmTypes);
			aCtor.newInstance(parms);
		} catch (java.lang.Throwable exc) {};
		aYr_Term.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of com.sun.java.swing.JFrame");
		exception.printStackTrace(System.out);
	}
}
}