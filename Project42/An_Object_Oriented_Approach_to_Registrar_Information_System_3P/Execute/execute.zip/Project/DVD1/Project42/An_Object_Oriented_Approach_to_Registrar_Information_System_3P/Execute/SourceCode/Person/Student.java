package Person;

/**
 * This type was created in VisualAge.
 */
import java.sql.*;
import java.math.*;
import java.io.*;

public class Student {
	Connection          conn;
	Statement stmt;
	ResultSet rs;

	boolean found = false;
	
	String stdId;
	String stdName;
	String fac;
	String dept;
	String freecr_schp;
	String loan_schp;
	String freesppt_schp;
	String edutype;
	
/**
 * Student constructor comment.
 */
public Student() {
	super();
}
/**
 * This method was created in VisualAge.
 * @exception java.sql.SQLException The exception description.
 */
public void close() throws SQLException {
	rs.close();
		stmt.close();
		conn.close();
}
/**
 * This method was created in VisualAge.
 * @exception java.sql.SQLException The exception description.
 */
public void connectDB() throws SQLException {
	
	DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());

	conn =
		DriverManager.getConnection ("jdbc:oracle:thin:@dbserver:1521:orcl","database","0ew,jwfh");
	conn.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
	conn.setAutoCommit(false);
	
}
/**
 * This method was created in VisualAge.
 * @return boolean
 */
public boolean foundStd() {
	return found;
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getDept() {
	return dept;
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getEdutype() {
	return edutype;
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getFac() {
	return fac;
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getFreecr_schp() {
	return freecr_schp;
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getFreesppt_schp() {
	return freesppt_schp;
}
/**
 * This method was created in VisualAge.
 * @param stdid java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public void getInfoForCalMoney(String stdid) throws SQLException {
	
	try
	{
		connectDB();
		
		String query = "SELECT stdid,edutype,freecr_schp,loan_schp,freesppt_schp " +
					 "FROM student " +
					 "WHERE stdid = '" +
					 stdid + 
					 "'";
			
		stmt = conn.createStatement();
		
		rs = stmt.executeQuery(query);
		ResultSetMetaData rsmd = rs.getMetaData();
	    int cols = rsmd.getColumnCount();
		
		while (rs.next())
		{				
			for(int i=1;i<=cols;i++)
			{
				
				if (i==1){ stdId = rs.getString(i);}
							
				else if (i==2) {
					edutype = rs.getString(i); }
				else if (i==3) {
					freecr_schp = rs.getString(i);}
				else if (i==4) {
					loan_schp = rs.getString(i);}
				else {
					freesppt_schp = rs.getString(i);}
			}
		}
		close();
	
		}catch (SQLException e){}
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getLoan_schp() {
	return loan_schp;
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getName() {
	return stdName;
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getStdId() {
	return stdId;
}
/**
 * This method was created in VisualAge.
 * @return boolean
 * @param stdid java.lang.String
 * @param facName java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public void getStudent(String stdid,String facName) throws SQLException {
	
	try
	{	
		connectDB();
		String query = "SELECT student.stdid,student.tname,faculty.tname,department.tname " +
					 "from student,faculty,department " +
					 "where student.depid = department.depid " +
					 "and student.facid = department.facid "+
					 "and student.facid = faculty.facid " +
					 "and student.stdid = '" +
					 stdid + 
					 "' " +	 
					 "and faculty.ename = '" +
					 facName + 
					 "'";
					 
			
		 stmt = conn.createStatement();
		 rs = stmt.executeQuery(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
		
		while (rs.next())
		{
		
			for(int i=1;i<=cols;i++)
			{
				if (i==1) 
				{
					stdId = rs.getString(i);
					if (!rs.wasNull())
						found = true;	
				}
				
				else if (i==2){stdName = rs.getString(i); }
				else if (i==3) {fac = rs.getString(i);}
				else {dept = rs.getString(i);}
				
			}
		}
		close();
	
		}catch (SQLException e){}

}
}