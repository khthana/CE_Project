package PersonManager;

/**
 * This type was created in VisualAge.
 */
 import java.sql.*;
import java.math.*;
import java.io.*;
import Person.*;
public class StudentManager {
	private Student aStudent;
/**
 * StudentManager constructor comment.
 */
public StudentManager() {
	super();
}
/**
 * StudentManager constructor comment.
 */
public StudentManager(Student std) {
	super();
	aStudent = std;
}
/**
 * This method was created in VisualAge.
 * @return boolean
 */
public boolean foundStd() {
	return aStudent.foundStd();
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getDepartment() {
	return aStudent.getDept();
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getEdutype() {
	return aStudent.getEdutype();
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getFaculty() {
	return aStudent.getFac();
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getFreecr_schp() {
	return aStudent.getFreecr_schp();
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getFreesppt_schp() {
	return aStudent.getFreesppt_schp();
}
/**
 * This method was created in VisualAge.
 * @param stdid java.lang.String
 */
public void getInfoForCalMoney(String stdid) {
	try
	{
		
		aStudent.getInfoForCalMoney(stdid);
	}catch (SQLException e){}
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getLoan_schp() {
	return aStudent.getLoan_schp();
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getStdId() {
	return aStudent.getStdId();
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getStdName() {
	return aStudent.getName();
}
/**
 * This method was created in VisualAge.
 * @param stdid java.lang.String
 * @param facid java.lang.String
 */
public void getStudent(String stdid,String facid) {
	try
	{	
		aStudent.getStudent(stdid,facid);
	}catch(SQLException e){}
	}
}