package Person;

/**
 * This type was created in VisualAge.
 */
import java.sql.*;
import java.math.*;
import java.io.*;
public class Register_Course {
		Connection          conn;
		ResultSet 		rs;
		Statement stmt;
		String subId;
		String subName;
		String credit;
/**
 * Register_Course constructor comment.
 */
public Register_Course() {
	super();
}
	public void close() throws SQLException {
		
		rs.close();
		stmt.close();
		conn.close();
	}
/**
 * This method was created in VisualAge.
 * @exception java.sql.SQLException The exception description.
 */
public void connectDB() throws SQLException {
	
	DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());

	conn =
		DriverManager.getConnection ("jdbc:oracle:thin:@dbserver:1521:orcl","database","0ew,jwfh");
	conn.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
	conn.setAutoCommit(false);
	
}
/**
 * This method was created in VisualAge.
 * @param stdId java.lang.String
 * @param term java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public ResultSet getConstrainSubjects(String stdId,String term) throws SQLException {
	try
	{
		connectDB();
		String query = "SELECT reg.subid,sub.ename,sub.credit "+
					 "FROM register_course reg,subject sub,student std  "+
					 "WHERE reg.subid = sub.subid "+
					 "and reg.class = std.year# "+
					 "and std.stdid = '" +
					 stdId + "'" +
					 "and reg.term = '" +
					 term + "'";
		 stmt = conn.createStatement();
		
		 rs = stmt.executeQuery(query);
		
	}
	catch (SQLException e) {}
	return rs;
}
}