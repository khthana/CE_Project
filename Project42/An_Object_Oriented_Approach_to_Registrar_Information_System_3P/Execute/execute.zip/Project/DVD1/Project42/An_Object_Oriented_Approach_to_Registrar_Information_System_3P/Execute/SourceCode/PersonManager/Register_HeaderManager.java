package PersonManager;

/**
 * This type was created in VisualAge.
 */
 import java.sql.*;
import java.math.*;
import java.io.*;
import Person.*;
public class Register_HeaderManager {
	private Register_Header aRegister_Header;
	private StudentManager aStudentManager;
	private int cst_total=0;
/**
 * Register_Header constructor comment.
 */
public Register_HeaderManager() {
	super();
}
/**
 * Register_Header constructor comment.
 */
public Register_HeaderManager(Register_Header rh,StudentManager stdm) {
	super();
	aRegister_Header = rh;
	aStudentManager = stdm;
}
/**
 * This method was created in VisualAge.
 * @param stdid java.lang.String
 * @param yr java.lang.String
 * @param term java.lang.String
 * @param totalCredit int
 * @exception java.sql.SQLException The exception description.
 */
public void addRegister_Header(String stdid,String yr,String term,int totalcrd) throws java.sql.SQLException {
	aStudentManager.getInfoForCalMoney(stdid);
	
	//info from student
	String freecr_schp = aStudentManager.getFreecr_schp(); 
	String loan_schp = aStudentManager.getLoan_schp();
	String freesppt_schp = aStudentManager.getFreesppt_schp();
	String edutype = aStudentManager.getEdutype();


	int freecrd = findFreeCredit(freecr_schp,totalcrd);
	int cst_credit = fineLoan_schp(loan_schp,totalcrd);
	int cst_support = fineFreesppt_schp(loan_schp,freesppt_schp,edutype,term);
	
	//
	int cst_accident = fineCst_accident(term);
	
	int cst_activity = fineCst_activity(term);
	
	int cst_free = fineCst_free();

	int cst_lib = fineCst_lib();

	int cst_health = fineHealth();
	
	cst_total = fineCst_total(loan_schp,cst_credit,cst_support,cst_accident,cst_activity,cst_free,
									cst_lib,cst_health);
	
	String regid = "1";
	//add in register_header
	
	try
	{
		aRegister_Header.addRegister_Header(stdid,yr,term,regid,totalcrd,freecrd,cst_credit,
			cst_accident,cst_free,cst_lib,cst_health,cst_activity,cst_support,cst_total);
	}catch (SQLException e){}





	



	//
	
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 * @param text java.lang.String
 */
public String convertToThai(String text) {
		StringBuffer buffer = new StringBuffer ();
		
	 	for (int i=0;i<text.length();i++)
		{
			
			int c = (int)text.charAt(i);
			if (c>255)
			{
				c -=3424;
				buffer.append ((char)c);
			}
			
		}
		
	return buffer.toString ().trim ();;
}
/**
 * This method was created in VisualAge.
 * @return int
 * @param freecr_schp java.lang.String
 */
public int findFreeCredit(String freecr_schp,int totalcrd) {
	int freecrd=0;
	if (freecr_schp.equals("Y"))
		return totalcrd;
	else return 0;
}
/**
 * This method was created in VisualAge.
 * @return int
 * @param term java.lang.String
 */
public int fineCst_accident(String term) {
	if (term.equals("1"))
		return 130;
	else return 0;
}
/**
 * This method was created in VisualAge.
 * @return int
 * @param term java.lang.String
 */
public int fineCst_activity(String term) {
	if (term.equals("1"))
		return 240;
	else return 0;
}
/**
 * This method was created in VisualAge.
 * @return int
 */
public int fineCst_free() {
	return 250;
}
/**
 * This method was created in VisualAge.
 * @return int
 */
public int fineCst_lib() {
	return 100;
}
/**
 * This method was created in VisualAge.
 * @return int
 */
public int fineCst_total(String loan_schp,int cst_credit,int cst_support,int cst_accident,int cst_activity,
						int cst_free,int cst_lib,int cst_health) {
	int costTotal=0;
						
	if (loan_schp.equals("Y"))
	{
		costTotal = cst_credit + cst_accident;
		
	}
	else
	{
		costTotal = cst_credit + cst_support + cst_accident + cst_activity + cst_free +
									cst_lib + cst_health;
	}
	return costTotal;
}
/**
 * This method was created in VisualAge.
 * @return int
 * @param freesppt_schp java.lang.String
 * @param term java.lang.String
 */
public int fineFreesppt_schp(String loan_schp,String freesppt_schp,String edutype,String term) {
	String normal = "����";
	String support = "����";
	
	String stdNormal = convertToThai(normal);
	String stdSupport = convertToThai(support);
	String edutypeThai = convertToThai(edutype);

	
	int cst_support = 0;
	if (freesppt_schp.equals("Y") ||loan_schp.equals("Y"))
		cst_support = 0;
	else
	{
		if (edutypeThai.equals(stdNormal)&& (term.equals("1")||term.equals("2"))) //normal student
			{
				cst_support = 5000;
				
				
			}
		else if (edutypeThai.equals(stdSupport) && term.equals("1")) //support student
			{
				cst_support = 30000;
				
			}
		else {
				cst_support = 0;
				
			}
		
		
	}
	
	return cst_support;
}
/**
 * This method was created in VisualAge.
 * @return int
 */
public int fineHealth() {
	return 50;
}
/**
 * This method was created in VisualAge.
 * @return boolean
 * @param loan_schp java.lang.String
 */
public int fineLoan_schp(String loan_schp,int totalcrd) {
	int cst_total=0;
	if (loan_schp.equals("Y"))
		cst_total = 0;
	else cst_total = totalcrd*100;
	return cst_total;
}
/**
 * This method was created in VisualAge.
 * @return int
 */
public int getCst_total() {
	return cst_total;
}
/**
 * This method was created in VisualAge.
 * @return boolean
 * @param stdid java.lang.String
 * @param yr java.lang.String
 * @param term java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public boolean registerAlready(String stdid,String yr,String term) throws SQLException {
		boolean already = false;
		
		ResultSet rs = aRegister_Header.getReg_Header(stdid,yr,term);
		
		ResultSetMetaData rsmd = rs.getMetaData();
		int countCols = rsmd.getColumnCount();
		
		while (rs.next())
		{
			for(int i=1;i<=countCols;i++)
			{
				if (i==1) 
				{
					String stdID = rs.getString(i);
					
					if (!rs.wasNull()) already = true;
					
				}
				
				
			}//end i
		} //end while
		aRegister_Header.close();
	if (already) return true;
	else return false;
}
}