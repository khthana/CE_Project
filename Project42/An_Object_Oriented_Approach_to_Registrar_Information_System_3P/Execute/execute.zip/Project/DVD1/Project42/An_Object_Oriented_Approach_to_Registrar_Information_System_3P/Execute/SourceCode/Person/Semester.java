package Person;

/**
 * This type was created in VisualAge.
 */
 import java.sql.*;
import java.math.*;
import java.io.*;

public class Semester {
	Connection          conn;
	PreparedStatement   pstmt;
	Statement stmt;
	ResultSet rs;
	float gps=0;
	float gpa=0;
	
/**
 * Semester constructor comment.
 */
public Semester() {
	super();
}
/**
 * This method was created in VisualAge.
 * @param stdid java.lang.String
 * @param yr java.lang.String
 * @param term java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public void add(String stdid,String yr,String term) throws SQLException {
	String sql = "INSERT INTO Semester (STDID,YR,TERM) VALUES(?,?,?)";
		try {
			connectDB();
		    pstmt = conn.prepareStatement(sql);
			pstmt.setString(1,stdid);
			pstmt.setString(2,yr);
			pstmt.setString(3,term);
			pstmt.executeUpdate();
			
			pstmt.close();
			conn.commit();
			conn.close();
			
		}catch (SQLException e) {System.err.println(e.getMessage());} 
}
/**
 * This method was created in VisualAge.
 * @exception java.sql.SQLException The exception description.
 */
public void close() throws SQLException {
	rs.close();
		stmt.close();
		conn.close();
}
/**
 * This method was created in VisualAge.
 * @exception java.sql.SQLException The exception description.
 */
public void connectDB() throws SQLException {
	
	DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());

	conn =
		DriverManager.getConnection ("jdbc:oracle:thin:@dbserver:1521:orcl","database","0ew,jwfh");
	conn.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
	conn.setAutoCommit(false);
	
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 * @param text java.lang.String
 */
public String convertToThai(String text) {
		StringBuffer buffer = new StringBuffer ();
		
	 	for (int i=0;i<text.length();i++)
		{
			
			int c = (int)text.charAt(i);
			if (c>255)
			{
				c -=3424;
				buffer.append ((char)c);
			}
			
		}
		
	return buffer.toString ().trim ();;
}
/**
 * This method was created in VisualAge.
 * @return float
 */
public float getGpa() {
	return gpa;
}
/**
 * This method was created in VisualAge.
 * @return float
 */
public float getGps() {
	return gps;
}
/**
 * This method was created in VisualAge.
 * @param stdid java.lang.String
 * @param yr java.lang.String
 * @param term java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public void getGpxxx(String stdid,String yr,String term) throws SQLException {
	try
	{
		connectDB();
		String query = "SELECT gps,gpa "+
					 "FROM semester "+
					 "WHERE stdid = '" +
					 stdid + 
					 "' "+
					 "AND yr = '" +
					 yr +
					 "' "+
					 "AND term = '" +
					 term +
					 "'";
				
		stmt = conn.createStatement();
		rs = stmt.executeQuery(query);

		ResultSetMetaData rsmd = rs.getMetaData();
	    int cols = rsmd.getColumnCount();
		
		while (rs.next())
		{				
			for(int i=1;i<=cols;i++)
			{
				
				if (i==1)
				{
					gps = rs.getFloat(i);
					if (rs.wasNull())
						gps = 0;
				}
				else
				{
					gpa = rs.getFloat(i);
					
					if (rs.wasNull())
						gpa = 0;
				}
			
			}
		}
		close();
		
	}
	catch (SQLException e) {}
	
	
}
}