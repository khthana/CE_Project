package PersonManager;

/**
 * This type was created in VisualAge.
 */
import java.sql.*;
import java.math.*;
import java.io.*;
import Person.*;
import TableInUseManager.*;
public class SubjectsManager {
	private Subjects aSubjects;
	private RegisterTableManager aRegisterTableManager;
	private AddSubjectTableManager aAddSubjectTableManager;
	private DelSubjectTableManager aDelSubjectTableManager;
	private Register_CourseManager aRegister_CourseManager;
	ResultSet rs;
	 int countRow = 0;  //for continue register
	 int rowInTable=-1;
	
	 int countRowOfAdd = 0; // for Add
	 int rowInTableOfAdd = -1;

	 int countRowOfDel = 0; //for Del
	 int rowInTableOfDel = -1;
	 
	 int countCols;
	 boolean useSubjectManager=false; // for check isCreditUp12 in register_detailManager
	 boolean first=true;  //for getSubjectsContinue
	 boolean firstForAdd = true; //for isExistAlreadyForAdd;
	 boolean firstForDel = true; //for isExistAlreadyForDel;
	

/**
 * SubjectsManager constructor comment.
 */
public SubjectsManager() {
	super();
}
/**
 * SubjectsManager constructor comment.
 */
public SubjectsManager(Subjects s) {
	super();
	aSubjects = s;
}
/**
 * SubjectsManager constructor comment.
 */
public SubjectsManager(Subjects s,RegisterTableManager rm,AddSubjectTableManager atm,
	DelSubjectTableManager dtm,Register_CourseManager rcm) {
	
	super();
	aSubjects = s;
	aRegisterTableManager = rm;
	aAddSubjectTableManager = atm;
	aDelSubjectTableManager = dtm;
	aRegister_CourseManager = rcm;
}
/**
 * This method was created in VisualAge.
 * @exception java.sql.SQLException The exception description.
 */
public void close() throws SQLException {
	aSubjects.close();
}
/**
 * This method was created in VisualAge.
 * @return int
 */
public int getCountCols() {
	return countCols;
}
/**
 * This method was created in VisualAge.
 * @return int
 */
public int getCountRow() {
	return countRow; //number of row int RegisterTable
}
/**
 * This method was created in VisualAge.
 * @return int
 */
public int getCountRowOfAdd() {
	return countRowOfAdd;
}
/**
 * This method was created in VisualAge.
 * @return int
 */
public int getCountRowOfDel() {
	return countRowOfDel;
}
/**
 * This method was created in VisualAge.
 * @param subId java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public void getSubjectsContinue(String subId) throws SQLException {
		useSubjectManager = true;
		ResultSet rs = aSubjects.getSubjects(subId);
		ResultSetMetaData rsmd = rs.getMetaData();
		countCols = rsmd.getColumnCount();
		
		if (first)
		{	 countRow = aRegister_CourseManager.getCountRow();
			 rowInTable = aRegister_CourseManager.getRowInTable();
			first = false;
		}	
		
		while (rs.next())
		{
			countRow++;
			rowInTable++;
			for(int i=0;i<=countCols;i++)
			{
				if (i==0) {String rr = ""+countRow;
							Object ob = (Object)rr;
							aRegisterTableManager.setValuesInTable(ob,rowInTable,0);}
				else if (i==1) {String subid = rs.getString(i);
							Object ob = (Object)subid;
							aRegisterTableManager.setValuesInTable(ob,rowInTable,i);}
				else if (i==2){String subname= rs.getString(i);
							Object ob = (Object)subname;
							aRegisterTableManager.setValuesInTable(ob,rowInTable,i); }
				else {String credit = rs.getString(i);
							Object ob = (Object)credit;
							aRegisterTableManager.setValuesInTable(ob,rowInTable,i);}
				
				
			}//end i
		} //end while
		aSubjects.close();
	
	
}
/**
 * This method was created in VisualAge.
 * @param subid java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public void getSubjectsForAdd(String subid) throws SQLException {
	
	ResultSet rs = aSubjects.getSubjects(subid);
		
		ResultSetMetaData rsmd = rs.getMetaData();
		countCols = rsmd.getColumnCount();
		
	
		while (rs.next())
		{
			countRowOfAdd++;
			rowInTableOfAdd++;
			for(int i=0;i<=countCols;i++)
			{
				if (i==0) {String rr = ""+countRowOfAdd;
							Object ob = (Object)rr;
							aAddSubjectTableManager.setValuesInTable(ob,rowInTableOfAdd,0);}
				else if (i==1) {String subId = rs.getString(i);
							Object ob = (Object)subid;
							aAddSubjectTableManager.setValuesInTable(ob,rowInTableOfAdd,i);}
				else if (i==2){String subname= rs.getString(i);
							Object ob = (Object)subname;
							aAddSubjectTableManager.setValuesInTable(ob,rowInTableOfAdd,i); }
				else {String credit = rs.getString(i);
							Object ob = (Object)credit;
							aAddSubjectTableManager.setValuesInTable(ob,rowInTableOfAdd,i);}
				
				
			}//end i
		} //end while
		aSubjects.close();
	
}
/**
 * This method was created in VisualAge.
 * @param subid java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public void getSubjectsForDel(String subid) throws SQLException {
		ResultSet rs = aSubjects.getSubjects(subid);
		
		ResultSetMetaData rsmd = rs.getMetaData();
		countCols = rsmd.getColumnCount();
		
	
		while (rs.next())
		{
			countRowOfDel++;
			rowInTableOfDel++;
			for(int i=0;i<=countCols;i++)
			{
				if (i==0) {String rr = ""+countRowOfDel;
							Object ob = (Object)rr;
							aDelSubjectTableManager.setValuesInTable(ob,rowInTableOfDel,0);}
				else if (i==1) {String subId = rs.getString(i);
							Object ob = (Object)subid;
							aDelSubjectTableManager.setValuesInTable(ob,rowInTableOfDel,i);}
				else if (i==2){String subname= rs.getString(i);
							Object ob = (Object)subname;
							aDelSubjectTableManager.setValuesInTable(ob,rowInTableOfDel,i); }
				else {String credit = rs.getString(i);
							Object ob = (Object)credit;
							aDelSubjectTableManager.setValuesInTable(ob,rowInTableOfDel,i);}
				
				
			}//end i
		} //end while
		aSubjects.close();
	

}
/**
 * This method was created in VisualAge.
 * @return boolean
 */
public boolean isExistAlreadyForAdd(String subid) {
	int c=0;
	int r = 0;
	int i=0,j;
	boolean found = false;
	
	
	if (firstForAdd)
	{
		r = 1;
		c = aRegister_CourseManager.getCountCols();
		firstForAdd = false;
	}
	else 
	{
		r = getCountRowOfAdd();
		c = getCountCols();
	}
	while (i<r && !found)
	{
		
		for (j=1;j<=c;j++)
		{
			if (j==1) {
					
					Object ob_subid = aAddSubjectTableManager.getValuesInTable(i,j);
					
					String str_subid = (String)ob_subid;
					int compare = str_subid.compareTo(subid);
					if (compare == 0) found = true;
					
					}
					
		} //end j
	i++;
	}//end while
	
	if (found) return true;
	else return false;
}
/**
 * This method was created in VisualAge.
 * @return boolean
 */
public boolean isExistAlreadyForContinue(String subid) {
	//getValue and checkExistAlready
	
	int c = aRegister_CourseManager.getCountCols();
	int i=0,j;
	boolean found = false;
	int r = 0;
	
	if (getCountRow()>0)
		r = getCountRow();
	else r = aRegister_CourseManager.getCountRow();
	
	while (i<r && !found)
	{
		
		for (j=1;j<=c;j++)
		{
			if (j==1) {
					
					Object ob_subid = aRegisterTableManager.getValuesInTable(i,j);
					
					String str_subid = (String)ob_subid;
					int compare = str_subid.compareTo(subid);
					if (compare == 0) found = true;
					
					}
					
		} //end j
	i++;
	}//end while
	
	if (found) return true;
	else return false;
}
/**
 * This method was created in VisualAge.
 * @return boolean
 */
public boolean isExistAlreadyForDel(String subid) {
	int c=0;
	int r = 0;
	int i=0,j;
	boolean found = false;
	
	
	if (firstForDel)
	{
		r = 1;
		c = aRegister_CourseManager.getCountCols();
		firstForDel = false;
	}
	else 
	{
		r = getCountRowOfDel();
		c = getCountCols();
	}
	
	while (i<r && !found)
	{
		
		for (j=1;j<=c;j++)
		{
			if (j==1) {
					
					Object ob_subid = aDelSubjectTableManager.getValuesInTable(i,j);
					
					String str_subid = (String)ob_subid;
					int compare = str_subid.compareTo(subid);
					if (compare == 0) found = true;
					
					}
					
		} //end j
	i++;
	}//end while
	
	if (found) return true;
	else return false;
}
/**
 * This method was created in VisualAge.
 * @return boolean
 */
public boolean isUseSubjectManager() {
	return useSubjectManager;
}
/**
 * This method was created in VisualAge.
 */
public void setFirstValues() {
	countRow = 0;
		rowInTable = -1;
}
/**
 * This method was created in VisualAge.
 */
public void setFirstValuesForAdd() {
	countRowOfAdd = 0; 
	rowInTableOfAdd = -1;
}
/**
 * This method was created in VisualAge.
 */
public void setFirstValuesForDel() {
	countRowOfDel = 0; 
	rowInTableOfDel = -1;
}
}