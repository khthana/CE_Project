#include "utils.h"
#include "dllib.h"


unsigned char ChkPkt(unsigned char xdata *);


unsigned char ToutCount[8]={0,0,0,0,0,0,0,0};
code void (*ToutFunc[8])()={DataLinkTimeOut,0,0,0,0,0,0,0};


bit IS_ESC=0;
bit PACKET_OK;
unsigned int Timecount;
unsigned int CountIn;
unsigned char xdata Inbuf[0x800];
unsigned char xdata Outbuf[0x800];
unsigned char CountData;


void StartNet485(void)
{
	EnaSerial();
	StartTimer0();
	RecvMode;
}

void StopNet485(void)
{
	EnaSerial();
	StartTimer0();
}


void TimerISR0(void) interrupt 1 using 1
{
unsigned char	TimeIndex = 0;
	TR0 = 0;				/* stop timer 0 */
	/* define follow to flowchat */
	
	for(TimeIndex=0;TimeIndex<8;TimeIndex++)
	{	
		if(ToutCount[TimeIndex]!=0)
		{
			if(ToutCount[TimeIndex]==1){}
			/* CallBack to pointer function */
				//ToutFunc[TimeIndex]();
			ToutCount[TimeIndex]--;
		}
		
	}
	
	/* define follow to flowchat */
	TL0 = TIMERLOW;
	TH0 = TIMERHIGH;
	TR0 = 1;				/* start timer 0 */
}

void ExtISR1(void) interrupt 2 using 1
{
}

void TimerISR1(void) interrupt 3 using 1
{
}

void SerialISR(void) interrupt 4 using 1
{
unsigned char	DataIn;
	if(RI)
	{
		DataIn = SBUF;
		if(DataIn == __END)              // __END
		{
			if(GetDistID(currentPacketIn->id)==DEVICE_ID) /* This is My Packet */
			{
				//PACKET_OK = (bit)ChkPkt((unsigned char xdata *)Inbuf); /* Check Sum Packet flag */
				//SendControlTo(CONT_SND_NAK,1);
				IntoPhase(); /* in to phase operation */
			}
			CountIn = 0;
		}
		else
		{
			if(IS_ESC)
			{
				switch(DataIn)
				{
				case __ESC_END:
					Inbuf[CountIn++] = __END;
					break;
				case __ESC_ESC:
					Inbuf[CountIn++] = __ESC;
					break;
				default:
					SetPhase(COVE_PHASE);
				}
				IS_ESC = 0;
			}
			else
			{
				if(DataIn == __ESC)
					IS_ESC = 1;
				else
					Inbuf[CountIn++] = DataIn;
			}
		}
		RI=0;
	}
}

void InitTimer0(void)
{
	INT_DISABLE;			/* disable interrupts */


	TR0 = 0;			/* stop timer 0 */

	TMOD &= ~0x0F;			/* clear timer 0 mode bits */
	TMOD |= 0x01;			/* put timer 0 into 16-bit no prescale */

	TL0 = TIMERLOW;
	TH0 = TIMERHIGH;

	PT0 = 0;			/* set low priority for timer 0 */
	ET0 = 1;			/* enable timer 0 interrupt */

/*	TR0 = 1;	*/		/* start timer 0 */

	INT_ENABLE;			/* enable interrupts */
}


void InitSer(void)
{
	//	RCAP = 0xFFC0 is 9600 bps
	//	RCAP = 0xFFE0 is 19.2K bps
	//	Serial Interrupt service routine is interrupt 4
	RCAP2L = 0xe0;
	RCAP2H = 0xff;
	SCON =  0x50;
	T2CON = 0x34;
	TI = 0;
	RI = 0;
	
}
void ServerStart(void)
{
unsigned char dy;
	SendMode;
	ES=0;
	SBUF=0x55;
	while(!TI);
	TI=0;
	for(dy=0;dy<10;dy++);
	SBUF=0xaa;
	while(!TI);
	TI=0;
	ES=1;
	RecvMode;
}
void ClientStart(void)
{
	RecvMode;
	ES=0;
	RI=0;
	while(SBUF!=0x55);
	RI=0;
	while(SBUF!=0xaa);
	RI=0;
	ES=1;
}

unsigned char GetToutIndex(unsigned char idx)
{
	return ToutCount[idx];
}
void SetToutIndex(unsigned char fIdx,unsigned char cnt)
{
	ToutCount[fIdx] = cnt;
}

void ClrToutIndex(unsigned char fIdx)
{
	ToutCount[fIdx] = 0;
}

void ClearPacket(void)
{
	CountIn=0;
	CountData=0;
}

void SendByte(unsigned char send)
{
	DisSerial();
	SendMode;
	SBUF=send;
	while(!TI);
	TI=0;
	RecvMode;
	EnaSerial();
}
/* ======================================== packet ========================================= */
/* ----------------------------------------------------------------------------------------- *
 *	|         |           |           |           |                        |          |     | *
 * | type[8] | id_sour[4]|id_dist[4] | lenght[8] | data[$lenght]..........|chksum[8] | END | *
 *	|         |           |           |           |                        |          |     | *
 *	----------------------------------------------------------------------------------------- */
	
void SendPacket(unsigned char xdata *pkt,unsigned int counts)
{
	unsigned int cntt;
	DisSerial();
	SendMode;
	for(cntt=0; cntt < counts; cntt++)
	{
		switch(pkt[cntt])
		{
		case __END:
			SBUF = __ESC;
			while(!TI);
			TI=0;
			SBUF = __ESC_END;
			while(!TI);
			TI=0;
			break;
		case __ESC:
			SBUF = __ESC;
			while(!TI);
			TI=0;
			SBUF = __ESC_ESC;
			while(!TI);
			TI=0;
			break;
		default:
			SBUF = pkt[cntt];
			while(!TI);
			TI=0;
		}
	}
	SBUF = __END;
	while(!TI);
	TI=0;
	RecvMode;
	EnaSerial();
}

unsigned char ChkPkt(unsigned char xdata *pkt)
{
	unsigned char l;
	unsigned char csum;
	struct Hdrpkt xdata *hdr;
	
	csum = 0;
	hdr = (struct Hdrpkt xdata *)pkt;
	
	for(l=0;l<(hdr->len + 3);l++)
		csum = csum + pkt[l];
	csum = (~csum) + 1;
	if( csum == pkt[l] )
		return 1;
	else
		return 0;
}





















































































































































































































































































































