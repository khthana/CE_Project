#ifndef	_RAMSHARE_H_
#define	_RAMSHARE_H_
extern void SendToPC(unsigned char len,unsigned char xdata *dat);
extern char ChkReqPC(void);
extern unsigned char GetDataTo(unsigned char xdata *dist);
extern void InitEx0(void);
#endif
