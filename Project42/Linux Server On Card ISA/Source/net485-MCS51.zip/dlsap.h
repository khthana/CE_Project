#ifndef  _DLSAP_H_
#define  _DLSAP_H_

extern void PutPacket(unsigned char dist_id,unsigned char len,void xdata *outpkt);
extern char ChkPacketToSend(void);
#endif 
