/* data link service access provider */
#include "dllib.h"
#include "memlib.h"

struct dlpkt xdata *pkt_list=0;

void PutPacket(unsigned char dist_id,unsigned char len,void xdata *outpkt)
{
struct dlpkt xdata *pkl;
unsigned char datalen,idd;
	datalen = len;
	idd = (0xf0&(DEVICE_ID<<4)) | (0x0f&dist_id);
	if(pkt_list == 0)
	{
		pkt_list = malloc(sizeof(struct dlpkt));
		pkt_list->pkt_hdr.cont = CONT_PAK;
		pkt_list->pkt_hdr.id = idd;
		pkt_list->pkt_hdr.len = datalen;
		pkt_list->pkt_next = (void xdata*)0;
		pkt_list->pkt = outpkt;
	}
	else
	{
		pkl = pkt_list;
		while(pkl->pkt_next==0)
			pkl = pkl->pkt_next;
		
		pkl->pkt_next = malloc(len + sizeof(struct dlpkt) - 1);
		pkt_list->pkt_next->pkt_hdr.cont = CONT_PAK;
		pkt_list->pkt_next->pkt_hdr.id = DEVICE_ID | (0x0f&dist_id);
		pkt_list->pkt_next->pkt_hdr.len = len;
		pkl->pkt_next->pkt_next = (void xdata*)0 ;
		pkl->pkt_next->pkt = outpkt;
	}
}

char ChkPacketToSend(void)
{
	if(pkt_list!=0)
	{
		MkpktToOutbuf((unsigned char xdata*)pkt_list->pkt,pkt_list->pkt_hdr.id,pkt_list->pkt_hdr.len);
	}
	return 0;
}










































































































































































