#ifndef	_UTILLIB_H_
#define	_UTILLIB_H_
#include "utils.h"

extern void StartNet485(void);
extern void StopNet485(void);
extern void InitTimer0(void);
extern void InitSer(void);
extern unsigned char GetToutIndex(unsigned char idx);
extern void SetToutIndex(unsigned char fIdx,unsigned char cnt);
extern void ClrToutIndex(unsigned char fIdx);
extern void ClearPacket(void);
extern void SendByte(unsigned char send);
extern void SendPacket(unsigned char xdata *packet,unsigned int counts);
extern unsigned char ChkPkt(unsigned char xdata *pkt);
extern void ServerStart(void);
extern void ClientStart(void);

extern unsigned char xdata Inbuf[0x800];
extern unsigned char xdata Outbuf[0x800];

#endif 
