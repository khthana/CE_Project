//#include <reg52.h>
#include "mmem.h"
struct superb	xdata *superblock;

void init_mem(struct superb xdata *super,unsigned int len)
{
	superblock = super;
	superblock->Usage = 0;
	superblock->Empty = (struct mm xdata*)&superblock->mem;
	superblock->len = len - (sizeof(struct superb) - 1);
	superblock->Empty->next = 0;
	superblock->Empty->len = superblock->len - (sizeof(struct mm) - 1);
}

void xdata *malloc(unsigned int sz)
{
	struct mm xdata *p;
	struct mm xdata *k;
	struct mm xdata *l;
	p = superblock->Empty;
	l = p;
	sz += sizeof(struct mm) - 1;	
	while((p!=0) && (p->len <= sz))
	{
		l = p;      		//
		p = p->next;      // l->next == p for reference in use.
	}
	
	if(p==0)
		return (void xdata *)0;

	if(p==superblock->Empty)
	{
		if((p->len - sz) <= 4)
		{
			superblock->Empty = p->next;
			
		}
		else
		{// when this empty block is pointer {p}
			superblock->Empty =(void xdata *) p + sz; //next memory space
			superblock->Empty->next = p->next;
			superblock->Empty->len = p->len - sz;
			p->len = sz - (sizeof(struct mm) -1 );
		}
	}
	else
	{
		if((p->len - sz) <= 4)
		{
			l->next = p->next;
		}
		else
		{
			l->next = (void xdata *)p + sz;
			l->next->next = p->next;
			l->next->len = p->len - sz;
			p->len = sz - (sizeof(struct mm) -1 );
		}
	}
	

	k = superblock->Usage;
	if(k==0)
	{
		superblock->Usage = p;
	}
	else
	{
		while(k->next!=0)
			k = k->next;
		k->next = p;
	}
	
   p->next = (void xdata *)0;

	return (&p->mem);	
	
}



/* Free memory */
char freemem(void *mem)
{
	struct mm xdata *mmhead;
	struct mm xdata *k;
	struct mm xdata *l;
	
	mmhead = (void xdata *)mem - (sizeof(struct mm) - 1)  ;
	//Check this mem pointer is list in mem management
	
	/* superblock usage cleanning */
	if(mmhead == superblock->Usage)
	{
		superblock->Usage = mmhead->next;
	}
	else
	{
		k = superblock->Usage;
		while((k->next!=mmhead) && (k->next!=0))
			k = k->next;
		if(k->next!=mmhead)
			return -1; // Error , becouse this pointer is not in list memory
		k->next = mmhead->next;
	}
	
	/* superblock empty cleanning */
	
	/* defarg empty list memory */

	if( (void xdata *)(mmhead + mmhead->len + (sizeof(struct mm) - 1)) < 
	(void xdata *)(superblock + superblock->len + (sizeof(struct superb) - 1)) ) 
	{
		k = superblock->Empty;
		l =(void xdata *) mmhead + mmhead->len + (sizeof(struct mm) - 1);
		while( (k != l) && (k!=0))
			k = k->next;
			
		if(k!=0)
		{
			l = superblock->Empty;
			if(superblock->Empty == k)
			{
				superblock->Empty = k->next;
			}
			else
			{
				while((l->next != k) && (l->next != 0))
					l = l->next;
					
				l->next = k->next;
			}
			mmhead->len += k->len + (sizeof(struct mm) - 1);
			if(superblock->Empty == 0)
				superblock->Empty = mmhead;
		}
		
	}


	if(mmhead!=(void xdata *)&superblock->mem)
	{
		k = superblock->Empty;
		l = (void xdata *)k+k->len+(sizeof(struct mm)-1);
		while( ( l != mmhead) && (k != 0) )
		{
			k = k->next;
			l = (void xdata *)k+k->len+(sizeof(struct mm)-1);
		}
		
		if(k!=0)
		{
			k->len += mmhead->len + (sizeof(struct mm) - 1);
		}
		else
		{
			k = superblock->Empty;
			while(k->next != 0)
				k = k->next;
			k->next = mmhead;;
			mmhead->next = 0;
		}
	}
	else
	{
		k = superblock->Empty;
		while(k->next!=0)
			k = k->next;
		k->next = mmhead;
		mmhead->next = 0;
	}
	return 0;
}

void memcpy(unsigned char xdata *memdist,unsigned char xdata *memsrc,unsigned int len)
{
	unsigned int l;
	for(l=0;l<len;l++)
		memdist[l] = memsrc[l];
}






































































































































































