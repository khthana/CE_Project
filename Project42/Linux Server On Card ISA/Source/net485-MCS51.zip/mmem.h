struct mm {
	struct mm xdata	*next;
	unsigned int		len;
	unsigned char		mem[1];
	};
struct superb {
	struct mm xdata	*Usage;
	struct mm xdata	*Empty;
	unsigned int		len;
	unsigned char		mem[1];
	};
