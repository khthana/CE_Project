#include <reg52.h>                           
#include <stdio.h>
#define InPort 0x8000
#define OutPort 0x8000
sbit IRQ7      =P3^5;
sbit Dir       =P3^4; 
void SendPackage();
void irq7();
void initial();
void Send(unsigned char Address,unsigned char Data);
void Delay();
char Command=0xff,Status=0xff;
unsigned char xdata Xram[0xffff];
unsigned char Address,Data;
main()
{
	initial();
	while(1){};

}

void initial()
{
        SCON=0xf0;      //mode 3 Rx,Tx enable
        PCON=0x00;
        TMOD=0x21;      //timer 1 mode 2 timer 0 mode 1
        TH1=0xfd;       //baud rate 9600
        TR1=1;          //start timer
        EA=1;
        IT0=1;
        EX0=1;
        IRQ7=0;
        ET0=1;
        ES=1;
        SM2=0;        //receive data don't care address flag
        Dir=0;        //control direction 485 0=receive 1=send
        P1=0x5a;
}



void Send(unsigned char Address,unsigned char Data)
{
        ES=0;
        Dir=1;
        //TB8=1;             //address flag
        //SBUF=Address;
        //while(!TI);
        TI=0;
        TB8=0;             //data flag
        SBUF=Data;
        while(!TI);
        TI=0;
        Dir=0;
        ES=1;
}


void SendPackage()
{
	//unsigned char Control=Xram[0],Source=Xram[1],Destination=Xram[2];
//	unsigned long Length=Xram[0],i;
//	Length=Length & 0x00ffffff;
   unsigned short Length=Xram[0],i;  
	for(i=2;i<Length;i++)
	{
		 Send(0,Xram[i]);
		 P1=Xram[i];
 	}
}

void Delay()
{
	unsigned int	j;
	for(j=0;j<30000;j++)
	{
	}
}

serialint() interrupt 4
{
        if(TI)  TI=0;
        else
        {
                if(RB8) Address=SBUF;
                else Data=SBUF;
                RI=0;
         }
}



ext0() interrupt 0
{
        Command=Xram[InPort];
        switch(Command)
        {
        		case 0:{ Xram[OutPort]=0;irq7();break;}  //PC request mem
        		case 1:{ SendPackage();Xram[OutPort]=1;irq7();break;} // PC release mem
        }
        
}


void irq7()
{
 	char i=0;
	IRQ7=1;
    for(i=0;i<3;i++);
	IRQ7=0;
}
		













