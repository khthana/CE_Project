#ifndef	_DLLIB_H_
#define	_DLLIB_H_
#include "datalink.h"
extern void DataLinkInit(void);
extern void Mkhdr(unsigned char conts,unsigned char id,unsigned char len,struct Hdrpkt xdata *buff);
extern char MkpktToOutbuf(unsigned char xdata *datasnd,unsigned char ids,unsigned char len);
extern void SendControlTo(unsigned char cont,unsigned char dist);
extern void IntoPhase(void);
extern unsigned char phase;
extern struct Hdrpkt xdata *currentPacketIn;
extern void DataLinkTimeOut();

extern bit waitACK;
extern bit readyToSend;
extern bit readyToRecv;

#endif 
