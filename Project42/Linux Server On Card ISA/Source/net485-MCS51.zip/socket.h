#include "socktype.h"                      
#define MIN_SOCK	1
#define MAX_SOCK	100
extern void socketinit(void);
extern int skopen(int domain, int type, int protocol);
extern void close(int socket);
extern int bind(int socket, struct sockaddr_in xdata *address, int address_len);
extern int connect(int socket, struct sockaddr_in xdata *address, int address_len);
extern void sockwrite(int socket,void xdata *dat,int len);
extern char sockread(int socket);
extern void xdata *findsock(int socket);
