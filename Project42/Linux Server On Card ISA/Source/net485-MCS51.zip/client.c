#define LOCALHOST	0xc0a80102	/* decimal IP 192.168.1.2 */
#define DISTHOST	0xa1f60594	/* decimal IP 161.246.5.148 */
#include "memlib.h"
#include "dllib.h"
#include "utillib.h"
#include "socket.h"
xdata void *ma,*a;
unsigned char xdata sys_mem[0x4000];
xdata char testdata[]={"test the RS485 device"};
xdata char distdata[100];
void main(void)
{
int sk;
struct sockaddr_in xdata addr;
	InitSer();                         
	InitTimer0();
	DataLinkInit();
	StartNet485();
	ClientStart();
//	SendControlTo(CONT_SND_CHK,2);
/*============================================*/
	
	init_mem((void xdata*)&sys_mem,sizeof(sys_mem));
	sk = skopen(0,0,0);
	addr.sin_family = AF_INET;
	addr.sin_port = 6000;
	addr.sin_addr.s_addr =  LOCALHOST;
	if(bind(sk,&addr,0)==-1)
		return;
	addr.sin_port = 6000;
	addr.sin_addr.s_addr =  DISTHOST;
	if(connect(sk,&addr,0)==-1)
		return;
	sockwrite(sk,(void xdata*)&testdata,sizeof(testdata));
	while(1);
	close(sk);

/*
	InitSer();
	InitTimer0();
	DataLinkInit();
	StartNet485();
	SendControlTo(CONT_SND_ACK,1);
	while(1);
	StopNet485();
*/
} 




































































































































































