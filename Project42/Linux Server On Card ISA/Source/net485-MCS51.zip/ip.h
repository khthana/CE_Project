#ifndef  _IP_H_
#define  _IP_H_
#include "protocol.h"
extern void PutUDP(int socket,void xdata *Dat,unsigned int len);
extern void PutIP(int socket,void xdata *Dat,unsigned int len);

#endif 

