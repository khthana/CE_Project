#define MIN_SOCK	1
#define MAX_SOCK	100
#define SOCK_STREAM	1
#define SOCK_DGRAM	2

#define AF_UNIX			1
#define AF_INET			2
#define AF_ISO				3
#define AF_NS				4
#define AF_APPLETALK		5

/* status socket define */
#define SK_STAR	1
#define SK_BIND	2
#define SK_CONN	2
#define SK_STOP	4

struct in_addr
{
	unsigned long	s_addr;
};
struct sockaddr_in 
{
	unsigned char	sin_family;
	unsigned int	sin_port;
	struct in_addr	sin_addr;
}; 

struct sockbuf
{
	void xdata *next;
	unsigned int len;
};

struct skfd
{
	int	sock_id;
	unsigned char status;
	unsigned char type;
	struct sockaddr_in	address;
	struct sockaddr_in	dist_addr;
	struct skfd xdata *skfd_next;
	struct sockbuf xdata *buffer;
};
