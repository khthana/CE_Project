#include <reg52.h>
#include <stdlib.h>
#include <stdio.h>
void main(void)
{
void *ma;
ma = (void *)malloc(3);
} 
