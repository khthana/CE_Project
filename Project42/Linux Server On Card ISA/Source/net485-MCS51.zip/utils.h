#include <reg52.h>
#define INT_DISABLE	EA = 0
#define INT_ENABLE	EA = 1
#define TIMERHIGH	0xe0
#define TIMERLOW	0x34
#define SendMode	SEND_EN=1
#define RecvMode	SEND_EN=0
#define DisSerial()		ES=0
#define EnaSerial()		ES=1
#define StartTimer0()	TR0=1;
#define StopTimer0()		TR0=0;
#define __END			192
#define __ESC			219
#define __ESC_END	220
#define __ESC_ESC	221 

sbit	SEND_EN	=	P3^4;

