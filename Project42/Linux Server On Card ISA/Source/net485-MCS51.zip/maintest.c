#include <reg52.h>
#include <memset.h>
#include "utils.h"
#include "dmem.h"
#include "datalink.h"
#define XBYTE ((unsigned char *) 0x20000L)
extern bit waitACK;
extern void InitTimer0(void);
extern void InitSer(void);
extern void StartNet485(void);
extern void SetToutIndex(unsigned char ,unsigned char );
extern void ClrToutIndex(unsigned char fIdx);
extern unsigned char xdata Inbuf[0x800];
extern void DataLinkInit(void);
extern unsigned char GetToutIndex(unsigned char idx);

void SendControlTo(unsigned char cont,unsigned char dist);
xdata void *ma,*a;

void main(void)
{
unsigned char idd;
 InitSer();
 InitTimer0();
 DataLinkInit();
 StartNet485();
 
 SetToutIndex(0,3);
 init_mempool((struct mem xdata *)&Inbuf, 0x800);
 ma = (void xdata *)malloc(3);
 a = (void xdata *)malloc(3);
 /* working */
 while(1)
 {
 for (idd=2;idd<8;idd++)
 {
 	SetWaitACK();
 	SetToutIndex(0,10);
	SendControlTo(CONT_SND_CHK,idd);
	while(GetToutIndex(0)){};
 }
 };
}






































