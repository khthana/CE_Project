#include "protocol.h"
#include "memlib.h"
#include "socket.h"
#include "dlsap.h"
/* Send UDP packet side */
void PutUDP(int socket,void xdata *Dat,unsigned int len)
{

}


/* Send IP packet side */
void PutIP(int socket,void xdata *Dat,unsigned int len)
{
struct skfd *sk;
unsigned char xdata *ip_dgram;
struct iphdr xdata *ipheader;
struct udp xdata *udpheader;
unsigned char data_len;
	if(((sk = findsock(socket)) == 0))
		return ;

	ip_dgram = malloc(sizeof(struct iphdr)+sizeof(struct udp)+len);

	ipheader = (void xdata*)ip_dgram;
	udpheader = (void xdata*)ipheader + sizeof(struct iphdr);
	
	/* IP Header Making */
	ipheader->ver_len = 0x45; /* ser version and lenght of IP header */
	ipheader->tos = 0x00;
	ipheader->totallen = sizeof(struct iphdr)+sizeof(struct udp)+len;
	ipheader->id = 0;
	ipheader->fg_fm = 0x00;
	ipheader->ttl = 0x40;
	ipheader->protocol = UDP_PROTOCOL;
	ipheader->hchksum = 0;
	ipheader->ip_sour = sk->address.sin_addr.s_addr;
	ipheader->ip_dist = sk->dist_addr.sin_addr.s_addr;
	
	/* UDP Header Making */
	udpheader->port_sour = sk->address.sin_port;
	udpheader->port_dist = sk->dist_addr.sin_port;
	udpheader->len = sizeof(struct udp) + len;
	udpheader->chksum = 0;
	
	memcpy((void xdata*)ip_dgram + sizeof(struct iphdr) + sizeof(struct udp),
			(void xdata*)Dat,
			len);
	
	/* map ARP -> IP to DEVICE ID */
	
	
	
	/* Put Packet to datalink service access provider [DLSAP]*/
		
	data_len = sizeof(struct iphdr)+sizeof(struct udp)+(unsigned char)len;
	PutPacket(1,data_len,(void xdata*)ip_dgram);
	
}









































































































