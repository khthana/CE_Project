#include "datalink.h"
#include "utillib.h"
#include "dlsap.h"
/*
extern SendPacket(unsigned char xdata *,unsigned int);
extern unsigned char xdata Inbuf[0x800];
extern unsigned char xdata Outbuf[0x800];
extern bit PACKET_OK;
extern void PacketIN(void);
*/
void ServerSync(void);
void ClientSync(void);
void ConnectPhase(void);
void ConnectPhase(void);
void TransmitPhase(void);
void DisconnectPhase(void);
void PassivePhase(void);


bit readyToSend; /* This is API to high layer */
bit readyToRecv;
bit waitACK;
unsigned char phase=0;
unsigned char sourceID;
struct Hdrpkt xdata *currentPacketIn;
struct Hdrpkt xdata *currentPacketOut;


void DataLinkInit(void)
{
	currentPacketIn  = (struct Hdrpkt xdata *)&Inbuf;
	currentPacketOut = (struct Hdrpkt xdata *)&Outbuf;
	phase = SYNC_PHASE;
	ReadyToSend();
	ReadyToRecv();

}

void Mkhdr(unsigned char conts,unsigned char id,unsigned char len,struct Hdrpkt xdata *buff)
{
unsigned char IDS;
	IDS=DEVICE_ID<<4;
//	buff->id = id;
	buff->id = (DEVICE_ID<<4)|id;
//	IDS=(IDS&0xf0)|(id);
	buff->cont=conts;
//	buff->id=(buff->id&0xf0)|(id);
	buff->len=len;
}

/* Make datagram to Out buffer and set not ready to send for send packet */
char MkpktToOutbuf(unsigned char xdata *datasnd,unsigned char ids,unsigned char len)
{
	unsigned char l;
	unsigned char csum;
	csum = 0;
	if(readyToSend)
	{
		Mkhdr(CONT_PAK, 
				ids ,
				len ,
				(struct Hdrpkt xdata *)&Outbuf);
		/* copy data */
		for(l=0;l<len;l++)
			Outbuf[l+3] = datasnd[l];
		/* make check sum */
		for(l=0;l<(len+3);l++)
			csum = csum + Outbuf[l];
		csum = (~csum) + 1;
		Outbuf[len+3] = csum;
		readyToSend = 0;
		return 1;
	}
	else
		return 0;
}


void SendControlTo(unsigned char cont,unsigned char dist)
{
unsigned char xdata HeaderCont[4];
	Mkhdr(cont,dist,0,(struct Hdrpkt xdata*)&HeaderCont);
	HeaderCont[3] = ~(HeaderCont[0] + HeaderCont[1] + HeaderCont[2]) + 1;
	SendPacket((unsigned char xdata*)&HeaderCont,sizeof(struct Hdrpkt)+1);
}

void DataLinkTimeOut()
{
}


void IntoPhase(void)
{
	sourceID = GetSourID(currentPacketIn->id);
	switch(phase)
	{
	case SERV_SYNC:
		ServerSync();
		break;
	case CLNT_SYNC:
		ClientSync();
		break;
	case CONN_PHASE:
		ConnectPhase();
		break;
	case TRAN_PHASE:
		TransmitPhase();
		break;
	case DISC_PHASE:
		DisconnectPhase();
		break;
	case PASS_PHASE:
		PassivePhase();
		break;
	case COVE_PHASE:
		break;
	default:;
	}
}


void delay(void)
{
}

void ServerSync(void)
{
	switch(currentPacketIn->cont)
	{
	case CONT_SND_ACK:
		SendControlTo(CONT_SND_ALW,sourceID);
		break;
	case CONT_SND_NAK:
		ClrWaitACK();
		break;
	case CONT_SND_END:
		ClrWaitACK();
		break;
	case CONT_CON_REQ:
		if(readyToRecv)
		{
			SendControlTo(CONT_CON_ACK,sourceID);
			SetPhase(PASS_PHASE);
		}
		else
		{
			SendControlTo(CONT_CON_NAK,sourceID);
			ClrWaitACK();
		}
		break;
	default:
		ClrWaitACK();
		break;
	}
}

void ClientSync(void)
{
	switch(currentPacketIn->cont)
	{
	case CONT_SND_CHK:
		if(ChkPacketToSend())
			NotReadyToSend();
		if(!readyToSend)
		{ /* not ready to sending is meanning to this SYSTEM has packet to send */
			SendControlTo(CONT_SND_ACK,sourceID);
			SetPhase(CONN_PHASE);
		}
		else
			SendControlTo(CONT_SND_NAK,sourceID);
		break;
	case CONT_CON_REQ:
		if(readyToRecv)
		{
			SendControlTo(CONT_CON_ACK,sourceID);
			SetPhase(PASS_PHASE);
		}
		else
			SendControlTo(CONT_CON_NAK,sourceID);
		break;
	default:
		SetPhase(SYNC_PHASE);
		break;
	}
}

void ConnectPhase(void)
{
unsigned char connectID;
	if(currentPacketIn->cont == CONT_SND_ALW)
	{
		connectID = GetDistID(Outbuf[1]);
		SendControlTo(CONT_CON_REQ,connectID);
		SetPhase(TRAN_PHASE);
	}
	else
		SetPhase(SYNC_PHASE);
}

void TransmitPhase(void)
{
unsigned int pklen;
	switch(currentPacketIn->cont)
	{
	case CONT_CON_ACK:
		pklen = Outbuf[2]+4; //currentPacketOut->len+4;
		SendPacket((unsigned char xdata *)&Outbuf,pklen);
		break;
	case CONT_CON_NAK:
		SetPhase(SYNC_PHASE);
		break;
	case CONT_PAK_ACK:
		SendControlTo(CONT_DIS_REQ,sourceID);
		SetPhase(DISC_PHASE);
		break;
	case CONT_PAK_NAK:
		SendPacket((unsigned char xdata *)Outbuf,currentPacketOut->len+4);
		break;
	default:
		break;
	}
}


void DisconnectPhase(void)
{
	if(currentPacketIn->cont == CONT_DIS_REQ)
	{
		ReadyToSend();
		SendControlTo(CONT_SND_END,sourceID);
		SetPhase(SYNC_PHASE);
	}
	else
	{ /* Error Report */ }	
}

void PassivePhase(void)
{
	switch(currentPacketIn->cont)
	{
	case CONT_PAK:
			/* send event to high layer */
//		PacketIN();
		SendControlTo(CONT_PAK_ACK,sourceID);
		break;
	case CONT_DIS_REQ:
		SendControlTo(CONT_DIS_ACK,sourceID);
		break;
	default:
		break;
	}
}












































































































































































































































































































