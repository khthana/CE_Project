#include <reg52.h>
#include "datalink.h"
#include "utils.h"

//////////////////// function decaiar /////////////////////
void StartNet485(void);
void StopNet485(void);
void ExtISR0(void);
void TimerISR0(void);
void ExtISR1(void);
void TimerISR1(void);
void SerialISR(void);
void InitTimer0(void);
void InitSer(void);
unsigned char GetToutIndex(unsigned char idx);
void SetToutIndex(unsigned char fIdx,unsigned char cnt);
void ClrToutIndex(unsigned char fIdx);
void ClearPacket(void);
void SendByte(unsigned char send);
void SendPacket(unsigned char xdata *packet,unsigned int count);
unsigned char ChkPkt(unsigned char xdata *pkt);



void ServerSync(void);
void ClientSync(void);
void ConnectPhase(void);
void ConnectPhase(void);
void TransmitPhase(void);
void DisconnectPhase(void);
void PassivePhase(void);
void DataLinkInit(void);
void Mkhdr(unsigned char conts,unsigned char id,unsigned char len,struct Hdrpkt xdata *buff);
char MkpktToOutbuf(unsigned char xdata *datasnd,unsigned char ids,unsigned char len);
void SendControlTo(unsigned char cont,unsigned char dist);
void DataLinkTimeOut();
void IntoPhase(void);
void ServerSync(void);
void ClientSync(void);
void ConnectPhase(void);
void TransmitPhase(void);
void DisconnectPhase(void);
void PassivePhase(void);


void TestData(unsigned char cnt,unsigned char xdata *t);
///////////////////////////////////////////////////////////////////////////////////////


bit readyToSend; /* This is API to high layer */
bit readyToRecv;
bit waitACK;
bit DLTimeout;
unsigned char phase=0;
struct Hdrpkt xdata *currentPacketIn;
struct Hdrpkt xdata *currentPacketOut;
sbit	SEND_EN	=	P1^7;

unsigned char ToutCount[8]={0,0,0,0,0,0,0,0};
code void (*ToutFunc[8])()={DataLinkTimeOut,0,0,0,0,0,0,0};


bit IS_ESC=0;
bit PACKET_OK;
unsigned int Timecount;
unsigned int CountIn;
unsigned char xdata Inbuf[0x800];
unsigned char xdata Outbuf[0x800];
unsigned char CountData;

xdata void *ma,*a;

xdata unsigned char dataout[10] = {00,01,02,192,219,220,221,0,0,0};
void StartNet485(void)
{
	EnaSerial();
	StartTimer0();
}

void StopNet485(void)
{
	EnaSerial();
	StartTimer0();
}

void ExtISR0(void) interrupt 0 using 1
{
}

void TimerISR0(void) interrupt 1 using 1
{
unsigned char	TimeIndex = 0;
	TR0 = 0;				/* stop timer 0 */
	/* define follow to flowchat */
	
	for(TimeIndex=0;TimeIndex<8;TimeIndex++)
	{	
		if(ToutCount[TimeIndex]!=0)
		{
			if(ToutCount[TimeIndex]==1)
			/* CallBack to pointer function */
				ToutFunc[TimeIndex]();
			ToutCount[TimeIndex]--;
		}
		
	}
	
	/* define follow to flowchat */
	TL0 = TIMERLOW;
	TH0 = TIMERHIGH;
	TR0 = 1;				/* start timer 0 */
}

void ExtISR1(void) interrupt 2 using 1
{
}

void TimerISR1(void) interrupt 3 using 1
{
}

void SerialISR(void) interrupt 4 using 1
{
unsigned char	DataIn;
	if(RI)
	{
		DataIn = SBUF;
		if(DataIn == END)
		{
			if(GetSourID(currentPacketIn->id)==DEVICE_ID) /* This is My Packet */
			{
				PACKET_OK = (bit)ChkPkt((unsigned char xdata *)Inbuf); /* Check Sum Packet flag */
				IntoPhase(); /* in to phase operation */
			}
		}
		else
		{
			if(IS_ESC)
			{
				switch(DataIn)
				{
				case ESC_END:
					Inbuf[CountIn++] = END;
					break;
				case ESC_ESC:
					Inbuf[CountIn++] = ESC;
					break;
				default:
					SetPhase(COVE_PHASE);
				}
				IS_ESC = 0;
			}
			else
			{
				if(DataIn == ESC)
					IS_ESC = 1;
				else
					Inbuf[CountIn++] = DataIn;
			}
		}
		RI=0;
	}
}

void InitTimer0(void)
{
	INT_DISABLE;			/* disable interrupts */


	TR0 = 0;			/* stop timer 0 */

	TMOD &= ~0x0F;			/* clear timer 0 mode bits */
	TMOD |= 0x01;			/* put timer 0 into 16-bit no prescale */

	TL0 = TIMERLOW;
	TH0 = TIMERHIGH;

	PT0 = 0;			/* set low priority for timer 0 */
	ET0 = 1;			/* enable timer 0 interrupt */

/*	TR0 = 1;	*/		/* start timer 0 */

	INT_ENABLE;			/* enable interrupts */
}


void InitSer(void)
{
	//	RCAP = 0xFFC0 is 9600 bps
	//	RCAP = 0xFFE0 is 19.2K bps
	//	Serial Interrupt service routine is interrupt 4
	RCAP2L = 0xe0;
	RCAP2H = 0xff;
	SCON =  0x50;
	T2CON = 0x34;
	TI = 0;
}

unsigned char GetToutIndex(unsigned char idx)
{
	return ToutCount[idx];
}
void SetToutIndex(unsigned char fIdx,unsigned char cnt)
{
	ToutCount[fIdx] = cnt;
}

void ClrToutIndex(unsigned char fIdx)
{
	ToutCount[fIdx] = 0;
}

void ClearPacket(void)
{
	CountIn=0;
	CountData=0;
}

void SendByte(unsigned char send)
{
	DisSerial();
	SendMode;
	SBUF=send;
	while(!TI);
	TI=0;
	RecvMode;
	EnaSerial();
}
/* ======================================== packet ========================================= */
/* ----------------------------------------------------------------------------------------- *
 *	|         |           |           |           |                        |          |     | *
 * | type[8] | id_sour[4]|id_dist[4] | lenght[8] | data[$lenght]..........|chksum[8] | END | *
 *	|         |           |           |           |                        |          |     | *
 *	----------------------------------------------------------------------------------------- */
	
void SendPacket(unsigned char xdata *packet,unsigned int count)
{
	unsigned int cont;
	DisSerial();
	SendMode;
	cont = 0;
	for(cont=0;cont<count;cont++)
	{
		switch(packet[cont])
		{
		case END:
			SBUF=ESC;
			while(!TI);
			TI=0;
			SBUF=ESC_END;
			while(!TI);
			TI=0;
			break;
		case ESC:
			SBUF=ESC;
			while(!TI);
			TI=0;
			SBUF=ESC_ESC;
			while(!TI);
			TI=0;
			break;
		default:
			SBUF=packet[cont];
			while(!TI);
			TI=0;
			break;
		}
	}
	SBUF=END;
	while(!TI);
	TI=0;
	
	RecvMode;
	EnaSerial();
}

unsigned char ChkPkt(unsigned char xdata *pkt)
{
	unsigned char l;
	unsigned char csum;
	struct Hdrpkt xdata *hdr;
	
	csum = 0;
	hdr = (struct Hdrpkt xdata *)pkt;
	
	for(l=0;l<(hdr->len + 3);l++)
		csum = csum + pkt[l];
	csum = (~csum) + 1;
	if( csum == pkt[l] )
		return 1;
	else
		return 0;
}

void DataLinkInit(void)
{
	currentPacketIn  = (struct Hdrpkt xdata *)&Inbuf;
	currentPacketOut = (struct Hdrpkt xdata *)&Outbuf;
}

void Mkhdr(unsigned char conts,unsigned char id,unsigned char len,struct Hdrpkt xdata *buff)
{
unsigned char IDS;
	IDS=DEVICE_ID<<4;
	buff->id = id;
	buff->id = IDS;
	IDS=(IDS&0xf0)|(id);
	buff->cont=conts;
	buff->id=IDS;
	buff->len=len;
}

/* Make datagram to Out buffer and set not ready to send for send packet */
char MkpktToOutbuf(unsigned char xdata *datasnd,unsigned char ids,unsigned char len)
{
	unsigned char l;
	unsigned char csum;
	csum = 0;
	if(readyToSend)
	{
		Mkhdr(CONT_PAK, 
				ids ,
				len ,
				(struct Hdrpkt xdata *)&Outbuf);
		/* copy data */
		for(l=0;l<len;l++)
			Outbuf[l+3] = datasnd[l];
		/* make check sum */
		for(l=0;l<(len+3);l++)
			csum = csum + Outbuf[l];
		csum = (~csum) + 1;
		Outbuf[len+3] = csum;
		readyToSend = 0;
		return 1;
	}
	else
		return 0;
}


void SendControlTo(unsigned char cont,unsigned char dist)
{
unsigned char xdata HeaderCont[4];
	Mkhdr(cont,dist,0,(struct Hdrpkt xdata *)&HeaderCont);
	HeaderCont[3] = ~(HeaderCont[0] + HeaderCont[1] + HeaderCont[2]) + 1;
	SendPacket((unsigned char xdata *)&HeaderCont,sizeof(struct Hdrpkt)+1);
}

void DataLinkTimeOut()
{
	DLTimeout = 1;
}


void IntoPhase(void)
{
	switch(phase)
	{
	case SERV_SYNC:
		ServerSync();
		break;
	case CLNT_SYNC:
		ClientSync();
		break;
	case CONN_PHASE:
		ConnectPhase();
		break;
	case TRAN_PHASE:
		TransmitPhase();
		break;
	case DISC_PHASE:
		DisconnectPhase();
		break;
	case PASS_PHASE:
		PassivePhase();
		break;
	case COVE_PHASE:
		break;
	default:;
	}
}

void ServerSync(void)
{
	switch(currentPacketIn->cont)
	{
	case CONT_SND_ACK:
		SendControlTo(CONT_SND_ALW,GetSourID(currentPacketIn->id));
		break;
	case CONT_SND_NAK:
		ClrWaitACK();
		break;
	case CONT_SND_END:
		ClrWaitACK();
		break;
	case CONT_CON_REQ:
		if(readyToRecv)
		{
			SendControlTo(CONT_CON_ACK,GetSourID(currentPacketIn->id));
			SetPhase(PASS_PHASE);
		}
		else
		{
			SendControlTo(CONT_CON_NAK,GetSourID(currentPacketIn->id));
			ClrWaitACK();
		}
		break;
	default:
		ClrWaitACK();
		break;
	}
}

void ClientSync(void)
{
	switch(currentPacketIn->cont)
	{
	case CONT_SND_CHK:
		if(!readyToSend)
		{ /* not ready to sending is meanning to this SYSTEM has packet to send */
			SendControlTo(CONT_SND_ACK,GetSourID(currentPacketIn->id));
			SetPhase(CONN_PHASE);
		}
		else
			SendControlTo(CONT_SND_NAK,GetSourID(currentPacketIn->id));
		break;
	case CONT_CON_REQ:
		if(readyToRecv)
		{
			SendControlTo(CONT_CON_ACK,GetSourID(currentPacketIn->id));
			SetPhase(PASS_PHASE);
		}
		else
			SendControlTo(CONT_CON_NAK,GetSourID(currentPacketIn->id));
		break;
	default:
		break;
	}
}

void ConnectPhase(void)
{
	if(currentPacketIn->cont == CONT_SND_ALW)
	{
		SendControlTo(CONT_CON_REQ,GetSourID(currentPacketIn->id));
		SetPhase(TRAN_PHASE);
	}
	else
		SetPhase(SYNC_PHASE);
}

void TransmitPhase(void)
{
	switch(currentPacketIn->cont)
	{
	case CONT_CON_ACK:
		SendPacket((unsigned char xdata *)&Outbuf,currentPacketOut->len+4);
		break;
	case CONT_CON_NAK:
		SetPhase(SYNC_PHASE);
		break;
	case CONT_PAK_ACK:
		SendControlTo(CONT_DIS_REQ,GetSourID(currentPacketIn->id));
		SetPhase(DISC_PHASE);
		break;
	case CONT_PAK_NAK:
		SendPacket((unsigned char xdata *)Outbuf,currentPacketOut->len+4);
		break;
	default:
		break;
	}
}


void DisconnectPhase(void)
{
	if(currentPacketIn->cont == CONT_DIS_REQ)
	{
		ReadyToSend();
		SendControlTo(CONT_SND_END,GetSourID(currentPacketIn->id));
		SetPhase(SYNC_PHASE);
	}
	else
	{ /* Error Report */ }	
}

void PassivePhase(void)
{
	switch(currentPacketIn->cont)
	{
	case CONT_PAK:
			/* send event to high layer */
		SendControlTo(CONT_PAK_ACK,GetSourID(currentPacketIn->id));
		break;
	case CONT_DIS_REQ:
		SendControlTo(CONT_DIS_ACK,GetSourID(currentPacketIn->id));
		break;
	default:
		break;
	}
}

void TestData(unsigned char cnt,unsigned char xdata *t)
{
unsigned char cnts;
	for (cnts=0;cnts<cnt;cnts++)
		SendByte(t[cnts]);
}
 
void main(void)
{
unsigned char idd;
 InitSer();
 InitTimer0();
 DataLinkInit();
 StartNet485();
 
 SetToutIndex(0,3);
 /*
 init_mempool((struct mem xdata *)&Inbuf, 0x800);
 ma = (void xdata *)malloc(3);
 a = (void xdata *)malloc(3);
 */
 /* working */
 while(1)
 {
// TestData(10,&Outbuf);
	MkpktToOutbuf((unsigned char xdata *)&dataout,idd,10);
	TestData(currentPacketOut->len+4,&Outbuf);
	while(1);
 for (idd=2;idd<8;idd++)
 {
 	SetWaitACK();
	ReadyToSend();
 	SetToutIndex(0,150);
	SendControlTo(CONT_SND_CHK,idd);
	MkpktToOutbuf((unsigned char xdata *)&dataout,idd,10);
	TestData(currentPacketOut->len+4,&Outbuf);
//	SendPacket(&Outbuf,currentPacketOut->len+4);
	while(1);
	while(GetToutIndex(0)){};
 }
 }
 
}
 




