//#include <reg52.h>
#include "utillib.h"
#define XBYTE ((unsigned char *) 0x20000L)
#define XWORD ((unsigned char *) 0x20000L)
#define COMDPORT XBYTE[0x8000]
#define DATALENG XBYTE[0x0000]
#define RAMSHARE	XBYTE
#define SEND_REQ	0x80
#define SEND_ACK	0x40
#define SEND_NAK	0x20
#define SEND_OK	0x10
#define SEND_NAL	0x08
#define SEND_ALW	0x04

unsigned char COMD_PC=0;
sbit	IRQ7	= P3^5;
bit sysready=1;
bit req_cmd=0;
void SendCmd(unsigned char cmd);
unsigned char RecvCmd(void);

void ExtISR0(void) interrupt 0 using 1
{
unsigned int lenr;
	COMD_PC = COMDPORT;
	if(COMD_PC == SEND_REQ)
	{
		if(!sysready)
		{
			SendCmd(SEND_NAK);
			req_cmd=0;
		}
		else
			req_cmd=1;
		COMD_PC = 0;
	}
			
}

void InitEx0(void)
{
	IT0 = 1;
	EX0 = 1;
	IRQ7 = 0;
}

char ChkReqPC(void)
{
	if(req_cmd)
	{
		SendCmd(SEND_ACK);
		if(RecvCmd()==SEND_OK)
		{
			sysready = 0;
			return 1;
		}
	}
	
	/* Tramfer data to buffer */
	return 0;
}

unsigned char GetDataTo(unsigned char xdata *dist)
{
unsigned char xdata *pDat;
unsigned char l,k;
	pDat = (void xdata*)0;
	k = *pDat;
	
	for(l=0;l<k;l++)
		dist[l] = pDat[l+1];

	sysready = 1;
	req_cmd = 0;
	return k;
}

void SendToPC(unsigned char len,unsigned char xdata *dat)
{
unsigned char xdata *ramb;
unsigned char l;
	sysready = 0;
	ramb = (void xdata*)0x0000;
	
	ramb[0] = len;
	
	for(l=0;l<len;l++)
		ramb[l+1] = dat[l];
	
	SendCmd(SEND_REQ);
	SendByte('A');
	if(RecvCmd() == SEND_NAK)
	{
		SendByte('b');
		sysready = 1;
		return ;
	}
	SendByte('B');
	SendCmd(SEND_OK);
	SendByte('C');
	sysready = 1;
}

unsigned char RecvCmd(void)
{
unsigned char tmpcmd;
	while(COMD_PC == 0);
	tmpcmd = COMD_PC;
	COMD_PC = 0;
	return tmpcmd;
}

void SendCmd(unsigned char cmd)
{
unsigned char i;
	COMDPORT = cmd;
	IRQ7 = 1;
	for(i=0;i<3;i++); /* Delay irq signal phuse */
	IRQ7 = 0;
}













