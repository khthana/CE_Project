#ifndef  _MEMLIB_H_
#define  _MEMLIB_H_
#include "mmem.h"
extern void init_mem(struct superb xdata *super,unsigned int len);
extern void xdata *malloc(unsigned int sz);
extern char freemem(void *mem);
void memcpy(void xdata *memdist,void xdata *memsrc,unsigned int len);
#endif 
