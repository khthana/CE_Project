struct arp{
	unsigned char id;
	unsigned long IPaddr;
	}; 
