#ifdef SERVER
#define DEVICE_ID		1
#endif

#ifdef DEVICE2
#define DEVICE_ID		2
#endif

#ifdef DEVICE3
#define DEVICE_ID		3
#endif

#ifdef DEVICE4
#define DEVICE_ID		4
#endif

#ifdef DEVICE5
#define DEVICE_ID		5
#endif

#ifdef DEVICE6
#define DEVICE_ID		6
#endif

#define CONT_CHK		0x00
#define CONT_ACK		0x01

#define CONT_SND_CHK	0x02
#define CONT_SND_ACK	0x03
#define CONT_SND_NAK	0x04
#define CONT_SND_ALW	0x05
#define CONT_SND_END	0x06

#define CONT_CON_REQ	0x07
#define CONT_CON_ACK	0x08
#define CONT_CON_NAK	0x09

#define CONT_DIS_REQ	0x0a
#define CONT_DIS_ACK 0x0b

#define CONT_PAK		0x0c
#define CONT_PAK_ACK	0x0d
#define CONT_PAK_NAK	0x0e
#define CONT_PAK_END	0x0f

#define	SERV_SYNC	1	/* Synchronization Server phase */
#define	CLNT_SYNC	2	/* Synchronization Client phase */

#ifdef SERVER
	#define SYNC_PHASE	SERV_SYNC
#else
	#define SYNC_PHASE	CLNT_SYNC
#endif

#define	CONN_PHASE	3	/* Connection phase */
#define	STRN_PHASE	4	/* Send transmit phase */
#define	DISC_PHASE	5	/* Disconnect phase */
#define	PASS_PHASE	6	/* Passive phase */
#define	TRAN_PHASE	7	/* Recive transmit phase */
#define	COVE_PHASE	8 	/* Error Recover phase */

#define	SetWaitACK()	waitACK = 1
#define	ClrWaitACK()	waitACK = 0
#define	ReadyToSend()	readyToSend = 1
#define	NotReadyToSend()	readyToSend = 0
#define	ReadyToRecv()	readyToRecv = 1
#define	NotReadyToRecv()	readyToRecv = 0

#define	GetSourID(x)	(( 0xf0 & x )>>4)
#define	GetDistID(x)	( 0x0f & x )
#define	SetPhase(x)		(phase = x)
#define	GetPhase()		(phase)

struct Hdrpkt{
	unsigned char cont; 
	unsigned char id;	
	unsigned char len;	
	};
struct dlpkt{
	struct dlpkt xdata *pkt_next;
	struct Hdrpkt	pkt_hdr;
	unsigned char xdata *pkt;
	};
