//#include <reg52.h>
#include "utillib.h"
#include "dllib.h"
#include "ramshare.h"

#define XBYTE ((unsigned char *) 0x20000L)

unsigned int ip_chksum(unsigned int xdata *iph);

xdata void *ma,*a;

/* send data from 192.168.1.2 to 161.246.5.148 */
xdata unsigned char dataout[] = {0x45,0x00,0x00,0x32,0xe5,0x27,0x00,0x00,0x40,0x11,0x2c,0x5f,0xc0,0xa8,0x01,0x02,
											0xa1,0xf6,0x05,0x94,0x70,0x17,0x70,0x17,0x00,0x1e,0x45,0xa1,0x74,0x65,0x73,0x74,
											0x20,0x74,0x68,0x65,0x20,0x52,0x53,0x34,0x38,0x35,0x20,0x64,0x65,0x76,0x69,0x63,
											0x65,0x00};
xdata unsigned char dataout2[] ={0x45,0x00,0x00,0x32,0xa5,0xd9,0x00,0x00,0x40,0x11,0x51,0x8e,0xc0,0xa8,0x01,0x02,
											0xc0,0xa8,0x01,0x01,0x04,0x05,0x70,0x17,0x00,0x1e,0x97,0x94,0x74,0x65,0x73,0x74,
											0x20,0x74,0x68,0x65,0x20,0x52,0x53,0x34,0x38,0x35,0x20,0x64,0x65,0x76,0x69,0x63,
											0x65,0x00};							
xdata unsigned char datain[100];
void main(void)
{
unsigned char idd;
unsigned char datalen;
unsigned char xdata *datainbuf; 
unsigned char ld;
 InitEx0();
 InitSer();
 InitTimer0();
 DataLinkInit();
 StartNet485();
 ServerStart();

 for(ld=0;ld<200;ld++);
 /* working */
 //while(1)
 //{
 /*
 datainbuf = (void xdata*)0;
 while(1)
 {
 	if(ChkReqPC())
 	{
 		ReadyToSend(); // <<<<<<<<< This point Importent
 		datalen = GetDataTo((unsigned char xdata*)&datain);
		MkpktToOutbuf((unsigned char xdata *)&datain,idd,datalen);
   	//SendPacket(&Outbuf,Outbuf[2]+4);

		// Send data ip to PC
 		SendToPC(sizeof(dataout),(unsigned char xdata*)&dataout);
 		//while(1);
 	}
 	
 }
  */
/*==========================================*/
			SendControlTo(CONT_SND_CHK,2);
			while(1);
		//SendControlTo(CONT_SND_CHK,2);
	
/*
 for (idd=2;idd<8;idd++)
 {
 	SetWaitACK();
	ReadyToSend();
 	//SetToutIndex(0,10);
	SendControlTo(CONT_SND_CHK,idd);
	MkpktToOutbuf((unsigned char xdata *)&dataout,idd,10);
   SendPacket(&Outbuf,Outbuf[2]+4);
	//while(GetToutIndex(0));
 }
*/
/*
	ReadyToSend();
	SendControlTo(CONT_SND_CHK,2);
	SetToutIndex(0,100);
	while(GetToutIndex(0));
	SendControlTo(CONT_SND_ALW,2);
	SetToutIndex(0,100);
	while(GetToutIndex(0));
	SendControlTo(CONT_CON_ACK,2);
	SetToutIndex(0,100);
	while(GetToutIndex(0));
*/	
 while(1) ;
 //}
 
}

unsigned int ip_chksum(unsigned int xdata *iph)
{
}


























