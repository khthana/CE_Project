#include "socktype.h"
#include "ip.h"
#include "memlib.h"
void xdata *findsock(int sock);

struct skfd xdata *sockfd;
void socketinit(void)
{
	sockfd = 0;
}
int skopen(int domain, int type, int protocol)
{
struct skfd xdata *sktmp;
struct skfd xdata *sk;
struct skfd xdata *sock;
int skid;

	sock = sockfd;
	for(skid=MIN_SOCK;skid<MAX_SOCK;skid++)
	{
		if((sock == 0) || (sock->sock_id != skid))
			break;
		sock = sock->skfd_next;
	}
	if(skid==MAX_SOCK)
		return 0;
	
	sk = malloc(sizeof(struct skfd));
	sk->sock_id = skid;
	if(skid == 1)
	{
		sk->skfd_next = sockfd;
		sockfd = sk;
	}
	else
	{
		sktmp = sockfd;
		while(sktmp->sock_id == (skid - 1))
			sktmp = sktmp->skfd_next;
		sk->skfd_next = sktmp->skfd_next;
		sktmp->skfd_next = sk;
	}
	
	sk->type = SOCK_DGRAM;
	sk->status = SK_STAR;
	return sk->sock_id;
}

void close(int sock_id)
{
struct skfd xdata *sock;
struct skfd xdata *sktmp;
	sock = sockfd;
	if(sock_id == 1)
	{
		sockfd = sock->skfd_next;
		freemem(sock);
	}
	else
	{
		while((sock->skfd_next->sock_id != sock_id) && (sock->skfd_next != 0))
			sock = sock->skfd_next;
		if(sock->skfd_next == 0)
			return ;
		sktmp = sock->skfd_next;
		sock->skfd_next = sock->skfd_next->skfd_next;
		freemem(sktmp);
	}
}

int bind(int socket, struct sockaddr_in xdata *address, int address_len)
{
struct skfd xdata *sk;
	
	if(((sk = findsock(socket)) == 0) || (sk->status != SK_STAR))
		return -1;
	
	sk->address.sin_family = address->sin_family;
	sk->address.sin_port = address->sin_port;
	sk->address.sin_addr = address->sin_addr;		
	sk->status = SK_BIND;	
	return 0;
	
}

int connect(int socket, struct sockaddr_in xdata *address, int address_len)
{
struct skfd xdata *sk;
	
	if(((sk = findsock(socket)) == 0) || (sk->status != SK_BIND))
		return -1;

	//sk->address.sin_family = address->sin_family;
	sk->dist_addr.sin_port = address->sin_port;
	sk->dist_addr.sin_addr = address->sin_addr;		
	sk->status = SK_CONN;	
	return 0;
}

void sockwrite(int socket,void xdata *dat,int len)
{
struct skfd xdata *sk;
	if(((sk = findsock(socket)) == 0) || (sk->status != SK_CONN))
		return;
	PutIP(socket,(void xdata*)dat,len);
}

char sockread(int socket)
{
}

void xdata *findsock(int socket)
{
struct skfd xdata *sk;
	sk = sockfd;
	while(sk->sock_id != socket)
		sk = sk->skfd_next;
	if(sk == 0)
		return (void xdata*)0;
	
	return (void xdata*)sk;
}
/* this version is not implement */
int listen(int socket, int blocklog)
{
}

int accept(int socket, struct sockaddr_in *address, int *address_len)
{
}






























































































































































