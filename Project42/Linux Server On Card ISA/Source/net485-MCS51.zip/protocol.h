#define MTU	255
#define ICMP_PROTOCOL	1
#define TCP_PROTOCOL		6
#define UDP_PROTOCOL		17
struct iphdr{
	unsigned char ver_len; /* version and length order in 4 bit high and 4 bit low */
	unsigned char tos; /* type of service -> is any of data set to 0x00 */
	unsigned int  totallen; /* total length -> is size if IP datagram in header lenght and data lenght */
	unsigned int  id; /* identification */
	unsigned int  fg_fm; /* flags 3 bit and fragment offset 13 bit */
	unsigned char ttl; /* time to live -> some value 32 to 64 */
	unsigned char protocol; /* protocol */
	unsigned int  hchksum; /* header checksum -> calculated for the IP header only for "16 bit one's and subject 2 "by first set hchksum is zero */
	unsigned long ip_sour; /* source ip */
	unsigned long ip_dist; /* distination ip */
	};
struct udp{
	unsigned int  port_sour;
	unsigned int  port_dist;
	unsigned int  len; /* lenght of UDP header + Data */
	unsigned int  chksum;	/* for 16 bit one's by first set chksum is zero and may is odd number it has pad byte */
									/* and is set to zero is not computed check sum */
	};

struct icmp{
	unsigned char type;
	unsigned char cd;
	unsigned char chksum;
	};

/***********************************************************************

   Assigned Internet Protocol Numbers
 
      Decimal    Octal      Protocol Numbers                  References
      -------    -----      ----------------                  ----------
           0       0         Reserved                              [JBP]
           1       1         ICMP                               [53,JBP]
           2       2         Unassigned                            [JBP]
           3       3         Gateway-to-Gateway              [48,49,VMS]
           4       4         CMCC Gateway Monitoring Message [18,19,DFP]
           5       5         ST                                 [20,JWF]
           6       6         TCP                                [34,JBP]
           7       7         UCL                                    [PK]
           8      10         Unassigned                            [JBP]
           9      11         Secure                                [VGC]
          10      12         BBN RCC Monitoring                    [VMS]
          11      13         NVP                                 [12,DC]
          12      14         PUP                                [4,EAT3]
          13      15         Pluribus                             [RDB2]
          14      16         Telenet                              [RDB2]
          15      17         XNET                              [25,JFH2]
          16      20         Chaos                                [MOON]
          17      21         User Datagram                      [42,JBP] <======== usage only [UDP]
          18      22         Multiplexing                       [13,JBP]
          19      23         DCN                                  [DLM1]
          20      24         TAC Monitoring                     [55,RH6]
       21-62   25-76         Unassigned                            [JBP]
          63      77         any local network                     [JBP]
          64     100         SATNET and Backroom EXPAK            [DM11]
          65     101         MIT Subnet Support                    [NC3]
       66-68 102-104         Unassigned                            [JBP]
          69     105         SATNET Monitoring                    [DM11]
          70     106         Unassigned                            [JBP]
          71     107         Internet Packet Core Utility         [DM11]
       72-75 110-113         Unassigned                            [JBP]
          76     114         Backroom SATNET Monitoring           [DM11]
          77     115         Unassigned                            [JBP]
          78     116         WIDEBAND Monitoring                  [DM11]
          79     117         WIDEBAND EXPAK                       [DM11]
      80-254 120-376         Unassigned                            [JBP]
         255     377         Reserved                              [JBP]
         
************************************************************************/
