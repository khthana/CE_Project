
/*
 * Battle Tetris
 * -------------
 * 
 * Original Version (C) Iwan van Rienen, 1995, 1996
 * Duoplay Version  (C) Song Li, 1996
 *
 * Iwan van Rienen  http://www.bart.nl/~ivr       E-Mail: ivr@bart.nl
 * Song Li          http://www.cs.umbc.edu/~sli2  E-Mail: sli2@gl.umbc.edu
 *
 *
 * This is a "postcard-ware", as Iwan calls it. He hopes his cup of java
 * to be shared by anyone insterested with Java. Actually, this is where
 * I started. I am a C++ programmer for years, but one week ago (01/17/96) 
 * I got a keen desire to learn Java, a new language for me. At first, I
 * wanted to begin with a Tetris program written in C developed for 
 * OpenLook by myself years ago. After looking up Gamelan, however, I 
 * found there were a lot of Tetrises up there already. So I gave up my 
 * first thought and picked up Iwan's source code and tried to improve it. 
 *
 * Since the program is based on Iwan's postcard-ware, I put his name
 * here and hope those who has a chance to get this code improve it in
 * any favorable way. Please let your friends know this little program
 * and contribute some additional functions if any of you is a programmer.
 *
 *
 * Song Li.
 * Jan 25, 1996.
 *
 *
 */

 
 
 
 
import java.awt.*;
import java.awt.image.*;
import java.applet.Applet;
import java.applet.AudioClip;
import java.util.Vector;
import java.lang.Math;
import java.lang.Thread;
import java.lang.System;




public class TetrisApp extends java.applet.Applet {
    Panel         Player1, Player2 ;
    TetrisThread  Tetris1, Tetris2 ;
    Choice        PlayerNumChoice ;
    Choice        LevelChoice ;
    Choice        RandomChoice ;


    public void init () {
        setLayout (new BorderLayout ());
        Panel grid = new Panel ();
        grid.setLayout (new GridLayout (1, 2));
        add ("Center", grid);

        Player1 = new Panel () ;
        Player1.setLayout (null) ;
        grid.add ("Left", Player1) ;
        
        Player2 = new Panel () ;
        Player2.setLayout (null) ;
        grid.add ("Right", Player2) ;

        Panel control = new Panel () ;
        control.setLayout (new FlowLayout ()) ;
        add ("South", control) ;
        
        control.add (new Button ("New Game")) ;
        control.add (new Button ("Pause / Resume")) ;
        control.add (new Button ("About")) ;
        
        PlayerNumChoice = new Choice () ;
        PlayerNumChoice.addItem ("2 Players") ;
        PlayerNumChoice.addItem ("1 - Right") ;
        PlayerNumChoice.addItem ("1 - Left") ;
        control.add (PlayerNumChoice) ;

        LevelChoice = new Choice () ;
        for (int i=0; i<=9; i++)
             LevelChoice.addItem ("Level " + i) ;
        control.add (LevelChoice) ;
        
        RandomChoice = new Choice () ;
        for (int i=0; i<=9; i++)
            RandomChoice.addItem (i + " Rows") ;
        control.add (RandomChoice) ;


        TetrisThread.BlockMap   = new int [TetrisThread.BlockNum][4] ;
        TetrisThread.BlockColor = new Color [TetrisThread.BlockNum] ;
        TetrisThread.BlockValue = new int [TetrisThread.BlockNum] ;
        
        TetrisThread.BlockMap[0][0] = 0x0000 ;
        TetrisThread.BlockMap[0][1] = 0x0FF0 ;
        TetrisThread.BlockMap[0][2] = 0x0FF0 ;
        TetrisThread.BlockMap[0][3] = 0x0000 ;
        TetrisThread.BlockColor[0]  = Color.blue ;
        TetrisThread.BlockValue[0]  = 3 ;
        
        TetrisThread.BlockMap[1][0] = 0x0F00 ;
        TetrisThread.BlockMap[1][1] = 0x0F00 ;
        TetrisThread.BlockMap[1][2] = 0x0FF0 ;
        TetrisThread.BlockMap[1][3] = 0x0000 ;
        TetrisThread.BlockColor[1]  = Color.yellow ;
        TetrisThread.BlockValue[1]  = 5 ;
        
        TetrisThread.BlockMap[2][0] = 0x00F0 ;
        TetrisThread.BlockMap[2][1] = 0x00F0 ;
        TetrisThread.BlockMap[2][2] = 0x0FF0 ;
        TetrisThread.BlockMap[2][3] = 0x0000 ;
        TetrisThread.BlockColor[2]  = Color.pink ;
        TetrisThread.BlockValue[2]  = 5 ;
        
        TetrisThread.BlockMap[3][0] = 0x0000 ;
        TetrisThread.BlockMap[3][1] = 0x0F00 ;
        TetrisThread.BlockMap[3][2] = 0xFFF0 ;
        TetrisThread.BlockMap[3][3] = 0x0000 ;
        TetrisThread.BlockColor[3]  = Color.green ;
        TetrisThread.BlockValue[3]  = 4 ;
        
        TetrisThread.BlockMap[4][0] = 0x0F00 ;
        TetrisThread.BlockMap[4][1] = 0x0F00 ;
        TetrisThread.BlockMap[4][2] = 0x0F00 ;
        TetrisThread.BlockMap[4][3] = 0x0F00 ;
        TetrisThread.BlockColor[4]  = Color.red ;
        TetrisThread.BlockValue[4]  = 4 ;
        
        TetrisThread.BlockMap[5][0] = 0x0F00 ;
        TetrisThread.BlockMap[5][1] = 0x0FF0 ;
        TetrisThread.BlockMap[5][2] = 0x00F0 ;
        TetrisThread.BlockMap[5][3] = 0x0000 ;
        TetrisThread.BlockColor[5]  = Color.magenta ;
        TetrisThread.BlockValue[5]  = 4 ;
        
        TetrisThread.BlockMap[6][0] = 0x00F0 ;
        TetrisThread.BlockMap[6][1] = 0x0FF0 ;
        TetrisThread.BlockMap[6][2] = 0x0F00 ;
        TetrisThread.BlockMap[6][3] = 0x0000 ;
        TetrisThread.BlockColor[6]  = Color.orange ;
        TetrisThread.BlockValue[6]  = 4 ;

        TetrisThread.Sound = new AudioClip [4] ;
        TetrisThread.Sound[0] = getAudioClip (getCodeBase (), "audio/drop.au");
        TetrisThread.Sound[1] = getAudioClip (getCodeBase (), "audio/gameover.au");
        TetrisThread.Sound[2] = getAudioClip (getCodeBase (), "audio/nextlevel.au");
        TetrisThread.Sound[3] = getAudioClip (getCodeBase (), "audio/line.au");
    }


    public void start() {
        Tetris1 = new TetrisThread (this, Player1, 'a', 's', 'd', 'z') ;
        Tetris2 = new TetrisThread (this, Player2, 'j', 'k', 'l', 'm') ;
        Tetris1.SetEnemy (Tetris2) ;
        Tetris2.SetEnemy (Tetris1) ;
        Tetris1.start () ;
        Tetris2.start () ;
    }


    public void stop() {
        Tetris1.stop () ;
        Tetris2.stop () ;
    }


    public int StartLevel () {
        return LevelChoice.getSelectedIndex () ;
    }
    
    
    public int StartRow () {
        return RandomChoice.getSelectedIndex () ;
    }



    private boolean CommandAction (Event event, Object arg) {
        if (event.target == PlayerNumChoice)
            switch (PlayerNumChoice.getSelectedIndex ()) {
                case 0 :
                     Tetris1.Suspend (false) ;
                     Tetris2.Suspend (false) ;
                     break ;
                case 1:
                     Tetris1.Suspend (true) ;
                     Tetris2.Suspend (false) ;
                     break ;
                case 2:
                     Tetris1.Suspend (false) ;
                     Tetris2.Suspend (true) ;
                     break ;
             }

        if (event.target == LevelChoice) {
            Tetris1.SetLevel (LevelChoice.getSelectedIndex ()) ;
            Tetris2.SetLevel (LevelChoice.getSelectedIndex ()) ;
        }
        

        if ("New Game".equals (arg)) {
            Tetris1.NewGame () ;
            Tetris2.NewGame () ;
        }
        
        if ("About".equals (arg)) {
            Tetris1.Pause (true) ;
            Tetris2.Pause (true) ;
            
            AboutFrame about = new AboutFrame () ;
            about.show () ;
        }

        if ("Pause / Resume".equals (arg)) {
            Tetris1.Pause () ;
            Tetris2.Pause () ;
        }

        return true;
    }



    public synchronized boolean handleEvent (Event event) {
        switch  (event.id) {
            case Event.ACTION_EVENT:
                 return CommandAction (event, event.arg);
        
            case Event.KEY_ACTION:
            case Event.KEY_PRESS:
                 Tetris1.KeyAction (event.key) ;
                 Tetris2.KeyAction (event.key) ;
                 return true ;
        
            default:
                 return false;
            }
    }
        

}





class TetrisThread extends Thread {
    public static final int Cols        = 10 ;
    public static final int Rows        = 18 ;
    public static final int ElementSize = 15 ;
    public static final int MaxElement  = 3 ;
    public static final int BlockNum    = 7 ;

    public static int   BlockMap  [][] ;
    public static Color BlockColor  [] ;
    public static int   BlockValue  [] ;
    public static AudioClip Sound [] ;

    public static final int SND_DROP     = 0;
    public static final int SND_GAMEOVER = 1;
    public static final int SND_NEXTLEVEL= 2;
    public static final int SND_LINE     = 3;

    char           KeyLeft ;
    char           KeyRight ;
    char           KeyRotate ;
    char           KeyDrop ;

    TetrisApp      Applet ;
    ArenaCanvas    Arena ;
    ReportCanvas   Report ;
    TetrisThread   Enemy ;
    Shape          CurrentShape = null;
    Shape          NextShape = null;
    Color          PlayMap [][];
    boolean        GamePaused = false;
    boolean        GameRestart = false ;
    boolean        GameSuspended = false ;


    public TetrisThread (TetrisApp app, Panel panel,
                         char left, char rotate, char right, char drop) {
        Applet = app ;
        Arena = new ArenaCanvas ();
        panel.add (Arena) ;
        Report = new ReportCanvas ();
        panel.add (Report) ;
        Report.move (170, 0) ;

        KeyLeft   = left ;
        KeyRight  = right ;
        KeyRotate = rotate ;
        KeyDrop   = drop ;

        PlayMap = new Color [Rows] [Cols];
        Arena.SetPlayMap (PlayMap);
        InitGame ();
        GetNextRandomShape ();
    }


    public void SetEnemy (TetrisThread enemy) {
        Enemy = enemy ;
    }


    private void InitGame () {
        int x, y ;
        
        for (y=0 ; y<Rows-Applet.StartRow (); y++)
            for (x=0; x<Cols; x++)
                PlayMap[y][x] = Color.black;

        for (; y<Rows; y++)
            RandomRow (PlayMap[y]) ;

        Arena.RepaintPlayMap () ;
        Report.InitGame (Applet.StartLevel ()) ;
    }


    private int RandomShapeNum () {
        int num ;
        do {
            num =  (int)  (Math.random () * BlockNum);
        } while  (num >= BlockNum);
        return num ;
    }


    private void GetNextRandomShape () {
        int num ;
        if (CurrentShape == null) {
            num = RandomShapeNum () ;
            CurrentShape = new Shape (BlockMap[num], BlockColor[num], BlockValue[num]) ;
            }
        else
            CurrentShape = NextShape;

        CurrentShape.Init ();
        if  (!CurrentShape.CheckFit (PlayMap, 0, 0, false))
            GameOver ();

        num = RandomShapeNum () ;
        NextShape = new Shape (BlockMap[num], BlockColor[num], BlockValue[num]) ;
        Report.DisplayNextShape (NextShape);
    }


    private void GameOver () {
        Play  (SND_GAMEOVER);
        Arena.GameOver ();
        Report.GameOver ();
        InitGame ();
    }


    public void NewGame () {
        GameRestart = true ;
        Pause (false) ;
    }


    public void Suspend (boolean needsuspend) {
        GameSuspended = needsuspend ;
    }
    

    public void Pause () {
        GamePaused = ! GamePaused;
    }


    public void Pause (boolean needpause) {
        GamePaused = needpause ;
    }


    public void run () {
        for (;;) {
            try {
                Thread.sleep (Report.GetGameSpeed ());
            } catch  (InterruptedException e) {}
            
            if (! GamePaused && ! GameSuspended)
                UpdateMap (false, 0, 0, false) ;
        }
    }


    private void CheckLines () {
        int Lines = 0;
        int x, y, yc;
        boolean Gap;
        
        for  (y=0; y<Rows; y++) {
            for  (Gap=false, x=0; x<Cols; x++)
                if  (PlayMap[y][x] == Color.black) 
                    Gap = true;

            if  (! Gap) {
                Lines ++;
                for  (yc=y-1; yc>=0; yc--)
                    for  (x=0; x<Cols; x++)
                        PlayMap [yc+1][x] = PlayMap[yc][x];

                for  (x = 0; x < Cols; x++)    // Delete top row.
                    PlayMap[0][x] = Color.black;
            }
        }

        if  (Lines > 0) {
            Play  (SND_LINE);
            Arena.RepaintPlayMap ();
            if (Lines > 1)
                Enemy.Suffer (Lines) ;
        }

        Report.AddLines (Lines);
    }



    private void ChangeShape (int incx, int incy, boolean rotate) {
        while  (! CurrentShape.IsReady ()) ;
        if  (CurrentShape.CheckFit (PlayMap, incx, incy, rotate)) {
            CurrentShape.ChangePosition (incx, incy, rotate);
            Arena.repaint (CurrentShape);
        }
    }


    private synchronized void UpdateMap (boolean userrequest,
                                         int     incx,
                                         int     incy,
                                         boolean rotate) {
        if (userrequest)
            ChangeShape  (incx, incy, rotate) ;
        else {
            if (GameRestart) {
                GameRestart = false ;
                GameOver () ;
                GetNextRandomShape () ;
                }
            else
                if (CurrentShape != null)
                    if  (CurrentShape.CheckFit (PlayMap, 0, 1, false))
                        ChangeShape (0, 1, false);
                    else 
                        {
                        Play  (SND_DROP);
                        CurrentShape.Place (PlayMap);
                        Arena.RepaintPlayMap ();
                        Report.AddScore (CurrentShape.GetValue ());
                        CheckLines ();
                        GetNextRandomShape ();
                        }
            
            Arena.repaint (CurrentShape);
        }
    }


    public synchronized void Suffer (int linecount) {
        if (GameSuspended)
            return ;

        int x, y ;
        for (y=0; y<Rows-linecount; y++)
            for (x=0; x<Cols; x++)
                PlayMap[y][x] = PlayMap[y+linecount][x] ;

        for (; y<Rows; y++)
            RandomRow (PlayMap[y]) ;
            
        Arena.RepaintPlayMap () ;
    }



    public void SetLevel (int level) {
        if (! GameSuspended)
            Report.SetLevel (level) ;
    }


    public boolean KeyAction (int key) {
        int incx = 0;
        int incy = 0;
        boolean rotate = false;

        if (GameSuspended)
            return true ;
            
        if (key>='A' && key<='Z')
            key += 'a' - 'A' ;
        
        if (key == KeyLeft)
            incx --;
        if (key == KeyRight)
            incx ++;
        if (key == KeyDrop)
            incy ++;
        if (key == KeyRotate)
            rotate = true ;
        
        UpdateMap (true, incx, incy, rotate) ;
        return true;
    }



    private void RandomRow (Color rowmap []) {
        Color [] colortab = {
            Color.blue,  Color.yellow, Color.pink,
            Color.green, Color.red,    Color.magenta, Color.orange } ;
        
        for (int col=0; col<Cols; col++)
            rowmap[col] = Color.black ;
        
        for (int i=0; i<Cols*0.7; i++)
            for (;;) {
               int num = (int) (Math.random () * Cols) ;
               if (rowmap[num] == Color.black) {
                   rowmap[num] = colortab [(int) (Math.random() * BlockNum)] ;
                   break ;
               }
            }
    }
    


    public static void Play (int n) {
        if  (Sound[n] != null)
            Sound[n].play ();
    }

}





class ArenaCanvas extends Canvas {
    public static final int BorderWidth   = 5;
    public static final Color BorderColor = Color.blue;

    protected Shape CurrentShape    = null;
    boolean CurrentShapeNeedRepaint = false;
    boolean PlayMapNeedRepaint      = false;
    boolean DiscardGame             = false;

    protected Font TetrisFont1, TetrisFont2;

    Color PlayMap [][] = null;


    public void GameOver () {
        DiscardGame = true;
        repaint ();
    }


    public void RepaintPlayMap () {
        PlayMapNeedRepaint = true;
        repaint ();
    }


    public void SetPlayMap (Color playmap [][]) {
        PlayMap = playmap ;
    }


    public ArenaCanvas () {
        TetrisFont1 = new Font ("TimesRoman", Font.BOLD, 20);
        FontMetrics TetrisFontMetrics1 = getFontMetrics (TetrisFont1);
        TetrisFont2 = new Font ("TimesRoman", Font.PLAIN, 14);
        FontMetrics TetrisFontMetrics2 = getFontMetrics (TetrisFont2);
    
        reshape (0, 0, 
            TetrisThread.ElementSize * TetrisThread.Cols + BorderWidth * 2, 
            TetrisThread.ElementSize * TetrisThread.Rows + BorderWidth );
    }


    public void repaint (Shape shape) {
        CurrentShape = shape ;
        CurrentShapeNeedRepaint = true;
        repaint ();
    }


    private void DrawLines  (Graphics graph, int ymin, int ymax) {
        int y ;
        for (y = ymin * TetrisThread.ElementSize; 
             y < ymax * TetrisThread.ElementSize; 
             y ++ )
             graph.drawLine (BorderWidth, y, 
                 BorderWidth + TetrisThread.Cols * TetrisThread.ElementSize, y);
    }


    private void GraphicsEffect (Graphics graph, int ymin, int ymax) {
        for (int line=0; line<10; line++) {
            graph.setColor (Color.red);
            DrawLines  (graph, ymin, ymax);
            graph.setColor (Color.green);
            DrawLines  (graph, ymin, ymax);
            graph.setColor (Color.blue);
            DrawLines  (graph, ymin, ymax);
            graph.setColor (Color.black);
            DrawLines  (graph, ymin, ymax);
        }
    }


    private void Discard (Graphics graph) {
        DiscardGame = false;
        GraphicsEffect (graph, 0, TetrisThread.Rows);
    }


    public void update (Graphics graph) {
        if  (DiscardGame)
            Discard (graph);
        if (PlayMapNeedRepaint)
            DrawPlayMap (graph);
        DrawCurrentShape (graph);
    }


    public void paint (Graphics graph) {
        DrawPlayMap (graph);
        CurrentShapeNeedRepaint = true;
        DrawCurrentShape (graph);
    }


    private void DrawCurrentShape (Graphics graph) {
        if  (CurrentShapeNeedRepaint && CurrentShape != null) {
            CurrentShape.Hide (graph, BorderWidth);
            while (! CurrentShape.IsReady ()) ;
            CurrentShape.Display (graph, BorderWidth);
            CurrentShapeNeedRepaint = false;
        }
    }


    private void DrawPlayMap (Graphics graph) {
        graph.setColor (BorderColor);
        graph.fillRect (0, 0, BorderWidth, TetrisThread.ElementSize * TetrisThread.Rows);
        graph.fillRect (TetrisThread.ElementSize * TetrisThread.Cols + BorderWidth, 0, BorderWidth, TetrisThread.ElementSize * TetrisThread.Rows);
        graph.fillRect (0, TetrisThread.ElementSize * TetrisThread.Rows, TetrisThread.ElementSize * TetrisThread.Cols + BorderWidth * 2, BorderWidth);
        
        int x, y ;
        
        for (x=0; x<TetrisThread.Cols; x++)
            for  (y=0; y<TetrisThread.Rows; y++)
                if  (PlayMap[y][x] != Color.black) {
                    graph.setColor (PlayMap[y][x]);
                    graph.fill3DRect (BorderWidth + x * TetrisThread.ElementSize + 1, y * TetrisThread.ElementSize + 1, TetrisThread.ElementSize - 2, TetrisThread.ElementSize - 2, true);
                    } 
                else {
                    graph.setColor (Color.black);
                    graph.fillRect (BorderWidth + x * TetrisThread.ElementSize, y * TetrisThread.ElementSize, TetrisThread.ElementSize, TetrisThread.ElementSize);
                }

        PlayMapNeedRepaint = false;
    }
}




class ReportCanvas extends Canvas {
    public static final Color TextColor  = Color.black;
    public static final int   MaxLevel   = 9;
    public static final int   FontHeight = 16;

    protected Font        TetrisFont;
    protected FontMetrics TetrisFontMetrics;
    protected int         Level, Lines, Score;
    protected Shape       NextShape = null;

    public void InitGame (int level) {
        Lines = Score = 0;
        Level = level ;
    }

    public void GameOver () {
    }

    public int GetGameSpeed () {
        switch  (Level) {
            case 0:     return 700;
            case 1:     return 600;
            case 2:     return 500;
            case 3:     return 400;
            case 4:     return 350;
            case 5:     return 300;
            case 6:     return 250;
            case 7:     return 200;
            case 8:     return 150;
            case 9:     return 100;
        }
        return 100 ;
    }

    public ReportCanvas () {
        reshape (0, 0, 100, 250);
        TetrisFont = new Font ("TimesRoman", Font.PLAIN, 20);
        setFont (TetrisFont);
        TetrisFontMetrics = getFontMetrics (TetrisFont);
    }


    public void SetLevel (int level) {
        Level = level ;
        repaint ();
    }


    public void AddScore (int point) {
        Score += point;
        repaint ();
    }


    public void AddLines (int num) {
        switch  (num) {
            case 1:
                AddScore  (10);
                break;
            case 2:
                AddScore  (20);
                break;
            case 3:
                AddScore  (30);
                break;
            case 4:
                AddScore  (40);
                break;
        }

        Lines += num;
        if (Lines >  (10 * (Level+1))) 
            AddLevel ();
        repaint ();
    }


    public void AddLevel () {
        TetrisThread.Play (TetrisThread.SND_NEXTLEVEL);
        if (Level < MaxLevel) 
            Level ++ ;
        repaint ();
    }


    public void DisplayNextShape (Shape shape) {
        NextShape = shape ;
        repaint ();
    }

    public void paint (Graphics graph) {
        graph.setColor (TextColor);
        graph.drawString ("Level: " + Level, 0, FontHeight);
        graph.drawString ("Lines: " + Lines, 0, FontHeight * 3);
        graph.drawString ("Score: " + Score, 0, FontHeight * 5);
        graph.drawString ("Next:", 0, FontHeight * 7);
        if (NextShape != null) {
            NextShape.DisplayAbs (graph, 10, FontHeight * 7 + 10);
        }
    }
}





class Element {
    protected int     X, Y ;
    int               OldX, OldY;
    protected int     XinShape, YinShape;
    protected int     OrgX, OrgY;
    protected int     OrgXinShape, OrgYinShape;
    protected Color   ElementColor;
    protected boolean ErasePossible;


    public Element (int xpos, int ypos, Color color) {
        XinShape = OrgXinShape = xpos;
        YinShape = OrgYinShape = ypos;
        X = OrgX = xpos + TetrisThread.Cols/2 - (TetrisThread.MaxElement+1)/2;
        Y = OrgY = ypos;
        ElementColor  = color;
        ErasePossible = false;
    }


    public void Init () {
        ErasePossible = false;
        X = OrgX;   Y = OrgY;
        XinShape = OrgXinShape;
        YinShape = OrgYinShape;
    }


    public void Hide  (Graphics graph, int xoff, int yoff) {
        if  (ErasePossible) {
            int size = TetrisThread.ElementSize;
            graph.setColor (Color.black);
            graph.fillRect (xoff + OldX * size, yoff + OldY * size, size, size);
            ErasePossible = false;
        }
    }

    public void Display  (Graphics graph, int xoff, int yoff) {
        int size = TetrisThread.ElementSize;
        graph.setColor (ElementColor);
        graph.fill3DRect (xoff + X*size + 1, yoff + Y*size + 1, size-2, size-2, true);
        OldX = X;
        OldY = Y;
        ErasePossible = true;
    }


    public void DisplayAbs  (Graphics graph, int xoff, int yoff) {
        int size = TetrisThread.ElementSize;
        graph.setColor (ElementColor);
        graph.fill3DRect (xoff + OrgXinShape*size + 1, yoff + OrgYinShape*size + 1, size-2, size-2, true);
        graph.setColor (Color.white);
        graph.drawRect (xoff + OrgXinShape*size, yoff + OrgYinShape*size, size-1, size-1);
	}


    public boolean CheckFit (Color playmap [][],
                             int xoff, int yoff, boolean rotate) {
        if  (rotate) {
            xoff += TetrisThread.MaxElement - YinShape - XinShape;
            yoff += XinShape - YinShape;
        }
        
        if  (X + xoff < 0 || X + xoff >= TetrisThread.Cols) 
            return false;
        if  (Y + yoff >= TetrisThread.Rows ) 
            return false;
        if  (playmap[Y + yoff][X + xoff] != Color.black) 
            return false;
        
        return true;
    }


    public void ChangePostion (int xoff, int yoff, boolean rotate) {
        if  (rotate) {
            xoff += TetrisThread.MaxElement - YinShape - XinShape;
            yoff += XinShape - YinShape;
            int tempXinShape = XinShape;
            XinShape = TetrisThread.MaxElement - YinShape;
            YinShape = tempXinShape;
        }

        X += xoff;
        Y += yoff;
    }


    public int   GetXPos  () { return X; }
    public int   GetYPos  () { return Y; }
    public Color GetColor () { return ElementColor; }

}







class Shape {
    protected Vector  Elements;
    protected int     Value;
    protected boolean DrawReady = true;


    public Shape () {
        DrawReady = true;
    }


    public void Init () {
        DrawReady = true;
        for  (int ix=0; ix<Elements.size (); ix++)
            ((Element) Elements.elementAt (ix)).Init () ;
    }

    public Shape (int blockmap [], Color color, int value) {
        Value = value;
        Elements = new Vector ();
        for (int i=0; i<4; i++)
            AddElements (i, blockmap[i], color);
        Init ();
    }


    protected void AddElements  (int row, int map, Color color) {
        if ((map & 0xf000) > 0) Elements.addElement (new Element (0, row, color));
        if ((map & 0x0f00) > 0) Elements.addElement (new Element (1, row, color));
        if ((map & 0x00f0) > 0) Elements.addElement (new Element (2, row, color));
        if ((map & 0x000f) > 0) Elements.addElement (new Element (3, row, color));
	}


    public void Hide  (Graphics graph, int xoff) {
        for  (int ix=0; ix<Elements.size (); ix++)
            ((Element) Elements.elementAt (ix)).Hide (graph, xoff, 0);
    }


    public void Display  (Graphics graph, int xoff) {
        DrawReady = false;
        for  (int ix=0; ix<Elements.size (); ix++)
            ((Element) Elements.elementAt (ix)).Display (graph, xoff, 0);
        DrawReady = true;
    }


    public void DisplayAbs  (Graphics graph, int x, int y) {
        for  (int ix = 0; ix < Elements.size (); ix++)
            ((Element) Elements.elementAt (ix)).DisplayAbs (graph, x, y);
	}


    public boolean CheckFit (Color playmap [][], 
                             int xoff, int yoff,
                             boolean rotate) {
        for  (int ix=0; ix<Elements.size (); ix++)
            if (! ((Element) Elements.elementAt (ix)).CheckFit (
                playmap, xoff, yoff, rotate)) 
                return false;

        return true;
    }


    public void ChangePosition (int xoff, int yoff, boolean rotate) {
        for  (int ix=0; ix<Elements.size (); ix++)
            ((Element) Elements.elementAt (ix)).ChangePostion (
                xoff, yoff, rotate);
    }


    public void Place (Color playmap [][]) {
        for  (int ix=0; ix<Elements.size (); ix++) {
            Element element = (Element) Elements.elementAt (ix) ;
            playmap [element.GetYPos()] [element.GetXPos()] = element.GetColor();
        }
    }

    public int GetValue ()    { return Value; }
    public boolean IsReady () { return DrawReady; }

    
}





class AboutFrame extends Frame {
    Button  OK = new Button (" O K ") ;
    Label   Caption = new Label ("Battle Tetris  V1.2", Label.CENTER) ;
    Label   Space   = new Label ("                          ") ;
    Label   Author  = new Label ("(C) Iwan van Rienen, 1995, 1996", Label.CENTER) ;
    Label   Author2 = new Label ("(C) Song Li, 1996", Label.CENTER) ;
    Label   Address = new Label ("I.V.Rienen - http://www.bart.nl/~ivr", Label.CENTER) ;
    Label   Address2= new Label ("S.Li - http://www.cs.umbc.edu/~sli2", Label.CENTER) ;
    Label   Space2  = new Label ("                          ") ;
    Label   Hotkey  = new Label ("Hotkeys: A S D F  vs.  J K L M", Label.CENTER) ;
    Label   Space3  = new Label ("                          ") ;

    public AboutFrame () {
        super ("Battle Tetris") ;
        resize (250, 270) ;
        setResizable (false) ;
        setLayout (new FlowLayout (FlowLayout.CENTER, 1000, 0)) ;

        add (Caption) ;
        add (Space) ;
        add (Author) ;
        add (Author2) ;
        add (Address) ;
        add (Address2) ;
        add (Space2) ;
        add (Hotkey) ;
        add (Space3) ;
        add (OK) ;
    }

    public synchronized boolean handleEvent (Event event) {
        if (event.id != Event.ACTION_EVENT)
            return false ;
        
        if (" O K ".equals (event.arg))
            dispose () ;
        return true ;
    }
}



