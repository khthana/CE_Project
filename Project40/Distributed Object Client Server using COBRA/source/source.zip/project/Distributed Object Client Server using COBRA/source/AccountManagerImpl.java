 // AccountManagerImpl.java

import java.util.*;
import java.io.*;
import java.io.IOException;

public class AccountManagerImpl extends Bank._AccountManagerImplBase {
  public AccountManagerImpl(String name) {
    super(name);
  }
  public synchronized Bank.Account open(String name) {

    String fname = name+".name";
    String fbal = name+".balance";
    float balance = -1;

    // Lookup the account in the account dictionary.
    Bank.Account account = (Bank.Account) _accounts.get(name);
    // If there was no account in the dictionary, create one.
    if(account == null) {
      try {
        FileInputStream fnamein = new FileInputStream(fname);
        DataInputStream namein = new DataInputStream(fnamein);
        FileInputStream fbalin = new FileInputStream(fbal);
        DataInputStream balin = new DataInputStream(fbalin);
        balance = balin.readFloat();
        fbalin.close();
        fnamein.close();
      } catch (IOException e){}

      if (balance<0) {
        System.out.println("Can't find this account's name");
      } else {
          // Create the account implementation, given the balance.
          account = new AccountImpl(balance);
          // Make the object available to the ORB.
          _boa().obj_is_ready(account);
          // Print out the new account.
          System.out.println("Created " + name + "'s account: " + account);
          // Save the account in the account dictionary.
          _accounts.put(name, account);
        }
    }
    // Return the account.
    return account;
  }
  private Dictionary _accounts = new Hashtable();
  private Random _random = new Random();
}

