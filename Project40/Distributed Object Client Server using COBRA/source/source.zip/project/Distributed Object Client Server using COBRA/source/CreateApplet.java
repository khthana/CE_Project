// CreateApplet.java for Admin

import java.lang.*;
import java.io.*;
import java.awt.*;
import java.security.*;

public class CreateApplet extends java.applet.Applet {

  private TextField _nameField, _balanceField;
  private TextArea _statusArea;
  private Button _createBalance;
  private Bank.AccountManager _manager;
  private String  name,sumtext="";
  String myFile = "/corba";
  File f = new File(myFile);

 public void init() {

    String osname = System.getProperty("os.name");
    if (osname.indexOf("Windows") != -1) {
      myFile="tmpfoo";
     }
    // This GUI uses a 3 by 3 grid of widgets.
    setLayout(new FlowLayout(FlowLayout.LEFT));
//    setLayout(new GridLayout(3, 2, 5, 5));
    // Add the four widgets.
    add(new Label("Account Name   "));
    add(_nameField = new TextField(10));
    add(new Label("                                                       "));

    add(new Label("Create Balance "));
    add(_balanceField = new TextField(10));
    add(new Label("                                                                "));

    add(_createBalance = new Button("Create Balance"));
    add(new Label("                                                                                                 "));

    add(new Label("Status        "));
    add(_statusArea = new TextArea("",10,60));
    _statusArea.setEditable(false);
    
   // Initialize the ORB.
//    org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init();
     // Locate an account manager.
//      _manager = Bank.AccountManagerHelper.bind(orb, "BankChecking");
 }

 public boolean action(Event ev, Object o) {
    if(ev.target == _createBalance) {
     try {
      // Get the account name from the name text widget.
      name=(_nameField.getText());
      String fname = name+".name";
      String fbal = name+".balance";
        int balance=Integer.parseInt(_balanceField.getText());

          //Save the account to File.

           FileOutputStream fnameout = new FileOutputStream(fname);
           FileOutputStream fbalout = new FileOutputStream(fbal);
           DataOutputStream nameout = new DataOutputStream(fnameout);
           DataOutputStream balout = new DataOutputStream(fbalout);
           nameout.writeBytes(name);
           balout.writeFloat(balance);
           fnameout.close();
           fbalout.close();
           
           sumtext=_nameField.getText()+"'s account created balance was "+_balanceField.getText()+".00 $  \n"+sumtext;	
           showStatus("Ready..");
        } 
	catch (SecurityException e) {
          showStatus("writeFile: caught security exception");
         
  	}
        catch (IOException e){
           sumtext=_nameField.getText()+"'s account can't create balance  "+_balanceField.getText()+"  \n"+sumtext; 
           showStatus("Exception: "+e.toString());
        }
        catch(NumberFormatException e){
           sumtext=_nameField.getText()+"'s account can't create balance  "+_balanceField.getText()+"  \n"+sumtext; 
           System.out.print("Exception Number Format Error. Try again ...\n");
	   showStatus("Exception: "+e.toString());
        }
        _statusArea.setText(sumtext);  
	_nameField.setText("");
	_balanceField.setText("");

	return true;
     }
   return false;  
 }
}