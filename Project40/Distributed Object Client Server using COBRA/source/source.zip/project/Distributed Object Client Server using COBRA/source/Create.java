// Create.java for teller.

import java.lang.*;
import java.io.*;
import java.awt.event.*;
import java.security.*;

class Create {
  public static void main(String[] arg) {
    String name = arg.length > 0 ? arg[0] : null;
    if (name==null) {
      System.out.println("Want two argument..!");
    } else {
        String money = arg.length > 1 ? arg[1] : null;
        if (money==null) {
          System.out.println("Not have money..!");
        } else {
            char[] ch = money.toCharArray();
            int dot_position = convert(ch);
            if (dot_position>2) {
            System.out.println("Decimal Over..!");
            } else {
                Float t0 = Float.valueOf(money);
                float balance = t0.floatValue();
                String fname = name+".name";
                String fbal = name+".balance";

                //Save the account to File.
                try {
                  FileOutputStream fnameout = new FileOutputStream(fname);
                  FileOutputStream fbalout = new FileOutputStream(fbal);
                  DataOutputStream nameout = new DataOutputStream(fnameout);
                  DataOutputStream balout = new DataOutputStream(fbalout);
                  nameout.writeBytes(name);
                  balout.writeFloat(balance);
                  System.out.println("Created "+name+"'s account..!");
                  fnameout.close();
                  fbalout.close();
                } catch (IOException e){}
              }
          }
       }
  }

  private static int convert(char[] ch_in) {
    int len_t =  ch_in.length;
    int len = len_t;
    int temp1 = 0;
    int pos_dot = 0;
    if (len<=14) {
      do {
        char temp0 = ch_in[len-1];
        --len;
        if (temp0!='.') {
          temp1++;
        } else {
            pos_dot = temp1;
          }
      } while(len!=0);
    }
    return pos_dot;
  }

}