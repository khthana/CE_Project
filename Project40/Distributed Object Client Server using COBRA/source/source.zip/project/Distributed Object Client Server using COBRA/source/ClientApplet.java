// ClientApplet.java


import java.awt.*;
import java.lang.*;

public class ClientApplet extends java.applet.Applet {

  private TextField _nameField, _balanceField;
  private TextArea _statusArea;
  private Button _checkBalance;
  private Bank.AccountManager _manager;
  private float nonbalance;
  String sumtext="";

  public void init() {
    // This GUI uses a 2 by 2 grid of widgets.
    setLayout(new FlowLayout(FlowLayout.LEFT));
//    setLayout(new GridLayout(4, 2, 5, 5));
    // Add the four widgets.
    add(new Label("Account Name  "));
    add(_nameField = new TextField(10));
                     add(new Label("                                                       "));
 
    add(_checkBalance = new Button("Check Balance "));
    add(_balanceField = new TextField(10));
    add(new Label("                                                                "));

    // make the balance text field non-editable.
    _balanceField.setEditable(false);	

    add(new Label("Status   "));
    add(_statusArea = new TextArea("",10,60));
    _statusArea.setEditable(false);

   // Initialize the ORB.
    org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(this);
     // Locate an account manager.
      _manager = Bank.AccountManagerHelper.bind(orb, "BankChecking");

}
  public boolean action(Event ev, Object arg) {
    if(ev.target == _checkBalance) {
     try 
        {
         // Request the account manager to open a named account.
         // Get the account name from the name text widget.
  
         Bank.Account account = _manager.open(_nameField.getText());
         nonbalance=account.balance();
         if ((account == null) || (nonbalance < 0)) {
           _balanceField.setText("           ");
           sumtext=_nameField.getText()+" have not in Account.  Try again....\n"+sumtext;  
           }
            else {
           // Set the balance text widget to the account's balance.
           _balanceField.setText(Float.toString(account.balance()));
           sumtext=_nameField.getText()+"'s account have balance is "+Float.toString(account.balance())+" $ ... \n"+sumtext; 	   
            }
       }
      catch(NullPointerException e)
         { 
           _balanceField.setText("           ");
           sumtext=_nameField.getText()+" have not in Account.  Try again....\n"+sumtext;  
          }  	
       _statusArea.setText(sumtext);   
      return true;
    }
    return false;
  }

}