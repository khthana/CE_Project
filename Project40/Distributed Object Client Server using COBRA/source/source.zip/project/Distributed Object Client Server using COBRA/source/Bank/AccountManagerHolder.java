package Bank;
/**
<p>
<ul>
<li> <b>Java Class</b> Bank.AccountManagerHolder
<li> <b>Source File</b> Bank/AccountManagerHolder.java
<li> <b>IDL Source File</b> Bank.idl
<li> <b>IDL Absolute Name</b> ::Bank::AccountManager
<li> <b>Repository Identifier</b> IDL:Bank/AccountManager:1.0
</ul>
<b>IDL definition:</b>
<pre>
    interface AccountManager {
      ::Bank::Account open(
        in string name
      );
    };
</pre>
</p>
*/
final public class AccountManagerHolder implements org.omg.CORBA.portable.Streamable {
  public Bank.AccountManager value;
  public AccountManagerHolder() {
  }
  public AccountManagerHolder(Bank.AccountManager value) {
    this.value = value;
  }
  public void _read(org.omg.CORBA.portable.InputStream input) {
    value = AccountManagerHelper.read(input);
  }
  public void _write(org.omg.CORBA.portable.OutputStream output) {
    AccountManagerHelper.write(output, value);
  }
  public org.omg.CORBA.TypeCode _type() {
    return AccountManagerHelper.type();
  }
}
