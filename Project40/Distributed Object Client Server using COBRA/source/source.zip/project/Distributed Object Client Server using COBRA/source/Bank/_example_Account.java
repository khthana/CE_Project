package Bank;
/**
<p>
<ul>
<li> <b>Java Class</b> Bank._example_Account
<li> <b>Source File</b> Bank/_example_Account.java
<li> <b>IDL Source File</b> Bank.idl
<li> <b>IDL Absolute Name</b> ::Bank::Account
<li> <b>Repository Identifier</b> IDL:Bank/Account:1.0
</ul>
<b>IDL definition:</b>
<pre>
    interface Account {
      float balance();
    };
</pre>
</p>
*/
public class _example_Account extends Bank._AccountImplBase {
  /** Construct a persistently named object. */
  public _example_Account(java.lang.String name) {
    super(name);
  }
  /** Construct a transient object. */
  public _example_Account() {
    super();
  }
  /**
  <p>
  Operation: <b>::Bank::Account::balance</b>.
  <pre>
    float balance();
  </pre>
  </p>
  */
  public float balance() {
    // implement operation...
    return 0;
  }
}
