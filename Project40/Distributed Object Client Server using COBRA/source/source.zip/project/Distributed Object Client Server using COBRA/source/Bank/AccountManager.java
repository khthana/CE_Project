package Bank;
/**
<p>
<ul>
<li> <b>Java Class</b> Bank.AccountManager
<li> <b>Source File</b> Bank/AccountManager.java
<li> <b>IDL Source File</b> Bank.idl
<li> <b>IDL Absolute Name</b> ::Bank::AccountManager
<li> <b>Repository Identifier</b> IDL:Bank/AccountManager:1.0
</ul>
<b>IDL definition:</b>
<pre>
    interface AccountManager {
      ::Bank::Account open(
        in string name
      );
    };
</pre>
</p>
*/
public interface AccountManager extends org.omg.CORBA.Object {
  /**
  <p>
  Operation: <b>::Bank::AccountManager::open</b>.
  <pre>
    ::Bank::Account open(
      in string name
    );
  </pre>
  </p>
  */
  public Bank.Account open(
    java.lang.String name
  );
}
