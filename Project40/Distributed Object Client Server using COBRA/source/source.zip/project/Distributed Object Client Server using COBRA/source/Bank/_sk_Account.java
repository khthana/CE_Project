package Bank;
/**
<p>
<ul>
<li> <b>Java Class</b> Bank._sk_Account
<li> <b>Source File</b> Bank/_sk_Account.java
<li> <b>IDL Source File</b> Bank.idl
<li> <b>IDL Absolute Name</b> ::Bank::Account
<li> <b>Repository Identifier</b> IDL:Bank/Account:1.0
</ul>
<b>IDL definition:</b>
<pre>
    interface Account {
      float balance();
    };
</pre>
</p>
*/
// Warning: 
//   This class has been deprecated by the new IDL to Java Language mapping.
//   Please use the new implementation base class: _AccountImplBase
abstract public class _sk_Account extends _AccountImplBase {
  protected _sk_Account(java.lang.String name) {
    super(name);
  }
  protected _sk_Account() {
  }
}
