package Bank;
/**
<p>
<ul>
<li> <b>Java Class</b> Bank._AccountImplBase
<li> <b>Source File</b> Bank/_AccountImplBase.java
<li> <b>IDL Source File</b> Bank.idl
<li> <b>IDL Absolute Name</b> ::Bank::Account
<li> <b>Repository Identifier</b> IDL:Bank/Account:1.0
</ul>
<b>IDL definition:</b>
<pre>
    interface Account {
      float balance();
    };
</pre>
</p>
*/
abstract public class _AccountImplBase extends org.omg.CORBA.portable.Skeleton implements Bank.Account {
  protected _AccountImplBase(java.lang.String name) {
    super(name);
  }
  protected _AccountImplBase() {
  }
  public java.lang.String[] _ids() {
    return __ids;
  }
  private static java.lang.String[] __ids = {
    "IDL:Bank/Account:1.0"
  };
  public org.omg.CORBA.portable.MethodPointer[] _methods() {
    org.omg.CORBA.portable.MethodPointer[] methods = {
      new org.omg.CORBA.portable.MethodPointer("balance", 0, 0),
    };
    return methods;
  }
  public boolean _execute(org.omg.CORBA.portable.MethodPointer method, org.omg.CORBA.portable.InputStream input, org.omg.CORBA.portable.OutputStream output) {
    switch(method.interface_id) {
    case 0: {
      return Bank._AccountImplBase._execute(this, method.method_id, input, output); 
    }
    }
    throw new org.omg.CORBA.MARSHAL();
  }
  public static boolean _execute(Bank.Account _self, int _method_id, org.omg.CORBA.portable.InputStream _input, org.omg.CORBA.portable.OutputStream _output) {
    switch(_method_id) {
    case 0: {
      float _result = _self.balance();
      _output.write_float(_result);
      return false;
    }
    }
    throw new org.omg.CORBA.MARSHAL();
  }
}
