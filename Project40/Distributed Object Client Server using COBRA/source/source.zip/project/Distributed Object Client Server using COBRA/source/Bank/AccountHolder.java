package Bank;
/**
<p>
<ul>
<li> <b>Java Class</b> Bank.AccountHolder
<li> <b>Source File</b> Bank/AccountHolder.java
<li> <b>IDL Source File</b> Bank.idl
<li> <b>IDL Absolute Name</b> ::Bank::Account
<li> <b>Repository Identifier</b> IDL:Bank/Account:1.0
</ul>
<b>IDL definition:</b>
<pre>
    interface Account {
      float balance();
    };
</pre>
</p>
*/
final public class AccountHolder implements org.omg.CORBA.portable.Streamable {
  public Bank.Account value;
  public AccountHolder() {
  }
  public AccountHolder(Bank.Account value) {
    this.value = value;
  }
  public void _read(org.omg.CORBA.portable.InputStream input) {
    value = AccountHelper.read(input);
  }
  public void _write(org.omg.CORBA.portable.OutputStream output) {
    AccountHelper.write(output, value);
  }
  public org.omg.CORBA.TypeCode _type() {
    return AccountHelper.type();
  }
}
