package Bank;
/**
<p>
<ul>
<li> <b>Java Class</b> Bank._st_AccountManager
<li> <b>Source File</b> Bank/_st_AccountManager.java
<li> <b>IDL Source File</b> Bank.idl
<li> <b>IDL Absolute Name</b> ::Bank::AccountManager
<li> <b>Repository Identifier</b> IDL:Bank/AccountManager:1.0
</ul>
<b>IDL definition:</b>
<pre>
    interface AccountManager {
      ::Bank::Account open(
        in string name
      );
    };
</pre>
</p>
*/
public class _st_AccountManager extends org.omg.CORBA.portable.ObjectImpl implements Bank.AccountManager {
  public java.lang.String[] _ids() {
    return __ids;
  }
  private static java.lang.String[] __ids = {
    "IDL:Bank/AccountManager:1.0"
  };
  /**
  <p>
  Operation: <b>::Bank::AccountManager::open</b>.
  <pre>
    ::Bank::Account open(
      in string name
    );
  </pre>
  </p>
  */
  public Bank.Account open(
    java.lang.String name
  ) {
    try {
      org.omg.CORBA.portable.OutputStream _output = this._request("open", true);
      _output.write_string(name);
      org.omg.CORBA.portable.InputStream _input = this._invoke(_output, null);
      Bank.Account _result;
      _result = Bank.AccountHelper.read(_input);
      return _result;
    }
    catch(org.omg.CORBA.TRANSIENT _exception) {
      return open(
        name
      );
    }
  }
}
