package Bank;
/**
<p>
<ul>
<li> <b>Java Class</b> Bank._sk_AccountManager
<li> <b>Source File</b> Bank/_sk_AccountManager.java
<li> <b>IDL Source File</b> Bank.idl
<li> <b>IDL Absolute Name</b> ::Bank::AccountManager
<li> <b>Repository Identifier</b> IDL:Bank/AccountManager:1.0
</ul>
<b>IDL definition:</b>
<pre>
    interface AccountManager {
      ::Bank::Account open(
        in string name
      );
    };
</pre>
</p>
*/
// Warning: 
//   This class has been deprecated by the new IDL to Java Language mapping.
//   Please use the new implementation base class: _AccountManagerImplBase
abstract public class _sk_AccountManager extends _AccountManagerImplBase {
  protected _sk_AccountManager(java.lang.String name) {
    super(name);
  }
  protected _sk_AccountManager() {
  }
}
