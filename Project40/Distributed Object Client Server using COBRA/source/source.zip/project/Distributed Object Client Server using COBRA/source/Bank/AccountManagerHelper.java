package Bank;
/**
<p>
<ul>
<li> <b>Java Class</b> Bank.AccountManagerHelper
<li> <b>Source File</b> Bank/AccountManagerHelper.java
<li> <b>IDL Source File</b> Bank.idl
<li> <b>IDL Absolute Name</b> ::Bank::AccountManager
<li> <b>Repository Identifier</b> IDL:Bank/AccountManager:1.0
</ul>
<b>IDL definition:</b>
<pre>
    interface AccountManager {
      ::Bank::Account open(
        in string name
      );
    };
</pre>
</p>
*/
abstract public class AccountManagerHelper {
  public static Bank.AccountManager narrow(org.omg.CORBA.Object object) {
    return narrow(object, false);
  }
  private static Bank.AccountManager narrow(org.omg.CORBA.Object object, boolean is_a) {
    if(object == null) {
      return null;
    }
    if(object instanceof Bank.AccountManager) {
      return (Bank.AccountManager) object;
    }
    if(is_a || object._is_a(id())) {
      Bank.AccountManager result = new Bank._st_AccountManager();
      ((org.omg.CORBA.portable.ObjectImpl) result)._set_delegate
        (((org.omg.CORBA.portable.ObjectImpl) object)._get_delegate());
      return result;
    }
    return null;
  }
  public static Bank.AccountManager bind(org.omg.CORBA.ORB orb) {
    return bind(orb, null, null, null);
  }
  public static Bank.AccountManager bind(org.omg.CORBA.ORB orb, java.lang.String name) {
    return bind(orb, name, null, null);
  }
  public static Bank.AccountManager bind(org.omg.CORBA.ORB orb, java.lang.String name, java.lang.String host, org.omg.CORBA.BindOptions options) {
    return narrow(orb.bind(id(), name, host, options), true);
  }
//  private static org.omg.CORBA.ORB _orb() {

  public static org.omg.CORBA.ORB _orb() {
    return org.omg.CORBA.ORB.init();
  }
  public static Bank.AccountManager read(org.omg.CORBA.portable.InputStream _input) {
    return Bank.AccountManagerHelper.narrow(_input.read_Object(), true);
  }
  public static void write(org.omg.CORBA.portable.OutputStream _output, Bank.AccountManager value) {
    _output.write_Object(value);
  }
  public static void insert(org.omg.CORBA.Any any, Bank.AccountManager value) {
    org.omg.CORBA.portable.OutputStream output = any.create_output_stream();
    write(output, value);
    any.read_value(output.create_input_stream(), type());
  }
  public static Bank.AccountManager extract(org.omg.CORBA.Any any) {
    if(!any.type().equal(type())) {
      throw new org.omg.CORBA.BAD_TYPECODE();
    }
    return read(any.create_input_stream());
  }
  private static org.omg.CORBA.TypeCode _type;
  public static org.omg.CORBA.TypeCode type() {
    if(_type == null) {
      _type = _orb().create_interface_tc(id(), "AccountManager");
    }
    return _type;
  }
  public static java.lang.String id() {
    return "IDL:Bank/AccountManager:1.0";
  }
}
