package Bank;
/**
<p>
<ul>
<li> <b>Java Class</b> Bank._tie_AccountManager
<li> <b>Source File</b> Bank/_tie_AccountManager.java
<li> <b>IDL Source File</b> Bank.idl
<li> <b>IDL Absolute Name</b> ::Bank::AccountManager
<li> <b>Repository Identifier</b> IDL:Bank/AccountManager:1.0
</ul>
<b>IDL definition:</b>
<pre>
    interface AccountManager {
      ::Bank::Account open(
        in string name
      );
    };
</pre>
</p>
*/
public class _tie_AccountManager extends Bank._AccountManagerImplBase {
  private Bank.AccountManagerOperations _delegate;
  public _tie_AccountManager(Bank.AccountManagerOperations delegate, java.lang.String name) {
    super(name);
    this._delegate = delegate;
  }
  public _tie_AccountManager(Bank.AccountManagerOperations delegate) {
    this._delegate = delegate;
  }
  public Bank.AccountManagerOperations _delegate() {
    return this._delegate;
  }
  /**
  <p>
  Operation: <b>::Bank::AccountManager::open</b>.
  <pre>
    ::Bank::Account open(
      in string name
    );
  </pre>
  </p>
  */
  public Bank.Account open(
    java.lang.String name
  ) {
    return this._delegate.open(
      name
    );
  }
}
