package Bank;
/**
<p>
<ul>
<li> <b>Java Class</b> Bank._tie_Account
<li> <b>Source File</b> Bank/_tie_Account.java
<li> <b>IDL Source File</b> Bank.idl
<li> <b>IDL Absolute Name</b> ::Bank::Account
<li> <b>Repository Identifier</b> IDL:Bank/Account:1.0
</ul>
<b>IDL definition:</b>
<pre>
    interface Account {
      float balance();
    };
</pre>
</p>
*/
public class _tie_Account extends Bank._AccountImplBase {
  private Bank.AccountOperations _delegate;
  public _tie_Account(Bank.AccountOperations delegate, java.lang.String name) {
    super(name);
    this._delegate = delegate;
  }
  public _tie_Account(Bank.AccountOperations delegate) {
    this._delegate = delegate;
  }
  public Bank.AccountOperations _delegate() {
    return this._delegate;
  }
  /**
  <p>
  Operation: <b>::Bank::Account::balance</b>.
  <pre>
    float balance();
  </pre>
  </p>
  */
  public float balance() {
    return this._delegate.balance(
    );
  }
}
