package Bank;
/**
<p>
<ul>
<li> <b>Java Class</b> Bank._st_Account
<li> <b>Source File</b> Bank/_st_Account.java
<li> <b>IDL Source File</b> Bank.idl
<li> <b>IDL Absolute Name</b> ::Bank::Account
<li> <b>Repository Identifier</b> IDL:Bank/Account:1.0
</ul>
<b>IDL definition:</b>
<pre>
    interface Account {
      float balance();
    };
</pre>
</p>
*/
public class _st_Account extends org.omg.CORBA.portable.ObjectImpl implements Bank.Account {
  public java.lang.String[] _ids() {
    return __ids;
  }
  private static java.lang.String[] __ids = {
    "IDL:Bank/Account:1.0"
  };
  /**
  <p>
  Operation: <b>::Bank::Account::balance</b>.
  <pre>
    float balance();
  </pre>
  </p>
  */
  public float balance() {
    try {
      org.omg.CORBA.portable.OutputStream _output = this._request("balance", true);
      org.omg.CORBA.portable.InputStream _input = this._invoke(_output, null);
      float _result;
      _result = _input.read_float();
      return _result;
    }
    catch(org.omg.CORBA.TRANSIENT _exception) {
      return balance();
    }
  }
}
