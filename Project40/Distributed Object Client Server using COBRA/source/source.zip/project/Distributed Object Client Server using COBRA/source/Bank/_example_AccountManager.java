package Bank;
/**
<p>
<ul>
<li> <b>Java Class</b> Bank._example_AccountManager
<li> <b>Source File</b> Bank/_example_AccountManager.java
<li> <b>IDL Source File</b> Bank.idl
<li> <b>IDL Absolute Name</b> ::Bank::AccountManager
<li> <b>Repository Identifier</b> IDL:Bank/AccountManager:1.0
</ul>
<b>IDL definition:</b>
<pre>
    interface AccountManager {
      ::Bank::Account open(
        in string name
      );
    };
</pre>
</p>
*/
public class _example_AccountManager extends Bank._AccountManagerImplBase {
  /** Construct a persistently named object. */
  public _example_AccountManager(java.lang.String name) {
    super(name);
  }
  /** Construct a transient object. */
  public _example_AccountManager() {
    super();
  }
  /**
  <p>
  Operation: <b>::Bank::AccountManager::open</b>.
  <pre>
    ::Bank::Account open(
      in string name
    );
  </pre>
  </p>
  */
  public Bank.Account open(
    java.lang.String name
  ) {
    // implement operation...
    return null;
  }
}
