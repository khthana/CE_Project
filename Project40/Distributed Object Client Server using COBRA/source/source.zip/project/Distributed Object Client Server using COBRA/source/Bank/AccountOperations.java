package Bank;
/**
<p>
<ul>
<li> <b>Java Class</b> Bank.AccountOperations
<li> <b>Source File</b> Bank/AccountOperations.java
<li> <b>IDL Source File</b> Bank.idl
<li> <b>IDL Absolute Name</b> ::Bank::Account
<li> <b>Repository Identifier</b> IDL:Bank/Account:1.0
</ul>
<b>IDL definition:</b>
<pre>
    interface Account {
      float balance();
    };
</pre>
</p>
*/
public interface AccountOperations {
  /**
  <p>
  Operation: <b>::Bank::Account::balance</b>.
  <pre>
    float balance();
  </pre>
  </p>
  */
  public float balance();
}
