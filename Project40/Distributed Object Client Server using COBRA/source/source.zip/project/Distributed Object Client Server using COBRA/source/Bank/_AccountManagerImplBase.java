package Bank;
/**
<p>
<ul>
<li> <b>Java Class</b> Bank._AccountManagerImplBase
<li> <b>Source File</b> Bank/_AccountManagerImplBase.java
<li> <b>IDL Source File</b> Bank.idl
<li> <b>IDL Absolute Name</b> ::Bank::AccountManager
<li> <b>Repository Identifier</b> IDL:Bank/AccountManager:1.0
</ul>
<b>IDL definition:</b>
<pre>
    interface AccountManager {
      ::Bank::Account open(
        in string name
      );
    };
</pre>
</p>
*/
abstract public class _AccountManagerImplBase extends org.omg.CORBA.portable.Skeleton implements Bank.AccountManager {
  protected _AccountManagerImplBase(java.lang.String name) {
    super(name);
  }
  protected _AccountManagerImplBase() {
  }
  public java.lang.String[] _ids() {
    return __ids;
  }
  private static java.lang.String[] __ids = {
    "IDL:Bank/AccountManager:1.0"
  };
  public org.omg.CORBA.portable.MethodPointer[] _methods() {
    org.omg.CORBA.portable.MethodPointer[] methods = {
      new org.omg.CORBA.portable.MethodPointer("open", 0, 0),
    };
    return methods;
  }
  public boolean _execute(org.omg.CORBA.portable.MethodPointer method, org.omg.CORBA.portable.InputStream input, org.omg.CORBA.portable.OutputStream output) {
    switch(method.interface_id) {
    case 0: {
      return Bank._AccountManagerImplBase._execute(this, method.method_id, input, output); 
    }
    }
    throw new org.omg.CORBA.MARSHAL();
  }
  public static boolean _execute(Bank.AccountManager _self, int _method_id, org.omg.CORBA.portable.InputStream _input, org.omg.CORBA.portable.OutputStream _output) {
    switch(_method_id) {
    case 0: {
      java.lang.String name;
      name = _input.read_string();
      Bank.Account _result = _self.open(name);
      Bank.AccountHelper.write(_output, _result);
      return false;
    }
    }
    throw new org.omg.CORBA.MARSHAL();
  }
}
