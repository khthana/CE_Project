// Client.java

public class Client {

  public static void main(String[] args) {
    // use args[0] as the account name.
    String name = args.length > 0 ? args[0] : null;
    if (name==null) {
      System.out.println("Must have an account's name");
    } else {
        // Initialize the ORB.
        org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);
        // Locate an account manager.
        Bank.AccountManager manager = 
	    Bank.AccountManagerHelper.bind(orb, "BankChecking");
        // Request the account manager to open a named account.
        Bank.Account account = manager.open(name);
        if (account==null) {
          System.out.println("Not have your account's name..!");
        }  else {
             float balance = account.balance();
             System.out.println
               ("The balance in " + name + "'s account is $" + balance);
           }
       }
  }

}