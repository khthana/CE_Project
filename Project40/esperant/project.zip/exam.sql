select t1."species no",t2."orderno"

from "biolife.db" t1,"orders.db" t2
