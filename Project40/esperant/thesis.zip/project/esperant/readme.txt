PROJECT FILE : Querypro.exe
REQUIRMENT : Windows95
                          BDE Engine

note : BDE Engine can install while install Delphi 3.0 client/server