// WWWQUERY.CPP - Implementation file for your Internet Server
//    WWWQuery 

#include "stdafx.h"
#include "WWWQuery.h"


///////////////////////////////////////////////////////////////////////
// command-parsing map

BEGIN_PARSE_MAP(CWWWQuery, CHttpServer)
	// TODO: insert your ON_PARSE_COMMAND() and 
	// ON_PARSE_COMMAND_PARAMS() here to hook up your commands.
	// For example:
	ON_PARSE_COMMAND(QueryNext,CWWWQuery,ITS_PSTR  ITS_I4 ITS_I4 ITS_I4)
	ON_PARSE_COMMAND_PARAMS("strsql  ni=-1 x=0 y=0")
	ON_PARSE_COMMAND(Menu1,CWWWQuery,ITS_PSTR ITS_PSTR ITS_I4 ITS_I4)
	ON_PARSE_COMMAND_PARAMS("type_name=' ' type_no=' ' x=0 y=0")
	ON_PARSE_COMMAND(QueryDetail,CWWWQuery,ITS_PSTR ITS_I4 ITS_I4)
	ON_PARSE_COMMAND_PARAMS("title_key x=0 y=0")
	ON_PARSE_COMMAND(Query,CWWWQuery,ITS_PSTR ITS_PSTR ITS_PSTR ITS_PSTR ITS_I4 ITS_I4)
	ON_PARSE_COMMAND_PARAMS("title_name=' ' title_author=' ' title_type=' ' title_class=' ' x=0 y=0")
	ON_PARSE_COMMAND(Default, CWWWQuery, ITS_I4 ITS_I4)
	ON_PARSE_COMMAND_PARAMS("x=0 y=0")
	ON_PARSE_COMMAND(DefaultNew,CWWWQuery,ITS_I4 ITS_I4)
	ON_PARSE_COMMAND_PARAMS("x=0 y=0")
	DEFAULT_PARSE_COMMAND(DefaultNew, CWWWQuery)
END_PARSE_MAP(CWWWQuery)


///////////////////////////////////////////////////////////////////////
// The one and only CWWWQuery object

CWWWQuery theExtension;


///////////////////////////////////////////////////////////////////////
// CWWWQuery implementation
CString CWWWQuery::GenSQL(CString title_name,CString title_author,CString type_name,CString class_name)
{
	BOOL first=TRUE;
	CString temp;
	CString strSQL="SELECT title_key,title_name,title_author  FROM mls_title_view ";
	title_name.TrimLeft();title_name.TrimRight();
	title_author.TrimLeft();title_author.TrimRight();
	type_name.TrimLeft();type_name.TrimRight();
	class_name.TrimLeft();class_name.TrimRight();
	if(title_name.IsEmpty() && title_author.IsEmpty() && type_name.IsEmpty() && class_name.IsEmpty())
		return strSQL;
	strSQL+=" WHERE";

	if(!title_name.IsEmpty())
	{
		int i=0;
		int j;
		title_name+=" ";
		while((title_name.GetLength()-1)>i)
		{
			while(title_name.GetAt(i)==' ') i++;
			j=i;
			while(title_name.GetAt(i)!=' ') i++;
			if(!first)
				strSQL+=" AND";
			temp=title_name.Mid(j,i-j);

			strSQL+="( title_name LIKE '%";
			strSQL+=temp;
			strSQL+="%'";
			strSQL+=" OR";
			strSQL+=" title_name LIKE '%";temp.MakeUpper();
			strSQL+=temp;
			strSQL+="%'";
			strSQL+=" OR";
			strSQL+=" title_name LIKE '%";temp.MakeLower();
			strSQL+=temp;
			strSQL+="%'";
			strSQL+=" OR";
			strSQL+=" title_keyword LIKE '%";
			strSQL+=temp;
			strSQL+="%'";
			strSQL+=" OR";
			strSQL+=" title_keyword LIKE '%";temp.MakeUpper();
			strSQL+=temp;
			strSQL+="%'";
			strSQL+=" OR";
			strSQL+=" title_keyword LIKE '%";temp.MakeLower();
			strSQL+=temp;
			strSQL+="%' )";

			first=FALSE;
		}
	}
	if(!title_author.IsEmpty())
	{
		int i=0;
		int j;
		title_author+=" ";
		while((title_author.GetLength()-1)>i)
		{
			while(title_author.GetAt(i)==' ') i++;
			j=i;
			while(title_author.GetAt(i)!=' ') i++;
			if(!first)
				strSQL+=" AND";
			temp=title_author.Mid(j,i-j);

			strSQL+=" title_author LIKE '%";
			strSQL+=temp;
			strSQL+="%'";
			strSQL+=" AND";
			strSQL+=" title_author LIKE '%";temp.MakeUpper();
			strSQL+=temp;
			strSQL+="%'";
			strSQL+=" AND";
			strSQL+=" title_author LIKE '%";temp.MakeLower();
			strSQL+=temp;
			strSQL+="%'";

			first=FALSE;
		}
	}
	
	if(!type_name.IsEmpty())
	{
		if(!first)
				strSQL+=" AND";
		strSQL+=" type_name='";
		strSQL+=type_name;
		strSQL+="'";
		first=FALSE;
	}
	if(!class_name.IsEmpty())
	{
		if(!first)
				strSQL+=" AND";
		strSQL+=" class_name='";
		strSQL+=class_name;
		strSQL+="'";
		first=FALSE;
	}
	return strSQL;
}

CWWWQuery::CWWWQuery()
{
	Mls_db.OpenEx("DSN=mlsdata;UID=mlsadmin;PWD=multimedia", CDatabase::noOdbcDialog);
}

CWWWQuery::~CWWWQuery()
{
	Mls_db.Close();
}

BOOL CWWWQuery::GetExtensionVersion(HSE_VERSION_INFO* pVer)
{
	// Call default implementation for initialization
	CHttpServer::GetExtensionVersion(pVer);

	// Load description string
	TCHAR sz[HSE_MAX_EXT_DLL_NAME_LEN+1];
	ISAPIVERIFY(::LoadString(AfxGetResourceHandle(),
			IDS_SERVER, sz, HSE_MAX_EXT_DLL_NAME_LEN));
	_tcscpy(pVer->lpszExtensionDesc, sz);
	return TRUE;
}

void CWWWQuery::DefaultNew(CHttpServerContext* pCtxt,int x=0,int y=0)
{
	*pCtxt<<"<HTML><HEAD>";
	*pCtxt<<"<TITLE></TITLE>";
	*pCtxt<<"</HEAD>";
	*pCtxt<<"<BODY BACKGROUND=\"/mls/image/bg_main.jpg\" TEXT=\"#FFFFFF\">\n";
	*pCtxt<<"<CENTER><IMG SRC=\"/mls/image/ti_main.gif\" ALT=\"MLS\"></CENTER>";
	*pCtxt<<"<CENTER>\n";
	*pCtxt<<"<FONT SIZE=+1><B>";
	*pCtxt<<"��س����͡���������ͷ���ҹ��ͧ���<br>";
	*pCtxt<<"</B></FONT>";
	*pCtxt<<"</CENTER>";
	*pCtxt<<"<CENTER>";
	{
		CDynamicBulkSet    Rmls(&Mls_db);
		Rmls.Open(CRecordset::snapshot, "SELECT type_no,type_name FROM mls_type",
					CRecordset::readOnly | CRecordset::useMultiRowFetch);
		CDynamicBulkSet *m_prs=&Rmls;
		long* rgLength;
		LPSTR rgData;

		// Need to use this to convert LPSTR to UNICODE
		CString strData[2][26];					// [field][row]

		int nFields = m_prs->GetODBCFieldCount();
		int nRowsFetched = m_prs->GetRowsFetched();

		// Display 1 rowset of data by field

		for (int nField = 0; nField < nFields; nField++)
		{
				// set up the correct data and length arrays
				rgData = (LPSTR)m_prs->m_ppvData[nField];
				rgLength = (long*)m_prs->m_ppvLengths[nField];

				for (int nRow = 0; nRow < nRowsFetched; nRow++)
				{
						int nStatus = m_prs->GetRowStatus(nRow + 1);
						// Get the string to display
						if (nStatus == SQL_ROW_DELETED)
											strData[nField][nRow] = _T("<DELETED>");
						else if (nStatus == SQL_ROW_NOROW)
						// Shouldn't get this since rows fetched is checked
											strData[nField][nRow] = _T("<NO_ROW>");
						else if (rgLength[nRow] == SQL_NULL_DATA)
											strData[nField][nRow] = _T("<NULL>");
						else
						{
									strData [nField][nRow]= &rgData[nRow * MAX_TEXT_LEN];
									strData[nField][nRow].TrimLeft();strData[nField][nRow].TrimRight();
						}
				}
		}
			
		// Show Type to the web
		for(int nRow=0;nRow<nRowsFetched;nRow++)
		{
				*pCtxt<<"<FORM ACTION=\"/mls/mls-cgi/WWWQuery.dll?\" METHOD=\"POST\">\n";
				*pCtxt<< "<INPUT TYPE=HIDDEN NAME=\"MfcISAPICommand\" VALUE=\"Menu1\">\n";
				*pCtxt<<"<INPUT TYPE=HIDDEN NAME=\"type_name\" VALUE=\"";
				*pCtxt<<strData[1][nRow];*pCtxt<<"\">\n";
				*pCtxt<<"<INPUT TYPE=IMAGE SRC=\"/mls/image/bt_type";
				*pCtxt<<strData[0][nRow];*pCtxt<<".gif\" BORDER=0 ALT=\"";
				*pCtxt<<strData[1][nRow];*pCtxt<<"\" HEIGHT=30>\n";
				*pCtxt<<"<INPUT TYPE=HIDDEN NAME=\"type_no\" VALUE=\"";
				*pCtxt<<strData[0][nRow];*pCtxt<<"\">\n";
				*pCtxt<<"</FORM>\n";	
		}
	}
	// Query Form for name and keyword
	*pCtxt<<"</CENTER>\n";
	*pCtxt<<"<CENTER>";
	*pCtxt<<"<FORM ACTION=\"/mls/mls-cgi/WWWQuery.dll?\" METHOD=\"POST\">\n";
	*pCtxt<<"<TABLE BORDER=0>\n";
	*pCtxt<<"<TR><TD>";
	*pCtxt<<"���ͤ��ҵ���Ӵѧ���";
	*pCtxt<<"</TD><TD>\n";
	*pCtxt<< "<INPUT TYPE=HIDDEN NAME=\"MfcISAPICommand\" VALUE=\"Query\">\n";
	*pCtxt<<"<INPUT TYPE=TEXT SIZE=20 MAXLENGHT=40 NAME=\"title_name\">\n";
	*pCtxt<<"</TD>\n<TD ALIGN=CENTER VALIGN=CENTER>";
	*pCtxt<<"<INPUT TYPE=IMAGE SRC=\"/mls/image/bt_submit.gif\" ALT=\"submit\" ALIGN=CENTER VALIGN=CENTER BORDER=0>\n";
	*pCtxt<<"</TD></TR></TABLE>";
	*pCtxt<<"</FORM>\n";
	*pCtxt<<"</CENTER>";

	*pCtxt<<"</BODY></HTML>";
}
///////////////////////////////////////////////////////////////////////
// CWWWQuery command handlers
void CWWWQuery::Default(CHttpServerContext* pCtxt,int x=0,int y=0)
{
	*pCtxt<<"<HTML><HEAD>";
	*pCtxt << "<TITLE> Query Form</TITLE>\n";
	*pCtxt<<"</HEAD>";
	*pCtxt<<"<BODY BACKGROUND=\"/mls/image/bg_main.jpg\" TEXT=\"#FFFFFF\">\n";
	*pCtxt<<"<CENTER><IMG SRC=\"/mls/image/ti_main.gif\" ALT=\"MLS\"></CENTER>";
	*pCtxt<<"<CENTER>";
	 QueryTable(pCtxt);
	 *pCtxt<<"</CENTER>";
	*pCtxt<<"</BODY></HTML>";
}

void CWWWQuery::QueryTable(CHttpServerContext* pCtxt)
{
	*pCtxt << "<TABLE BORDER=0>\n";
	*pCtxt<<"<CAPTION>��س������������´���ͷ���ͧ��ä���</CAPTION>\n";
	*pCtxt << "<FORM ACTION=\"/mls/mls-cgi/WWWQuery.dll?\"  METHOD=POST >\n";
	*pCtxt<< "<INPUT TYPE=HIDDEN NAME=\"MfcISAPICommand\" VALUE=\"Query\">\n";
		// Title name
	*pCtxt  <<  "<TR>\n";
	*pCtxt << "<TD>��������</TD>\n";
	*pCtxt << "<TD><INPUT TYPE=text  SIZE=40 NAME=\"title_name\"></TD>\n";
	*pCtxt<<"</TR>\n";
		// author name
	*pCtxt << "<TR>\n";
	*pCtxt << "<TD>���ͼ����/����Ե</TD>\n";
	*pCtxt << "<TD><INPUT TYPE=text  SIZE=40 NAME=\"title_author\"></TD>\n";
	*pCtxt<<"</TR>\n";
	{
		CDynamicBulkSet    Rmls(&Mls_db);
		Rmls.Open(CRecordset::snapshot, "SELECT type_name FROM mls_type",
					CRecordset::readOnly | CRecordset::useMultiRowFetch);
		CDynamicBulkSet *m_prs=&Rmls;
		
		long* rgLength;
		LPSTR rgData;

		// Need to use this to convert LPSTR to UNICODE
		CString strData;

		int nFields = m_prs->GetODBCFieldCount();
		int nRowsFetched = m_prs->GetRowsFetched();

		// Display 1 rowset of data by field
		*pCtxt << "<TR>\n";
		*pCtxt << "<TD>��Դ�ͧ����</TD>\n";
		*pCtxt << "<TD><SELECT NAME=\"title_type\">\n";
		for (int nField = 0; nField < nFields; nField++)
		{
				// set up the correct data and length arrays
				rgData = (LPSTR)m_prs->m_ppvData[nField];
				rgLength = (long*)m_prs->m_ppvLengths[nField];

				for (int nRow = 0; nRow < nRowsFetched; nRow++)
				{
						int nStatus = m_prs->GetRowStatus(nRow + 1);
						// Get the string to display
						if (nStatus == SQL_ROW_DELETED)
											strData = _T("<DELETED>");
						else if (nStatus == SQL_ROW_NOROW)
						// Shouldn't get this since rows fetched is checked
											strData = _T("<NO_ROW>");
						else if (rgLength[nRow] == SQL_NULL_DATA)
											strData = _T("<NULL>");
						else
						{
									strData = &rgData[nRow * MAX_TEXT_LEN];
									strData.TrimLeft();strData.TrimRight();
						}
							*pCtxt<<"<OPTION>";
							*pCtxt<<strData;
							*pCtxt<<"\n";
				}
		}
		*pCtxt<<"<OPTION SELECTED> ";
		*pCtxt<<"</SELECT></TD>\n";
		*pCtxt<<"</TR>\n";
	}
	{
		CDynamicBulkSet    Rmls(&Mls_db);
		Rmls.Open(CRecordset::snapshot, "SELECT class_name FROM mls_class",
					CRecordset::readOnly | CRecordset::useMultiRowFetch);
		CDynamicBulkSet *m_prs=&Rmls;
		
		long* rgLength;
		LPSTR rgData;

		// Need to use this to convert LPSTR to UNICODE
		CString strData;

		int nFields = m_prs->GetODBCFieldCount();
		int nRowsFetched = m_prs->GetRowsFetched();

		// Display 1 rowset of data by field
		*pCtxt << "<TR>\n";
		*pCtxt << "<TD>����������ͧ</TD>\n";
		*pCtxt << "<TD><SELECT NAME=\"title_class\">\n";
		for (int nField = 0; nField < nFields; nField++)
		{
				// set up the correct data and length arrays
				rgData = (LPSTR)m_prs->m_ppvData[nField];
				rgLength = (long*)m_prs->m_ppvLengths[nField];

				for (int nRow = 0; nRow < nRowsFetched; nRow++)
				{
						int nStatus = m_prs->GetRowStatus(nRow + 1);
						// Get the string to display
						if (nStatus == SQL_ROW_DELETED)
											strData = _T("<DELETED>");
						else if (nStatus == SQL_ROW_NOROW)
						// Shouldn't get this since rows fetched is checked
											strData = _T("<NO_ROW>");
						else if (rgLength[nRow] == SQL_NULL_DATA)
											strData = _T("<NULL>");
						else
						{
									strData = &rgData[nRow * MAX_TEXT_LEN];
									strData.TrimLeft();strData.TrimRight();
						}
							*pCtxt<<"<OPTION>";
							*pCtxt<<strData;
							*pCtxt<<"\n";
				}
		}
		*pCtxt<<"<OPTION SELECTED> ";
		*pCtxt<<"</SELECT></TD>\n";
		*pCtxt<<"</TR>\n";
	}
	*pCtxt<<"<TR><TD COLSPAN=2 ALIGN=CENTER  BGCOLOR=\"#0000FF\">";
	*pCtxt << "<INPUT TYPE=\"IMAGE\" SRC=\"/mls/image/bt_submit.gif\"  ALIGN=MIDDLE BORDER=0>";
	*pCtxt<<"</TR><TD>";
	*pCtxt << "</FORM>\n";
	*pCtxt << "</TABLE>\n";
}
void CWWWQuery::QueryNext(CHttpServerContext* pCtxt,LPTSTR StrSQL,long nI,int x ,int y)
{
	CString strSQL=StrSQL;
	if(strSQL=="" || nI<0)
	{
		*pCtxt<<"Error! Please do not call this module in this way";
		return ;
	}
		CDynamicBulkSet    Rmls(&Mls_db);
		Rmls.Open(CRecordset::snapshot, strSQL,
					CRecordset::readOnly | CRecordset::useMultiRowFetch);
		CDynamicBulkSet *m_prs=&Rmls;
		for(int i=0;i<nI;i++)
		{
			m_prs->MoveNext();
		}
		
		if (m_prs->IsEOF())			//Table is nothing
		{
			*pCtxt<<"<HTML><HEAD><TITLE>NO DATA</TITLE></HEAD>\n";
			*pCtxt<<"<BODY BACKGROUND=\"/mls/image/bg_nodata.jpg\" TEXT=\"#FFFFFF\">\n";
			*pCtxt<<"<CENTER><FONT SIZE=+3><BLINK>������������ա���ǡ�س� �� Back  ���͡�Ѻ�</BLINK></FONT></CENTER>\n";
			*pCtxt<<"</BODY></HTML>";
			return ;
		}
		long* rgLength;
		LPSTR rgData;

		// Need to use this to convert LPSTR to UNICODE
		CString strData[8][26];					// [field][row]
		int nFields = m_prs->GetODBCFieldCount();
		int nRowsFetched = m_prs->GetRowsFetched();

		// Display 1 rowset of data by field
		for (int nField = 0; nField < nFields; nField++)
		{
				// set up the correct data and length arrays
				rgData = (LPSTR)m_prs->m_ppvData[nField];
				rgLength = (long*)m_prs->m_ppvLengths[nField];

				for (int nRow = 0; nRow < nRowsFetched; nRow++)
				{
						int nStatus = m_prs->GetRowStatus(nRow + 1);
						// Get the string to display
						if (nStatus == SQL_ROW_DELETED)
											strData [nField][nRow]= _T("<DELETED>");
						else if (nStatus == SQL_ROW_NOROW)
						// Shouldn't get this since rows fetched is checked
											strData [nField][nRow]= _T("<NO_ROW>");
						else if (rgLength[nRow] == SQL_NULL_DATA)
											strData [nField][nRow]= _T("<NULL>");
						else
						{
									strData [nField][nRow]= &rgData[nRow * MAX_TEXT_LEN];
									strData[nField][nRow].TrimLeft();strData[nField][nRow].TrimRight();
						}
				}
		}
	// Send HTML to Client
	*pCtxt<<"<HTML><HEAD><TITLE>QUERY RESULT</TITLE></HEAD>";
	*pCtxt<<"<BODY BACKGROUND=\"/mls/image/bg_result.jpg\" TEXT=\"#FFFFFF\">\n";
	*pCtxt<<"<CENTER><IMG SRC=\"/mls/image/ti_result.gif\" ALT=\"MLS\"></CENTER>";
	*pCtxt<<"<CENTER>\n";
	*pCtxt<<"<TABLE BORDER=0>\n";
//	*pCtxt<<"<CAPTION>�š�ä���</CAPTION>";
	// Header of Table
	*pCtxt<<"<TR BGCOLOR=\"#777711\">\n";
	*pCtxt<<"<TD > ��������</TD><TD>���ͼ����/����Ե</TD><TD>��������´</TD>\n";
	*pCtxt<<"</TR>\n";
	for(int nRow=0;nRow<nRowsFetched;nRow++)
	{
		*pCtxt<<"<TR>\n";
		for(int nField=1;nField<nFields;nField++)  // nField =1 Skip title_key
		{
			*pCtxt<<"<TD ALIGN=CENTER>";
			*pCtxt<<strData[nField][nRow];
			*pCtxt<<"</TD>";
		}
		*pCtxt<<"<TD ALIGN=CENTER><FORM ACTION=\"/mls/mls-cgi/WWWQuery.dll?\" METHOD=\"POST\">";
		*pCtxt<< "<INPUT TYPE=HIDDEN NAME=\"MfcISAPICommand\" VALUE=\"QueryDetail\">\n";
		*pCtxt<<"<INPUT TYPE=HIDDEN NAME=\"title_key\" VALUE=\"";
		*pCtxt<<strData[0][nRow];
		*pCtxt<<"\">\n";
		//*pCtxt<<"<INPUT TYPE=SUBMIT VALUE=\"��������´\"> \n";
		*pCtxt<<"<INPUT TYPE=IMAGE  SRC=\"/mls/image/bt_detail.gif\" BORDER=0> \n";
		*pCtxt<<"</FORM></TD>";
		*pCtxt<<"</TR>\n";
	}
	*pCtxt<<"</TABLE>\n";
	*pCtxt<<"</CENTER>\n";
		// Next Bottom
	*pCtxt<<"<CENTER>";
	*pCtxt<<"<FORM ACTION=\"/mls/mls-cgi/WWWQuery.dll?\" METHOD=POST>\n";
	*pCtxt<< "<INPUT TYPE=HIDDEN NAME=\"MfcISAPICommand\" VALUE=\"QueryNext\">\n";
	*pCtxt<<"<INPUT TYPE=HIDDEN NAME=\"strsql\" VALUE=\"";
	*pCtxt<<strSQL;
	*pCtxt<<"\">";
	*pCtxt<<"<INPUT TYPE=HIDDEN NAME=\"ni\" VALUE=";
	*pCtxt<<(long)(nI+1);
	*pCtxt<<">";
	*pCtxt<<"<INPUT TYPE=IMAGE SRC=\"/mls/image/bt_next.gif\" BORDER=0>";
	*pCtxt<<"</FORM>";
	*pCtxt<<"</CENTER>";
	// End Next
	*pCtxt<<"</BODY></HTML>";

}
void CWWWQuery::QueryDetail(CHttpServerContext* pCtxt,LPTSTR Title_key,int x,int y)
{
		// Generate SQL Query
		CString strSQL="SELECT title_name,title_author,title_long,title_exam_name,title_cover_name,type_name,class_name,title_description FROM mls_title_view WHERE";
		strSQL+=" title_key='";
		strSQL+=Title_key;
		strSQL+="'";
		// Retrive Database
		CDynamicBulkSet    Rmls(&Mls_db);
		Rmls.Open(CRecordset::snapshot, strSQL,
					CRecordset::readOnly | CRecordset::useMultiRowFetch);
		CDynamicBulkSet *m_prs=&Rmls;
		if (m_prs->IsEOF() && m_prs->IsBOF())			//Table is nothing
		{
			NoData(pCtxt);
			return ;
		}
		
		long* rgLength;
		LPSTR rgData;

		// Need to use this to convert LPSTR to UNICODE
		CString strData[8][1];					// [field][row]
		int nFields = m_prs->GetODBCFieldCount();
		int nRowsFetched = m_prs->GetRowsFetched();

		// Display 1 rowset of data by field
		for (int nField = 0; nField < nFields; nField++)
		{
				// set up the correct data and length arrays
				rgData = (LPSTR)m_prs->m_ppvData[nField];
				rgLength = (long*)m_prs->m_ppvLengths[nField];

				for (int nRow = 0; nRow < nRowsFetched; nRow++)
				{
						int nStatus = m_prs->GetRowStatus(nRow + 1);
						// Get the string to display
						if (nStatus == SQL_ROW_DELETED)
											strData [nField][nRow]= _T("<DELETED>");
						else if (nStatus == SQL_ROW_NOROW)
						// Shouldn't get this since rows fetched is checked
											strData [nField][nRow]= _T("<NO_ROW>");
						else if (rgLength[nRow] == SQL_NULL_DATA)
											strData [nField][nRow]= _T("<NULL>");
						else
						{
									strData [nField][nRow]= &rgData[nRow * MAX_TEXT_LEN];
									strData[nField][nRow].TrimLeft();strData[nField][nRow].TrimRight();
						}
				}
		}

		// Output to Web Browser
		*pCtxt<<"<HTML><HEAD><TITLE>Detail of  ";
		*pCtxt<<Title_key<<"</TITLE></HEAD>";
		*pCtxt<<"<BODY BACKGROUND=\"/mls/image/bg_detail.jpg\" TEXT=\"#FFFFFF\">\n";
		*pCtxt<<"<CENTER><IMG SRC=\"/mls/image/ti_detail.gif\" ALT=\"MLS\"></CENTER>\n";
		//Table of  Detail
		*pCtxt<<"<CENTER>";
		*pCtxt<<"<TABLE BORDER=0 WIDTH=450>\n";
		// Show cover and Example Icon
		*pCtxt<<"<TR><TD COLSPAN=2 ALIGN=RIGHT>";
		// Cover
		if(strData[4][0]!="(NULL)")
		{
				*pCtxt<<"<A HREF=\"/mls/cover/";
				*pCtxt<<strData[4][0];
				*pCtxt<<"\">";
				*pCtxt<<"<IMG SRC=\"/mls/image/ic_cover.gif\" ALT=\"�Ҿ��\" BORDER=0>";
				*pCtxt<<"</A>";
		}
		if(strData[3][0]!="(NULL)")
		{
				*pCtxt<<"<A HREF=\"/mls/example/";
				*pCtxt<<strData[3][0];
				*pCtxt<<"\">";
				int i=strData[3][0].Find('.');
				if( (strData[3][0].GetAt(i+1)=='w') || (strData[3][0].GetAt(i+1)=='W') || (strData[3][0].GetAt(i+1)=='a') ||(strData[3][0].GetAt(i+1)=='A'))
				{
					*pCtxt<<"<IMG SRC=\"/mls/image/ic_snd.gif\" ALT=\"������ҧ\" BORDER=0>";
				}
				else
				{
					*pCtxt<<"<IMG SRC=\"/mls/image/ic_mov.gif\" ALT=\"������ҧ\" BORDER=0>";
				}
				*pCtxt<<"</A>";
		}
		// Title Key
		*pCtxt<<"<TR><TD BGCOLOR=\"881111\">��������ͧ</TD><TD>";
		*pCtxt<<Title_key;
		*pCtxt<<"</TD></TR>\n";

		// Title name
		*pCtxt<<"<TR><TD BGCOLOR=\"881111\">��������ͧ</TD><TD>";
		*pCtxt<<strData[0][0];
		*pCtxt<<"</TD></TR>\n";
		// author
		*pCtxt<<"<TR><TD BGCOLOR=\"881111\">���ͼ����/����Ե</TD><TD>";
		*pCtxt<<strData[1][0];
		*pCtxt<<"</TD></TR>\n";
		// long
		*pCtxt<<"<TR><TD BGCOLOR=\"881111\">�������(�ҷ�)</TD><TD>";
		if(strData[2][0]="0")
			*pCtxt<<"-";
		else
			*pCtxt<<strData[2][0];
		*pCtxt<<"</TD></TR>\n";

		//type
		*pCtxt<<"<TR><TD BGCOLOR=\"881111\">��Դ����</TD><TD>";
		*pCtxt<<strData[5][0];
		*pCtxt<<"</TD></TR>\n";
		//class
		*pCtxt<<"<TR><TD BGCOLOR=\"881111\">����������ͧ</TD><TD>";
		*pCtxt<<strData[6][0];
		*pCtxt<<"</TD></TR>\n";
		//Description
		*pCtxt<<"<TR><TD BGCOLOR=\"881111\">�Ӻ�����</TD><TD>";
		*pCtxt<<strData[7][0];
		*pCtxt<<"</TD></TR>\n";
		//End Table
		*pCtxt<<"</TABLE><P>\n";
		*pCtxt<<"<CENTER>";
		*pCtxt<<"<A HREF=\"/mls/mls-cgi/WWWQuery.dll?\" >";
		*pCtxt<<"<IMG SRC=\"/mls/image/bt_return.gif\" ATL=\"��Ѻ���˹�Ҩ���ѡ\" BORDER=0></A></CENTER>";
		*pCtxt<<"</CENTER></BODY></HTML>";
}
void CWWWQuery::Query(CHttpServerContext* pCtxt,LPTSTR Title_name,LPTSTR Title_author,LPTSTR Title_type,LPTSTR Title_class,int x=0, int y=0)
{
	CString Stitle_name=Title_name;
	CString Stitle_author=Title_author;
	CString Stype_name=Title_type;
	CString Sclass_name=Title_class;
		// Get Data from mls Database
		CString strSQL=GenSQL(Stitle_name,Stitle_author,Stype_name,Sclass_name);
//		*pCtxt<<strSQL;
		CDynamicBulkSet    Rmls(&Mls_db);
		Rmls.Open(CRecordset::snapshot, strSQL,
					CRecordset::readOnly | CRecordset::useMultiRowFetch);
		CDynamicBulkSet *m_prs=&Rmls;
		
		if (m_prs->IsEOF() && m_prs->IsBOF())			//Table is nothing
		{
			NoData(pCtxt);
			return ;
		}
		long* rgLength;
		LPSTR rgData;

		// Need to use this to convert LPSTR to UNICODE
		CString strData[8][26];					// [field][row]
		int nFields = m_prs->GetODBCFieldCount();
		int nRowsFetched = m_prs->GetRowsFetched();

		// Display 1 rowset of data by field
		for (int nField = 0; nField < nFields; nField++)
		{
				// set up the correct data and length arrays
				rgData = (LPSTR)m_prs->m_ppvData[nField];
				rgLength = (long*)m_prs->m_ppvLengths[nField];

				for (int nRow = 0; nRow < nRowsFetched; nRow++)
				{
						int nStatus = m_prs->GetRowStatus(nRow + 1);
						// Get the string to display
						if (nStatus == SQL_ROW_DELETED)
											strData [nField][nRow]= _T("<DELETED>");
						else if (nStatus == SQL_ROW_NOROW)
						// Shouldn't get this since rows fetched is checked
											strData [nField][nRow]= _T("<NO_ROW>");
						else if (rgLength[nRow] == SQL_NULL_DATA)
											strData [nField][nRow]= _T("<NULL>");
						else
						{
									strData [nField][nRow]= &rgData[nRow * MAX_TEXT_LEN];
									strData[nField][nRow].TrimLeft();strData[nField][nRow].TrimRight();
						}
				}
		}
	// Send HTML to Client
	*pCtxt<<"<HTML><HEAD><TITLE>QUERY RESULT</TITLE></HEAD>\n";
	*pCtxt<<"<BODY BACKGROUND=\"/mls/image/bg_result.jpg\" TEXT=\"#FFFFFF\">\n";
	*pCtxt<<"<CENTER><IMG SRC=\"/mls/image/ti_result.gif\" ALT=\"MLS\"></CENTER>";
	*pCtxt<<"<CENTER>\n";
	*pCtxt<<"<TABLE BORDER=0>\n";
	*pCtxt<<"<CAPTION>�š�ä���";
	*pCtxt<<Title_type;
	*pCtxt<<"</CAPTION>";
	// Header of Table
	*pCtxt<<"<TR BGCOLOR=\"#777711\">\n";
	*pCtxt<<"<TD>��������</TD><TD>���ͼ����/����Ե</TD><TD>��������´</TD>\n";
	*pCtxt<<"</TR>\n";
	for(int nRow=0;nRow<nRowsFetched;nRow++)
	{
		*pCtxt<<"<TR>\n";
		for(int nField=1;nField<nFields;nField++)  // nField =1 Skip title_key
		{
			*pCtxt<<"<TD ALIGN=CENTER>";
			*pCtxt<<strData[nField][nRow];
			*pCtxt<<"</TD>";
		}
		*pCtxt<<"<TD ALIGN=CENTER><FORM ACTION=\"/mls/mls-cgi/WWWQuery.dll?\" METHOD=\"POST\">";
		*pCtxt<< "<INPUT TYPE=HIDDEN NAME=\"MfcISAPICommand\" VALUE=\"QueryDetail\">\n";
		*pCtxt<<"<INPUT TYPE=HIDDEN NAME=\"title_key\" VALUE=\"";
		*pCtxt<<strData[0][nRow];
		*pCtxt<<"\">\n";
		*pCtxt<<"<INPUT TYPE=IMAGE  SRC=\"/mls/image/bt_detail.gif\" BORDER=0 ALIGN=MIDDLE> </FORM></TD>";
		*pCtxt<<"</TR>\n";
	}
	*pCtxt<<"</TABLE>\n";
	*pCtxt<<"</CENTER>\n";
	// For Next Bottom
	*pCtxt<<"<CENTER>";
	*pCtxt<<"<FORM ACTION=\"/mls/mls-cgi/WWWQuery.dll?\" METHOD=POST>\n";
	*pCtxt<< "<INPUT TYPE=HIDDEN NAME=\"MfcISAPICommand\" VALUE=\"QueryNext\">\n";
	*pCtxt<<"<INPUT TYPE=HIDDEN NAME=\"strsql\" VALUE=\"";
	*pCtxt<<strSQL;
	*pCtxt<<"\">";
	*pCtxt<<"<INPUT TYPE=HIDDEN NAME=\"ni\" VALUE=1>";
	*pCtxt<<"<INPUT TYPE=IMAGE SRC=\"/mls/image/bt_next.gif\" BORDER=0>";
	*pCtxt<<"</FORM>";
	*pCtxt<<"</CENTER>";
	// End Next Bottom
	*pCtxt<<"</BODY></HTML>";
}
void CWWWQuery::Menu1(CHttpServerContext *pCtxt,LPTSTR Type_name,LPTSTR Type_no,int x,int y)
{
	*pCtxt<<"<HTML><HEAD>";
	*pCtxt<<"<TITLE>";
	*pCtxt<<Type_name;
	*pCtxt<<"</TITLE>\n";
	*pCtxt<<"</HEAD>\n";
	*pCtxt<<"<BODY BACKGROUND=\"/mls/image/bg_type";
	*pCtxt<<Type_no;*pCtxt<<".jpg\" TEXT=\"#FFFFFF\">\n";
	*pCtxt<<"<CENTER><IMG SRC=\"/mls/image/ti_type";
	*pCtxt<<Type_no;*pCtxt<<".gif\" ALT=\"MLS\"></CENTER>";
	*pCtxt<<"<CENTER>\n";
	*pCtxt<<"<FONT SIZE=+1><B>";
	*pCtxt<<"��س����͡����������ͧ";
	*pCtxt<<Type_name;
	*pCtxt<<"����ҹ��ͧ���<br>";
	*pCtxt<<"</B></FONT>";
	*pCtxt<<"</CENTER>";
	*pCtxt<<"<CENTER>";
	{
		CDynamicBulkSet    Rmls(&Mls_db);
		Rmls.Open(CRecordset::snapshot, "SELECT class_no,class_name FROM mls_class",
					CRecordset::readOnly | CRecordset::useMultiRowFetch);
		CDynamicBulkSet *m_prs=&Rmls;
		long* rgLength;
		LPSTR rgData;

		// Need to use this to convert LPSTR to UNICODE
		CString strData[2][26];					// [field][row]

		int nFields = m_prs->GetODBCFieldCount();
		int nRowsFetched = m_prs->GetRowsFetched();

		// Display 1 rowset of data by field

		for (int nField = 0; nField < nFields; nField++)
		{
				// set up the correct data and length arrays
				rgData = (LPSTR)m_prs->m_ppvData[nField];
				rgLength = (long*)m_prs->m_ppvLengths[nField];

				for (int nRow = 0; nRow < nRowsFetched; nRow++)
				{
						int nStatus = m_prs->GetRowStatus(nRow + 1);
						// Get the string to display
						if (nStatus == SQL_ROW_DELETED)
											strData[nField][nRow] = _T("<DELETED>");
						else if (nStatus == SQL_ROW_NOROW)
						// Shouldn't get this since rows fetched is checked
											strData[nField][nRow] = _T("<NO_ROW>");
						else if (rgLength[nRow] == SQL_NULL_DATA)
											strData[nField][nRow] = _T("<NULL>");
						else
						{
									strData [nField][nRow]= &rgData[nRow * MAX_TEXT_LEN];
									strData[nField][nRow].TrimLeft();strData[nField][nRow].TrimRight();
						}
				}
		}
			
		// Show Type to the web
//7		*pCtxt<<"\n<TABLE BORDER=0>\n";
		for(int nRow=0;nRow<nRowsFetched;nRow++)
		{
				*pCtxt<<"<FORM ACTION=\"/mls/mls-cgi/WWWQuery.dll?\" METHOD=\"POST\">\n";
				*pCtxt<< "<INPUT TYPE=HIDDEN NAME=\"MfcISAPICommand\" VALUE=\"Query\">\n";
				*pCtxt<<"<INPUT TYPE=HIDDEN NAME=\"title_type\" VALUE=\"";
				*pCtxt<<Type_name;*pCtxt<<"\">\n";
				*pCtxt<<"<INPUT TYPE=HIDDEN NAME=\"title_class\" VALUE=\"";
				*pCtxt<<strData[1][nRow];*pCtxt<<"\">\n";
				*pCtxt<<"<INPUT TYPE=IMAGE SRC=\"/mls/image/bt_class";
				*pCtxt<<strData[0][nRow];*pCtxt<<".gif\" BORDER=0 ALT=\"";
				*pCtxt<<strData[1][nRow];*pCtxt<<"\" HEIGHT=30>\n";
				*pCtxt<<"</FORM>\n";
		}
	}
	*pCtxt<<"</CENTER>";

	// Query Form for name and keyword
	*pCtxt<<"</CENTER>\n";
/*	*pCtxt<<"<CENTER>";
	*pCtxt<<"<TABLE BORDER=0>\n";
	*pCtxt<<"<TR><TD>";
	*pCtxt<<"���ͤ���";
	*pCtxt<< Type_name;*pCtxt<<"����Ӵѧ���";
	*pCtxt<<"</TD><TD>\n";
	*pCtxt<<"<FORM ACTION=\"/mls/mls-cgi/WWWQuery.dll?\" METHOD=\"POST\">\n";
	*pCtxt<< "<INPUT TYPE=HIDDEN NAME=\"MfcISAPICommand\" VALUE=\"Query\">\n";
	*pCtxt<<"<INPUT TYPE=TEXT SIZE=20 MAXLENGHT=40 NAME=\"title_name\">\n";
	*pCtxt<<"<INPUT TYPE=HIDDEN NAME=\"title_type\" VALUE=\"";
	*pCtxt<<Type_no;*pCtxt<<"\">\n";
	*pCtxt<<"</TD>\n<TD ALIGN=CENTER VALIGN=CENTER>";
	*pCtxt<<"<INPUT TYPE=IMAGE SRC=\"/mls/image/bt_submit.gif\" ALT=\"submit\" ALIGN=MIDDLE BORDER=0>\n";
	*pCtxt<<"</FORM>\n";
	*pCtxt<<"</TD></TR></TABLE>";
	*pCtxt<<"</CENTER>";*/
	*pCtxt<<"</BODY></HTML>";

}
void CWWWQuery::NoData(CHttpServerContext *pCtxt)
{
	*pCtxt<<"<HTML><HEAD><TITLE>NO DATA</TITLE></HEAD>";
	*pCtxt<<"<BODY BACKGROUND=\"/mls/image/bg_nodata.jpg\" TEXT=\"#FFFFFF\">\n";
	*pCtxt<<"<CENTER><IMG SRC=\"/mls/image/ti_nodata.gif\" ALT=\"MLS\"></CENTER>";
	*pCtxt<<"<CENTER>����բ����ŷ���ҹ��ͧ��ä��ҡ�س� ��������</CENTER>";
	*pCtxt<<"<CENTER>";
	//QueryTable(pCtxt);
	*pCtxt<<"</CENTER>";
	*pCtxt<<"</BODY></HTML>";
}
// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CWWWQuery, CHttpServer)
	//{{AFX_MSG_MAP(CWWWQuery)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0



///////////////////////////////////////////////////////////////////////
// If your extension will not use MFC, you'll need this code to make
// sure the extension objects can find the resource handle for the
// module.  If you convert your extension to not be dependent on MFC,
// remove the comments arounn the following AfxGetResourceHandle()
// and DllMain() functions, as well as the g_hInstance global.

/****

static HINSTANCE g_hInstance;

HINSTANCE AFXISAPI AfxGetResourceHandle()
{
	return g_hInstance;
}

BOOL WINAPI DllMain(HINSTANCE hInst, ULONG ulReason,
					LPVOID lpReserved)
{
	if (ulReason == DLL_PROCESS_ATTACH)
	{
		g_hInstance = hInst;
	}

	return TRUE;
}

****/
