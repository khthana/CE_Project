#if !defined(AFX_WWWQUERY_H__0844AFE7_E28A_11D1_ABE0_0040052F5C5F__INCLUDED_)
#define AFX_WWWQUERY_H__0844AFE7_E28A_11D1_ABE0_0040052F5C5F__INCLUDED_

// WWWQUERY.H - Header file for your Internet Server
//    WWWQuery 

#include "resource.h"
#include "bulkset.h"
#define HEADER_COLOR  RED

class CWWWQuery : public CHttpServer
{
public:
	CWWWQuery();
	~CWWWQuery();
	CDatabase Mls_db;
// Overrides
	// ClassWizard generated virtual function overrides
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//{{AFX_VIRTUAL(CWWWQuery)
	public:
	virtual BOOL GetExtensionVersion(HSE_VERSION_INFO* pVer);
	//}}AFX_VIRTUAL

	// TODO: Add handlers for your commands here.
	// For example:

	void Default(CHttpServerContext* pCtxt,int x,int y);
	void Query(CHttpServerContext* pCtxt,LPTSTR Title_name,LPTSTR Title_author,LPTSTR Title_type,LPTSTR Title_class,int x,int y);
	void QueryDetail(CHttpServerContext* pCtxt,LPTSTR Title_key,int x,int y);
	void NoData(CHttpServerContext* pCtxt);
	void QueryTable(CHttpServerContext* pCtxt);
	void QueryNext(CHttpServerContext* pCtxt,LPTSTR StrSQL,long nI,int x,int y);
	void DefaultNew(CHttpServerContext* pCtxt,int x,int y);
	void Menu1(CHttpServerContext* pCtxt,LPTSTR Type_name,LPTSTR Type_no,int x,int y);
	DECLARE_PARSE_MAP()

	//{{AFX_MSG(CWWWQuery)
	//}}AFX_MSG
	private:
	CString	GenSQL(CString title_name,CString title_author,CString type_name,CString class_name);
};


//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WWWQUERY_H__0844AFE7_E28A_11D1_ABE0_0040052F5C5F__INCLUDED)
