#if !defined(AFX_DB_EDIT1_H__738DBDE3_DF00_11D1_ABD3_0040052F5C5F__INCLUDED_)
#define AFX_DB_EDIT1_H__738DBDE3_DF00_11D1_ABD3_0040052F5C5F__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// db_edit1.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// db_edit1 dialog

class db_edit1 : public CDialog
{
// Construction
public:
	db_edit1(CWnd* pParent = NULL);   // standard constructor
	CString		n_edit_name;
	CString		n_edit_no;
	CString		n_header;
	CString		n_name;
	CString		n_no;
	CString		default_table;
	int		action_type;
	CDatabase  *Mls_db;
// Dialog Data
	//{{AFX_DATA(db_edit1)
	enum { IDD = IDD_EDIT1 };
	CButton	m_ok;
	CButton	m_cancel;
	CStatic	m_no;
	CStatic	m_name;
	CStatic	m_header;
	CEdit	m_edit_no;
	CEdit	m_edit_name;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(db_edit1)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(db_edit1)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DB_EDIT1_H__738DBDE3_DF00_11D1_ABD3_0040052F5C5F__INCLUDED_)
