#if !defined(AFX_MLS_TITLE_H__738DBDE4_DF00_11D1_ABD3_0040052F5C5F__INCLUDED_)
#define AFX_MLS_TITLE_H__738DBDE4_DF00_11D1_ABD3_0040052F5C5F__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// mls_title.h : header file
//
//#include "bulkset.h"

/////////////////////////////////////////////////////////////////////////////
// Cmls_title dialog

class Cmls_title : public CDialog
{
// Construction
public:
	Cmls_title(CWnd* pParent = NULL);   // standard constructor
	CString n_author_name;
	CString n_title_key;
	CString n_title_header;
	CString n_title_long;
	CString n_title_name;
	CString n_class_name;
	CString n_type_name;
	CString n_exam_name;
	CString n_cover_name;
	CString n_description;
	CString n_title_keyword;
	CRecordset  *m_prs;
	int action_type;
	// Dialog Data
	//{{AFX_DATA(Cmls_title)
	enum { IDD = IDD_MLS_TITLE };
	CEdit	m_title_keyword;
	CButton	m_browse_exam;
	CButton	m_browse_cover;
	CComboBox	m_type_name;
	CComboBox	m_class_name;
	CEdit	m_title_name;
	CEdit	m_title_long;
	CEdit	m_title_key;
	CStatic	m_title_header;
	CEdit	m_exam_file;
	CEdit	m_description;
	CEdit	m_author_name;
	CEdit	m_cover_file;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(Cmls_title)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(Cmls_title)
	afx_msg void OnBrowseCover();
	afx_msg void OnBrowseExam();
	virtual void OnCancel();
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	CFileDialog	 f_cover_file;
	CFileDialog  f_exam_file;
	void sendftp();
	CString remote_file;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MLS_TITLE_H__738DBDE4_DF00_11D1_ABD3_0040052F5C5F__INCLUDED_)
