#if !defined(AFX_MLSTYPE_H__831F2AD5_DF82_11D1_ABD3_0040052F5C5F__INCLUDED_)
#define AFX_MLSTYPE_H__831F2AD5_DF82_11D1_ABD3_0040052F5C5F__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// mlstype.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// mlstype recordset

class mlstype : public CRecordset
{
public:
	mlstype(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(mlstype)

// Field/Param Data
	//{{AFX_FIELD(mlstype, CRecordset)
	long	m_type_no;
	CString	m_type_name;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(mlstype)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MLSTYPE_H__831F2AD5_DF82_11D1_ABD3_0040052F5C5F__INCLUDED_)
