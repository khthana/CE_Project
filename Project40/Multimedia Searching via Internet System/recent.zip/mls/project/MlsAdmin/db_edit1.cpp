// db_edit1.cpp : implementation file
//

#include "stdafx.h"
#include "dbfetch.h"
#include "db_edit1.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// db_edit1 dialog


db_edit1::db_edit1(CWnd* pParent /*=NULL*/)
	: CDialog(db_edit1::IDD, pParent)
{
	n_edit_name="";
	n_edit_no="";
	n_header="";
	n_name="";
	n_no="";
	//{{AFX_DATA_INIT(db_edit1)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void db_edit1::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(db_edit1)
	DDX_Control(pDX, IDOK, m_ok);
	DDX_Control(pDX, IDCANCEL, m_cancel);
	DDX_Control(pDX, IDC_NO2, m_no);
	DDX_Control(pDX, IDC_NAME, m_name);
	DDX_Control(pDX, IDC_HEADER, m_header);
	DDX_Control(pDX, IDC_EDIT_NO, m_edit_no);
	DDX_Control(pDX, IDC_EDIT_NAME, m_edit_name);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(db_edit1, CDialog)
	//{{AFX_MSG_MAP(db_edit1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// db_edit1 message handlers

BOOL db_edit1::OnInitDialog() 
{
	CDialog::OnInitDialog();
	// Initial data on Dialog
	m_edit_name.SetWindowText(n_edit_name);
	m_edit_no.SetWindowText(n_edit_no);
	m_header.SetWindowText(n_header);
	m_name.SetWindowText(n_name);
	m_no.SetWindowText(n_no);
	// Check Action type for each way
	switch(action_type)
	{
		case	-1 :{
				break;
				}
	default:{
				m_edit_no.EnableWindow(FALSE);
				break;
				}
	}	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void db_edit1::OnOK() 
{
	// TODO: Add extra validation here
	switch(action_type)
	{
	case -1:
		if(default_table=="mls_type")
		{
				CString strQuery="INSERT mls_type(type_no,type_name) VALUES(";
				CString  temp;
				m_edit_no.GetWindowText(temp);
				temp.TrimLeft();temp.TrimRight();
				strQuery+=temp;strQuery+=",";
				m_edit_name.GetWindowText(temp);
				temp.TrimLeft();temp.TrimRight();
				strQuery+="'";strQuery+=temp;strQuery+="')";
				Mls_db->BeginTrans();
				Mls_db->ExecuteSQL(strQuery);
				Mls_db->CommitTrans();
		}
		else if(default_table=="mls_class")
		{
				CString strQuery="INSERT mls_class(class_no,class_name) VALUES(";
				CString  temp;
				m_edit_no.GetWindowText(temp);
				temp.TrimLeft();temp.TrimRight();
				strQuery+=temp;strQuery+=",";
				m_edit_name.GetWindowText(temp);
				temp.TrimLeft();temp.TrimRight();
				strQuery+="'";strQuery+=temp;strQuery+="')";
				Mls_db->BeginTrans();
				Mls_db->ExecuteSQL(strQuery);
				Mls_db->CommitTrans();
		}
		break;
	default:
		{
		if(default_table=="mls_type")
		{
				CString strQuery="UPDATE mls_type SET type_name='";
				CString  temp;
				m_edit_name.GetWindowText(temp);
				temp.TrimLeft();temp.TrimRight();
				strQuery+=temp;strQuery+="' WHERE type_no=";
				m_edit_no.GetWindowText(temp);
				temp.TrimLeft();temp.TrimRight();
				strQuery+=temp;
				Mls_db->BeginTrans();
				Mls_db->ExecuteSQL(strQuery);
				Mls_db->CommitTrans();
		}
		else if(default_table=="mls_class")
		{
				CString strQuery="UPDATE mls_class SET class_name='";
				CString  temp;
				m_edit_name.GetWindowText(temp);
				temp.TrimLeft();temp.TrimRight();
				strQuery+=temp;strQuery+="' WHERE class_no=";
				m_edit_no.GetWindowText(temp);
				temp.TrimLeft();temp.TrimRight();
				strQuery+=temp;
				Mls_db->BeginTrans();
				Mls_db->ExecuteSQL(strQuery);
				Mls_db->CommitTrans();		
		}
		break;
		}
	}
	CDialog::OnOK();
}
