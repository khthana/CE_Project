#if !defined(AFX_MLS_TYPE_H__831F2AD3_DF82_11D1_ABD3_0040052F5C5F__INCLUDED_)
#define AFX_MLS_TYPE_H__831F2AD3_DF82_11D1_ABD3_0040052F5C5F__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// mls_type.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// mls_type recordset

class mls_type : public CRecordset
{
public:
	mls_type(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(mls_type)

// Field/Param Data
	//{{AFX_FIELD(mls_type, CRecordset)
	CString	m_title_key;
	CString	m_title_name;
	CString	m_title_author;
	long	m_title_long;
	CString	m_title_cover_name;
	CString	m_title_exam_name;
	long	m_titleFKtype_name;
	long	m_titleFKclass_name;
	CString	m_title_description;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(mls_type)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MLS_TYPE_H__831F2AD3_DF82_11D1_ABD3_0040052F5C5F__INCLUDED_)
