// datadlg.cpp : implementation file
//

// This is a part of the Microsoft Foundation Classes C++ library.
// Copyright (C) 1992-1997 Microsoft Corporation
// All rights reserved.
//
// This source code is only intended as a supplement to the
// Microsoft Foundation Classes Reference and related
// electronic documentation provided with the library.
// See these sources for detailed information regarding the
// Microsoft Foundation Classes product.

#include "stdafx.h"
#include "dbfetch.h"
#include "datadlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
/////////////////////////////////////////////////////////////////////////////
// CDataDialog dialog


CDataDialog::CDataDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CDataDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDataDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	list_select=-1;

	m_prs = NULL;
}


void CDataDialog::SetRecordset(CDynamicBulkSet* prs)
{
	ASSERT(prs != NULL);

	m_prs = prs;
}

int CDataDialog::DoModal()
{
	ASSERT(m_prs != NULL);

	return CDialog::DoModal();
}

BOOL CDataDialog::OnInitDialog()
{
	BOOL bReturn = CDialog::OnInitDialog();
	AddColumns();
	FillData();
	if(default_table!="mls_title_view")
		m_query.EnableWindow(FALSE);
	return bReturn;
}

void CDataDialog::AddColumns()
{
	ASSERT(m_prs->IsOpen());

	// declare a CODBCFieldInfo structure and get a count
	// of the number of columns in the database
	CODBCFieldInfo info;
	int nColumns = m_prs->GetODBCFieldCount();

	// for each column, retrieve the field name and 
	// insert the field name in the header
	for (int nNum = 0; nNum < nColumns; nNum++)
	{
		m_prs->GetODBCFieldInfo(nNum, info);
		if (m_listData.InsertColumn(nNum, info.m_strName,
			LVCFMT_CENTER, 80) != nNum)
		{
			ASSERT(FALSE);
			return;
		}
	}
}

void CDataDialog::FillData()
{
	ASSERT(m_prs->IsOpen());

	// Make sure there are no items
	m_listData.DeleteAllItems();

	// Validate that there is data
	if (m_prs->IsEOF() && m_prs->IsBOF())
	{
		// Disable all the controls
		GetDlgItem(IDC_FIRST)->EnableWindow(FALSE);
		GetDlgItem(IDC_LAST)->EnableWindow(FALSE);
		GetDlgItem(IDC_NEXT)->EnableWindow(FALSE);
		GetDlgItem(IDC_PREV)->EnableWindow(FALSE);

		// Put up a warning dialog and return
		CString strError;
		strError.LoadString(IDS_ERROR_NODATA);
		MessageBox(strError,"MLS-Administrator",MB_OK | MB_ICONWARNING);
		return;
	}
	else
	{
		// Enable all the controls
		GetDlgItem(IDC_FIRST)->EnableWindow(TRUE);
		GetDlgItem(IDC_LAST)->EnableWindow(TRUE);
		GetDlgItem(IDC_NEXT)->EnableWindow(TRUE);
		GetDlgItem(IDC_PREV)->EnableWindow(TRUE);
	}


	long* rgLength;
	LPSTR rgData;

	// Need to use this to convert LPSTR to UNICODE
	CString strData;

	int nFields = m_prs->GetODBCFieldCount();
	int nRowsFetched = m_prs->GetRowsFetched();

	// Display 1 rowset of data by field
	for (int nField = 0; nField < nFields; nField++)
	{
		// set up the correct data and length arrays
		rgData = (LPSTR)m_prs->m_ppvData[nField];
		rgLength = (long*)m_prs->m_ppvLengths[nField];

		for (int nRow = 0; nRow < nRowsFetched; nRow++)
		{
			int nStatus = m_prs->GetRowStatus(nRow + 1);

			// Get the string to display
			if (nStatus == SQL_ROW_DELETED)
				strData = _T("<DELETED>");
			else if (nStatus == SQL_ROW_NOROW)
				// Shouldn't get this since rows fetched is checked
				strData = _T("<NO_ROW>");
			else if (rgLength[nRow] == SQL_NULL_DATA)
				strData = _T("<NULL>");
			else
			{
				strData = &rgData[nRow * MAX_TEXT_LEN];
				strData.TrimLeft();strData.TrimRight();
			}

			// Set the string (if first column must add)
			if (nField == 0)
				m_listData.InsertItem(nRow, strData);
			else
			{
				m_listData.SetItem(nRow, nField, LVIF_TEXT,
					strData, -1, 0, 0, 0);
			}
		}
	}
}

void CDataDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDataDialog)
	DDX_Control(pDX, IDC_QUERY, m_query);
	DDX_Control(pDX, IDC_DATALIST, m_listData);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDataDialog, CDialog)
	//{{AFX_MSG_MAP(CDataDialog)
	ON_BN_CLICKED(IDC_FIRST, OnFirst)
	ON_BN_CLICKED(IDC_LAST, OnLast)
	ON_BN_CLICKED(IDC_NEXT, OnNext)
	ON_BN_CLICKED(IDC_PREV, OnPrev)
	ON_BN_CLICKED(IDC_ADD, OnAdd)
	ON_BN_CLICKED(IDC_MODIFY, OnModify)
	ON_BN_CLICKED(IDC_DELETE, OnDelete)
	ON_BN_CLICKED(IDC_QUERY, OnQuery)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_DATALIST, OnItemchangedDatalist)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDataDialog message handlers

void CDataDialog::OnFirst() 
{
	ASSERT(m_prs->IsOpen());

	m_prs->MoveFirst();

	FillData();

	// Disable the correct controls
	GetDlgItem(IDC_PREV)->EnableWindow(FALSE);
}

void CDataDialog::OnLast() 
{
	ASSERT(m_prs->IsOpen());

	m_prs->MoveLast();
	FillData();

	// Disable the correct controls
	GetDlgItem(IDC_NEXT)->EnableWindow(FALSE);
}

void CDataDialog::OnNext() 
{
	ASSERT(m_prs->IsOpen());

	m_prs->MoveNext();

	if (m_prs->IsEOF())
	{
		// Disable the correct controls
		GetDlgItem(IDC_NEXT)->EnableWindow(FALSE);

		CString strError;
		strError.LoadString(IDS_ERROR_EOF);
		MessageBox(strError,"Error",MB_OK|MB_ICONWARNING);
	}
	else
		FillData();
}

void CDataDialog::OnPrev() 
{
	ASSERT(m_prs->IsOpen());

	m_prs->MovePrev();

	if (m_prs->IsBOF())
	{
		// Disable the correct controls
		GetDlgItem(IDC_PREV)->EnableWindow(FALSE);

		CString strError;
		strError.LoadString(IDS_ERROR_BOF);
		MessageBox(strError,"Error",MB_OK|MB_ICONWARNING);
	}
	else
		FillData();
}

void CDataDialog::OnAdd() 
{
	// TODO: Add your control notification handler code here
	if(default_table == "mls_type")
	{
			db_edit1 mls_dialog;
			mls_dialog.n_name="media type name";
			mls_dialog.n_no="media type no";
			mls_dialog.n_header="Add type of media";
			mls_dialog.action_type=-1;
			mls_dialog.default_table="mls_type";
			mls_dialog.Mls_db=m_prs->m_pDatabase;
			while(mls_dialog.DoModal() == IDOK)
			{
					m_prs->Requery();
					FillData();
			}
	}
	else if(default_table=="mls_class")
	{
			db_edit1 mls_dialog;
			mls_dialog.n_name="title type name";
			mls_dialog.n_no="title type no";
			mls_dialog.n_header="Add type of  title";
			mls_dialog.action_type=-1;
			mls_dialog.default_table="mls_class";
			mls_dialog.Mls_db=m_prs->m_pDatabase;
			while(mls_dialog.DoModal() == IDOK)
			{
					m_prs->Requery();
					FillData();
			}
	}
	else if(default_table=="mls_title_view")
	{
			Cmls_title mls_dialog;
			mls_dialog.n_title_header="Add type of  title";
			mls_dialog.action_type=-1;
			mls_dialog.m_prs=m_prs;
			mls_dialog.n_type_name="no";
			mls_dialog.n_class_name="no";
			while(mls_dialog.DoModal() == IDOK)
			{
					m_prs->Requery();
					FillData();
			}
	}
	
}

void CDataDialog::OnModify() 
{
	// TODO: Add your control notification handler code here
	if(list_select==-1)
	{
			MessageBox("Please Select Item for modify","????",MB_OK|MB_ICONQUESTION);
			return;
	}
	if(default_table == "mls_type")
	{
			db_edit1 mls_dialog;
			mls_dialog.n_name="media type name";
			mls_dialog.n_no="media type no";
			mls_dialog.n_header="Modify type of media";
			mls_dialog.action_type=1;			//Do Modify
			mls_dialog.default_table="mls_type";
			mls_dialog.Mls_db=m_prs->m_pDatabase;
			mls_dialog.n_edit_no=m_listData.GetItemText(list_select,0);
			mls_dialog.n_edit_name=m_listData.GetItemText(list_select,1);
			mls_dialog.DoModal();
	}
	else if(default_table=="mls_class")
	{
			db_edit1 mls_dialog;
			mls_dialog.n_name="title type name";
			mls_dialog.n_no="title type no";
			mls_dialog.n_header="Modify type of  title";
			mls_dialog.action_type=1;			//Do Modify
			mls_dialog.default_table="mls_class";
			mls_dialog.Mls_db=m_prs->m_pDatabase;
			mls_dialog.n_edit_no=m_listData.GetItemText(list_select,0);
			mls_dialog.n_edit_name=m_listData.GetItemText(list_select,1);
			mls_dialog.DoModal();
	}
	else if(default_table=="mls_title_view")
	{
		Cmls_title mls_dialog;
		// Initial from List
		mls_dialog.n_title_key=m_listData.GetItemText(list_select,0);
		mls_dialog.n_title_name=m_listData.GetItemText(list_select,1);
		mls_dialog.n_author_name=m_listData.GetItemText(list_select,2);
		mls_dialog.n_title_long=m_listData.GetItemText(list_select,3);
		mls_dialog.n_title_keyword=m_listData.GetItemText(list_select,4);
		mls_dialog.n_exam_name=m_listData.GetItemText(list_select,5);
		mls_dialog.n_cover_name=m_listData.GetItemText(list_select,6);
		mls_dialog.n_type_name=m_listData.GetItemText(list_select,7);
		mls_dialog.n_class_name=m_listData.GetItemText(list_select,8);
		mls_dialog.n_description=m_listData.GetItemText(list_select,9);
		
		mls_dialog.n_title_header="Modify Title";
		mls_dialog.m_prs=m_prs;
		mls_dialog.action_type=1;
		mls_dialog.DoModal();
	}
	m_prs->Requery();
	FillData();
}

void CDataDialog::OnDelete() 
{
	// TODO: Add your control notification handler code here
	if(list_select==-1)
	{
			MessageBox("Please Select Item for delete","????",MB_OK|MB_ICONQUESTION);
			return;
	}
	if(MessageBox("You are removing. Are you sure ? ","!!!!",MB_YESNO|MB_ICONWARNING)==IDNO)
	{
		return;
	}
	if(default_table == "mls_type")
	{
		CString strQuery="DELETE FROM mls_type WHERE type_no=";
		strQuery+=m_listData.GetItemText(list_select,0);
		(m_prs->m_pDatabase)->ExecuteSQL(strQuery);
	}
	else if(default_table=="mls_class")
	{
		CString strQuery="DELETE FROM mls_class WHERE class_no=";
		strQuery+=m_listData.GetItemText(list_select,0);
		(m_prs->m_pDatabase)->ExecuteSQL(strQuery);
	}
	else if(default_table=="mls_title_view")
	{
		CString strQuery="DELETE FROM mls_title WHERE title_key='";
		strQuery+=m_listData.GetItemText(list_select,0);
		strQuery+="'";
		(m_prs->m_pDatabase)->ExecuteSQL(strQuery);
		CString temp;
	}
	m_prs->Requery();
	FillData();
	list_select=-1;
}

void CDataDialog::OnQuery() 
{
	CString oldSQL="Now SQL=\n";
	oldSQL+=m_prs->GetSQL();
//	MessageBox(oldSQL,"Query",MB_OK|MB_ICONINFORMATION);
	Cmls_title mls_dialog;
	mls_dialog.action_type=2;
	mls_dialog.n_title_header="Query New";
	mls_dialog.m_prs=m_prs;
	mls_dialog.n_type_name="no";
	mls_dialog.n_class_name="no";
	mls_dialog.DoModal();
	FillData();
}

void CDataDialog::OnItemchangedDatalist(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	list_select=pNMListView->iItem;
	*pResult = 0;
}
