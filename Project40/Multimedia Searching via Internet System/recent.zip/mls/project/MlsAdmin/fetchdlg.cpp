// fetchDlg.cpp : implementation file
//

// This is a part of the Microsoft Foundation Classes C++ library.
// Copyright (C) 1992-1997 Microsoft Corporation
// All rights reserved.
//
// This source code is only intended as a supplement to the
// Microsoft Foundation Classes Reference and related
// electronic documentation provided with the library.
// See these sources for detailed information regarding the
// Microsoft Foundation Classes product.

#include "stdafx.h"
#include "dbfetch.h"
#include "fetchDlg.h"
#include "datadlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDbfetchDlg dialog

CDbfetchDlg::~CDbfetchDlg()
{
	m_db.Close();
}
CDbfetchDlg::CDbfetchDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDbfetchDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDbfetchDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDI_MAINFRAME);
}

void CDbfetchDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDbfetchDlg)
	DDX_Control(pDX, IDC_TABLE_COMBO, m_cbTable);
	DDX_Control(pDX, ID_QUIT_SELECT, m_buttonQuit);
	DDX_Control(pDX, ID_GETDATA, m_buttonGetData);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CDbfetchDlg, CDialog)
	//{{AFX_MSG_MAP(CDbfetchDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDOK, OnOk)
	ON_BN_CLICKED(ID_QUIT_SELECT, OnQuitSelect)
	ON_BN_CLICKED(ID_GETDATA, OnGetData)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDbfetchDlg message handlers

BOOL CDbfetchDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	CString strAboutMenu;
	strAboutMenu.LoadString(IDS_ABOUTBOX);
	if (!strAboutMenu.IsEmpty())
	{
		pSysMenu->AppendMenu(MF_SEPARATOR);
		pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
	}

	// Set the icon for this dialog.  The framework does this automatically
	// when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	Getdatasource();
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CDbfetchDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
// to draw the icon.  For MFC applications using the document/view model,
// this is automatically done for you by the framework.

void CDbfetchDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
// the minimized window.
HCURSOR CDbfetchDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CDbfetchDlg::OnOk() 
{
	
}

void CDbfetchDlg::OnCancel() 
{
	
	CDialog::OnCancel();
}

void CDbfetchDlg::Getdatasource() 
{
	// Make sure the list box is empty
	m_cbTable.ResetContent();
	//AfxMessageBox("this is version b");

	// If already open, close it and reselect
	if (m_db.IsOpen())
		m_db.Close();
	if (!m_db.OpenEx("DSN=mlsdata;UID=mlsadmin;PWD=multimedia", CDatabase::noOdbcDialog))
	{
		MessageBox("�������ö�Դ��͡Ѻ DSN=mlsdata �� \n ��سҵ�Ǩ�ͺ ODBC","Error!",MB_OK|MB_ICONWARNING);
		GetDlgItem(IDC_TABLE_COMBO)->EnableWindow(FALSE);
		GetDlgItem(ID_GETDATA)->EnableWindow(FALSE);
		return;
	}

	// Get a list of the tables
	m_cbTable.AddString("��Դ�ͧ����");
	type_table="mls_type";
	m_cbTable.SetItemDataPtr(0,&type_table);
	m_cbTable.AddString("�������ͧ����ͧ");
	class_table="mls_class";
	m_cbTable.SetItemDataPtr(1,&class_table);
	m_cbTable.AddString("����ͧ");
	title_table="mls_title_view";
	m_cbTable.SetItemDataPtr(2,&title_table);
	m_cbTable.SetCurSel(0);
	// Make sure the controls are enabled
	GetDlgItem(IDC_TABLE_COMBO)->EnableWindow(TRUE);
	GetDlgItem(ID_GETDATA)->EnableWindow(TRUE);
}

void CDbfetchDlg::OnQuitSelect() 
{
	OnCancel();
}

void CDbfetchDlg::OnGetData() 
{
	CDynamicBulkSet rs(&m_db);
	CDataDialog dlgData;

	// Get the current table selected and validate
	int nCurSel = m_cbTable.GetCurSel();
	if (nCurSel == CB_ERR)
	{
		CString strError;
		strError.LoadString(IDS_ERROR_NOTABLE);
		MessageBox(strError,"MLS-Administrator",MB_OK | MB_ICONWARNING);
		return;
	}
	CString strSQL;
	switch(nCurSel)
	{
	case 0:strSQL="SELECT * FROM ";
				break;
	case 1:strSQL="SELECT * FROM ";
				break;
	case 2:	strSQL="SELECT * FROM ";
				break;
	}
	strSQL+=*(CString *) m_cbTable.GetItemDataPtr(nCurSel);
	dlgData.default_table = *(CString *) m_cbTable.GetItemDataPtr(nCurSel);
	// Open the recordset, create the dialog and hand it the recordset
	rs.Open(CRecordset::snapshot, strSQL,
		CRecordset::readOnly | CRecordset::useMultiRowFetch);
	dlgData.SetRecordset(&rs);
	dlgData.DoModal();

	// Make sure the CDynamicBulkSet is cleaned up properly
	rs.Close();
}
