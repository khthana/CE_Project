// mls_class.cpp : implementation file
//

#include "stdafx.h"
#include "dbfetch.h"
#include "mls_class.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// mls_class

IMPLEMENT_DYNAMIC(mls_class, CRecordset)

mls_class::mls_class(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(mls_class)
	m_class_no = 0;
	m_class_name = _T("");
	m_nFields = 2;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString mls_class::GetDefaultConnect()
{
	return _T("ODBC;DSN=mlsdata");
}

CString mls_class::GetDefaultSQL()
{
	return _T("[dbo].[mls_class]");
}

void mls_class::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(mls_class)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[class_no]"), m_class_no);
	RFX_Text(pFX, _T("[class_name]"), m_class_name);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// mls_class diagnostics

#ifdef _DEBUG
void mls_class::AssertValid() const
{
	CRecordset::AssertValid();
}

void mls_class::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
