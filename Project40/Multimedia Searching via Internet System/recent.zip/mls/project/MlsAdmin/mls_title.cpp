// mls_title.cpp : implementation file
//

#include "stdafx.h"
#include "dbfetch.h"
#include "mls_title.h"
#include "mls_class.h"
#include "mlstype.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Cmls_title dialog

void Cmls_title::sendftp()
{
	CInternetSession   Sess("MLSAdmin",1,INTERNET_OPEN_TYPE_DIRECT);
	CFtpConnection *FtptoMls;
	FtptoMls = Sess.GetFtpConnection(FTP_SERVER,"mlsadmin","multimedia",21);
	// For example File
	//MessageBox(" It will take a serveral minute  for put file to mls server",");
	if(f_exam_file.GetPathName()!="")
	{
		CString remote_file;
		m_title_key.GetWindowText(remote_file);remote_file.TrimLeft();remote_file.TrimRight();
		for(int k=0 ;k<remote_file.GetLength();k++) // Convert White space to under score
		{
			if(remote_file[k]==' ') 
				remote_file.SetAt(k,'_');
		}
		remote_file+=".";remote_file+=f_exam_file.GetFileExt();
		FtptoMls->SetCurrentDirectory("/mls/example");
		if((FtptoMls->PutFile(f_exam_file.GetPathName(),remote_file, FTP_TRANSFER_TYPE_BINARY))==0)
		{
			remote_file.Format("%ld", GetLastError());
			MessageBox(remote_file,"Error !!",MB_OK|MB_ICONWARNING);
			return ;
		}
	}
	if(f_cover_file.GetPathName()!="")
	{
		CString remote_file;
		m_title_key.GetWindowText(remote_file);remote_file.TrimLeft();remote_file.TrimRight();
		for(int k=0 ;k<remote_file.GetLength();k++) // Convert White space to under score
		{
			if(remote_file[k]==' ') 
				remote_file.SetAt(k,'_');
		}
		remote_file+=".";remote_file+=f_cover_file.GetFileExt();
		FtptoMls->SetCurrentDirectory("/mls/cover");
		if((FtptoMls->PutFile(f_cover_file.GetPathName(),remote_file, FTP_TRANSFER_TYPE_BINARY))==0)
		{
			remote_file.Format("%ld", GetLastError());
			MessageBox(remote_file,"Error !!",MB_OK|MB_ICONWARNING);
			return ;
		}
	}
	FtptoMls->Close();
	Sess.Close();
}

Cmls_title::Cmls_title(CWnd* pParent /*=NULL*/)
	: CDialog(Cmls_title::IDD, pParent),
	f_cover_file(TRUE,NULL,NULL,OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,"Picture (*.jpg;*.jpeg;*.gif)|*.jpg;*.jpeg;*.gif||"),
	f_exam_file(TRUE,NULL,NULL,OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,"Multimedia |*.mov;*.avi;*.wav;*.au|Picture|*.jpg;*.jpeg;*.gif|Movie (*.mov;*.avi)|*.mov;*.avi|Sound (*.wav;*.au)|*.wav;*.au||")
{
	//{{AFX_DATA_INIT(Cmls_title)
	//}}AFX_DATA_INIT
	n_author_name="";
	n_class_name="";
	n_title_header="";
	n_title_key="";
	n_title_long="";
	n_title_name="";
	n_title_keyword="";
	n_description="";
	n_exam_name="";
	n_cover_name="";
}


void Cmls_title::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(Cmls_title)
	DDX_Control(pDX, IDC_TITLE_KEYWORD, m_title_keyword);
	DDX_Control(pDX, IDC_BROWSE_EXAM, m_browse_exam);
	DDX_Control(pDX, IDC_BROWSE_COVER, m_browse_cover);
	DDX_Control(pDX, IDC_TYPE_NAME, m_type_name);
	DDX_Control(pDX, IDC_CLASS_NAME, m_class_name);
	DDX_Control(pDX, IDC_TITLE_NAME, m_title_name);
	DDX_Control(pDX, IDC_TITLE_LONG, m_title_long);
	DDX_Control(pDX, IDC_TITLE_KEY, m_title_key);
	DDX_Control(pDX, IDC_TITLE_HEADER, m_title_header);
	DDX_Control(pDX, IDC_EXAM_FILE, m_exam_file);
	DDX_Control(pDX, IDC_DESCRIPTION, m_description);
	DDX_Control(pDX, IDC_AUTHOR_NAME, m_author_name);
	DDX_Control(pDX, IDC_COVER_FILE, m_cover_file);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(Cmls_title, CDialog)
	//{{AFX_MSG_MAP(Cmls_title)
	ON_BN_CLICKED(IDC_BROWSE_COVER, OnBrowseCover)
	ON_BN_CLICKED(IDC_BROWSE_EXAM, OnBrowseExam)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Cmls_title message handlers

void Cmls_title::OnBrowseCover() 
{
	// TODO: Add your control notification handler code here
	if(f_cover_file.DoModal()==IDOK)
	{
			m_cover_file.SetWindowText(f_cover_file.GetPathName());
	}
}

void Cmls_title::OnBrowseExam() 
{
	// TODO: Add your control notification handler code here
	if(f_exam_file.DoModal()==IDOK)
	{
			m_exam_file.SetWindowText(f_exam_file.GetPathName());
	}
}

void Cmls_title::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	CDialog::OnCancel();
}

void Cmls_title::OnOK() 
{
	// TODO: Add extra validation here
	CString strSQL;
	switch(action_type)
	{
	case -1:{
		strSQL="INSERT mls_title(title_key,title_name,title_author,title_long,title_keyword,title_cover_name,title_exam_name,titleFKtype_name,titleFKclass_name,title_description) VALUES(";
		CString temp;
		// Title Key
		m_title_key.GetWindowText(temp);temp.TrimLeft();temp.TrimRight();
		strSQL+="'";strSQL+=temp;strSQL+="',";
		//Title Name
		m_title_name.GetWindowText(temp);temp.TrimLeft();temp.TrimRight();
		strSQL+="'";strSQL+=temp;strSQL+="',";
		//Title Author
		m_author_name.GetWindowText(temp);temp.TrimLeft();temp.TrimRight();
		strSQL+="'";strSQL+=temp;strSQL+="',";
		//Tile Long
		m_title_long.GetWindowText(temp);
		if (temp=="") temp="0"; // If  no long
		temp.TrimLeft();temp.TrimRight();
		strSQL+=temp;strSQL+=",";
		//Title keyword
		m_title_keyword.GetWindowText(temp);temp.TrimLeft();temp.TrimRight();
		strSQL+="'";strSQL+=temp;strSQL+="',";
		//Cover name
		if(f_cover_file.GetPathName()!="")
		{
			m_title_key.GetWindowText(temp);temp.TrimLeft();temp.TrimRight();
			for(int k=0 ;k<temp.GetLength();k++) // Convert White space to under score
			{
				if(temp.GetAt(k)==' ') 
					temp.SetAt(k,'_');
			}
			strSQL+="'";strSQL+=temp;strSQL+=".";strSQL+=f_cover_file.GetFileExt();strSQL+="',";
		}
		else
		{
					strSQL+="'(NULL)'";strSQL+=",";
		}
		//Example name
		if(f_exam_file.GetPathName()!="")
		{
			m_title_key.GetWindowText(temp);temp.TrimLeft();temp.TrimRight();
			for(int k=0 ;k<temp.GetLength();k++) // Convert White space to under score
			{
				if(temp.GetAt(k)==' ') 
					temp.SetAt(k,'_');
			}
			strSQL+="'";strSQL+=temp;strSQL+=".";strSQL+=f_exam_file.GetFileExt();strSQL+="',";
		}
		else
		{
			strSQL+="'(NULL)'";strSQL+=",";
		}
		//Type_name
		temp.Format("%ld",m_type_name.GetItemData(m_type_name.GetCurSel()));
		strSQL+=temp;strSQL+=",";
		//Class name
		temp.Format("%ld",m_class_name.GetItemData(m_class_name.GetCurSel()));
		strSQL+=temp;strSQL+=",";
		// Title Description
		m_description.GetWindowText(temp);temp.TrimLeft();temp.TrimRight();
		strSQL+="'";strSQL+=temp;strSQL+="')";
//		AfxMessageBox(strSQL);
		(m_prs->m_pDatabase)->BeginTrans();
		(m_prs->m_pDatabase)->ExecuteSQL(strSQL);
		(m_prs->m_pDatabase)->CommitTrans();
		if((f_cover_file.GetPathName()!="") || (f_exam_file.GetPathName()!=""))
				sendftp();
		break;
			}	
	case 1:{
						strSQL="UPDATE mls_title SET ";
						CString temp;
						// Title Name
						strSQL+="title_name=";
						m_title_name.GetWindowText(temp);temp.TrimLeft();temp.TrimRight();
						strSQL+="'";strSQL+=temp;strSQL+="',";
						//Title Author
						strSQL+="title_author=";
						m_author_name.GetWindowText(temp);temp.TrimLeft();temp.TrimRight();
						strSQL+="'";strSQL+=temp;strSQL+="',";
						//Tile Long
						strSQL+="title_long=";
						m_title_long.GetWindowText(temp);temp.TrimLeft();temp.TrimRight();
						strSQL+=temp;strSQL+=",";
						//Title Keyword
						strSQL+="title_keyword=";
						m_title_keyword.GetWindowText(temp);temp.TrimLeft();temp.TrimRight();
						strSQL+="'";strSQL+=temp;strSQL+="',";
						//Cover name
						if(f_cover_file.GetPathName()!="")
						{
								strSQL+="title_cover_name=";
								m_title_key.GetWindowText(temp);temp.TrimLeft();temp.TrimRight();
								for(int k=0 ;k<temp.GetLength();k++) // Convert White space to under score
								{
									if(temp.GetAt(k)==' ') 
									temp.SetAt(k,'_');
								}
								strSQL+="'";strSQL+=temp;strSQL+=".";strSQL+=f_cover_file.GetFileExt();strSQL+="',";
						}
			
						//Example name
						if(f_exam_file.GetPathName()!="")
						{
							strSQL+="title_exam_name=";
							m_title_key.GetWindowText(temp);temp.TrimLeft();temp.TrimRight();
								for(int k=0 ;k<temp.GetLength();k++) // Convert White space to under score
								{
									if(temp.GetAt(k)==' ') 
									temp.SetAt(k,'_');
								}
							strSQL+="'";strSQL+=temp;strSQL+=".";strSQL+=f_exam_file.GetFileExt();strSQL+="',";
						}
					//Type_name
					strSQL+="titleFKtype_name=";
					temp.Format("%ld",m_type_name.GetItemData(m_type_name.GetCurSel()));
					strSQL+=temp;strSQL+=",";
					//Class name
					strSQL+="titleFKclass_name=";
					temp.Format("%ld",m_class_name.GetItemData(m_class_name.GetCurSel()));
					strSQL+=temp;strSQL+=",";
					// Title Description
					strSQL+="title_description=";
					m_description.GetWindowText(temp);temp.TrimLeft();temp.TrimRight();
					strSQL+="'";strSQL+=temp;strSQL+="'";
					strSQL+=" WHERE";
					strSQL+=" title_key=";
					m_title_key.GetWindowText(temp);temp.TrimLeft();temp.TrimRight();
					strSQL+="'";strSQL+=temp;strSQL+="'";
//					AfxMessageBox(strSQL);
					(m_prs->m_pDatabase)->BeginTrans();
					(m_prs->m_pDatabase)->ExecuteSQL(strSQL);
					(m_prs->m_pDatabase)->CommitTrans();
					if((f_cover_file.GetPathName()!="") || (f_exam_file.GetPathName()!=""))
						sendftp();
					break;
				}
	case 2:
			{
				BOOL first=TRUE;

						strSQL="SELECT title_key,title_name,title_author,title_long,title_keyword,title_exam_name,title_cover_name,type_name,class_name,title_description  FROM  mls_title_view ";
						CString temp;

						m_title_key.GetWindowText(temp);temp.TrimLeft();temp.TrimRight();
						if(temp!="")
						{
							if(first) strSQL+=" WHERE ";
							strSQL+="title_key like ";
							strSQL+="'";strSQL+=temp;strSQL+="'";
							first=FALSE;
						}
						// Title Name
						m_title_name.GetWindowText(temp);temp.TrimLeft();temp.TrimRight();
						if(temp!="")
						{
							if(!first)
								strSQL+=" AND ";
							else
								strSQL+=" WHERE ";
							strSQL+="title_name LIKE ";
							strSQL+="'%",strSQL+=temp;strSQL+="%'";
							strSQL+=" AND ";
							strSQL+="title_name LIKE ";temp.MakeUpper();
							strSQL+="'%";strSQL+=temp;strSQL+="%'";
							strSQL+=" AND ";
							strSQL+="title_name LIKE ";temp.MakeLower();
							strSQL+="'%";strSQL+=temp;strSQL+="%'";
							first=FALSE;
						}
						//Title Author
						m_author_name.GetWindowText(temp);temp.TrimLeft();temp.TrimRight();
						if(temp!="")
						{
							if(!first)
								strSQL+=" AND ";
							else
								strSQL+=" WHERE ";
							strSQL+="title_author LIKE ";
							strSQL+="'%",strSQL+=temp;strSQL+="%'";
							strSQL+=" AND ";
							strSQL+="title_author LIKE ";temp.MakeUpper();
							strSQL+="'%";strSQL+=temp;strSQL+="%'";
							strSQL+=" AND ";
							strSQL+="title_author LIKE ";temp.MakeLower();
							strSQL+="'%";strSQL+=temp;strSQL+="%'";
							first=FALSE;
						}
						//Tile Long
						m_title_long.GetWindowText(temp);temp.TrimLeft();temp.TrimRight();
						if(temp!="")
						{
							if(!first)
								strSQL+=" AND ";
							else
								strSQL+=" WHERE ";
							strSQL+="title_long=";
							strSQL+=temp;
							first=FALSE;
						}
						//Title keyword
						m_title_keyword.GetWindowText(temp);temp.TrimLeft();temp.TrimRight();
						if(temp!="")
						{
							if(!first)
								strSQL+=" AND ";
							else
								strSQL+=" WHERE ";
							strSQL+="title_keyword LIKE ";
							strSQL+="'%",strSQL+=temp;strSQL+="%'";
							strSQL+=" AND ";
							strSQL+="title_keyword LIKE ";temp.MakeUpper();
							strSQL+="'%";strSQL+=temp;strSQL+="%'";
							strSQL+=" AND ";
							strSQL+="title_keyword LIKE ";temp.MakeLower();
							strSQL+="'%";strSQL+=temp;strSQL+="%'";
							first=FALSE;
					}
					//Type_name
					m_type_name.GetLBText(m_type_name.GetCurSel(),temp);
					if(temp!="%")
					{
						if(!first)
								strSQL+=" AND ";
						else
								strSQL+=" WHERE ";
						strSQL+="type_name='";
						strSQL+=temp;strSQL+="' ";
						first=FALSE;
					}
					//Class name
					m_class_name.GetLBText(m_class_name.GetCurSel(),temp);
					if(temp!="%")
					{
						if(!first)
								strSQL+=" AND ";
						else
								strSQL+=" WHERE ";
						strSQL+="class_name='";
						strSQL+=temp;strSQL+="' ";
						first=FALSE;
					}
					// Title Description
					m_description.GetWindowText(temp);temp.TrimLeft();temp.TrimRight();
					if(temp!="")
					{
						if(!first)
								strSQL+=" AND ";
						else
								strSQL+=" WHERE ";
						strSQL+="title_description like ";
						strSQL+="'";strSQL+=temp;strSQL+="'";
					}
					temp="New Query = \n";
					temp+=strSQL;
//					MessageBox(temp,"New Query",MB_OK | MB_ICONINFORMATION);
					if(m_prs->IsOpen())
					{
						m_prs->Close();
					}
					m_prs->Open(CRecordset::snapshot, strSQL,
											CRecordset::readOnly | CRecordset::useMultiRowFetch);
					//if((f_cover_file.GetPathName()!="") || (f_exam_file.GetPathName()!=""))
					//	sendftp();
					break;
			}
	}
	
	CDialog::OnOK();
}

BOOL Cmls_title::OnInitDialog() 
{
	CDialog::OnInitDialog();
	// Set Class and Type Combobox
		{
		mlstype Rset(m_prs->m_pDatabase);
		CString strSQL="mls_type";
		Rset.Open(CRecordset::snapshot, strSQL,
		CRecordset::readOnly);
		if(Rset.IsOpen())
		{
				int i=0;
				m_type_name.ResetContent();
				while(!Rset.IsEOF())
				{
					m_type_name.AddString(Rset.m_type_name);
					m_type_name.SetItemData(i,Rset.m_type_no);
					i++;
					Rset.MoveNext();
				}
				Rset.Close();
				if(action_type==2)
				{
					m_type_name.AddString("%");
					m_type_name.SetItemData(i,-1);
					m_type_name.SetCurSel(i);
				}
				else
				{
							m_type_name.SetCurSel(0);					// Set Default Selection
				}
		}
		}
		/////////////////////////////////
		{
		mls_class Rset(m_prs->m_pDatabase);
		CString strSQL="mls_class";
		Rset.Open(CRecordset::snapshot, strSQL,
		CRecordset::readOnly);
		if(Rset.IsOpen())
		{
				int i=0;
				m_class_name.ResetContent();
				while(!Rset.IsEOF())
				{
					m_class_name.AddString(Rset.m_class_name);
					m_class_name.SetItemData(i,Rset.m_class_no);
					i++;
					Rset.MoveNext();
				}
				Rset.Close();
				if(action_type==2)
				{
					m_class_name.AddString("%");
					m_class_name.SetItemData(i,-1);
					m_class_name.SetCurSel(i);
				}
				else
				{
							m_class_name.SetCurSel(0);					// Set Default Selection
				}
		}
		}
		/////////////// End Initial Combobox


	// initial 
	m_author_name.SetWindowText(n_author_name);
	m_title_header.SetWindowText(n_title_header);
	m_title_key.SetWindowText(n_title_key);
	m_title_long.SetWindowText(n_title_long);
	m_title_keyword.SetWindowText(n_title_keyword);
	m_title_name.SetWindowText(n_title_name);
	m_exam_file.SetWindowText(n_exam_name);
	m_cover_file.SetWindowText(n_cover_name);
	if(n_type_name!="no")
		m_type_name.SetCurSel(m_type_name.FindString(0,n_type_name));
	if(n_class_name!="no")
		m_class_name.SetCurSel(m_class_name.FindString(0,n_class_name));
	m_description.SetWindowText(n_description);
	switch(action_type)
	{
	case 1:
//			m_title_key.EnableWindow(FALSE);
			break;
	case 2:
			m_browse_cover.EnableWindow(FALSE);
			m_browse_exam.EnableWindow(FALSE);
			break;
	}
	// End initial
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
