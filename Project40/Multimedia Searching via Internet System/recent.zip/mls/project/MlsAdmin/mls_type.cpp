// mls_type.cpp : implementation file
//

#include "stdafx.h"
#include "dbfetch.h"
#include "mls_type.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// mls_type

IMPLEMENT_DYNAMIC(mls_type, CRecordset)

mls_type::mls_type(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(mls_type)
	m_title_key = _T("");
	m_title_name = _T("");
	m_title_author = _T("");
	m_title_long = 0;
	m_title_cover_name = _T("");
	m_title_exam_name = _T("");
	m_titleFKtype_name = 0;
	m_titleFKclass_name = 0;
	m_title_description = _T("");
	m_nFields = 9;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString mls_type::GetDefaultConnect()
{
	return _T("ODBC;DSN=mlsdata");
}

CString mls_type::GetDefaultSQL()
{
	return _T("[dbo].[mls_title]");
}

void mls_type::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(mls_type)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[title_key]"), m_title_key);
	RFX_Text(pFX, _T("[title_name]"), m_title_name);
	RFX_Text(pFX, _T("[title_author]"), m_title_author);
	RFX_Long(pFX, _T("[title_long]"), m_title_long);
	RFX_Text(pFX, _T("[title_cover_name]"), m_title_cover_name);
	RFX_Text(pFX, _T("[title_exam_name]"), m_title_exam_name);
	RFX_Long(pFX, _T("[titleFKtype_name]"), m_titleFKtype_name);
	RFX_Long(pFX, _T("[titleFKclass_name]"), m_titleFKclass_name);
	RFX_Text(pFX, _T("[title_description]"), m_title_description);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// mls_type diagnostics

#ifdef _DEBUG
void mls_type::AssertValid() const
{
	CRecordset::AssertValid();
}

void mls_type::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
