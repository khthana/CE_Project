// mlstype.cpp : implementation file
//

#include "stdafx.h"
#include "dbfetch.h"
#include "mlstype.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// mlstype

IMPLEMENT_DYNAMIC(mlstype, CRecordset)

mlstype::mlstype(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(mlstype)
	m_type_no = 0;
	m_type_name = _T("");
	m_nFields = 2;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString mlstype::GetDefaultConnect()
{
	return _T("ODBC;DSN=mlsdata");
}

CString mlstype::GetDefaultSQL()
{
	return _T("[dbo].[mls_type]");
}

void mlstype::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(mlstype)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[type_no]"), m_type_no);
	RFX_Text(pFX, _T("[type_name]"), m_type_name);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// mlstype diagnostics

#ifdef _DEBUG
void mlstype::AssertValid() const
{
	CRecordset::AssertValid();
}

void mlstype::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
