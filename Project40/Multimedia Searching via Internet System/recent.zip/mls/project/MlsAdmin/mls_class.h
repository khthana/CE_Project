#if !defined(AFX_MLS_CLASS_H__831F2AD4_DF82_11D1_ABD3_0040052F5C5F__INCLUDED_)
#define AFX_MLS_CLASS_H__831F2AD4_DF82_11D1_ABD3_0040052F5C5F__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// mls_class.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// mls_class recordset

class mls_class : public CRecordset
{
public:
	mls_class(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(mls_class)

// Field/Param Data
	//{{AFX_FIELD(mls_class, CRecordset)
	long	m_class_no;
	CString	m_class_name;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(mls_class)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MLS_CLASS_H__831F2AD4_DF82_11D1_ABD3_0040052F5C5F__INCLUDED_)
