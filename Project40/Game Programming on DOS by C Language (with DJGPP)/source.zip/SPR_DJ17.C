#include <stdlib.h>
#include <stdio.h>
#include <dir.h>
#include <pc.h>
#include <file.h>
#include <conio.h>
#include <dos.h>

#include "allegro.h"
#include "sprite.h"
#include "AI.h"
#include "random.h"
#include "block.h"
#include "err.h"
#include "knight.h"
#include "e1.h"
#include "e2.h"
#include "e3.h"
#include "rameng.h"
#include "ball.h"
#include "big.h"
#include "slime.h"
#include "sh_img.h"
#include "collide.h"
#include "load_fin.h"


#define MAX_SPEED 8
#define MAX_SPRITE  25
#define MAX_BLOCK 37
#define BYTES_PER_PAGE 285
#define HEADER_LENGTH 1+20

//BITMAP *E1_frame0,*E1_frame1,*E1_frame2,*E1_frame3,*E1_frame4,*E1_frame5;
//BITMAP *E2_frame0,*E2_frame1,*E2_frame2;
//BITMAP *block_image;
/*
BITMAP *E3_frame0,*E3_frame1,*E3_frame2;
BITMAP *E4_frame0,*E4_frame1,*E4_frame2;
BITMAP *E5_frame0,*E5_frame1,*E5_frame2;
*/
BITMAP *output;

//PALLETE the_pallete0,the_pallete1,the_pallete2;
//PALLETE the_pallete3,the_pallete4,the_pallete5;
PALLETE pallete_bck;
PALLETE pallete_bl;
//sprite T_sprite1/*,T_sprite2,T_sprite3,T_sprite4,T_sprite5,T_sprite6*/,T_sprite7;
sprite list[MAX_SPRITE];
block list_block[MAX_BLOCK];
//block block1,block2;


int Alive_Sprite[MAX_SPRITE];
int Alive_Block[MAX_BLOCK];
/* Place to store set_gfx_mode () output. -1 means error */
int err_vmode;
/* A boolean - if true, skip to next part */
int next;
/* for detail of graphic card , width_screen , height_screen*/
int c,w,h;
/* Used in file_exists routine   */
int *file_attr;
int wait;
int on_middle_screen,amount_page;
char stage_name[20];
//int bef_index;            //use in can's part for describe current left edge
			  //and right edge of screen compare with stage
int back_ground_ptr;      //use in can's part for detect left edge screen
int check,base;
//BITMAP* h_pic_t;

//BITMAP *a_pic,*b_pic;
PALLETE pal_im;

  /*---------------------------------------------------------------------*/
  void Prepare_All_Image(void)
  {  if ( Check_Not_Found_KN() == TRUE )
     {  printf("some file not found KN. Exiting");
	exit(0);
     }

     if ( Check_Not_Found_E1() == TRUE )
     {  printf("some file not found E1. Exiting");
	exit(0);
     }

     if ( Check_Not_Found_E2() == TRUE )
     {  printf("some file not found E2. Exiting");
	exit(0);
     }

     if ( Check_Not_Found_E3() == TRUE )
     {  printf("some file not found E3. Exiting");
	exit(0);
     }

     if ( Check_Not_Found_rameng() == TRUE )
     {  printf("some file not found rameng. Exiting");
	exit(0);
     }

     if ( Check_Not_Found_ball() == TRUE )
     {  printf("some file not found ball. Exiting");
	exit(0);
     }

     if ( Check_Not_Found_big() == TRUE )
     {  printf("some file not found big richard. Exiting");
	exit(0);
     }

     if ( Check_Not_Found_slime() == TRUE )
     {  printf("some file not found slime. Exiting");
	exit(0);
     }

     if ( Check_Not_Found_Other() == TRUE )
     {  printf("some file not found Other. Exiting");
	exit(0);
     }

     Prepare_KN();
     Prepare_E1();
     Prepare_E2();
     Prepare_E3();
     Prepare_rameng();
     Prepare_ball();
     Prepare_big();
     Prepare_slime();
     Prepare_Other();

//     a_pic = load_bitmap("//s7014278//test_im//kncs.pcx",pal_im);
//     b_pic = load_bitmap("//s7014278//test_im//slash1_r.pcx",pal_im);
//     c_pic = load_bitmap("//s7014278//test_im//kc0_r.pcx",pal_im);
//     d_pic = load_bitmap("//s7014278//test_im//sl0_r.pcx",pal_im);
//     e_pic = load_bitmap("//s7014278//test_im//w_r0.pcx",pal_im);
//     f_pic = load_bitmap("//s7014278//test_im//fire.pcx",pal_im);
//     g_pic = load_bitmap("//s7014278//test_im//kc03.pcx",pal_im);
//     i_pic = load_bitmap("//s7014278//test_im//kjc02.pcx",pal_im);




//     h_pic_t = load_bitmap("//s7014278//h_b.pcx",pallete_bl);
//     block_image  =  load_bitmap("//s7014255//p.pcx",pallete_bl);
  }  //end Prepare_All_Image()

/*--------------------------------------------------------------------------*/

  void Chk_Colide_All_Screen(void)
  {  char loop1,loop2,loop_block;
     char player,enemy;
//     int collide_bl;
     int x_pix1,y_pix1,x_pix2,y_pix2;

//     collide_bl = FALSE;
     for (loop1=1; loop1<=(MAX_SPRITE-1); loop1++)
     {  list[loop1].collide = FALSE;
	list[loop1].wounded = FALSE;
     }

     base = 0;
     check = 0;

     for (loop1=1; loop1<=(MAX_SPRITE-1); loop1++)
     {  if ( (Alive_Sprite[loop1] == TRUE) && (list[loop1].step_action >= 0)
	     && (list[loop1].dat.shield == 0) && (list[loop1].dat.hp != 0)
	   )
	{  for (loop2=loop1+1; loop2<=(MAX_SPRITE-1); loop2++)
	   {  if ( (Alive_Sprite[loop2] == TRUE) && (list[loop2].step_action >= 0)
		   && (list[loop2].dat.shield == 0) && (list[loop2].dat.hp != 0)
		 )
	      {  if ( Chk_Colide(&list[loop1],&list[loop2]) == TRUE)
		 {  base = 15;   //use for bounding collision text showing

		    if (Check_Case_Over(&list[loop1],&list[loop2],loop1,loop2) == FALSE)
		    {  Set_Smooth_Collide_Pix2(&list[loop1],&list[loop2],x_pix1,y_pix1,x_pix2,y_pix2);
		    }
		    else
		    {  //can use Chk_Pixel_Collide() when allow other sprite
		       //be over
		       if ( Chk_Pixel_Collide(&list[loop1],&list[loop2],&x_pix1,&y_pix1,&x_pix2,&y_pix2) == TRUE )
		       {  check = 15;  //use for pixel collision text showing

			  if ( (list[loop1].name == P) || (list[loop2].name == P) )
			  {  if (list[loop1].name == P)
			     {  player = loop1;
				enemy  = loop2;
			     }
			     else //name of loop2 is P
			     {  player = loop2;
				enemy  = loop1;
			     }
			     if ( //(list[player].dat.shield == 0) &&
				  //(list[enemy].dat.shield == 0) &&
				  (list[player].dat.hp > 0) &&
				  (list[enemy].name != KN_sl) )
			     { Set_Wound_Jump_Step(&list[player],&list[enemy]);
			       //loop1 is player character
			       list[player].wounded = TRUE;
			       Modify_Player_Data(&list[player],&list[enemy]);
			       if (list[player].dat.hp == 0)
			       {  list[player].what_action = 102;//dead
				  list[player].dat.shield = 0;
			       }
			     }
			  }
			  else
			  {  if ( //(list[loop2].dat.shield == 0) &&
				  (list[loop2].dat.hp > 0) &&
				  ((list[loop1].name == KN_sl) ||
				   (list[loop1].name == KN_f))
				)
			     {  list[loop2].dat.shield = 25;
				list[loop2].wounded = TRUE;
				list[loop2].index_attack = loop1;

				list[loop2].dat.hp = 0;

				list[loop1].collide = TRUE;
//				if (list[3].x_on_map < 0)
//      {
//	 allegro_exit(0);
//	 List_Check(loop2,-1,&list[loop2]);
//	 exit(1);
//      }

			  }
			     else
			     {  if ( //(list[loop1].dat.shield == 0) &&
				     (list[loop1].dat.hp > 0) &&
				     ((list[loop2].name == KN_sl) ||
				      (list[loop2].name == KN_f))
				   )
				{  list[loop1].dat.shield = 25;
				   list[loop1].wounded = TRUE;
				   list[loop1].index_attack = loop2;

				   list[loop1].dat.hp = 0;

				   list[loop2].collide = TRUE;
//					 allegro_exit(0);
//	 List_Check(loop1,-1,&list[loop1]);
//	 exit(1);
				}
				else
				{  Set_Smooth_Collide_Pix2(&list[loop1],&list[loop2],x_pix1,y_pix1,x_pix2,y_pix2);
				}
			     }
			  }
		       }
		    }
		 }
		 else
		 {  Clear_Case_Over(&list[loop1],&list[loop2],loop1,loop2);
//		    list[loop1].wounded = FALSE;
		 }
	      }
	   }
	}

	for (loop_block=1; loop_block<=MAX_BLOCK; loop_block++)
	{  if (Alive_Block[loop_block] == TRUE)
	   {  if (Chk_Colide_With_Block(&list[loop1],&list_block[loop_block]) == TRUE)
	      {
//		if ( (list[loop1].what_action == 7) && (list[loop1].step_action == 5) )
//		 {  allegro_exit();
//		    printf("good,step:%d,what:%d",list[loop1].step_action,list[loop1].what_action);
//		    List_Check(1,-1,&list[loop1]);
//		    printf("\n");
//		    Block_Check(loop_block,Alive_Block[loop_block],&list_block[loop_block]);
//		    exit(1);
//		 }

		 //Set_Smooth_Pix_Collide_With_Block(&list[loop1],&list_block[loop_block]);
		 Set_Smooth_Collide_B_Block(&list[loop1],&list_block[loop_block]);
	      }
	   }
	}
     }


  } // end Chk_Colide_All_Screen()

  /*----------------------------------------------------------------------*/

  void Chk_Keyboard(sprite_ptr T_sprite)
  /* auto detect out of screen */
  {  char free_index;

     if (key[KEY_H] == TRUE)
     {  T_sprite->dat.hp = 15;  //use in test (recover hp)
     }

     if (T_sprite->in_action == FALSE)
     {  if ( key[KEY_RIGHT] == TRUE )
	{  if (T_sprite->x_vel < MAX_SPEED)
	   { if (T_sprite->x_vel == 4)
	     {  T_sprite->x_vel = 8;  T_sprite->y_vel = 0;  }
	     else
	     {  T_sprite->x_vel += 2;  T_sprite->y_vel = 0; }
	   }
	}

	if ( key[KEY_LEFT] == TRUE )
	{  if (T_sprite->x_vel > -MAX_SPEED)
	   { if (T_sprite->x_vel == -4)
	     {  T_sprite->x_vel = -8;  T_sprite->y_vel = 0;  }
	     else
	     {  T_sprite->x_vel -= 2;  T_sprite->y_vel = 0;  }
	   }
	}

	if ( (key[KEY_UP] == TRUE) && (T_sprite->gravity_on == FALSE) )
	{  if (T_sprite->y_vel > -MAX_SPEED)
	   { if (T_sprite->y_vel == -4)
	     {  T_sprite->y_vel = -8;  T_sprite->x_vel = 0;  }
	     else
	     {  T_sprite->y_vel -= 2;  T_sprite->x_vel = 0;  }
	   }
	}


	if ( (key[KEY_DOWN] == TRUE) && (T_sprite->gravity_on == FALSE) )
	{  if (T_sprite->y_vel < MAX_SPEED)
	   { if (T_sprite->y_vel == 4)
	     {  T_sprite->y_vel = 8; T_sprite->x_vel = 0;  }
	     else
	     {  T_sprite->y_vel += 2;  T_sprite->x_vel = 0;  }
	   }
	}

	if ( key[KEY_SPACE] == TRUE )
	{  Set_Jump_Step(T_sprite);  //jump what_action = 1 and special jump
				     //what_action = 3
	}

	if (( key[KEY_CONTROL] == TRUE ) && (T_sprite->have_shot == FALSE))
	{  free_index = Search_Free_Index();
	   if (free_index != 0)
	   {  Set_KN_Shot_Step(T_sprite);   //shot what_action = 2
	      Alive_Sprite[free_index] = TRUE;
	      T_sprite->index_child = free_index;
	      list[free_index].index_parent = T_sprite->index_list;
	      if (T_sprite->direction == RIGHT)
	      {  Init_Sprite_KN_f(free_index,&list[free_index],0,T_sprite->y+T_sprite->T_dy,0,T_sprite->y_on_map+T_sprite->T_dy);

		 list[free_index].x = T_sprite->x+T_sprite->T_w - list[free_index].T_dx;
		 list[free_index].x_on_map = T_sprite->x_on_map+T_sprite->T_w - list[free_index].T_dx;
		 list[free_index].x_vel = 8;

	      }
	      else
	      {  Init_Sprite_KN_f(free_index,&list[free_index],0,T_sprite->y+T_sprite->T_dy,0,T_sprite->y_on_map+T_sprite->T_dy);
		 list[free_index].x = T_sprite->x+T_sprite->T_dx - list[free_index].T_w;
		 list[free_index].x_on_map = T_sprite->x_on_map+T_sprite->T_dx - list[free_index].T_w;
		 list[free_index].x_vel = -8;
//		 list[free_index].cur_frame = 0;
	      }
	   //   wait = 4;
	      T_sprite->index_child = free_index;
	      list[free_index].index_parent = T_sprite->index_list;
	      list[free_index].name = KN_f;
	   }
	   else
	   {  Not_Enough();
	   }

	}  //end shot step

//	if ( key[KEY_D] == TRUE )
//	{  Dead_Step(T_sprite);
//	}

//	if ( key[KEY_S] == TRUE )
//	{  Rameng_Supersplash_Step(T_sprite);
//	}
//	fflush(stdout);
     }  //end if not in_action

     if ( (key[KEY_A] == TRUE) && (T_sprite->have_shot == FALSE) &&
	  ( (T_sprite->in_action == FALSE) ||
	    ( (T_sprite->in_action == TRUE) &&
	      ((T_sprite->what_action == 1) || (T_sprite->what_action == 4))
	    )
	  )
	)
     /* use this action only not in other action or in jump or in falling */
     {  Set_Slash_Step(T_sprite);       // what_action = 99,100,101 chop

	free_index = Search_Free_Index();
	if (free_index != 0)
	{  Alive_Sprite[free_index] = TRUE;
	   T_sprite->index_child = free_index;
	   list[free_index].index_parent = T_sprite->index_list;
//	   list[free_index].step_action = -3;
//	   list[free_index].in_action = TRUE;
	   if (T_sprite->direction == RIGHT)
	   {  Init_Sprite_KN_sl(free_index,&list[free_index],T_sprite->x,T_sprite->y,T_sprite->x_on_map,T_sprite->y_on_map);
	      list[free_index].cur_frame = 0;
	      list[free_index].direction = RIGHT;
	   }
	   else
	   {  Init_Sprite_KN_sl(free_index,&list[free_index],T_sprite->x,T_sprite->y,T_sprite->x_on_map,T_sprite->y_on_map);
	      list[free_index].cur_frame = 1;
	      Set_Truth_Dim(&list[free_index]);
	      list[free_index].PT_h  = list[free_index].T_h;
	      list[free_index].PT_w  = list[free_index].T_w;
	      list[free_index].PT_dx = list[free_index].T_dx;
	      list[free_index].PT_dy = list[free_index].T_dy;

	      list[free_index].direction = LEFT;
	   }
	}
	else
	{  Not_Enough();
	}

     } //end slash step

  }  //end Chk_Keyboard()

  /*---------------------------------------------------------------------*/

  int Search_Free_Index(void)
  {  int loop_s;
     loop_s = 2;
     while (loop_s<=(MAX_SPRITE-1))
     {  if (Alive_Sprite[loop_s] == FALSE)
	{  return loop_s;
	}
	loop_s++;
     }
     return 0;
  }  //end Search_Free_Index()

  /*--------------------------------------------------------------------*/

  int Search_Free_Index_Block(void)
  {  int loop;
     loop = 1;
     while (loop<=(MAX_BLOCK-1))
     {  if (Alive_Block[loop] == FALSE)
	{  return loop;
	}
	loop++;
     }
     return 0;
  }  //end Search_Free_Index_BLOCK()

  /*--------------------------------------------------------------------*/

  void Relse_Sprite(int index)
  {  Relse_Jump_Step(&list[index]);
     list[index].x_on_map = 0 - list[index].w -1;
     Alive_Sprite[index] = FALSE;
     free(list[index].frame);
  }  //end Relse_Sprite()

  /*--------------------------------------------------------------------*/

  void Load_One_Page(FILE *f,int what_page)
  {  int type_rd,/*temp,*/loop;
     char temp;
     if ( (what_page >= 0) && (what_page <= (amount_page-1)) )
     //page start with 0
     {  fseek(f,((BYTES_PER_PAGE*what_page)+HEADER_LENGTH),SEEK_SET);
	getc(f);   //for start page
	do
	{  type_rd = getc(f);
	   if (type_rd == BLOCK)
	   {  temp = Search_Free_Index_Block();
	      if (temp != 0)
	      {  Prepare_Block(&list_block[temp],f,list[1].x_on_map,list[1].x);
		 Alive_Block[temp]  = TRUE;
	      }
	   }
	   else
	   {  if (type_rd == SPRITE)
	      {  temp = Search_Free_Index();
		 if (temp != 0)
		 {  Prepare_Sprite(temp,&list[temp],f,list[1].x_on_map,list[1].x);
		    /*---This loop for detect case there are more than one
			 sprite on stage , method check that no have two
			 sprite that have same x_start and y_start---*/
		    loop = 2;
		    while (loop <= (MAX_SPRITE-1))
		    {  if (Alive_Sprite[loop] == TRUE)
		       {  if ( (list[loop].x_start == list[temp].x_start) &&
			       (list[loop].y_start == list[temp].y_start) )
			  {  Alive_Sprite[temp] = FALSE;
			     list[temp].x_on_map = 0 - list[temp].w -1;
			     break;
			  }
		       }
		       loop++;
		    }
		    if (loop > (MAX_SPRITE-1))
		    {  Alive_Sprite[temp] = TRUE;
		    }

		    /*----------FOR TEST--------------*/
		    list[temp].dat.hp = 1;
		    /*--------------------------------*/

		 }  //end case found free index
	      }
	   }
	}  while ( (!feof(f)) && (type_rd != EOP) );  //(not end of page)
     } //end if what_page is not in range 0 - amount_page
  }  //end Load_One_Page()

  /*--------------------------------------------------------------------*/

  void Recycle_List(int now_page)
  {  int loop;
     /* name attribute of list[] that have not used is 0 and
	size (w , h) of list_block[] that have not used is 0 ,
	this function will work with only list[] and list_block[] that
	have used */
     for (loop=1; loop<=(MAX_SPRITE-1); loop++)
     {  /* first page is 0 */
	if ( ((list[loop].x_on_map + list[loop].w) >= (SCREEN_W * (now_page-1))) &&
	     (list[loop].x_on_map <= (SCREEN_W * (now_page+2))) &&
	     (list[loop].y_on_map <= SCREEN_H) &&
	     ((list[loop].y_on_map + list[loop].h) >= 0) &&
	     ((list[loop].x_on_map + list[loop].w) >= 0) &&
	     (list[loop].x_on_map <= (amount_page * SCREEN_W)) //&&
	     //((list[loop].dat.hp != 0) || (list[loop].step_action != 0) ||
	      //(list[loop].name != P)
	     //)
	   )
	{  if ( ( (list[loop].name == F) || (list[loop].name == KN_sl) ||
		  (list[loop].name == KN_f) || (list[loop].name == F_BALL1) ||
		  (list[loop].name == F_BALL2) || (list[loop].name == F_RAMENG)
		  //any weapon , bullet
		)
		&&
		( ((list[loop].x + list[loop].w) < 0) || (list[loop].x > SCREEN_W) ||
		  (list[loop].collide != FALSE) ||
		  // if parent wounded , child that wait for showing
		  // (step_action<0) is released
		  ((list[loop].step_action < 0) && (list[list[loop].index_parent].wounded == TRUE))
		)
	      )
	   {  Relse_Sprite(loop);
		//(list[loop].collide == BLK_LEFT) || (list[loop].collide == BLK_RIGHT) ||
		//(list[loop].collide == BLK_UPPER)   || (list[loop].collide == BLK_UNDER)
	   }
	   else
	   {  if ( ( (list[loop].dat.hp == 0) && (list[loop].step_action == 0) &&
		     (list[loop].in_action == TRUE) &&
		     (list[loop].what_action == 6)
		   ) ||
		   (Alive_Sprite[loop] == FALSE)
		 )
	      //dead & end delay dead showing
	      {  Relse_Sprite(loop);
	      }
	      else
	      {  Alive_Sprite[loop] = TRUE;
	      }
	   }
	}
	else
	{  Relse_Sprite(loop);
	}
     }

     for (loop=1; loop<=(MAX_BLOCK-1); loop++)
     {  if ( ((list_block[loop].x_on_map + list_block[loop].w) >= (SCREEN_W * (now_page-1))) &&
	     (list_block[loop].x_on_map <= (SCREEN_W * (now_page+2))) &&
	     (list_block[loop].y_on_map <= SCREEN_H) &&
	     ((list_block[loop].y_on_map + list_block[loop].h) >= 0) &&
	     (list_block[loop].w != 0) &&
	     (list_block[loop].h != 0) &&
	     ((list_block[loop].x_on_map + list_block[loop].w) >= 0) &&
	     (list_block[loop].x_on_map <= (amount_page * SCREEN_W)) )
	{  Alive_Block[loop] = TRUE; }
	else
	{  Alive_Block[loop] = FALSE; }
     }
  }  //end Recycle_List()

  /*--------------------------------------------------------------------*/

  int Now_On_Floor(sprite_ptr T_sprite)
  {  int loop_block;

     for (loop_block=1; loop_block<=MAX_BLOCK; loop_block++)
     {  if ( (((T_sprite->y_on_map+T_sprite->T_dy + T_sprite->T_h-T_sprite->T_dy + 1) == list_block[loop_block].y_on_map) &&
	     (((T_sprite->x_on_map+T_sprite->T_dx + T_sprite->T_w-T_sprite->T_dx /*- 1*/) >= list_block[loop_block].x_on_map) &&
	     ((T_sprite->x_on_map+T_sprite->T_dx /*- 1*/ ) <= (list_block[loop_block].x_on_map + list_block[loop_block].w))))
	     || (((T_sprite->y_on_map + T_sprite->T_h) == SCREEN_H) && (T_sprite->d_scr == TRUE))
	   )
	{  T_sprite->on_floor = TRUE;
	   return TRUE;
	}
	else
	T_sprite->on_floor = FALSE;
     }
     return FALSE;
  }  //end Now_On_Floor();

  /*---------------------------------------------------------------------*/

  void Detect_Edge(sprite_ptr T_sprite)
  {  if (T_sprite->d_scr == TRUE)
     {  /* out screen at left */
//	if ( (T_sprite->x < 0) && (T_sprite->x_vel <= 0) )
	if ( (T_sprite->x+T_sprite->T_dx < 0) && (T_sprite->x_vel <= 0) )
	{  T_sprite->x = -T_sprite->T_dx;//T_sprite->x = 0;
	   T_sprite->x_on_map = -T_sprite->T_dx;//T_sprite->x_on_map = 0;
	   T_sprite->collide = BLK_LEFT;
	}



	/* out screen at right */
//	if ( ((T_sprite->x + T_sprite->w) > SCREEN_W) && (T_sprite->x_vel >= 0) )
	if ( ((T_sprite->x + T_sprite->T_w) > SCREEN_W) && (T_sprite->x_vel >= 0) )
	{  T_sprite->x = SCREEN_W - T_sprite->T_w;//T_sprite->x = SCREEN_W - T_sprite->w ;
	   /* now determine stage have 320 pixel length */
	   T_sprite->x_on_map = (amount_page*SCREEN_W) - T_sprite->T_w;//T_sprite->w;
	   //T_sprite->x_vel = 0;
	   T_sprite->collide = BLK_RIGHT;
	}
	/* out screen at upper */
	if ( (T_sprite->y < 0) && (T_sprite->y_vel <= 0) )
	{  T_sprite->y = 0;
	   T_sprite->y_on_map = 0;
	}
	/* out screen at down */
	if ( ((T_sprite->y + T_sprite->T_h) > SCREEN_H) && (T_sprite->y_vel >= 0) )
	{  T_sprite->y = SCREEN_H - (T_sprite->T_h-T_sprite->T_dy) - T_sprite->T_dy;
	   T_sprite->y_on_map = SCREEN_H - (T_sprite->T_h-T_sprite->T_dy) - T_sprite->T_dy;
	}
     }
  }  //end Detect_Edge()

  /*----------------------------------------------------------------------*/

  void Show_Sprite(sprite_ptr T_sprite)
  {  ldiv_t temp_div;
     temp_div = ldiv(T_sprite->dat.shield,2);
     if ( (temp_div.rem == 0) && (T_sprite->step_action >= 0) )
     {
	blit (output,T_sprite->background,T_sprite->x,T_sprite->y,0,0,T_sprite->w,T_sprite->h);
	transparent_bit_blt(T_sprite->frame[T_sprite->cur_frame],output,T_sprite->x,T_sprite->y);
     }
  }  // end Show_Sprite()

  /*--------------------------------------------------------------------*/

  int Scroll(int x1_on_map,int w,int bef_index)
  {    bef_index = x1_on_map - (((SCREEN_W - w)/2)-1);
       if (bef_index < 0)
       {  bef_index = 0;
       }
       if (x1_on_map > ((((amount_page-1)*SCREEN_W) + ((SCREEN_W - w)/2)))-1)
       {  bef_index = (amount_page-1)*SCREEN_W;
       }
       return bef_index;
  }  // end scroll()

  /*--------------------------------------------------------------------*/

  int Prepare_Next_Sprite(sprite_ptr T_sprite,int number)
  {  int on_screen;

     /* for this object */
     if ( (T_sprite->x <= SCREEN_W) && (T_sprite->y <= SCREEN_H) &&
	((T_sprite->x + T_sprite->w) >= 0) && ((T_sprite->y + T_sprite->h) >= 0) )
     {  blit (T_sprite->background,output,0,0,T_sprite->x,T_sprite->y,T_sprite->w,T_sprite->h);
	on_screen = TRUE;
     }  //end if of itself
     else
     {  on_screen = FALSE;
     }

     /*----------------------------------------------*/

     if (T_sprite->in_action == TRUE)
     {  /* in this case (T_sprite in action) modify only x_vel and y_vel
	   attribute in sprite , in what_action of jump (1) jump special (3),
	   wound jump (5) and splash (7) will modify include y attribute */

	switch (T_sprite->what_action)
	{  case  1:  //jump action
		     //(**inter , use by many character)
		     Jump(T_sprite);  break;
	   case  2:  //shot action
		     //(**inter , use by many character)
		     if (T_sprite->step_action > 0)
		     {  //stop sprite until delay == 0 (step_action == 0)
			T_sprite->x_vel = 0;
			T_sprite->y_vel = 0;
			//wait--;
			T_sprite->step_action--;
		     }
		     else
		     {  T_sprite->in_action = FALSE;
		     }
		     break;
	   case  3:  //special jump action
		     Jump(T_sprite);  break;
	   case  4:  //falling down action because gravity
		     //(**inter , use by many character)
		     T_sprite->x_vel = 0;  break;
	   case  5:  //wound jump
		     Jump(T_sprite);  break;
	   case  6:  //dead
		     //(**inter , use by many character)
		     T_sprite->step_action--;
		     break;

	   case  7:  Rameng_Supersplash(T_sprite); break;  //action in jump
	   case  8:  Dead_Rameng(T_sprite); break;

	   case 66:  //Dead for Big_Richard
		     Jump(T_sprite); break;
	   case 99:  Knight_Slash(T_sprite);
		     break;
	   case 100: //continue jump while in slash
		     Jump(T_sprite);
		     if (T_sprite->index_child == 0)
		     {  if ( Read_Jump_Step(T_sprite,0) == -999 )
			{  //case that collision occur in what_action 100
			   //so its slot is cleared
			   T_sprite->what_action = 4;
			}
			else T_sprite->what_action = 1;
		     }
		     break;
	   case 101: //continue falling while in slash
		     T_sprite->x_vel = 0;
		     T_sprite->y_vel = 15;
		     if (T_sprite->index_child == 0)
		     T_sprite->what_action = 4;
		     break;
	   case 102: //wound jump&dead for knight
		     Jump(T_sprite);
		     break;
	   case 103: //delay
		     //(**inter , use by many character)
		     if (T_sprite->step_action > 0)
		     {  //stop sprite until delay == 0 (step_action == 0)
			T_sprite->x_vel = 0;
			T_sprite->y_vel = 0;
			T_sprite->step_action--;
		     }
		     else
		     {  T_sprite->in_action = FALSE;
		     }
		     break;
	   case 500: // shield
		     T_sprite->x_vel = 0;
		     T_sprite->y_vel = 0;
		     T_sprite->dat.shield = 20;
		     T_sprite->in_action = FALSE;
		     break;

	   default:  if (T_sprite->step_action <= 0)
		     T_sprite->step_action++; //use with child that has
					      //not AI such as slash
	}
     }

     if (T_sprite->step_action >= 0) //because it is set for delay showing
     {  if ( ((T_sprite->what_action != 1) && (T_sprite->what_action != 3) &&
	   (T_sprite->what_action != 5) && (T_sprite->what_action != 7) &&
	   (T_sprite->what_action != 100) && (T_sprite->what_action != 101)) ||
	  (T_sprite->in_action == FALSE) )
	{  /* every what_action that use Jump() */
	   T_sprite->y += T_sprite->y_vel;
	   T_sprite->y_on_map += T_sprite->y_vel;
	}

	T_sprite->x_on_map += T_sprite->x_vel;

	switch (T_sprite->name)
	{  case  P:   Prepare_next_frame_KN(T_sprite); break;
	   case  E1:  Prepare_next_frame_E1(T_sprite); break;
	   case  E2:  Prepare_next_frame_E2(T_sprite); break;
	   case  E3:  Prepare_next_frame_E3(T_sprite); break;
	   case  KN:  Prepare_next_frame_KN(T_sprite); break;
	   case  KN_sl:  Prepare_next_frame_KN_sl(T_sprite); break;
	   case  KN_f:  T_sprite->cur_frame = 0; break;
	   case  RAMENG: Prepare_next_frame_rameng(T_sprite); break;
	   case  BALL: Prepare_next_frame_ball(T_sprite); break;
	   case  B_RICH: Prepare_next_frame_big (T_sprite); break;
	   case  SLIME: Prepare_next_frame_slime (T_sprite); break;
	   case  F_BALL1: Prepare_next_frame_Ball_Shot1(T_sprite); break;
	   case  F_BALL2: Prepare_next_frame_Ball_Shot2(T_sprite); break;
	   case  F_RAMENG: Prepare_next_frame_Rameng_Shot(T_sprite); break;
	   case  F:   Prepare_next_frame_E1(T_sprite); break;
	   default:  Any_Error();
	}
     }
//   T_sprite->y_on_map = T_sprite->y_on_map - (T_sprite->frame[T_sprite->cur_frame]->h - T_sprite->h);
//   T_sprite->y = T_sprite->y_on_map;
     //Change x_on_map if sprite try to move in right .
//     if (T_sprite->x_vel > 0)
//     {  T_sprite->x_on_map = T_sprite->x_on_map - T_sprite->frame[T_sprite->cur_frame]->w + T_sprite->w;
//	if (on_middle_screen == TRUE)
//	{  //textout(screen,font,"right",0,150,255);
//	}

//     }
//     T_sprite->w = T_sprite->frame[T_sprite->cur_frame]->w;
//     T_sprite->h = T_sprite->frame[T_sprite->cur_frame]->h;

     Set_Truth_Dim(T_sprite);
     //Change y and y_on_map case y_base of image changed . Try to use old
     //y_base so change y and y_on_map to compatible with new height
     T_sprite->y_on_map = T_sprite->y_on_map + T_sprite->PT_h - T_sprite->T_h;
     T_sprite->y = T_sprite->y_on_map;

     return on_screen;

  }  //end Prepare_Next_Sprite();

  /*--------------------------------------------------------------------*/

/* Begin of main routine */
//void main (int argc, char *argv[])
void main (void)
{  BITMAP   *background_image;
   PALLETE  the_pallete2;
   FILE *f;
   int loop,have_loaded[4];
   ldiv_t temp_div;
   char free_index;
   int stage;
   char* ST_FIN[3];
   char* ST_PCX[3];

   int test;
   char msg[80];

   ST_FIN[1] = "\\s7014278\\stage\\stage1.fin";
   ST_PCX[1] = "\\s7014278\\stage\\stage1.pcx";
   ST_FIN[2] = "\\s7014278\\stage\\stage2.fin";
   ST_PCX[2] = "\\s7014278\\stage\\stage2.pcx";


   printf("insert No. stage 0 or 1:\n");
   for (test=1; test<=2; test++)
   { printf("%d\n",test);
     printf("%s\n",ST_FIN[test]);
     printf("%s\n",ST_PCX[test]);

   }
   scanf("%d",&stage);

   allegro_init();              /* Initialise all Allegro stuff       */
   install_keyboard();          /* Install keyboard interrupt handler */
   install_mouse();             /* Install mouse handler              */
   install_timer();


   /*-------------------------------*/
   if //( (file_exists ("\\s7014278\\stage\\temp2.fin",32,file_attr)) == 0)
//      ( (file_exists ("\\s7014278\\stage\\stage1.fin",32,file_attr)) == 0)
      ( (file_exists (ST_FIN[stage],32,file_attr)) == 0)
   {  printf("not found %s",ST_FIN[stage]);
      exit(0);
   }
   /* open file *.fin that stored data about stage */
   //f = fopen("\\s7014278\\stage\\temp2.fin", "rb");
//   f = fopen("\\s7014278\\stage\\stage1.fin", "rb");
   f = fopen(ST_FIN[stage], "rb");
//   f = fopen("\\s7014278\\stage\\temp3.fin", "rb");//F_READ);
   if (!f)      exit(0);//return NULL;
   //pack_fseek(f,0);
   fseek(f,0,SEEK_SET);
   /*----------------------------------------------*/

   fade_out(4);
   set_gfx_mode(GFX_VGA, 320, 200, 0, 0);
   clear(screen);

   set_gui_colors();

   if (!gfx_mode_select(&c, &w, &h)) {
      allegro_exit();
      exit(1);
   }

   /* Sets 320x200x256 mode */
   err_vmode = set_gfx_mode(c, w, h, 0, 0);
   /* Checks if any error occured during screen mode initialization   */
   if ( err_vmode != 0 )
   {
   /* If error - shut down Allegro          */
    allegro_exit ();
    printf("Error setting graphics mode\n%s\n\n", allegro_error);
    exit (1);
   }

   if (!((w==320) || (w==640)))
   {  allegro_exit();
      printf("Now for 320*200 or 640*480 only...");
      exit(1);
   }

   /* Removes everything from keyboard's buffer */
   clear_keybuf();
   output = create_bitmap(SCREEN_W, SCREEN_H);
   Prepare_All_Image();


   fade_out(2);

//   if ( (file_exists ("//s7014255//p.pcx",32,file_attr)) == 0)

//   if ( (file_exists ("//s7014278//stage//stage1.pcx",32,file_attr)) == 0)
   if ( (file_exists (ST_PCX[stage],32,file_attr)) == 0)
   {  //printf("\n%d..%s",stage,ST[01]);
      printf("Data file %s not found. Exiting",ST_PCX[stage]);
      exit(0);
   }

//   background_image = load_bitmap("//s7014255//p.pcx", pallete_bck);
//   background_image = load_bitmap("//s7014278//stage//stage1.pcx", pallete_bck);
   background_image = load_bitmap(ST_PCX[stage], pallete_bck);
   set_pallete(pallete_bck);

   vsync(); vsync();
//   blit (background_image, screen, 0,0,0,0,background_image->w,background_image->h);
//   blit (s, screen, 0,0,0,0,SCREEN_W,SCREEN_H);

   blit (background_image, screen, 0,0,0,0,SCREEN_W,SCREEN_H);


   next = FALSE;
   do
   {
      if ( key[KEY_SPACE] == TRUE ) next = TRUE;
   }
   while (next==FALSE);
   clear_keybuf();
   next = FALSE;


//-------------------------move in sprite too-------------------------------
   /*(spr,x_start,y_start,x_on_map,y_on_map,x_vel,y_vel,d_scr,allow_other_over,gravity_on)*/
   Alive_Sprite[1] = TRUE;
//   Init_Sprite_big(1,&list[1],70,130,70,130);//,0,0,TRUE,FALSE,TRUE);
   Init_Sprite_KN(1,&list[1],70,30,70,30);//,0,0,TRUE,FALSE,TRUE);
   list[1].d_scr = TRUE;
   list[1].gravity_on = TRUE;
   list[1].x_vel = 0;
   list[1].y_vel = 0;
   list[1].name = P;
   list[1].dat.hp = 1;//15;
   list[1].dat.mp = 0;
   list[1].dat.level = 1;
   list[1].dat.atk = 3;
   list[1].dat.def = 2;
   list[1].dat.luc = 0;
   list[1].dat.shield = 0;


//   Alive_Sprite[3] = TRUE;
//   Init_Sprite_rameng(3,&list[3],200,30,200,30);
/*   Alive_Sprite[4] = TRUE;
   Init_Sprite_slime(4,&list[4],150,80,150,80);
   Alive_Sprite[5] = TRUE;
   Init_Sprite_slime(5,&list[5],250,30,250,30);*/


//   list[3].x_vel = 0;
//   list[3].y_vel = 0;


//   Alive_Sprite[4] = TRUE;
//   Init_Sprite_E1(&list[4],150,30,150,30);
//   list[4].x_vel = -5;
//   list[4].y_vel = 0;

//   Alive_Sprite[5] = TRUE;
//   Init_Sprite_E1(&list[5],75,90,75,90);
//   list[5].x_vel = 4;
//   list[5].y_vel = -3;



   blit(screen,output,0,0,0,0,SCREEN_W,SCREEN_H);
   set_pallete(pallete_bck);
   have_loaded[1] = -1;
   have_loaded[2] = 0;  //initial value for start load file point
   have_loaded[3] = 1;
   amount_page = getc(f); //amount of page
   fgets(stage_name,21,f);//this function will get from current pointer to
			  //n-1 , exact string has 20 bytes length
   Load_One_Page(f,have_loaded[2]);
   Load_One_Page(f,have_loaded[3]);

   back_ground_ptr = 0;
   check = 0;

   do
   {  //---------------step 1 , load data from file *.fin-------------------
      temp_div = ldiv(list[1].x_on_map,SCREEN_W);//(list[1].x_on_map,320)
      if ( (temp_div.quot != have_loaded[2]) )//&& (temp_div.quot != 0) )
      {  if (temp_div.quot == have_loaded[1])
	 // case move left
	 {  Load_One_Page(f,(have_loaded[1]-1));

//	    printf("have_loaded[1]:%d",have_loaded[1]);

	 }
	 if (temp_div.quot == have_loaded[3])
	 // case move right
	 {  Load_One_Page(f,(have_loaded[3]+1));

//	    printf("have_loaded[3]:%d",have_loaded[3]);

	 }

	 have_loaded[2] = temp_div.quot;
	 have_loaded[1] = have_loaded[2] - 1;
	 have_loaded[3] = have_loaded[2] + 1;

      }

      //----------------step 2 , check keyboard---------------------------
      Chk_Keyboard(&list[1]);
      Chk_Keyboard(&list[1]);


      //----------step 2.1 , brain and determination of other sprite------
      //---Brain = Case that object must follow action with other sprite
      //---such as its parent.

      for (loop=1; loop<=(MAX_BLOCK-1); loop++)
      {  if (Alive_Sprite[loop] == TRUE)
	 {  switch (list[loop].name)
	    {  case KN_sl : if (list[loop].step_action == 0)
			    {  //prepare x,y for current position of
			       //parent sprite
			       Knight_Slash_Brain(&list[loop],&list[1]);
			       //clear attribute index_child in parent
			       list[list[loop].index_parent].index_child = 0;
			    }
			    if (list[loop].step_action > 0)
			    Relse_Sprite(loop);
			    break; //KN_sl
	       case E1:     if ( (list[1].in_action == TRUE) )
			    {  if (list[1].what_action == 1)
			       {  Set_Jump_Step(&list[loop]);
			       }
			       if (list[1].what_action == 99)
			       list[loop].y_vel = 4;
			    }
			    else
			    {  if (list[1].x_vel > 0)
			       { list[loop].x_vel = 4; }
			       if (list[1].x_vel < 0)
			       { list[loop].x_vel = -4; }
			       if (list[1].x_vel == 0)
			       { list[loop].x_vel = 0; }
			    }
			    break; //E1
	       case SLIME:  if (Ai_Slime(&list[loop],&list[1]) != 0)
			    {  switch (list[loop].what_action)
			       {  case 5:    Set_Wound_Jump_Step(&list[loop],&list[list[loop].index_attack]);
					     list[loop].dat.shield = 25;
					     break;  //slime wound
				  case 6:    Set_Dead_Step(&list[loop]);
					     break;
				  case 1:    Set_Slime_Walk_Step(&list[loop]);
					     break;  //slime jump
				  case 102:  Set_Wound_Jump_Step(&list[loop],&list[list[loop].index_attack]);
					     list[loop].dat.shield = 0;
					     list[loop].what_action = 102;
					     break;  //slime dead
			       }
			    }
			    break;  //SLIME
	       case RAMENG: if (Ai_rameng(&list[loop],&list[1]) != 0)
			    {  switch (list[loop].what_action)
			       {  case 2:
//----------------------
	   free_index = Search_Free_Index();
	   if (free_index != 0)
	   {  Set_Rameng_Shot_Step(&list[loop]);   //shot what_action = 2
	      Alive_Sprite[free_index] = TRUE;
	      list[loop].index_child = free_index;
	      list[free_index].index_parent = list[loop].index_list;
	      if (list[loop].direction == RIGHT)
	      {  Init_Sprite_Rameng_Shot(free_index,&list[free_index],0,list[loop].y+list[loop].T_dy,0,list[loop].y_on_map+list[loop].T_dy);

		 list[free_index].x = list[loop].x+list[loop].T_w - list[free_index].T_dx;
		 list[free_index].x_on_map = list[loop].x_on_map+list[loop].T_w - list[free_index].T_dx;
		 list[free_index].x_vel = 8;

	      }
	      else
	      {  Init_Sprite_Rameng_Shot(free_index,&list[free_index],0,list[loop].y+list[loop].T_dy,0,list[loop].y_on_map+list[loop].T_dy);
		 list[free_index].x = list[loop].x+list[loop].T_dx - list[free_index].T_w;
		 list[free_index].x_on_map = list[loop].x_on_map+list[loop].T_dx - list[free_index].T_w;
		 list[free_index].x_vel = -8;
	      }
	      list[loop].index_child = free_index;
	      list[free_index].index_parent = list[loop].index_list;
	      list[free_index].name = F_RAMENG;
	   }
	   else
	   {  Not_Enough();
	   }
	   break;  // for shot
//--------------------------------

				  case 3:    Set_Jump_Step(&list[loop]);
					     break;
				  case 6:    Set_Dead_Step(&list[loop]);
					     break;
				  case 7:    if (list[loop].x_vel < 0)
					     list[loop].x_vel = -2;
					     if (list[loop].x_vel > 0)
					     list[loop].x_vel = 2;
					     Rameng_Supersplash_Step(&list[loop]);
					     break;
				  case 8:    Dead_Rameng_Step(&list[loop]);
					     list[loop].dat.shield = 0;
					     break;
				  case 103:  list[loop].step_action = 10;
					     list[loop].in_action = TRUE;
					     list[loop].what_action = 103;
					     break;
			       }
			    }
			    break;  //RAMENG
	       case BALL:   if (Ai_Ball(&list[loop],&list[1]) != 0)
			    {  switch (list[loop].what_action)
			       {  case 5:  if (list[loop].dat.hp == 0)
					   {  Dead_Ball_Step(&list[loop]);
					   }
					   break;
				  case 2:
//--------------------------------
	   free_index = Search_Free_Index();
	   if (free_index != 0)
	   {  Alive_Sprite[free_index] = TRUE;
	      list[loop].index_child = free_index;
	      list[free_index].index_parent = list[loop].index_list;
	      Set_Ball_Shot_Step(&list[loop]);   //shot what_action = 22
	      if (list[loop].direction == RIGHT)
	      {  Init_Sprite_Ball_Shot1(free_index,&list[free_index],0,list[loop].y+list[loop].T_dy+20,0,list[loop].y_on_map+list[loop].T_dy+20);
		 list[free_index].x = list[loop].x+list[loop].T_w - list[free_index].T_dx+10;
		 list[free_index].x_on_map = list[loop].x_on_map+list[loop].T_w - list[free_index].T_dx+10;
		 list[free_index].x_vel = 8;
	      }
	      else
	      {  Init_Sprite_Ball_Shot1(free_index,&list[free_index],0,list[loop].y+list[loop].T_dy+20,0,list[loop].y_on_map+list[loop].T_dy+20);
		 list[free_index].x = list[loop].x+list[loop].T_dx - list[free_index].T_w-10;
		 list[free_index].x_on_map = list[loop].x_on_map+list[loop].T_dx - list[free_index].T_w-10;
		 list[free_index].x_vel = -8;
	      }
		 list[loop].index_child = free_index;
		 list[free_index].index_parent = list[loop].index_list;
		 list[free_index].name = F_BALL1;
	      }
	   else
	   {  Not_Enough();
	   }  //end ball 1
	   //--------------------------------------------
	   free_index = Search_Free_Index();
	   if (free_index != 0)
	   {  Alive_Sprite[free_index] = TRUE;
	      list[free_index].index_parent = list[loop].index_list;
	      if (list[loop].direction == RIGHT)
	      {  Init_Sprite_Ball_Shot1(free_index,&list[free_index],0,list[loop].y+list[loop].T_dy+17,0,list[loop].y_on_map+list[loop].T_dy+17);
		 list[free_index].x = list[loop].x+list[loop].T_w - list[free_index].T_dx+20;
		 list[free_index].x_on_map = list[loop].x_on_map+list[loop].T_w - list[free_index].T_dx+20;
		 list[free_index].x_vel = 8;
	      }
	      else
	      {  Init_Sprite_Ball_Shot1(free_index,&list[free_index],0,list[loop].y+list[loop].T_dy+17,0,list[loop].y_on_map+list[loop].T_dy+17);
		 list[free_index].x = list[loop].x+list[loop].T_dx - list[free_index].T_w-20;
		 list[free_index].x_on_map = list[loop].x_on_map+list[loop].T_dx - list[free_index].T_w-20;
		 list[free_index].x_vel = -8;
	      }
	      list[loop].index_child = free_index;
	      list[free_index].index_parent = list[loop].index_list;
	      list[free_index].step_action = -5;
	      list[free_index].name = F_BALL1;
	   }
	   else
	   {  Not_Enough();
	   }  //end shot 2
	   //--------------------------------------------
	   free_index = Search_Free_Index();
	   if (free_index != 0)
	   {  Alive_Sprite[free_index] = TRUE;
	      list[free_index].index_parent = list[loop].index_list;
	      if (list[loop].direction == RIGHT)
	      {  Init_Sprite_Ball_Shot2(free_index,&list[free_index],0,list[loop].y+list[loop].T_dy,0,list[loop].y_on_map+list[loop].T_dy);
		 list[free_index].x = list[loop].x+list[loop].T_w - list[free_index].T_dx+20;
		 list[free_index].x_on_map = list[loop].x_on_map+list[loop].T_w - list[free_index].T_dx+20;
		 list[free_index].x_vel = 8;
	      }
	      else
	      {  Init_Sprite_Ball_Shot2(free_index,&list[free_index],0,list[loop].y+list[loop].T_dy+7,0,list[loop].y_on_map+list[loop].T_dy+7);
		 list[free_index].x = list[loop].x+list[loop].T_dx - list[free_index].T_w-20;
		 list[free_index].x_on_map = list[loop].x_on_map+list[loop].T_dx - list[free_index].T_w-20;
		 list[free_index].x_vel = -8;
	      }
	      list[loop].index_child = free_index;
	      list[free_index].index_parent = list[loop].index_list;
	      list[free_index].step_action = -13;
	      list[free_index].name = F_BALL2;
	   }
	   else
	   {  Not_Enough();
	   } //end shot 3
	   break; // case 2
//--------------------------------
				  case 1:  Set_Jump_Step(&list[loop]);
					   break; // case 1
				  case 666: Dead_Ball(&list[loop]);
					    break;
				  case 6 : Set_Dead_Step(&list[loop]);
					   break;
			       } // end case what_action
			    } // end if
			    break; //BALL
	    }
	 }  //end if
      }

      //-------------------step 3 , write image in buffer-----------------


      //write new background to buffer
      blit (background_image,output,back_ground_ptr,0,0,0 ,SCREEN_W,SCREEN_H);

      //write sprite to buffer
      for (loop=1; loop<=(MAX_SPRITE-1); loop++)
      {  if ( (Alive_Sprite[loop] == TRUE) &&
	      (list[loop].now_over_other == FALSE) )
	 {  Show_Sprite(&list[loop]);
	 }
      }

      for (loop=1; loop<=(MAX_SPRITE-1); loop++)
      {  if ( (Alive_Sprite[loop] == TRUE) &&
	      (list[loop].now_over_other != FALSE) ) //== TRUE) )
	 {  Show_Sprite(&list[loop]);
	 }
      }

      //write data of player to buffer
      Show_Data(output,&list[1]);

      //------------------------------------------------------------


//      sprintf(msg,"list1.x_vel:%d,cur_frame:%d,cl:%din:%d",list[1].x_vel,list[1].cur_frame,list[1].collide,list[1].in_action);
//      textout(output,font,msg, 50,10,YELLOW);
      sprintf(msg,"sh:%d,cl:%d,x:%d,y:%d,xl:%d,yl:%d",list[3].dat.shield,list[3].collide,list[3].x_on_map,list[1].y_on_map,list[3].x_vel,list[3].y_vel);
      textout(output,font,msg,65,10,YELLOW);
      sprintf(msg,"in:%d,wh:%d,flr:%d,cur:%d,T_w:%d",list[3].in_action,list[3].what_action,list[3].on_floor,list[3].cur_frame,list[3].T_w);
      textout(output,font,msg,65,25,YELLOW);
      sprintf(msg,"slash..st_c:%d,st_p:%d,sh_e:%d",list[2].step_action,list[3].step_action,list[3].dat.shield);
      textout(output,font,msg,65,50,YELLOW);
//      if (check == 15)
//      {  sprintf(msg,"pixel collide");
//	 textout(output,font,msg,50,20,YELLOW);
//      }
//      if (base == 15)
//      {  sprintf(msg,"bounding collide");
//	 textout(output,font,msg,50,30,YELLOW);
//      }
//      sprintf(msg,"---1.x:%dT_dx:%dT_w:%df:%d---",list[1].x_on_map,list[1].T_dx,list[1].T_w,list[1].cur_frame);
//      textout(output,font,msg,50,30,YELLOW);
//      sprintf(msg,"---3.x:%dT_dx:%dT_w:%df:%d---",list[3].x_on_map,list[3].T_dx,list[3].T_w,list[3].cur_frame);
//      textout(output,font,msg,50,40,YELLOW);
      //-----------step 4 , copy image from buffer to screen --------------


      vsync();
      blit (output,screen,0,0,0,0,SCREEN_W, SCREEN_H);
      //delay(80);
      delay(60);

      //---step 5 , modify data in attribute of each object for next loop---
//      if ( (list[3].in_action == TRUE) &&
//	   (
//	   (list[3].what_action == 7)
//	   || (list[3].what_action == 5) )
//	if ( (Alive_Sprite[6] == TRUE) && (list[6].x_vel != 0)
//	 )
//	   (list[1].what_action == 7) //&&
	   //(list[1].collide != FALSE)
//	   (list[1].what_action == 7) && (list[1].step_action >=4)
//	 )
//    {
//    Wait_Space_Allegro();

//	 if (key[KEY_ESC] == TRUE)
//	 {  allegro_exit();
//	    List_Check(1,Alive_Sprite[1],&list[1]);
//	    printf("\n");
//	    Block_Check(6,Alive_Block[6],&list_block[6]);
//	    exit(1);
//	 }
//      }

      for (loop=1; loop<=(MAX_SPRITE-1); loop++)
      {  if ( (Alive_Sprite[loop] == TRUE) &&
	      (list[loop].now_over_other != FALSE) )   //== TRUE
	 {  Prepare_Next_Sprite(&list[loop],loop);
	    /* for this inheritance (shot) */
	    if (list[loop].have_shot == TRUE)
	    {  if (Alive_Sprite[list[loop].index_child] == FALSE)
	       {  list[loop].have_shot = FALSE;
	       }
	    }
	 }
      }

      for (loop=1; loop<=(MAX_SPRITE-1); loop++)
      {  if ( (Alive_Sprite[loop] == TRUE) &&
	      (list[loop].now_over_other == FALSE) )
	 {  //Alive_Sprite[loop] =
	    Prepare_Next_Sprite(&list[loop],loop);
	    /* for this inheritance (shot) */
	    if (list[loop].have_shot == TRUE)
	    {  if (Alive_Sprite[list[loop].index_child] == FALSE)  list[loop].have_shot = FALSE;
	    }
	 }
      }

      //---------step 6 , work with collide---------------------------------

      Chk_Colide_All_Screen();

      //---------step 7 , modify x attribute in every object----------------
      //----modify attribute x in each object to follow with player sprite
      //--- (list[1]) and modify Alive_Sprite and Alive_Block in case that
      //--- sprite or block now on screen again

      /*----for stop player sprite movement at SCREEN_W/2--*/

      if ( (list[1].x_on_map < (((SCREEN_W - list[1].w)/2))-1) ||
	   (list[1].x_on_map > ((((amount_page-1)*SCREEN_W) + ((SCREEN_W - list[1].w)/2)))-1)
	 )
      {  /* for make player sprite on screen is in same position as on map */
	    //for y attribute will have modified in Prepare_Next_Sprite()
	    //(have_loaded[2]*SCREEN_W) = amount of pixel before current page
	    list[1].x = list[1].x_on_map - (have_loaded[2]*SCREEN_W);
	    list[1].y = list[1].y_on_map;
	    on_middle_screen = FALSE;
      }
      else
      {  if ( (on_middle_screen == FALSE) )
	 {  list[1].x = ((SCREEN_W - list[1].w)/2) - 1;
	    list[1].x_on_map = ((have_loaded[2]*SCREEN_W) + (SCREEN_W - list[1].w)/2) - 1;
	    on_middle_screen = TRUE;
	 }
      }

     Detect_Edge(&list[1]);

      /*----------------------------------------------------*/

      for (loop=1; loop<=(MAX_BLOCK-1); loop++)
      {  if (Alive_Block[loop] == TRUE)
	 {  list_block[loop].x = list_block[loop].x_on_map - list[1].x_on_map + list[1].x;
	 }
      }

      for (loop=2; loop<=(MAX_SPRITE-1); loop++)
      {  if (Alive_Sprite[loop] == TRUE)
	 {  list[loop].x = list[loop].x_on_map - list[1].x_on_map + list[1].x;
	    Detect_Edge(&list[loop]);
	 }
      }

      back_ground_ptr = Scroll(list[1].x_on_map,list[1].w,back_ground_ptr);

      Recycle_List(have_loaded[2]);


      //---------step 8 set special what action to each sprite and--------
      //------------------work in other-------------------------------

      /*  set state now sprite is on some floor or not */
      for (loop=1; loop<=(MAX_SPRITE-1); loop++)
      {  Now_On_Floor(&list[loop]);
	 Gravity(&list[loop]);
      }


      for (loop=1; loop<=(MAX_SPRITE-1); loop++)
      {  if (Alive_Sprite[loop] == TRUE)
	 {  if ( (list[loop].collide != FALSE) &&
		 ( (list[loop].in_action == FALSE) ||
		   ((list[loop].what_action != 3) && (list[loop].what_action != 4))
		   /* not stop while in special jump & falling action */
		 )
	       )
	    {  list[loop].x_vel = 0;
	       list[loop].y_vel = 0;
	    }
	    if (list[loop].dat.shield != 0)
	    {  list[loop].dat.shield--;
	    }
//	    if (list[loop].dat.hp == 0)
//	    {  Set_Dead_Step(&list[loop]);
//	       allegro_exit();
//	       List_Check(loop,Alive_Sprite[loop],&list[loop]);
//	       exit(1);

//	    }
	 }
      }



      if (key[KEY_ESC] == TRUE) next = TRUE;
      if (list[1].x_vel > 0)   list[1].x_vel -= 2;
      if (list[1].x_vel < 0)   list[1].x_vel += 2;
      if (list[1].y_vel > 0)   list[1].y_vel -= 2;
      if (list[1].y_vel < 0)   list[1].y_vel += 2;
      if (list[1].x_vel == 6)  list[1].x_vel = 4;
      if (list[1].x_vel == -6) list[1].x_vel = -4;



      // for completely calculator (no have riminder when was divided by 320)
      // use only speed at 2 ,4 ,8
//      if (list[1].dat.shield != 0) list[1].dat.shield--;


   }
   while (next==FALSE);
//--------------------------------------------------------------------------

//   pack_fclose(f);
   fclose(f);
   destroy_bitmap(background_image);
   destroy_bitmap(output);

   Destroy_E1();
   Destroy_E2();
   Destroy_E3();
   Destroy_rameng();
   Destroy_ball();
   Destroy_big();
   Destroy_slime();
   Destroy_KN();
   Destroy_Other();

//   destroy_bitmap(a_pic);
//   destroy_bitmap(b_pic);
//   destroy_bitmap(h_pic);
//   destroy_bitmap(block_image);

   /* Shuts down Allegro     */
   allegro_exit();



   printf("\n");
   Block_Check(1,Alive_Block[1],&list_block[1]);
   printf("\n");
//   Block_Check(2,Alive_Block[2],&list_block[2]);
//   printf("\n");
//   Block_Check(3,Alive_Block[3],&list_block[3]);
//   printf("\n");
//   Block_Check(6,Alive_Block[6],&list_block[6]);
//   printf("\n");
//   Block_Check(7,Alive_Block[7],&list_block[7]);

   printf("\n");
   printf("back_ground_ptr:%d\n",back_ground_ptr);
   printf("amount of page:%d..Name:%s..before:%d,current_page:%d,next:%d\n",amount_page,stage_name,have_loaded[1],have_loaded[2],have_loaded[3]);
   printf("list[1].....w:%d..h:%d..",list[1].w,list[1].h);
   printf("detect:%d,x:%d..,y:%d..,have_shot:%d\n",list[1].d_scr,list[1].x,list[1].y,list[1].have_shot);
   printf("in_action:%d..what_action:%d..step_action:%d..check:%d..x_on_map:%d..y_on_map:%d\n",list[1].in_action,list[1].what_action,list[1].step_action,check,list[1].x_on_map,list[1].y_on_map);
   printf("x_vel:%d..y_vel:%d..index_child:%d..over_other:%d..collide:%d..wd:%d\n",list[1].x_vel,list[1].y_vel,list[1].index_child,list[1].now_over_other,list[1].collide,list[1].wounded);
   printf("on_floor:%d..T_w:%d,PT_w:%d,T_h:%d,PT_h:%d,T_dx:%d,PT_dx:%d,T_dy:%d,PT_dy:%d\n\n",list[1].on_floor,list[1].T_w,list[1].PT_w,list[1].T_h,list[1].PT_h,list[1].T_dx,list[1].PT_dx,list[1].T_dy,list[1].PT_dy);

//   printf("alive1=%d\n",Alive_Block[1]);
//   printf("alive2=%d\n",Alive_Sprite[2]);
//   printf("alive3=%d\n",Alive_Sprite[3]);
//   printf("alive4=%d\n",Alive_Sprite[4]);
//   printf("alive5=%d\n",Alive_Sprite[5]);
//   printf("alive6=%d\n",Alive_Sprite[6]);
//   printf("alive7=%d\n",Alive_Sprite[7]);
//   printf("alive8=%d\n",Alive_Sprite[8]);
//   printf("alive9=%d\n",Alive_Sprite[9]);
//   printf("alive10=%d\n",Alive_Sprite[10]);
/*   printf("sprite2,detect:%d,x:%d..,y:%d..,have_shot:%d\n",list[2].d_scr,list[2].x,list[2].y,list[2].have_shot);
   printf("in_action:%d..what_action:%d..check:%d..x_on_map:%d..y_on_map:%d\n",list[2].in_action,list[2].what_action,check,list[2].x_on_map,list[2].y_on_map);
   printf("index_child:%d..over_other:%d..collide:%d..\n",list[2].index_child,list[2].now_over_other,list[2].collide);
   printf("on_floor:%d\n",list[2].on_floor);*/
//   List_Check(5,Alive_Sprite[5],&list[5]);
//   printf("\n");
   List_Check(5,Alive_Sprite[3],&list[3]);
   printf("\n");
   List_Check(6,Alive_Sprite[2],&list[2]);

//   printf("middle_screen=%d\n",(SCREEN_W - list[1].w)/2);
// getch();
   for (test=0; test<=9; test++)
   printf("%d",list_step[test]);
   printf("\n");
   for (test=0; test<=20; test++)
   printf("%d,",t_step[0][test]);

   printf("\n");
   for (test=0; test<=20; test++)
   printf("%d,",t_step[1][test]);

   /* Exit program           */
   exit(0);
}




   /*getch();
   printf("check:%d\n",check);
   do{
   if ( key[KEY_SPACE] == TRUE )  next = TRUE;
   }
   while (next == FALSE);
   clear_keybuf();
   next = FALSE;
   exit(0);
   */