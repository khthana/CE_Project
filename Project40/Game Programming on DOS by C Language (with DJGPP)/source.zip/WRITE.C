/*now use max block = 12 per page use 17 bytes for each of them
	 max sprite = 8 per page use 10 bytes for each of them
	  1 byte for describe first x in that page*/

/*type of object 0 = block
		 1 = sprite
		 2 = end of page */

//#include <file.h>
#include <stdlib.h>
#include <stdio.h>
#include "allegro.h"
#define MAX_BLOCK_PER_PAGE 12
#define MAX_SPRITE_PER_PAGE 8
#define BYTES_PER_BLOCK 17
#define BYTES_PER_SPRITE 10
#define BYTES_PER_PAGE (MAX_BLOCK_PER_PAGE * BYTES_PER_BLOCK) + (MAX_SPRITE_PER_PAGE * BYTES_PER_SPRITE) +1

#define BLOCK 0
#define SPRITE 1
#define EOP 2

/* Knight as Player */
#define F -1
#define P 0
#define KN 1
#define KN_sl 2
#define KN_f 3
/* Ball Hunter */
#define BALL 10
#define F_BALL1 11
#define F_BALL2 12
/* Rameng */
#define RAMENG 20
#define F_RAMENG 21
/* Big Richard */
#define B_RICH 30
/* Slime */
#define SLIME 40
/* Others */
#define E1 50
#define E2 51
#define E3 52


int count_bl,count_spr,count_pg;

  void End_Page(FILE *f)
  {  int byte_skip,loop;
     byte_skip = BYTES_PER_PAGE - ((count_bl * BYTES_PER_BLOCK) + (count_spr * BYTES_PER_SPRITE) + 1);
     for (loop = 1; loop <= byte_skip; loop++)
     {  putc(EOP,f);     //write end of page for page occupying
     }
     putc(count_pg,f);
     printf("pg:%d.skip:%d.bl:%d.spr:%d//",count_pg,byte_skip,count_bl,count_spr);
     count_pg++;
     count_bl = 0;
     count_spr = 0;
  }

  void End_File(FILE *f)
  {  fseek(f,0,SEEK_SET);
     putc((count_pg-1),f);
  }


  int save_fin(char *filename)
  {  FILE *f;
     int c;
     int x, y;
     int runcount;
     char runchar;
     char ch;

   f = fopen(filename, "wb");
   if (!f)
      return errno;

   count_bl = 0;
   count_spr = 0;
   count_pg = 0;
   /* header of file *.fin */
   putc(0,f);                 /*1 byte for amount of pages*/
//   fputs("STAGE 1 IN THE TOWNS",f); /* 20 bytes */
   fputs("STAGE 2 IN THE TOWNS",f); /* 20 bytes */
   putc(0,f);                      /*first point is 0*/
   count_pg++;

   /*----------------------*/

/*STAGE1.FIN*/

   putc(BLOCK,f);                  //type
   putw(48,f);                     //x
   putw(184,f);                    //y
   putw(175,f);                    //w
   putw(16,f);                     //h
   count_bl++;

   putc(BLOCK,f);                  //type
   putw(190,f);                     //x
   putw(145,f);                    //y
   putw(308,f);                    //w
   putw(5,f);                     //h
   count_bl++;

   putc(BLOCK,f);                  //type
   putw(149,f);                     //x
   putw(166,f);                    //y
   putw(59,f);                    //w
   putw(7,f);                     //h
   count_bl++;

   putc(SPRITE,f);
   putw(0,f);                    //x
   putw(150,f);                     //y
   putc(E2,f);                     //character
   count_spr++;

   putc(SPRITE,f);
   putw(200,f);                    //x
   putw(30,f);                     //y
   putc(SLIME,f);                     //character
   count_spr++;

   putc(SPRITE,f);
   putw(150,f);                    //x
   putw(80,f);                     //y
   putc(SLIME,f);                     //character
   count_spr++;

   putc(SPRITE,f);
   putw(250,f);                    //x
   putw(30,f);                     //y
   putc(SLIME,f);                     //character
   count_spr++;

   End_Page(f);
/*--------------------------------------------*/
   putc(BLOCK,f);                  //type
   putw(507,f);                     //x
   putw(150,f);                    //y
   putw(62,f);                    //w
   putw(50,f);                     //h
   count_bl++;

   putc(BLOCK,f);                  //type
   putw(590,f);                     //x
   putw(123,f);                    //y
   putw(145,f);                    //w
   putw(77,f);                     //h
   count_bl++;

   putc(BLOCK,f);                  //type
   putw(592,f);                     //x
   putw(27,f);                    //y
   putw(407,f);                    //w
   putw(36,f);                     //h
   count_bl++;

   putc(SPRITE,f);
   putw(600,f);                    //x
   putw(90,f);                     //y
   putc(SLIME,f);                     //character
   count_spr++;

//   putc(SPRITE,f);
//   putw(575,f);
//   putw(89,f);
//   putc(E1,f);
//   count_spr++;

   End_Page(f);
/*--------------------------------------------*/
   putc(BLOCK,f);                  //type
   putw(737,f);                     //x
   putw(162,f);                    //y
   putw(48,f);                    //w
   putw(38,f);                     //h
   count_bl++;

   putc(BLOCK,f);                  //type
   putw(785,f);                     //x
   putw(186,f);                    //y
   putw(56,f);                    //w
   putw(14,f);                     //h
   count_bl++;

   putc(BLOCK,f);                  //type
   putw(880,f);                     //x
   putw(185,f);                    //y
   putw(89,f);                    //w
   putw(15,f);                     //h
   count_bl++;
   End_Page(f);
/*--------------------------------------------*/
   putc(BLOCK,f);                  //type
   putw(986,f);                     //x
   putw(170,f);                    //y
   putw(44,f);                    //w
   putw(30,f);                     //h
   count_bl++;

   putc(BLOCK,f);                  //type
   putw(1048,f);                     //x
   putw(155,f);                    //y
   putw(529,f);                    //w
   putw(45,f);                     //h
   count_bl++;

   putc(BLOCK,f);                  //type
   putw(1252,f);                     //x
   putw(80,f);                    //y
   putw(24,f);                    //w
   putw(24,f);                     //h
   count_bl++;

   putc(SPRITE,f);
   putw(1273,f);                    //x
   putw(90,f);                     //y
   putc(RAMENG,f);                     //character
   count_spr++;

   putc(SPRITE,f);
   putw(1256,f);                    //x
   putw(50,f);                     //y
   putc(SLIME,f);                     //character
   count_spr++;


   End_Page(f);
/*--------------------------------------------*/
   putc(BLOCK,f);                  //type
   putw(1337,f);                     //x
   putw(80,f);                    //y
   putw(24,f);                    //w
   putw(24,f);                     //h
   count_bl++;

   putc(BLOCK,f);                  //type
   putw(1583,f);                     //x
   putw(173,f);                    //y
   putw(342,f);                    //w
   putw(27,f);                     //h
   count_bl++;
   End_Page(f);
/*--------------------------------------------*/

   putc(SPRITE,f);
   putw(1700,f);                    //x
   putw(80,f);                     //y
   putc(BALL,f);                     //character
   count_spr++;

   End_Page(f); //for pixel 1600-1920
/*--------------------------------------------*/
   putc(BLOCK,f);                  //type
   putw(1932,f);                     //x
   putw(187,f);                    //y
   putw(48,f);                    //w
   putw(131,f);                     //h
   count_bl++;
   End_Page(f);

   End_Page(f);
   End_Page(f);
   End_Page(f);


   End_File(f);

   fclose(f);

   return 0;
  }


void main(void)
{
   allegro_init();
   //save_fin("\\s7014278\\stage\\temp2.fin");
   save_fin("\\s7014278\\stage\\stage1.fin");
   allegro_exit();
   printf("\ncount_bl:%d..count_spri:%d\n",count_bl,count_spr);
   printf("bytes_per_page:%d\n",BYTES_PER_PAGE);
   printf("amount_page:%d\n",count_pg-1);
 //   printf("temp2.fin complete");
   printf("stage1.fin complete");
}