/*
	A basic extension of the java.applet.Applet class
 */

import j102.sql.*;
import java.io.*;
import java.awt.*;
import java.applet.*;
import java.awt.Image;

import symantec.itools.awt.TreeView;
public class frmMain extends Applet
{
//============================================================
//                     Defined Variables
//============================================================    
    symantec.itools.awt.TreeNode root,father,child,now,forumNode,subfrNode,subfrNode1,subfrNode2,subfrNode3,subfrNode4,subfrNode5,fatherfr,Qnode = null;
    static String mode,user,Frid,ParentFrid,Rid,Qid,WarningText,About,SelectedNodeBe,SelectedNodeLink,SelectedNodeText = null;
    static int InsertCondition = 0,DelCondition = 0;
    static boolean haveChild = true;
    static Connection con = null;
/* 
InsertCondition = 0 ---> Not in any condition
InsertCondition = 1 ---> Insert to forum and parent is lname with child method & forum component
InsertCondition = 2 ---> Insert to forum and parent is lname with child method & question component
InsertCondition = 3 ---> Insert to forum and parent is lname with sibling method & forum component
InsertCondition = 4 ---> Insert to forum and parent is lname with sibling method & question component
InsertCondition = 5 ---> Insert to forum and parent is forum with child method & forum component
InsertCondition = 6 ---> Insert to forum and parent is forum with child method & question component
InsertCondition = 7 ---> Insert to forum and parent is forum with sibling method & forum component
InsertCondition = 8 ---> Insert to forum and parent is forum with sibling method & question component
InsertCondition = 9 ---> Insert to question and parent is lname with question component (sibling method)
InsertCondition = 10---> Insert to question and parent is lname with reply component (child method)
InsertCondition = 11---> Insert to question and parent is forum with question component (sibling method)
InsertCondition = 12---> Insert to question and parent is forum with reply component (sibling method)
InsertCondition = 13---> Insert to lname with child method & forum component
InsertCondition = 14---> Insert to lname with child method & question component

DelCondition = 0 ---> not in any condition
DelCondition = 1 ---> Del forum that parent is lname
DelCondition = 2 ---> Del forum that parent is forum
DelCondition = 3 ---> Del question node
*/
    String fathername,id,subid,Frheader = null;
    int frlevel = 0;
    static Image Qicon,OQicon,Bicon,OBicon,face1,face2,Ricon,SelectedImage,FatherImage = null;
    boolean TruePath = false;
    
//============================================================
//                          Make Tree
//============================================================
	void MakeNameNode() {
	    try {
	        String qs = "Select Lname from tblLecturer";
	        Statement stmt = con.createStatement();
	        ResultSet rs = stmt.executeQuery(qs);
	        boolean more = rs.next();	        
	        root = treeView1.getRootNode();
	        while (more) {	            	            
	            father = new symantec.itools.awt.TreeNode(rs.getString(1),face1,face2);
	            treeView1.insert(father,root,0);	            
	            more = rs.next();	         
	        }
	        rs.close();
	        stmt.close();
	        System.out.println("Make Lecturer Name Node");
	    }
	    catch (java.lang.Exception ex) {
	        // print description of the exception
	        System.out.println("** Error on data select **");
	        ex.printStackTrace();
	    }
	}
	
	void ChangeNameToId(String name) {
	    try {
	        String qs = "Select [Id#] from tblLecturer where Lname = '"+name+"'";
	        Statement stmt = con.createStatement();
	        ResultSet rs = stmt.executeQuery(qs);
	        boolean more = rs.next();	        
	        while (more) {	            	            
	            id = rs.getString(1);	            
	            more = rs.next();	         
	        }
	        rs.close();
	        stmt.close();
	        System.out.println("Change Lecturer Name '"+name+"' to Id#:"+id);
	    }
	    catch (java.lang.Exception ex) {
	        // print description of the exception
	        System.out.println("** Error on data select **");
	        ex.printStackTrace();
	    }
	}
	
	void MakeForumNode() {
	    try {
	        String qs = "Select Frheader,[Frid#] from tblForum where [Frid#] IN (Select [Frid#] from tblOwner where [Id#] = '"+id+"')";
	        Statement stmt = con.createStatement();
	        ResultSet rs = stmt.executeQuery(qs);
	        boolean more = rs.next();
	        while (more) {	            	            
	            child = new symantec.itools.awt.TreeNode(rs.getString(1),Bicon,OBicon);
	            treeView1.insert(child,father,0);
	            subid = rs.getString(2);    // get forum id
       	        frlevel = 1;
	            MakeQuestionNode();
	            more = rs.next();	         
	        }
	        rs.close();
	        stmt.close();
	        System.out.println("Make Forum Node");
	    }
	    catch (java.lang.Exception ex) {
	        // print description of the exception
	        System.out.println("** Error on data select **");
	        ex.printStackTrace();
	    }
	}
	
	void MakeQuestionNode() {
	    try {
	        String qs = "Select Header,[Qid#] from tblQuestion where [Frid#] = "+subid+" AND [Id#]='"+id+"'";
	        Statement stmt = con.createStatement();
	        ResultSet rs = stmt.executeQuery(qs);
	        boolean more = rs.next();	        
	        while (more) {	            	            
	            Qnode = new symantec.itools.awt.TreeNode(rs.getString(1),Qicon,OQicon);
	            switch(frlevel) 
	            {
	                case 1:
	                    treeView1.insert(Qnode,child,0);
	                    break;
	                case 2:
	                    treeView1.insert(Qnode,subfrNode,0);
	                    break;
	                case 3:
	                    treeView1.insert(Qnode,subfrNode1,0);
	                    break;
                    case 4:
                        treeView1.insert(Qnode,subfrNode2,0);
                        break;
                    case 5:
                        treeView1.insert(Qnode,subfrNode3,0);
                        break;
                    case 6:
                        treeView1.insert(Qnode,subfrNode4,0);
                        break;    
                    default :
                        System.out.println("Not in any case to built question node.");
                        break;
	            }
	            MakeReplyNode(rs.getString(2));
	            more = rs.next();	         
	        }
	        rs.close();
	        stmt.close();
	        System.out.println("Make Question Node");
	    }
	    catch (java.lang.Exception ex) {
	        // print description of the exception
	        System.out.println("** Error on data select **");
	        ex.printStackTrace();
	    }
	}
	
	void MakeReplyNode(String QuestionId) {
	    try {
	        String qs = "Select Rdate,Rdetails from tblReply where [Qid#] = "+QuestionId;
	        Statement stmt = con.createStatement();
	        ResultSet rs = stmt.executeQuery(qs);
	        symantec.itools.awt.TreeNode temp = null;
	        boolean more = rs.next();
	        String details = null;
	        int limit = 25;
	        char begin = 'a';
	        while (more) {
	            details = rs.getString(2);
	            begin = details.charAt(0);
	            if (details.length() <= limit) {
	                if ((begin == '\t')|(begin == '\n')) {
	                    details = details.substring(1,details.length())+"...";
	                }    
	                else {
	                    details = details.substring(0,details.length())+"...";
	                }
	            }
	            else {
	                if ((begin == '\t')|(begin == '\n')) {
	                    details = details.substring(1,limit)+"...";
	                }    
	                else {
	                    details = details.substring(0,limit)+"...";
	                }
	            }
	            temp = new symantec.itools.awt.TreeNode("("+rs.getString(1)+") "+details,Ricon,Ricon);
	            treeView1.insert(temp,Qnode,0);	            
	            more = rs.next();	         
	        }
	        rs.close();
	        stmt.close();
	        System.out.println("Make Reply Node");
	    }
	    catch (java.lang.Exception ex) {
	        // print description of the exception
	        System.out.println("** Error on data select **");
	        ex.printStackTrace();
	    }
	}
	
	void ChangeForumToId() {
	    try {
	        String qs = "Select [Frid#] from tblForum where (Frheader = '"+Frheader+"') AND ([Frid#] IN (Select [Frid#] from tblOwner where [Id#] = '"+id+"'))";
	        Statement stmt = con.createStatement();
	        ResultSet rs = stmt.executeQuery(qs);
	        boolean more = rs.next();	        
	        while (more) {	            	            
	            Frid = rs.getString(1);	            
	            more = rs.next();	         
	        }
	        rs.close();
	        stmt.close();
	        System.out.println("Change Forum Header to Forum Id#");
	    }
	    catch (java.lang.Exception ex) {
	        // print description of the exception
	        System.out.println("** Error on data select **");
	        ex.printStackTrace();
	    }
	}
	
	void MakeSubForumNode() {
	    try {
	        String qs = "Select Frheader,[Frid#] from tblForum where tblForum.[Frid#] IN (Select [Subid#] from tblSubforum where (tblSubforum.[Frid#] = "+Frid+") AND ([Subid#] <> 0))";
	        Statement stmt = con.createStatement();
	        ResultSet rs = stmt.executeQuery(qs);
	        boolean more = rs.next();	        
	        while (more) {	            	            
	            child = new symantec.itools.awt.TreeNode(rs.getString(1),Bicon,OBicon);
	            System.out.println(child.getText());
	            treeView1.insert(child,forumNode,0);
	            subid = rs.getString(2); // sub forum id
	            frlevel = 1;
	            MakeQuestionNode();
	            MakeSubOfSubFrNode();
	            more = rs.next();	         
	        }
	        rs.close();
	        stmt.close();
	        System.out.println("Make SubForum Node");
	    }
	    catch (java.lang.Exception ex) {
	        // print description of the exception
	        System.out.println("** Error on data select **");
	        ex.printStackTrace();
	    }
	}
	
	void MakeSubOfSubFrNode() 
	{
	    try {
	        String qs = "Select Frheader,[Frid#] from tblForum where tblForum.[Frid#] IN (Select [Subid#] from tblSubforum where (tblSubforum.[Frid#] = "+subid+") AND ([Subid#] <> 0))";
	        Statement stmt = con.createStatement();
	        ResultSet rs = stmt.executeQuery(qs);
	        boolean more = rs.next();	        
	        while (more) {	            	            
	            subfrNode = new symantec.itools.awt.TreeNode(rs.getString(1),Bicon,OBicon);
	            System.out.println(subfrNode.getText());
	            treeView1.insert(subfrNode,child,0);
	            subid = rs.getString(2);
       	        frlevel = 2;
       	        MakeQuestionNode();
	            MakeSubOfSubFrNode1();
	            more = rs.next();	         
	        }
	        rs.close();
	        stmt.close();
	    }
	    catch (java.lang.Exception ex) {
	        // print description of the exception
	        System.out.println("** Error on data select **");
	        ex.printStackTrace();
	    }
	}
	
	void MakeSubOfSubFrNode1() 
	{
	    try {
	        String qs = "Select Frheader,[Frid#] from tblForum where tblForum.[Frid#] IN (Select [Subid#] from tblSubforum where (tblSubforum.[Frid#] = "+subid+") AND ([Subid#] <> 0))";
	        Statement stmt = con.createStatement();
	        ResultSet rs = stmt.executeQuery(qs);
	        boolean more = rs.next();	        
	        while (more) {	            	            
	            subfrNode1 = new symantec.itools.awt.TreeNode(rs.getString(1),Bicon,OBicon);
	            System.out.println(subfrNode1.getText());
	            treeView1.insert(subfrNode1,subfrNode,0);
	            subid = rs.getString(2);
	            frlevel = 3;
       	        MakeQuestionNode();
	            MakeSubOfSubFrNode2();
	            more = rs.next();	         
	        }
	        rs.close();
	        stmt.close();
	    }
	    catch (java.lang.Exception ex) {
	        // print description of the exception
	        System.out.println("** Error on data select **");
	        ex.printStackTrace();
	    }
	}
	
    void MakeSubOfSubFrNode2() 
	{
	    try {
	        String qs = "Select Frheader,[Frid#] from tblForum where tblForum.[Frid#] IN (Select [Subid#] from tblSubforum where (tblSubforum.[Frid#] = "+subid+") AND ([Subid#] <> 0))";
	        Statement stmt = con.createStatement();
	        ResultSet rs = stmt.executeQuery(qs);
	        boolean more = rs.next();	        
	        while (more) {	            	            
	            subfrNode2 = new symantec.itools.awt.TreeNode(rs.getString(1),Bicon,OBicon);
	            System.out.println(subfrNode2.getText());
	            treeView1.insert(subfrNode2,subfrNode1,0);	
	            subid = rs.getString(2);
	            frlevel = 4;
       	        MakeQuestionNode();
	            MakeSubOfSubFrNode3();
	            more = rs.next();	         
	        }
	        rs.close();
	        stmt.close();
	    }
	    catch (java.lang.Exception ex) {
	        // print description of the exception
	        System.out.println("** Error on data select **");
	        ex.printStackTrace();
	    }
	}
	
	void MakeSubOfSubFrNode3() 
	{
	    try {
	        String qs = "Select Frheader,[Frid#] from tblForum where tblForum.[Frid#] IN (Select [Subid#] from tblSubforum where (tblSubforum.[Frid#] = "+subid+") AND ([Subid#] <> 0))";
	        Statement stmt = con.createStatement();
	        ResultSet rs = stmt.executeQuery(qs);
	        boolean more = rs.next();	        
	        while (more) {	            	            
	            subfrNode3 = new symantec.itools.awt.TreeNode(rs.getString(1),Bicon,OBicon);
	            System.out.println(subfrNode3.getText());
	            treeView1.insert(subfrNode3,subfrNode2,0);	
	            subid = rs.getString(2);
	            frlevel = 5;
       	        MakeQuestionNode();
	            MakeSubOfSubFrNode4();
	            more = rs.next();	         
	        }	        
	        rs.close();
	        stmt.close();
	    }
	    catch (java.lang.Exception ex) {
	        // print description of the exception
	        System.out.println("** Error on data select **");
	        ex.printStackTrace();
	    }
	}
	
	void MakeSubOfSubFrNode4() 
	{
	    try {
	        String qs = "Select Frheader,[Frid#] from tblForum where tblForum.[Frid#] IN (Select [Subid#] from tblSubforum where (tblSubforum.[Frid#] = "+subid+") AND ([Subid#] <> 0))";
	        Statement stmt = con.createStatement();
	        ResultSet rs = stmt.executeQuery(qs);
	        boolean more = rs.next();	        
	        while (more) {	            	            
	            subfrNode4 = new symantec.itools.awt.TreeNode(rs.getString(1),Bicon,OBicon);
	            System.out.println(subfrNode4.getText());
	            treeView1.insert(subfrNode4,subfrNode3,0);	
	            frlevel = 6;
       	        MakeQuestionNode();
	            more = rs.next();	         
	        }	        
	        rs.close();
	        stmt.close();
	    }
	    catch (java.lang.Exception ex) {
	        // print description of the exception
	        System.out.println("** Error on data select **");
	        ex.printStackTrace();
	    }
	}	
	
//====================================================================
//                      Change header to id
//====================================================================
	void ChangeNowToQid(String name) {
	    try {
	        String qs = "Select [Qid#],[Id#] from tblQuestion where Header = '"+name+"'";
	        Statement stmt = con.createStatement();
	        ResultSet rs = stmt.executeQuery(qs);
	        boolean more = rs.next(),foundTrueQid = false;
            symantec.itools.awt.TreeNode previousNode,nowNode = null;
            nowNode = now;
            previousNode = now;
            Qid = "";   // clear Qid
	        while ((more) & (!foundTrueQid)) 
	        {	            	            
	            Qid = rs.getString(1);
	            while (previousNode != root) 
	            {
	                try {
	                    nowNode = previousNode;
	                    previousNode = nowNode.getParent();
	                }
	                catch (Exception e) {
	                    e.printStackTrace();
	                }
	            }
	            ChangeNameToId(nowNode.getText());
	            if (id.equals(rs.getString(2))) {
	                foundTrueQid = true;
	            }
	            more = rs.next();	         
	        }
	        rs.close();
	        stmt.close();
	        System.out.println("Change selected question node to be Qid# "+Qid);
	    }
	    catch (java.lang.Exception ex) {
	        // print description of the exception
	        System.out.println("** Error on data select **");
	        ex.printStackTrace();
	    }
	}
	
	void ChangeNowToRid(String name) {
	    try {
	        String qs = "Select [Qid#],[Rid#] from tblReply where Rdate = #"+name+"#";
	        Statement stmt = con.createStatement();
	        ResultSet rs = stmt.executeQuery(qs);
	        boolean more = rs.next(),foundTrueRid = false;
            symantec.itools.awt.TreeNode previousNode = null;
            String QtId = null;
            previousNode = now.getParent();
            Rid = "";   // clear Rid
	        while ((more) & (!foundTrueRid)) 
	        {	            	
	            QtId = rs.getString(1);
	            Rid = rs.getString(2);
	            ChangeNowToQid(previousNode.getText());
	            if (QtId.equals(Qid)) {
	                foundTrueRid = true;
	            }
	            more = rs.next();	         
	        }
	        rs.close();
	        stmt.close();
	        System.out.println("Change selected reply node to be Rid# "+Rid);
	    }
	    catch (java.lang.Exception ex) {
	        // print description of the exception
	        System.out.println("** Error on data select **");
	        ex.printStackTrace();
	    }
	}
	
	void ChangeNowToFrid(String name) {
	    try {
	        String qs = "Select [Frid#],[Id#] from tblForum where Frheader = '"+name+"'";
	        Statement stmt = con.createStatement();
	        ResultSet rs = stmt.executeQuery(qs);
	        boolean more = rs.next(),foundTrueFrid = false;
            symantec.itools.awt.TreeNode previousNode,nowNode = null;
            nowNode = now;
            previousNode = now;
            Frid = "";          // clear Frid
	        while ((more) & (!foundTrueFrid)) 
	        {	            	            
	            Frid = rs.getString(1);
	            while (previousNode != root) 
	            {
	                try {
	                    nowNode = previousNode;
	                    previousNode = nowNode.getParent();
	                }
	                catch (Exception e) {
	                    e.printStackTrace();
	                }
	            }
	            ChangeNameToId(nowNode.getText());
	            if (id.equals(rs.getString(2))) {
	                foundTrueFrid = true;
	            }
	            more = rs.next();	         
	        }
	        rs.close();
	        stmt.close();
	        System.out.println("Change selected forum node to be Frid# "+Frid);
	    }
	    catch (java.lang.Exception ex) {
	        // print description of the exception
	        System.out.println("** Error on data select **");
	        ex.printStackTrace();
	    }
	}
	
//============================================================
//                          Others
//============================================================	    
    public void DoSubforum()
    {
        String substate = "Ready";
        // make subforum node
        Frheader = forumNode.getText();
        System.out.println("father:"+fatherfr.getText()+" Frheader:"+Frheader);
        while (substate.equals("Ready"))
        {
            ChangeForumToId();
            if (Frid.equals(""))
            {
                System.out.println("Not have this furum of indentify owner.");
            }
            else {
                MakeSubForumNode();
            try {                
                forumNode = forumNode.getSibling(); // next forum
                Frheader = forumNode.getText();
                }
            catch (Exception e)
            {
                substate = "NosubForum";
                System.out.println(substate);
                e.printStackTrace();
            }
            }
        }       
    }
    
    public void exit()
    {
        try {
            con.close();
        }
        catch (java.lang.Exception ex) {
	        // print description of the exception
	        System.out.println("** Error on data select **");
	        ex.printStackTrace();
	    }
    }
    
    public void start()
    {
		{
			Container theFrame = this;
			do {
				theFrame = theFrame.getParent();
			} while ((theFrame != null) && !(theFrame instanceof Frame));
			if (theFrame == null)
				theFrame = new Frame();
			(new Security((Frame)theFrame, true)).show();
		}
		if (mode.equals("guest")) {
		    // disable all update data button
		    UpdateButton.disable();
		    InsertButton.disable();
		    DelButton.disable();
		}
		else if (mode.equals("Lecturer"))
		{
		}		
        MakeNameNode();
        String state = "Ready",frstate = "Ready";        
        try {
        father = root.getChild();
        fathername = father.getText();
        }
        catch (Exception e)
        {
            state = "rootNoChild";
            System.out.println(state);
            e.printStackTrace();
        }
        while (state.equals("Ready"))
        {   
            // make forum node by pass fater node to do
            ChangeNameToId(fathername);
            MakeForumNode();
            // make subforum node
            {
                fatherfr = father;
                try {
                    forumNode = fatherfr.getChild(); // forum node
                    now = forumNode;    // save initial forum of this Lecturer Name
                    ChangeNameToId(fatherfr.getText()); // Return Id of owner in id                    
                    DoSubforum();
                }
                catch (Exception e)
                {
                    state = "Noforum";
                    System.out.println(state);
                    e.printStackTrace();
                }
                //DoSubforum();                                
            }
            //--------------------
            // get next lecturer name node (father)
            try {
                father = father.getSibling();
                fathername = father.getText();
            }
            catch (Exception e)
            {
                state = "NoSiblingNode";
                System.out.println(state);
                e.printStackTrace();
            }
        }
        MakeNoForumQuestion();
    }
    
    void MakeNoForumQuestion()
    {
        String state = "Ready";
        subid = "0";
        frlevel = 1;
        try {
        child = root.getChild();
        fathername = child.getText();
        }
        catch (Exception e)
        {
            state = "rootNoChild";
            System.out.println(state);
            e.printStackTrace();
        }
        while (state.equals("Ready"))
        {   
            // make Question node by pass fater node to do
            ChangeNameToId(fathername);
            MakeQuestionNode();            
            // get next lecturer name node (child)
            try {
                child = child.getSibling();
                fathername = child.getText();
            }
            catch (Exception e)
            {
                state = "NoSiblingNode";
                System.out.println(state);
                e.printStackTrace();
            }
        }
    }
    
//============================================================
//                     Init & Action Event
//============================================================    
	public void init()
	{
		// Take out this line if you don't use symantec.itools.net.RelativeURL or symantec.itools.awt.util.StatusScroller
		symantec.itools.lang.Context.setApplet(this);
	
		// This code is automatically generated by Visual Cafe when you add
		// components to the visual environment. It instantiates and initializes
		// the components. To modify the code, only use code syntax that matches
		// what Visual Cafe can generate, or Visual Cafe may be unable to back
		// parse your Java file into its visual environment.
		//{{INIT_CONTROLS
		/*
		Qicon = getImage(getCodeBase(),"Question.jpg");
		OQicon = getImage(getCodeBase(),"Q1.jpg");
		Bicon = getImage(getCodeBase(),"book.jpg");
		OBicon = getImage(getCodeBase(),"obook.jpg");
		Ricon = getImage(getCodeBase(),"reply.jpg");
		face1 = getImage(getCodeBase(),"face1.jpg");
		face2 = getImage(getCodeBase(),"face2.jpg");
		*/
		try
		{
		Qicon = getImage(new java.net.URL("http://161.246.6.91/DC3/Question.jpg"));
		OQicon = getImage(new java.net.URL("http://161.246.6.91/DC3/Q1.jpg"));
		Bicon = getImage(new java.net.URL("http://161.246.6.91/DC3/book.jpg"));
		OBicon = getImage(new java.net.URL("http://161.246.6.91/DC3/obook.jpg"));
		Ricon = getImage(new java.net.URL("http://161.246.6.91/DC3/reply.jpg"));
		face1 = getImage(new java.net.URL("http://161.246.6.91/DC3/face1.jpg"));
		face2 = getImage(new java.net.URL("http://161.246.6.91/DC3/face2.jpg"));
		}
		catch (java.net.MalformedURLException es)
		{
		System.out.println("Error loading images..");
		}
		
		setLayout(null);
		setSize(421,514);
		root = new symantec.itools.awt.TreeNode("Lecturer");
		treeView1 = new symantec.itools.awt.TreeView(root);
		treeView1.setLayout(null);
		treeView1.setBounds(12,48,400,408);
		treeView1.setBackground(new Color(16777215));
		add(treeView1);
		label1 = new java.awt.Label("Lecturer Discussion",Label.CENTER);
		label1.setBounds(84,12,252,31);
		label1.setFont(new Font("Dialog", Font.BOLD, 24));
		add(label1);
		UpdateButton = new java.awt.Button();
		UpdateButton.setActionCommand("button");
		UpdateButton.setLabel("Update");
		UpdateButton.setBounds(72,468,60,24);
		UpdateButton.setFont(new Font("Dialog", Font.BOLD, 12));
		UpdateButton.setBackground(new Color(12632256));
		add(UpdateButton);
		InsertButton = new java.awt.Button();
		InsertButton.setActionCommand("button");
		InsertButton.setLabel("Insert");
		InsertButton.setBounds(144,468,60,24);
		InsertButton.setFont(new Font("Dialog", Font.BOLD, 12));
		InsertButton.setBackground(new Color(12632256));
		add(InsertButton);
		DelButton = new java.awt.Button();
		DelButton.setActionCommand("button");
		DelButton.setLabel("Delete");
		DelButton.setBounds(216,468,60,24);
		DelButton.setFont(new Font("Dialog", Font.BOLD, 12));
		DelButton.setBackground(new Color(12632256));
		add(DelButton);
		DetailButton = new java.awt.Button();
		DetailButton.setActionCommand("button");
		DetailButton.setLabel("Details");
		DetailButton.setBounds(288,468,60,24);
		DetailButton.setFont(new Font("Dialog", Font.BOLD, 12));
		DetailButton.setBackground(new Color(12632256));
		add(DetailButton);
		//}}
	
		//{{REGISTER_LISTENERS
		SymAction lSymAction = new SymAction();
		DetailButton.addActionListener(lSymAction);
		treeView1.addActionListener(lSymAction);
		DelButton.addActionListener(lSymAction);
		InsertButton.addActionListener(lSymAction);
		SymFocus aSymFocus = new SymFocus();
		this.addFocusListener(aSymFocus);
		UpdateButton.addActionListener(lSymAction);
		SymItem lSymItem = new SymItem();
		treeView1.addItemListener(lSymItem);
		SymContainer aSymContainer = new SymContainer();
		treeView1.addContainerListener(aSymContainer);
		SymMouse aSymMouse = new SymMouse();
		treeView1.addMouseListener(aSymMouse);
		//}}
	}
	
	//{{DECLARE_CONTROLS
	public static symantec.itools.awt.TreeView treeView1;
	java.awt.Label label1;
	java.awt.Button UpdateButton;
	java.awt.Button InsertButton;
	java.awt.Button DelButton;
	java.awt.Button DetailButton;
	//}}

	class SymAction implements java.awt.event.ActionListener
	{
		public void actionPerformed(java.awt.event.ActionEvent event)
		{
			Object object = event.getSource();
			if (object == DetailButton)
				DetailButton_Action(event);
			else if (object == treeView1)
				treeView1_actionPerformed(event);
			else if (object == DelButton)
				DelButton_Action(event);
			else if (object == InsertButton)
				InsertButton_Action(event);
			else if (object == UpdateButton)
				UpdateButton_Action(event);
		}
	}

	void DetailButton_Action(java.awt.event.ActionEvent event)
	{
		now = treeView1.getSelectedNode();
		SelectedImage = now.getImage();
		if ((SelectedImage.equals(Qicon))|(SelectedImage.equals(OQicon)))
		{
		    ChangeNowToQid(now.getText());   // return Qid of selected node in Qid
		    {
			    Container theFrame = this;
			    do {
				    theFrame = theFrame.getParent();
			    } while ((theFrame != null) && !(theFrame instanceof Frame));
			    if (theFrame == null)
				    theFrame = new Frame();
			    (new Qdetails((Frame)theFrame, true)).show();
		    }		
	    }
	    else if ((SelectedImage.equals(Bicon))|(SelectedImage.equals(OBicon))) {
	        ChangeNowToFrid(now.getText());
            {
			    Container theFrame = this;
		    	do {
			    	theFrame = theFrame.getParent();
    			} while ((theFrame != null) && !(theFrame instanceof Frame));
	    		if (theFrame == null)
		    		theFrame = new Frame();
			    (new Frdetails((Frame)theFrame, true)).show();
		    }
	    }
	    else if (SelectedImage.equals(Ricon)) {
	        symantec.itools.awt.TreeNode pre = now.getParent();
	        ChangeNowToQid(pre.getText());
            {
			    Container theFrame = this;
		    	do {
			    	theFrame = theFrame.getParent();
    			} while ((theFrame != null) && !(theFrame instanceof Frame));
	    		if (theFrame == null)
		    		theFrame = new Frame();
			    (new Qdetails((Frame)theFrame, true)).show();
		    }
	    }
	    else {
	        // selected node not be question node
		    System.out.println("Not be Question,Reply,Forum Node");
	    }
	}

	void treeView1_actionPerformed(java.awt.event.ActionEvent event)
	{		    
		String command = event.getActionCommand();
		System.out.println(command);
		symantec.itools.awt.TreeNode Qt = null;
		now = treeView1.getSelectedNode();
		if (now.isExpandable()) {
		    System.out.println("Selected node is not leaf node");
		}
		else {
		    // selected node not expandable
		    try {
                Qt = now.getParent();
		    }
		    catch (Exception e) {
		        System.out.println("Root");
		    }
		    SelectedImage = now.getImage();
		    if (SelectedImage.equals(Qicon)) {
		        ChangeNowToQid(now.getText());   // return Qid of selected node in Qid
		    {
			    Container theFrame = this;
			    do {
				    theFrame = theFrame.getParent();
			    } while ((theFrame != null) && !(theFrame instanceof Frame));
			    if (theFrame == null)
				    theFrame = new Frame();
			    (new Qdetails((Frame)theFrame, true)).show();
		    }
		    }
		    else if (SelectedImage.equals(Ricon)) {
		        ChangeNowToQid(Qt.getText());   // return Qid of selected node in Qid
		    {
			    Container theFrame = this;
			    do {
				    theFrame = theFrame.getParent();
			    } while ((theFrame != null) && !(theFrame instanceof Frame));
			    if (theFrame == null)
				    theFrame = new Frame();
			    (new Qdetails((Frame)theFrame, true)).show();
		    }		
		    }
		    else {
		        // selected node not be question node
		        System.out.println("Not be Question or Reply Node");
		    }
		}
		treeView1.redraw();
	}

	void DelButton_Action(java.awt.event.ActionEvent event)
	{
	    symantec.itools.awt.TreeNode PreNode,NowNode,NextNode = null;
        SelectedNodeBe = "none";
        SelectedNodeLink = "none";
        haveChild = true;
        try {
            now = treeView1.getSelectedNode();
            PreNode = now.getParent();
            if (PreNode.equals(root)) {
               // Selected node parent is root ---> lname node
               WarningText = "You can't delete owner name node!";
        	   {
			        Container theFrame = this;
			        do {
				        theFrame = theFrame.getParent();
			        } while ((theFrame != null) && !(theFrame instanceof Frame));
			        if (theFrame == null)
				        theFrame = new Frame();
			        (new Warning((Frame)theFrame, true)).show();
		       }
               System.out.println("Can not delete name node.");
            }
            else {
                // Selected Node father isn't root
                NowNode = now;
                while (PreNode != root) 
	            {
	                try {
	                    NowNode = PreNode;
	                    PreNode = NowNode.getParent();
	                }
	                catch (Exception e) {
	                    e.printStackTrace();
	                }
	            }
	            ChangeNameToId(NowNode.getText()); //get Id# of Owner
	            if (id.equals(user)) {
	                SelectedImage = now.getImage();
	                if ((SelectedImage.equals(Bicon))|(SelectedImage.equals(OBicon))) {
	                    System.out.println("forum node");
	                    ChangeNowToFrid(now.getText()); // return Frid of selected node in Frid
                        SelectedNodeBe = "forum";                        
                        FatherImage = now.getParent().getImage();                        
                        if ((FatherImage.equals(face1))|(FatherImage.equals(face1))) {                            
                            SelectedNodeLink = "lname";
                        }
                        else if ((FatherImage.equals(Bicon))|(FatherImage.equals(OBicon))) {
                            SelectedNodeLink = "forum";
                        }
                        try {
                            NextNode = now.getChild();
                            // selected node have child
                            haveChild = true;
                            WarningText = "Delete all of forum";
                            About = "'"+now.getText()+"'?";
                        }
                        catch (Exception e) {
                            // selected node have no child
                            haveChild = false;
                            WarningText = "Delete forum";
                            About = "'"+now.getText()+"'?";
                        }
	                }
	                else if ((SelectedImage.equals(Qicon))|(SelectedImage.equals(OQicon))) {
                        System.out.println("question node");
                        ChangeNowToQid(now.getText());   // return Qid of selected node in Qid
                        SelectedNodeBe = "question";
                        WarningText = "Delete question";
                        About = "'"+now.getText()+"'?";
	                }
	                else if (SelectedImage.equals(Ricon)) {
	                    System.out.println("reply node");
	                    String ReplyText = now.getText();
	                    String Rdate = ReplyText.substring(1,20);
	                    System.out.println("Rdate:"+Rdate);
                        ChangeNowToRid(Rdate);   // return Rid of selected node in Rid
                        SelectedNodeBe = "reply";
                        WarningText = "Delete reply";
                        About = "'"+now.getText()+"'?";
	                }
	                {
			            Container theFrame = this;
			            do {
				            theFrame = theFrame.getParent();
			            } while ((theFrame != null) && !(theFrame instanceof Frame));
			            if (theFrame == null)
				            theFrame = new Frame();
			            (new DelWarning((Frame)theFrame, true)).show();
		            }
                } 
                else {
                    // not in your permission
                    WarningText = "You can't delete this node!";
        	        {
			            Container theFrame = this;
			            do {
				            theFrame = theFrame.getParent();
			            } while ((theFrame != null) && !(theFrame instanceof Frame));
			            if (theFrame == null)
				            theFrame = new Frame();
			            (new Warning((Frame)theFrame, true)).show();
		            }
                    System.out.println("Can not delete this node.");       
                }
            }
        }
        catch (Exception e) {
            // Selected Node no parent ---> root
            // Show Error Message
	        WarningText = "You can't delete root!";
	        {
			    Container theFrame = this;
			    do {
				    theFrame = theFrame.getParent();
			    } while ((theFrame != null) && !(theFrame instanceof Frame));
			    if (theFrame == null)
				    theFrame = new Frame();
			    (new Warning((Frame)theFrame, true)).show();
		    }
            System.out.println("Can not delete root.");
            e.printStackTrace();
        }        
	}

	void InsertButton_Action(java.awt.event.ActionEvent event)
	{
        symantec.itools.awt.TreeNode PreNode,NowNode = null;
        SelectedNodeBe = "none";
        SelectedNodeLink = "none";
        TruePath = false;
        try {
            now = treeView1.getSelectedNode();
            PreNode = now.getParent();
            if (PreNode.equals(root)) {
                // Selected node parent is root ---> lname node
                ChangeNameToId(now.getText()); //get Id# of inserted to node
                if (id.equals(user)) {    
                    // Security OK
                    TruePath = true;
                    // Selected Node is Lecturer Name Node
                    SelectedNodeBe = "lname";
                    SelectedNodeLink = "root";
                    SelectedNodeText = now.getText();
                    System.out.println("Selected Node is Lecturer Name Node.");
                }
                else {
                    // can't insert ot other lname
                    // not truepath to insert
                    WarningText = "You can't insert to this node!";
        	        {
			            Container theFrame = this;
			            do {
				            theFrame = theFrame.getParent();
			            } while ((theFrame != null) && !(theFrame instanceof Frame));
			            if (theFrame == null)
				            theFrame = new Frame();
			            (new Warning((Frame)theFrame, true)).show();
		            }
                    System.out.println("Can not insert to this node.");
                }
            }
            else {
                // Selected node parent is not root
                NowNode = now;
                while (PreNode != root) 
	            {
	                try {
	                    NowNode = PreNode;
	                    PreNode = NowNode.getParent();
	                }
	                catch (Exception e) {
	                    e.printStackTrace();
	                }
	            }
	            ChangeNameToId(NowNode.getText()); //get Id# of Owner
	            if (id.equals(user)) {
	                TruePath = true;
	                SelectedImage = now.getImage();
	                if ((SelectedImage.equals(Bicon))|(SelectedImage.equals(OBicon))) {
	                    System.out.println("forum node");
	                    ChangeNowToFrid(now.getText()); // return Frid of selected node in Frid
                        SelectedNodeBe = "forum";                        
                        SelectedNodeText = now.getText();
	                }
	                else if ((SelectedImage.equals(Qicon))|(SelectedImage.equals(OQicon))) {
                        System.out.println("question node");
                        ChangeNowToQid(now.getText());   // return Qid of selected node in Qid
                        SelectedNodeBe = "question";
                        SelectedNodeText = now.getText();
                    }
                    else if (SelectedImage.equals(Ricon)) {
                        System.out.println("reply node");
                        SelectedNodeBe = "reply";
                    }
                    if (SelectedNodeBe.equals("reply")) {
                        // not do anything
	                }
	                else {
	                    // find father node
	                    PreNode = now.getParent();
	                    FatherImage = PreNode.getImage();                        
                        if ((FatherImage.equals(face1))|(FatherImage.equals(face2))) {                            
                            SelectedNodeLink = "lname";
                            System.out.println("Parent is lname");
                        }
                        else if ((FatherImage.equals(Bicon))|(FatherImage.equals(OBicon))) {
                            SelectedNodeLink = "forum";
                            System.out.println("Parent is forum");
                            String temp = Frid;
                            ChangeNowToFrid((now.getParent()).getText()); // parent frid in Frid
                            ParentFrid = Frid;  // Parent Frid is in ParentFrid
                            Frid = temp;        // return old value of Frid
                        }
                        else {
                            System.out.println("FatherImage not match any case.");
                        }
                    }
                }
                else {
                    // not truepath to insert
                    WarningText = "You can't insert to this node!";
        	        {
			            Container theFrame = this;
			            do {
				            theFrame = theFrame.getParent();
			            } while ((theFrame != null) && !(theFrame instanceof Frame));
			            if (theFrame == null)
				            theFrame = new Frame();
			            (new Warning((Frame)theFrame, true)).show();
		            }
                    System.out.println("Can not insert to this node.");       
                }
            }
        }
        catch (Exception e) {
            // Selected Node no parent ---> root
            // Show Error Message
	        WarningText = "You can't insert to root!";
	        {
			    Container theFrame = this;
			    do {
				    theFrame = theFrame.getParent();
			    } while ((theFrame != null) && !(theFrame instanceof Frame));
			    if (theFrame == null)
				    theFrame = new Frame();
			    (new Warning((Frame)theFrame, true)).show();
		    }
            System.out.println("Can not insert to root.");
            e.printStackTrace();
        }        
        if (TruePath) {
            System.out.println(SelectedNodeBe+" node");
		    //{{CONNECTION
		    // Create and show as modal
		    {
			    Container theFrame = this;
			    do {
				    theFrame = theFrame.getParent();
			    } while ((theFrame != null) && !(theFrame instanceof Frame));
			    if (theFrame == null)
				theFrame = new Frame();
			    (new InsertForm((Frame)theFrame, true)).show();
		    }
		    //}}
		}
	}

	class SymFocus extends java.awt.event.FocusAdapter
	{
		public void focusGained(java.awt.event.FocusEvent event)
		{
			Object object = event.getSource();
			if (object == frmMain.this)
				frmMain_GotFocus(event);
		}
	}

	void frmMain_GotFocus(java.awt.event.FocusEvent event)
	{
	    System.out.println("frmMain GotFocus");	    
	}

	void UpdateButton_Action(java.awt.event.ActionEvent event)
	{
	    symantec.itools.awt.TreeNode PreNode,NowNode,NextNode = null;
        SelectedNodeBe = "none";
        haveChild = true;
        try {
            now = treeView1.getSelectedNode();
            PreNode = now.getParent();
            if (PreNode.equals(root)) {
               // Selected node parent is root ---> lname node
               WarningText = "You can't update owner name node!";
        	   {
			        Container theFrame = this;
			        do {
				        theFrame = theFrame.getParent();
			        } while ((theFrame != null) && !(theFrame instanceof Frame));
			        if (theFrame == null)
				        theFrame = new Frame();
			        (new Warning((Frame)theFrame, true)).show();
		       }
               System.out.println("Can not update name node.");
            }
            else {
                // Selected Node father isn't root
                NowNode = now;
                while (PreNode != root) 
	            {
	                try {
	                    NowNode = PreNode;
	                    PreNode = NowNode.getParent();
	                }
	                catch (Exception e) {
	                    e.printStackTrace();
	                }
	            }
	            ChangeNameToId(NowNode.getText()); //get Id# of Owner
	            if (id.equals(user)) {
	                SelectedImage = now.getImage();
	                if ((SelectedImage.equals(Bicon))|(SelectedImage.equals(OBicon))) {
	                    System.out.println("forum node");
	                    ChangeNowToFrid(now.getText()); // return Frid of selected node in Frid
                        {
			                Container theFrame = this;
                			do {
		                		theFrame = theFrame.getParent();
                			} while ((theFrame != null) && !(theFrame instanceof Frame));
                			if (theFrame == null)
				                theFrame = new Frame();
                			(new UpdateForum((Frame)theFrame, true)).show();
		                }
	                }
	                else if ((SelectedImage.equals(Qicon))|(SelectedImage.equals(OQicon))) {
                        System.out.println("question node");
                        ChangeNowToQid(now.getText());   // return Qid of selected node in Qid
                        {
		                	Container theFrame = this;
                			do {
				                theFrame = theFrame.getParent();
                			} while ((theFrame != null) && !(theFrame instanceof Frame));
                			if (theFrame == null)
				                theFrame = new Frame();
                			(new UpdateQuestion((Frame)theFrame, true)).show();
		                }
	                }
                } 
                else {
                    // not in your permission
                    WarningText = "You can't update this node!";
        	        {
			            Container theFrame = this;
			            do {
				            theFrame = theFrame.getParent();
			            } while ((theFrame != null) && !(theFrame instanceof Frame));
			            if (theFrame == null)
				            theFrame = new Frame();
			            (new Warning((Frame)theFrame, true)).show();
		            }
                    System.out.println("Can not update this node.");       
                }
            }
        }
        catch (Exception e) {
            // Selected Node no parent ---> root
            // Show Error Message
	        WarningText = "You can't update root!";
	        {
			    Container theFrame = this;
			    do {
				    theFrame = theFrame.getParent();
			    } while ((theFrame != null) && !(theFrame instanceof Frame));
			    if (theFrame == null)
				    theFrame = new Frame();
			    (new Warning((Frame)theFrame, true)).show();
		    }
            System.out.println("Can not update root.");
            e.printStackTrace();
        }        
	}

	class SymItem implements java.awt.event.ItemListener
	{
		public void itemStateChanged(java.awt.event.ItemEvent event)
		{
			Object object = event.getSource();
			if (object == treeView1)
				treeView1_itemStateChanged(event);
		}
	}

	void treeView1_itemStateChanged(java.awt.event.ItemEvent event)
	{
	    treeView1.redraw();
	}

	class SymContainer extends java.awt.event.ContainerAdapter
	{
		public void componentAdded(java.awt.event.ContainerEvent event)
		{
			Object object = event.getSource();
			if (object == treeView1)
				treeView1_componentAdded(event);
		}
	}

	void treeView1_componentAdded(java.awt.event.ContainerEvent event)
    {
	}

	class SymMouse extends java.awt.event.MouseAdapter
	{
		public void mouseClicked(java.awt.event.MouseEvent event)
		{
			Object object = event.getSource();
			if (object == treeView1)
				treeView1_mouseClicked(event);
		}
	}

	void treeView1_mouseClicked(java.awt.event.MouseEvent event)
	{
	    treeView1.redraw();
	}
}
